"""
Helper functions for Sales Return widget.
Contains utility methods for data handling and UI operations.
Column map for 15-col table:
  0=SL, 1=SalesRate, 2=Product, 3=HSN, 4=CGST%, 5=SGST%, 6=IGST%, 7=CESS%,
  8=Rate, 9=Qty, 10=Gross, 11=Disc, 12=Net, 13=Tax, 14=Total
"""

from typing import Dict, Any, List, Optional
from PySide6.QtWidgets import QTableWidgetItem
from PySide6.QtCore import Qt, QDate


class SalesReturnHelpersMixin:
    """Mixin class containing helper methods for Sales Return."""

    # Column indices
    COL_SL = 0
    COL_SALES_RATE = 1
    COL_PRODUCT = 2
    COL_HSN = 3
    COL_CGST = 4
    COL_SGST = 5
    COL_IGST = 6
    COL_CESS = 7
    COL_RATE = 8
    COL_QTY = 9
    COL_GROSS = 10
    COL_DISC = 11
    COL_NET = 12
    COL_TAX = 13
    COL_TOTAL = 14

    def format_currency(self, amount) -> str:
        try:
            return f"₹{float(amount):.2f}"
        except (TypeError, ValueError):
            return "₹0.00"

    def format_num(self, amount) -> str:
        try:
            return f"{float(amount):.2f}"
        except (TypeError, ValueError):
            return "0.00"

    def get_current_company_id(self) -> Optional[int]:
        if hasattr(self, 'company_id') and self.company_id:
            return self.company_id
        from config import active_company_manager
        active = active_company_manager.get_active_company()
        if active:
            self.company_id = active['id']
            return self.company_id
        return None

    def get_next_return_no(self) -> str:
        company_id = self.get_current_company_id()
        if company_id:
            return self.sales_return_logic.get_next_return_no(company_id)
        return "1"

    def populate_party_details(self, party_data: Dict[str, Any]):
        self.customer_name_input.blockSignals(True)
        self.customer_name_input.setText(party_data.get('name', ''))
        self.customer_name_input.blockSignals(False)
        self.address_input.setText(party_data.get('address', ''))
        self.mobile_input.setText(str(party_data.get('mobile_number', '') or ''))
        self.gstin_input.setText(str(party_data.get('gstin', '') or ''))
        state_val = str(party_data.get('state', '') or '')
        idx = self.state_combo.findText(state_val)
        if idx >= 0:
            self.state_combo.setCurrentIndex(idx)
        else:
            self.state_combo.setEditText(state_val)

    def clear_party_fields(self):
        self.current_party_id = None
        self.customer_name_input.blockSignals(True)
        self.customer_name_input.clear()
        self.customer_name_input.blockSignals(False)
        self.address_input.clear()
        self.mobile_input.clear()
        self.gstin_input.clear()
        self.state_combo.setCurrentIndex(0)

    def clear_product_fields(self):
        self.current_product_id = None
        self.current_product_data = {}
        self.barcode_input.clear()
        self.product_input.clear()
        self.stock_display.setText("")
        self.code_display.setText("")

    def clear_form(self):
        self.items_table.blockSignals(True)
        self.return_no_input.clear()
        self.return_no_input.setPlaceholderText("Auto")
        self.date_input.setDate(QDate.currentDate())
        self.return_type_combo.setCurrentIndex(0)
        self.nature_combo.setCurrentIndex(0)
        self.series_input.clear()
        self.original_bill_input.clear()
        self.narration_input.clear()
        self.clear_party_fields()
        self.clear_product_fields()
        self.items_table.setRowCount(0)
        self.items_table.blockSignals(False)
        self.current_return_id = None
        self.selected_sl_row = -1
        self._reset_footer_displays()
        next_no = self.get_next_return_no()
        self.return_no_input.setPlaceholderText(f"Auto ({next_no})")

    def _reset_footer_displays(self):
        self.grand_total_input.setText("")
        self.round_off_input.setText("0.00")
        self.net_amount_display.setText("0.00")
        self.amount_refunded_input.setText("0.00")
        self.balance_display.setText("0.00")
        self.net_value_display.setText("0.00")
        self.cgst_display.setText("0.00")
        self.sgst_display.setText("0.00")
        self.igst_display.setText("0.00")
        self.tax_amount_display.setText("0.00")
        self.cess_display.setText("0.00")
        self.final_amount_display.setText("₹ 0.00")
        self.grand_total_display.setText("")
        self.round_off_display.setText("0.00")

    def _safe_float(self, cell) -> float:
        if cell is None:
            return 0.0
        try:
            return float(cell.text().replace(',', '').replace('₹', '').strip() or '0')
        except (ValueError, AttributeError):
            return 0.0

    def _safe_pct(self, cell) -> float:
        if cell is None:
            return 0.0
        try:
            return float(cell.text().replace('%', '').strip() or '0')
        except (ValueError, AttributeError):
            return 0.0

    def get_form_data(self) -> Dict[str, Any]:
        company_id = self.get_current_company_id()
        return_no = self.return_no_input.text().strip() or self.get_next_return_no()

        try:
            amount_refunded = float(self.amount_refunded_input.text() or '0')
        except ValueError:
            amount_refunded = 0.0
        try:
            round_off = float(self.round_off_input.text() or '0')
        except ValueError:
            round_off = 0.0

        items = self.get_items_data()
        summary = self.calculate_summary_totals(items)
        final_amount = round(summary['rounded_total'] + round_off, 2)
        balance = round(final_amount - amount_refunded, 2)

        return {
            'company_id': company_id,
            'return_no': return_no,
            'return_date': self.date_input.date().toString('yyyy-MM-dd'),
            'original_bill_id': None,
            'original_bill_no': self.original_bill_input.text().strip(),
            'party_id': getattr(self, 'current_party_id', None),
            'return_type': self.return_type_combo.currentText(),
            'nature': self.nature_combo.currentText(),
            'narration': self.narration_input.text().strip(),
            'sub_total': summary['sub_total'],
            'discount_total': summary['discount_total'],
            'tax_total': summary['tax_total'],
            'round_off': round_off,
            'grand_total': final_amount,
            'amount_refunded_or_adjusted': amount_refunded,
            'balance_adjustment': balance,
            'items': items
        }

    def get_items_data(self) -> List[Dict[str, Any]]:
        items = []
        for row in range(self.items_table.rowCount()):
            product_cell = self.items_table.item(row, self.COL_PRODUCT)
            if not product_cell or not product_cell.text().strip():
                continue
            product_id = product_cell.data(Qt.UserRole)
            qty = self._safe_float(self.items_table.item(row, self.COL_QTY))
            if not product_id or qty <= 0:
                continue

            # Get tax percentages
            cgst_pct = self._safe_pct(self.items_table.item(row, self.COL_CGST))
            sgst_pct = self._safe_pct(self.items_table.item(row, self.COL_SGST))
            igst_pct = self._safe_pct(self.items_table.item(row, self.COL_IGST))
            cess_pct = self._safe_pct(self.items_table.item(row, self.COL_CESS))

            # Get net value to calculate tax amounts
            net_value = self._safe_float(self.items_table.item(row, self.COL_NET))

            # Determine GST nature
            nature_str = "Local"
            if hasattr(self, 'nature_combo'):
                nature_str = self.nature_combo.currentText()
            is_inter_state = 'inter' in nature_str.lower()

            # Calculate GST split amounts based on nature
            if is_inter_state:
                # Inter-state: IGST + CESS only
                cgst_amt = 0.0
                sgst_amt = 0.0
                igst_amt = net_value * (igst_pct / 100.0)
                cess_amt = net_value * (cess_pct / 100.0)
            else:
                # Local: CGST + SGST + CESS
                cgst_amt = net_value * (cgst_pct / 100.0)
                sgst_amt = net_value * (sgst_pct / 100.0)
                igst_amt = 0.0
                cess_amt = net_value * (cess_pct / 100.0)

            item = {
                'product_id': product_id,
                'product_name': product_cell.text(),
                'sl_no': row + 1,
                'hsn': self.items_table.item(row, self.COL_HSN).text() if self.items_table.item(row, self.COL_HSN) else '',
                'cgst': cgst_pct,
                'sgst': sgst_pct,
                'igst': igst_pct,
                'cess': cess_pct,
                'tax_percent': (cgst_pct + sgst_pct + igst_pct + cess_pct),
                'rate': self._safe_float(self.items_table.item(row, self.COL_RATE)),
                'quantity': qty,
                'gross_value': self._safe_float(self.items_table.item(row, self.COL_GROSS)),
                'discount': self._safe_float(self.items_table.item(row, self.COL_DISC)),
                'net_value': net_value,
                'cgst_amt': cgst_amt,
                'sgst_amt': sgst_amt,
                'igst_amt': igst_amt,
                'cess_amt': cess_amt,
                'tax_amount': self._safe_float(self.items_table.item(row, self.COL_TAX)),
                'grand_total': self._safe_float(self.items_table.item(row, self.COL_TOTAL))
            }
            items.append(item)
        return items

    def add_item_to_table(self, item: Dict[str, Any], sl_no: int):
        self.items_table.blockSignals(True)
        row = self.items_table.rowCount()
        self.items_table.insertRow(row)

        sl_item = QTableWidgetItem(str(sl_no))
        sl_item.setFlags(sl_item.flags() & ~Qt.ItemIsEditable)
        sl_item.setTextAlignment(Qt.AlignCenter)
        self.items_table.setItem(row, self.COL_SL, sl_item)

        sales_rate_item = QTableWidgetItem(self.format_num(item.get('rate', 0.0)))
        sales_rate_item.setFlags(sales_rate_item.flags() & ~Qt.ItemIsEditable)
        sales_rate_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_SALES_RATE, sales_rate_item)

        prod_item = QTableWidgetItem(item.get('product_name', ''))
        prod_item.setData(Qt.UserRole, item.get('product_id'))
        prod_item.setFlags(prod_item.flags() & ~Qt.ItemIsEditable)
        self.items_table.setItem(row, self.COL_PRODUCT, prod_item)

        hsn_item = QTableWidgetItem(str(item.get('hsn', '')))
        hsn_item.setFlags(hsn_item.flags() & ~Qt.ItemIsEditable)
        self.items_table.setItem(row, self.COL_HSN, hsn_item)

        cgst_item = QTableWidgetItem(f"{item.get('cgst', 0.0):.2f}%")
        cgst_item.setFlags(cgst_item.flags() & ~Qt.ItemIsEditable)
        cgst_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_CGST, cgst_item)

        sgst_item = QTableWidgetItem(f"{item.get('sgst', 0.0):.2f}%")
        sgst_item.setFlags(sgst_item.flags() & ~Qt.ItemIsEditable)
        sgst_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_SGST, sgst_item)

        igst_item = QTableWidgetItem(f"{item.get('igst', 0.0):.2f}%")
        igst_item.setFlags(igst_item.flags() & ~Qt.ItemIsEditable)
        igst_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_IGST, igst_item)

        cess_item = QTableWidgetItem(f"{item.get('cess', 0.0):.2f}%")
        cess_item.setFlags(cess_item.flags() & ~Qt.ItemIsEditable)
        cess_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_CESS, cess_item)

        rate_item = QTableWidgetItem(self.format_num(item.get('rate', 0.0)))
        rate_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_RATE, rate_item)

        qty_item = QTableWidgetItem(self.format_num(item.get('quantity', 0.0)))
        qty_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_QTY, qty_item)

        gross_item = QTableWidgetItem(self.format_num(item.get('gross_value', 0.0)))
        gross_item.setFlags(gross_item.flags() & ~Qt.ItemIsEditable)
        gross_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_GROSS, gross_item)

        disc_item = QTableWidgetItem(self.format_num(item.get('discount', 0.0)))
        disc_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_DISC, disc_item)

        net_item = QTableWidgetItem(self.format_num(item.get('net_value', 0.0)))
        net_item.setFlags(net_item.flags() & ~Qt.ItemIsEditable)
        net_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_NET, net_item)

        tax_item = QTableWidgetItem(self.format_num(item.get('tax_amount', 0.0)))
        tax_item.setFlags(tax_item.flags() & ~Qt.ItemIsEditable)
        tax_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_TAX, tax_item)

        total_item = QTableWidgetItem(self.format_num(item.get('grand_total', 0.0)))
        total_item.setFlags(total_item.flags() & ~Qt.ItemIsEditable)
        total_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.items_table.setItem(row, self.COL_TOTAL, total_item)

        self.items_table.blockSignals(False)

    def load_return_data(self, return_data: Dict[str, Any]):
        self.current_return_id = return_data['id']
        self.return_no_input.setText(return_data.get('return_no', ''))
        date_str = return_data.get('return_date', '')
        if date_str:
            parsed = QDate.fromString(date_str, 'yyyy-MM-dd')
            if parsed.isValid():
                self.date_input.setDate(parsed)
        self.return_type_combo.setCurrentText(return_data.get('return_type', 'Cash'))
        self.nature_combo.setCurrentText(return_data.get('nature', 'Local'))
        self.original_bill_input.setText(return_data.get('original_bill_no', '') or '')
        self.narration_input.setText(return_data.get('narration', '') or '')

        if return_data.get('party_id'):
            self.current_party_id = return_data['party_id']
            self.populate_party_details({
                'name': return_data.get('party_name', ''),
                'address': return_data.get('address', ''),
                'mobile_number': return_data.get('mobile_number', ''),
                'gstin': return_data.get('gstin', ''),
                'state': return_data.get('state', '')
            })

        self.items_table.blockSignals(True)
        self.items_table.setRowCount(0)
        items = return_data.get('items', [])
        for idx, item in enumerate(items):
            self.add_item_to_table(item, idx + 1)
        self.items_table.blockSignals(False)

        self.recalculate_summary()

        self.round_off_input.setText(self.format_num(return_data.get('round_off', 0.0)))
        # Restore the saved amount_refunded from DB, overriding what recalculate_summary set.
        # Block signals so this write doesn't recurse into _update_balance_display prematurely.
        amt_ref = return_data.get('amount_refunded_or_adjusted', 0.0)
        self.amount_refunded_input.blockSignals(True)
        try:
            self.amount_refunded_input.setText(self.format_num(amt_ref))
        finally:
            self.amount_refunded_input.blockSignals(False)
        # Now recompute balance against the restored amount.
        if hasattr(self, '_update_balance_display'):
            self._update_balance_display()

    def update_summary_display(self, return_data: Optional[Dict[str, Any]] = None):
        self._reset_footer_displays()
