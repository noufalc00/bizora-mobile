"""
Open Company page for the Accounting Desktop Application.
Provides a dialog to select and open an existing company from the database.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QFrame, QScrollArea, QDialog, QAbstractItemView
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont

from db import Database
from config import active_company_manager
from logic.company_logic import CompanyLogic
from .view_company_dialog import ViewCompanyDialog
from .edit_company_dialog import EditCompanyDialog


class OpenCompanyPageWidget(QWidget):
    """Open Company page with company selection functionality."""
    
    company_selected = Signal(dict)
    
    def __init__(self, db=None):
        super().__init__()
        self.db = db or Database()
        self.company_logic = CompanyLogic(self.db)
        self.setup_ui()
        self.load_companies()
    
    def setup_ui(self):
        """Setup the Open Company UI."""
        self.setObjectName("OpenCompanyPageWidget")
        self.setStyleSheet("""
            QWidget#OpenCompanyPageWidget {
                background-color: #111827;
            }
        """)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #111827;
            }
        """)
        
        # Content widget
        content_widget = QWidget()
        content_widget.setStyleSheet("background-color: #111827;")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(28, 22, 28, 22)
        content_layout.setSpacing(20)
        
        # Header
        self.create_header(content_layout)
        
        # Companies table
        self.create_companies_table(content_layout)
        
        # Action buttons
        self.create_action_buttons(content_layout)
        
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
    
    def create_header(self, layout):
        """Create page header."""
        title = QLabel("Open Company")
        title.setStyleSheet("""
            QLabel {
                color: #60a5fa;
                font-size: 28px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        layout.addWidget(title, alignment=Qt.AlignLeft)
        layout.addSpacing(10)

        subtitle = QLabel("Select a company to work with")
        subtitle.setStyleSheet("""
            QLabel {
                color: #9ca3af;
                font-size: 14px;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        layout.addWidget(subtitle, alignment=Qt.AlignLeft)
        layout.addSpacing(20)
    
    def create_companies_table(self, layout):
        """Create companies selection table."""
        # Table widget
        self.companies_table = QTableWidget()
        self.companies_table.setColumnCount(6)
        
        # Headers
        headers = ["Company Name", "GSTIN", "Phone", "Email", "Status", "Actions"]
        self.companies_table.setHorizontalHeaderLabels(headers)
        
        # Table styling
        self.companies_table.setStyleSheet("""
            QTableWidget {
                background-color: #1f2937;
                color: #f3f4f6;
                border: 1px solid #374151;
                border-radius: 8px;
                gridline-color: #374151;
                selection-background-color: #3b82f6;
                selection-color: white;
                font-size: 13px;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #374151;
            }
            QTableWidget::item:selected {
                background-color: #3b82f6;
                color: white;
            }
            QHeaderView::section {
                background-color: #374151;
                color: #d1d5db;
                padding: 10px;
                border: none;
                font-weight: bold;
                font-size: 13px;
            }
            QHeaderView::section:horizontal {
                border-right: 1px solid #4b5563;
            }
        """)
        
        # Table properties
        self.companies_table.setAlternatingRowColors(False)
        self.companies_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.companies_table.setSelectionMode(QTableWidget.SingleSelection)
        self.companies_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.companies_table.verticalHeader().setVisible(False)
        self.companies_table.horizontalHeader().setStretchLastSection(True)
        
        # Column widths
        header = self.companies_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)  # Company Name
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # GSTIN
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Phone
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Email
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Status
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)  # Actions
        
        # Row height
        self.companies_table.verticalHeader().setDefaultSectionSize(40)
        
        layout.addWidget(self.companies_table)
    
    def create_action_buttons(self, layout):
        """Create action buttons."""
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 10, 0, 0)
        button_layout.setSpacing(10)
        
        # Open button
        self.open_button = QPushButton("Open Selected Company")
        self.open_button.setMinimumHeight(42)
        self.open_button.setStyleSheet("""
            QPushButton {
                background-color: #3b82f6;
                color: white;
                border: none;
                border-radius: 8px;
                font-size: 13px;
                font-weight: bold;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background-color: #2563eb;
            }
            QPushButton:disabled {
                background-color: #4b5563;
                color: #9ca3af;
            }
        """)
        self.open_button.clicked.connect(self.open_selected_company)
        self.open_button.setEnabled(False)
        button_layout.addWidget(self.open_button)
        
        # Cancel button
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setMinimumHeight(42)
        self.cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #374151;
                color: #f3f4f6;
                border: none;
                border-radius: 8px;
                font-size: 13px;
                font-weight: bold;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
        """)
        self.cancel_button.clicked.connect(self.cancel)
        button_layout.addWidget(self.cancel_button)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
    
    def load_companies(self):
        """Load companies from database into table."""
        result = self.company_logic.get_all_companies()
        
        if not result['success']:
            companies = []
        else:
            companies = result['data']
        
        if not companies:
            # Show no companies message
            self.companies_table.setRowCount(1)
            no_company_item = QTableWidgetItem("No companies found. Create a new company first.")
            no_company_item.setTextAlignment(Qt.AlignCenter)
            self.companies_table.setItem(0, 0, no_company_item)
            self.companies_table.setSpan(0, 0, 1, 5)
            self.open_button.setEnabled(False)
            return
        
        self.companies_table.setRowCount(len(companies))
        
        for row, company in enumerate(companies):
            # Company Name
            name_item = QTableWidgetItem(company['business_name'])
            name_item.setData(Qt.UserRole, company)  # Store full company data
            self.companies_table.setItem(row, 0, name_item)
            
            # GSTIN
            gstin_item = QTableWidgetItem(company['gstin'] or "")
            self.companies_table.setItem(row, 1, gstin_item)
            
            # Phone
            phone_item = QTableWidgetItem(company['phone_number'] or "")
            self.companies_table.setItem(row, 2, phone_item)
            
            # Email
            email_item = QTableWidgetItem(company['email'] or "")
            self.companies_table.setItem(row, 3, email_item)
            
            # Status
            status = "Active" if company['is_active'] else "Inactive"
            status_item = QTableWidgetItem(status)
            if company['is_active']:
                # Use foreground color role instead of stylesheet
                status_item.setData(Qt.ForegroundRole, "#10b981")
                status_item.setData(Qt.FontRole, QFont("Segoe UI", -1, QFont.Bold))
            else:
                status_item.setData(Qt.ForegroundRole, "#9ca3af")
            self.companies_table.setItem(row, 4, status_item)
            
            # Actions - Create widget with buttons
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(2, 2, 2, 2)
            actions_layout.setSpacing(2)
            actions_layout.setAlignment(Qt.AlignCenter)
            
            # View button
            view_btn = QPushButton("View")
            view_btn.setFixedSize(40, 22)
            view_btn.setStyleSheet("""
                QPushButton {
                    background-color: #3b82f6;
                    color: white;
                    border: none;
                    border-radius: 2px;
                    font-size: 9px;
                    font-weight: bold;
                    padding: 1px 3px;
                }
                QPushButton:hover {
                    background-color: #2563eb;
                }
                QPushButton:pressed {
                    background-color: #1d4ed8;
                }
            """)
            view_btn.clicked.connect(lambda checked, comp=company: self.view_company(comp))
            actions_layout.addWidget(view_btn)
            
            # Edit button
            edit_btn = QPushButton("Edit")
            edit_btn.setFixedSize(40, 22)
            edit_btn.setStyleSheet("""
                QPushButton {
                    background-color: #f59e0b;
                    color: white;
                    border: none;
                    border-radius: 2px;
                    font-size: 9px;
                    font-weight: bold;
                    padding: 1px 3px;
                }
                QPushButton:hover {
                    background-color: #d97706;
                }
                QPushButton:pressed {
                    background-color: #b45309;
                }
            """)
            edit_btn.clicked.connect(lambda checked, comp=company: self.edit_company(comp))
            actions_layout.addWidget(edit_btn)
            
            # Delete button
            delete_btn = QPushButton("Delete")
            delete_btn.setFixedSize(40, 22)
            delete_btn.setStyleSheet("""
                QPushButton {
                    background-color: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 2px;
                    font-size: 9px;
                    font-weight: bold;
                    padding: 1px 3px;
                }
                QPushButton:hover {
                    background-color: #dc2626;
                }
                QPushButton:pressed {
                    background-color: #b91c1c;
                }
            """)
            delete_btn.clicked.connect(lambda checked, comp=company: self.delete_company(comp))
            actions_layout.addWidget(delete_btn)
            
            self.companies_table.setCellWidget(row, 5, actions_widget)
        
        # Enable selection handling
        self.companies_table.itemSelectionChanged.connect(self.on_selection_changed)
    
    def on_selection_changed(self):
        """Handle table selection change."""
        selected_items = self.companies_table.selectedItems()
        if selected_items:
            self.open_button.setEnabled(True)
        else:
            self.open_button.setEnabled(False)
    
    def open_selected_company(self):
        """Open the selected company."""
        selected_row = self.companies_table.currentRow()
        if selected_row < 0:
            QMessageBox.warning(self, "No Selection", "Please select a company to open.")
            return
        
        # Get company data from first column
        name_item = self.companies_table.item(selected_row, 0)
        if not name_item:
            return
        
        company_data = name_item.data(Qt.UserRole)
        
        # Set company as active
        active_company_manager.set_active_company(company_data)
        self.company_selected.emit(company_data)
        QMessageBox.information(self, "Success", f"Company '{company_data['business_name']}' has been opened successfully.")
    
    def view_company(self, company_data):
        """View company details in professional dialog."""
        dialog = ViewCompanyDialog(company_data, self)
        dialog.exec()

    def edit_company(self, company_data):
        """Edit company details in professional dialog."""
        dialog = EditCompanyDialog(company_data, self.db, self)
        dialog.company_updated.connect(self.on_company_updated)
        if dialog.exec() == QDialog.Accepted:
            # Refresh companies list to show updated data
            self.load_companies()
    
    def on_company_updated(self, updated_data):
        """Handle company update event."""
        # If the edited company is currently active, update active company details
        active_company = active_company_manager.get_active_company()
        if active_company and active_company['id'] == updated_data['id']:
            # The active company was updated, it should remain consistent
            pass  # Database already has updated values

    def delete_company(self, company_data):
        """Delete company with confirmation."""
        reply = QMessageBox.question(
            self,
            "Delete Company",
            f"Are you sure you want to permanently delete '{company_data['business_name']}'?\n\nThis action cannot be undone.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            result = self.company_logic.delete_company(company_data['id'])
            
            if result['success']:
                QMessageBox.information(self, "Success", f"Company '{company_data['business_name']}' has been deleted successfully.")
                # Refresh the companies list
                self.load_companies()
            else:
                QMessageBox.critical(self, "Error", result['message'])

    def cancel(self):
        """Cancel company selection."""
        main_window = self.window()
        if main_window and hasattr(main_window, 'show_dashboard'):
            main_window.show_dashboard()
        self.company_selected.emit(None)


# Create alias for consistency
OpenCompanyPage = OpenCompanyPageWidget
