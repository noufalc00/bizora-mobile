"""
Stock Report Page Widget
Displays stock reports with filtering, pagination, and multiple report types.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QDateEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QGroupBox, QLineEdit, QGridLayout,
    QDialog, QMessageBox
)
from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QFont, QColor

from config import COLORS, active_company_manager
from logic.stock_report_logic import StockReportLogic
from db import Database


class StockReportPageWidget(QWidget):
    """Widget for displaying stock reports."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.db = Database()
        self.stock_logic = StockReportLogic(self.db)
        self.company_id = active_company_manager.get_active_company_id() if active_company_manager else None

        # Pagination state
        self.current_page = 0
        self.page_size = 100
        self.total_count = 0
        self.page_sizes = [50, 100, 250, 500]

        # Current report state
        self.current_report_type = "Stock Summary"
        self.selected_product_id = None

        self.setup_ui()
        self.load_summary_stats()

    def setup_ui(self):
        """Setup the stock report page UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel("Stock Report")
        title_label.setStyleSheet(f"""
            QLabel {{
                font-size: 24px;
                font-weight: bold;
                color: {COLORS['text_primary']};
            }}
        """)
        header_layout.addWidget(title_label)

        header_layout.addStretch()

        # Refresh button
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        self.refresh_btn.clicked.connect(self.refresh_report)
        header_layout.addWidget(self.refresh_btn)

        # Export button
        self.export_btn = QPushButton("Export")
        self.export_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['success']};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: #059669;
            }}
        """)
        self.export_btn.clicked.connect(self.export_report)
        header_layout.addWidget(self.export_btn)

        layout.addLayout(header_layout)

        # Summary Cards
        self.setup_summary_cards(layout)

        # Filter section
        self.setup_filters(layout)

        # Main table
        self.setup_table(layout)

        # Pagination
        self.setup_pagination(layout)

        # Load initial report
        QTimer.singleShot(100, self.load_report)

    def setup_summary_cards(self, parent_layout):
        """Setup summary cards section."""
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(8)

        # Total Products
        self.total_products_card = self.create_summary_card("Total Products", "0", COLORS['primary'])
        cards_layout.addWidget(self.total_products_card)

        # Total Stock Qty
        self.total_qty_card = self.create_summary_card("Total Stock Qty", "0", COLORS['info'])
        cards_layout.addWidget(self.total_qty_card)

        # Total Stock Value
        self.total_value_card = self.create_summary_card("Total Stock Value", "₹0", COLORS['success'])
        cards_layout.addWidget(self.total_value_card)

        # Negative Stock Count
        self.negative_count_card = self.create_summary_card("Negative Stock", "0", COLORS['error'])
        cards_layout.addWidget(self.negative_count_card)

        # Zero Stock Count
        self.zero_count_card = self.create_summary_card("Zero Stock", "0", COLORS['warning'])
        cards_layout.addWidget(self.zero_count_card)

        parent_layout.addLayout(cards_layout)

    def create_summary_card(self, title, value, color):
        """Create a summary card widget."""
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
                padding: 8px;
            }}
        """)
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(2)

        title_label = QLabel(title)
        title_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 10px;")
        card_layout.addWidget(title_label)

        value_label = QLabel(value)
        value_label.setStyleSheet(f"color: {color}; font-size: 14px; font-weight: bold;")
        card_layout.addWidget(value_label)

        return card

    def setup_filters(self, parent_layout):
        """Setup filter section in one line."""
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(8)

        # Product search
        product_label = QLabel("Product:")
        product_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.product_search = QLineEdit()
        self.product_search.setPlaceholderText("Search...")
        self.product_search.setMaximumWidth(150)
        self.product_search.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QLineEdit:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        filter_layout.addWidget(product_label)
        filter_layout.addWidget(self.product_search)

        # Report Type
        report_type_label = QLabel("Report:")
        report_type_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.report_type_combo = QComboBox()
        self.report_type_combo.addItems([
            "Stock Summary",
            "Stock Ledger",
            "Negative Stock",
            "Zero Stock",
            "Low Stock",
            "Stock Valuation"
        ])
        self.report_type_combo.setMaximumWidth(120)
        self.report_type_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QComboBox:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        self.report_type_combo.currentTextChanged.connect(self.on_report_type_changed)
        filter_layout.addWidget(report_type_label)
        filter_layout.addWidget(self.report_type_combo)

        # Stock Status Filter
        status_label = QLabel("Status:")
        status_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.status_combo = QComboBox()
        self.status_combo.addItems([
            "All",
            "In Stock",
            "Low Stock",
            "Negative Stock",
            "Zero Stock"
        ])
        self.status_combo.setMaximumWidth(100)
        self.status_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QComboBox:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        filter_layout.addWidget(status_label)
        filter_layout.addWidget(self.status_combo)

        # From Date
        from_date_label = QLabel("From:")
        from_date_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.from_date_edit = QDateEdit()
        self.from_date_edit.setCalendarPopup(True)
        self.from_date_edit.setDate(QDate.currentDate().addMonths(-1))
        self.from_date_edit.setMaximumWidth(120)
        self.from_date_edit.setStyleSheet(f"""
            QDateEdit {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QDateEdit:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        filter_layout.addWidget(from_date_label)
        filter_layout.addWidget(self.from_date_edit)

        # To Date
        to_date_label = QLabel("To:")
        to_date_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.to_date_edit = QDateEdit()
        self.to_date_edit.setCalendarPopup(True)
        self.to_date_edit.setDate(QDate.currentDate())
        self.to_date_edit.setMaximumWidth(120)
        self.to_date_edit.setStyleSheet(f"""
            QDateEdit {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QDateEdit:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        filter_layout.addWidget(to_date_label)
        filter_layout.addWidget(self.to_date_edit)

        # Page Size
        page_size_label = QLabel("Size:")
        page_size_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        self.page_size_combo = QComboBox()
        self.page_size_combo.addItems([str(size) for size in self.page_sizes])
        self.page_size_combo.setCurrentText(str(self.page_size))
        self.page_size_combo.setMaximumWidth(70)
        self.page_size_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px;
                font-size: 11px;
            }}
            QComboBox:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
        """)
        self.page_size_combo.currentTextChanged.connect(self.on_page_size_changed)
        filter_layout.addWidget(page_size_label)
        filter_layout.addWidget(self.page_size_combo)

        # Buttons
        self.show_btn = QPushButton("Show")
        self.show_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 3px 12px;
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        self.show_btn.clicked.connect(self.load_report)
        filter_layout.addWidget(self.show_btn)

        self.reset_btn = QPushButton("Reset")
        self.reset_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 3px 12px;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['border']};
            }}
        """)
        self.reset_btn.clicked.connect(self.reset_filters)
        filter_layout.addWidget(self.reset_btn)

        self.export_excel_btn = QPushButton("Excel")
        self.export_excel_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: #10B981;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 3px 10px;
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: #059669;
            }}
        """)
        self.export_excel_btn.clicked.connect(self.export_excel)
        filter_layout.addWidget(self.export_excel_btn)

        self.export_pdf_btn = QPushButton("PDF")
        self.export_pdf_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: #EF4444;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 3px 10px;
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: #DC2626;
            }}
        """)
        self.export_pdf_btn.clicked.connect(self.export_pdf)
        filter_layout.addWidget(self.export_pdf_btn)

        filter_layout.addStretch()
        parent_layout.addLayout(filter_layout)

    def setup_table(self, parent_layout):
        """Setup main table."""
        self.table = QTableWidget()
        self.table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                gridline-color: {COLORS['border']};
            }}
            QTableWidget::item {{
                padding: 4px;
            }}
            QTableWidget::item:selected {{
                background-color: {COLORS['primary']};
                color: white;
            }}
            QHeaderView::section {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 4px;
                font-weight: bold;
            }}
        """)
        self.table.setAlternatingRowColors(True)
        # Set alternating row colors with proper contrast for white text
        self.table.setStyleSheet(self.table.styleSheet() + f"""
            QTableWidget::item:alternate {{
                background-color: #2D3748;
                color: {COLORS['text_primary']};
            }}
            QTableWidget::item {{
                background-color: #1A202C;
                color: {COLORS['text_primary']};
            }}
        """)
        # Reduce row height to show more rows
        self.table.verticalHeader().setDefaultSectionSize(25)
        self.table.verticalHeader().setMinimumSectionSize(20)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)

        # Double-click for drill-down (future-ready)
        self.table.cellDoubleClicked.connect(self.on_table_double_click)

        parent_layout.addWidget(self.table)

    def setup_pagination(self, parent_layout):
        """Setup pagination controls."""
        pagination_layout = QHBoxLayout()
        pagination_layout.addStretch()

        self.page_label = QLabel("Page 0 of 0")
        self.page_label.setStyleSheet(f"color: {COLORS['text_secondary']};")
        pagination_layout.addWidget(self.page_label)

        self.prev_btn = QPushButton("Previous")
        self.prev_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 6px 16px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['border']};
            }}
            QPushButton:disabled {{
                color: {COLORS['text_disabled']};
            }}
        """)
        self.prev_btn.clicked.connect(self.prev_page)
        self.prev_btn.setEnabled(False)
        pagination_layout.addWidget(self.prev_btn)

        self.next_btn = QPushButton("Next")
        self.next_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 6px 16px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['border']};
            }}
            QPushButton:disabled {{
                color: {COLORS['text_disabled']};
            }}
        """)
        self.next_btn.clicked.connect(self.next_page)
        self.next_btn.setEnabled(False)
        pagination_layout.addWidget(self.next_btn)

        parent_layout.addLayout(pagination_layout)

    def load_summary_stats(self):
        """Load summary statistics."""
        if not self.company_id:
            return

        result = self.stock_logic.get_stock_summary_stats(self.company_id)
        if result['success']:
            stats = result['data']
            self.total_products_card.layout().itemAt(1).widget().setText(str(stats.get('total_products', 0)))
            self.total_qty_card.layout().itemAt(1).widget().setText(f"{stats.get('total_qty', 0):.2f}")
            self.total_value_card.layout().itemAt(1).widget().setText(f"₹{stats.get('total_value', 0):.2f}")
            self.negative_count_card.layout().itemAt(1).widget().setText(str(stats.get('negative_count', 0)))
            self.zero_count_card.layout().itemAt(1).widget().setText(str(stats.get('zero_count', 0)))

    def load_report(self):
        """Load report based on selected type."""
        if not self.company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        report_type = self.report_type_combo.currentText()
        self.current_report_type = report_type

        # Build filters
        filters = {
            'search_text': self.product_search.text().strip(),
            'date_from': self.from_date_edit.date().toString("yyyy-MM-dd"),
            'date_to': self.to_date_edit.date().toString("yyyy-MM-dd"),
            'stock_status': self.status_combo.currentText()
        }

        # Reset pagination
        self.current_page = 0

        # Load based on report type
        if report_type == "Stock Summary":
            self.load_stock_summary(filters)
        elif report_type == "Stock Ledger":
            self.load_stock_ledger(filters)
        elif report_type == "Negative Stock":
            self.load_negative_stock(filters)
        elif report_type == "Zero Stock":
            self.load_zero_stock(filters)
        elif report_type == "Low Stock":
            self.load_low_stock(filters)
        elif report_type == "Stock Valuation":
            self.load_stock_valuation(filters)

    def load_stock_summary(self, filters):
        """Load stock summary report."""
        offset = self.current_page * self.page_size
        result = self.stock_logic.get_stock_summary(self.company_id, filters, self.page_size, offset)

        if result['success']:
            self.total_count = result['total_count']
            data = result['data']
            self.populate_stock_summary_table(data)
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def load_stock_ledger(self, filters):
        """Load stock ledger report for selected product."""
        if not self.selected_product_id:
            QMessageBox.information(self, "Info", "Please select a product from Stock Summary first.")
            self.report_type_combo.setCurrentText("Stock Summary")
            return

        offset = self.current_page * self.page_size
        result = self.stock_logic.get_stock_ledger(
            self.company_id, self.selected_product_id,
            filters.get('date_from'), filters.get('date_to'),
            self.page_size, offset
        )

        if result['success']:
            self.total_count = result['total_count']
            data = result['data']
            self.populate_stock_ledger_table(data)
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def load_negative_stock(self, filters):
        """Load negative stock report."""
        offset = self.current_page * self.page_size
        result = self.stock_logic.get_negative_stock(self.company_id, filters, self.page_size, offset)

        if result['success']:
            self.total_count = result['total_count']
            data = result['data']
            self.populate_negative_stock_table(data)
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def load_zero_stock(self, filters):
        """Load zero stock report."""
        offset = self.current_page * self.page_size
        result = self.stock_logic.get_zero_stock(self.company_id, filters, self.page_size, offset)

        if result['success']:
            self.total_count = result['total_count']
            data = result['data']
            self.populate_zero_stock_table(data)
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def load_low_stock(self, filters):
        """Load low stock report."""
        offset = self.current_page * self.page_size
        result = self.stock_logic.get_low_stock(self.company_id, filters, self.page_size, offset)

        if result['success']:
            self.total_count = result['total_count']
            data = result['data']
            self.populate_low_stock_table(data)
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def load_stock_valuation(self, filters):
        """Load stock valuation report."""
        result = self.stock_logic.get_stock_value(self.company_id, filters)
        if result['success']:
            value = result['data']
            self.table.setRowCount(1)
            self.table.setColumnCount(1)
            self.table.setHorizontalHeaderLabels(["Total Stock Value"])
            self.table.setItem(0, 0, QTableWidgetItem(f"₹{value:.2f}"))
            self.table.horizontalHeader().setStretchLastSection(True)
            self.total_count = 0
            self.update_pagination()
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def populate_stock_summary_table(self, data):
        """Populate stock summary table with warning color for negative stock."""
        columns = ["SL No", "Product", "Barcode", "Category", "Unit",
                   "Opening Qty", "Inward Qty", "Outward Qty", "Closing Qty",
                   "Purchase Rate", "Sales Rate", "Stock Value", "Last Movement"]
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(data))

        for row, item in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(item.get('name', '')))
            self.table.setItem(row, 2, QTableWidgetItem(item.get('barcode', '')))
            self.table.setItem(row, 3, QTableWidgetItem(item.get('category', '')))
            self.table.setItem(row, 4, QTableWidgetItem(item.get('unit', '')))
            self.table.setItem(row, 5, QTableWidgetItem(f"{item.get('opening_qty', 0):.2f}"))
            self.table.setItem(row, 6, QTableWidgetItem(f"{item.get('inward_qty', 0):.2f}"))
            self.table.setItem(row, 7, QTableWidgetItem(f"{item.get('outward_qty', 0):.2f}"))
            
            closing_qty = item.get('closing_qty', 0)
            qty_item = QTableWidgetItem(f"{closing_qty:.2f}")
            if closing_qty < 0:
                qty_item.setBackground(QColor(254, 202, 202))  # Light red background
            self.table.setItem(row, 8, qty_item)
            
            self.table.setItem(row, 9, QTableWidgetItem(f"{item.get('purchase_rate', 0):.2f}"))
            self.table.setItem(row, 10, QTableWidgetItem(f"{item.get('sale_price', 0):.2f}"))
            stock_value = closing_qty * item.get('purchase_rate', 0)
            self.table.setItem(row, 11, QTableWidgetItem(f"₹{stock_value:.2f}"))
            self.table.setItem(row, 12, QTableWidgetItem(item.get('last_movement_date', '') or ''))

        self.table.resizeColumnsToContents()

    def populate_stock_ledger_table(self, data):
        """Populate stock ledger table."""
        columns = ["SL No", "Date", "Voucher Type", "Voucher No", "Narration",
                   "Qty In", "Qty Out", "Rate", "Value", "Balance Qty", "Balance Value"]
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(data))

        for row, item in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(item.get('movement_date', '')))
            self.table.setItem(row, 2, QTableWidgetItem(item.get('voucher_type', item.get('movement_type', ''))))
            self.table.setItem(row, 3, QTableWidgetItem(item.get('voucher_no', '')))
            self.table.setItem(row, 4, QTableWidgetItem(item.get('narration', '')))
            self.table.setItem(row, 5, QTableWidgetItem(f"{item.get('qty_in', 0):.2f}"))
            self.table.setItem(row, 6, QTableWidgetItem(f"{item.get('qty_out', 0):.2f}"))
            self.table.setItem(row, 7, QTableWidgetItem(f"{item.get('rate', 0):.2f}"))
            value = item.get('value_in', 0) + item.get('value_out', 0)
            self.table.setItem(row, 8, QTableWidgetItem(f"₹{value:.2f}"))
            self.table.setItem(row, 9, QTableWidgetItem(f"{item.get('balance_qty', 0):.2f}"))
            self.table.setItem(row, 10, QTableWidgetItem(f"₹{item.get('balance_value', 0):.2f}"))

        self.table.resizeColumnsToContents()

    def populate_negative_stock_table(self, data):
        """Populate negative stock table with warning color."""
        columns = ["SL No", "Product", "Barcode", "Category", "Unit",
                   "Closing Qty", "Purchase Rate", "Sales Rate"]
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(data))

        for row, item in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(item.get('name', '')))
            self.table.setItem(row, 2, QTableWidgetItem(item.get('barcode', '')))
            self.table.setItem(row, 3, QTableWidgetItem(item.get('category', '')))
            self.table.setItem(row, 4, QTableWidgetItem(item.get('unit', '')))
            
            qty_item = QTableWidgetItem(f"{item.get('closing_qty', 0):.2f}")
            qty_item.setBackground(QColor(254, 202, 202))  # Light red background
            self.table.setItem(row, 5, qty_item)
            
            self.table.setItem(row, 6, QTableWidgetItem(f"{item.get('purchase_rate', 0):.2f}"))
            self.table.setItem(row, 7, QTableWidgetItem(f"{item.get('sale_price', 0):.2f}"))

        self.table.resizeColumnsToContents()

    def populate_zero_stock_table(self, data):
        """Populate zero stock table."""
        columns = ["SL No", "Product", "Barcode", "Category", "Unit",
                   "Closing Qty", "Purchase Rate", "Sales Rate"]
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(data))

        for row, item in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(item.get('name', '')))
            self.table.setItem(row, 2, QTableWidgetItem(item.get('barcode', '')))
            self.table.setItem(row, 3, QTableWidgetItem(item.get('category', '')))
            self.table.setItem(row, 4, QTableWidgetItem(item.get('unit', '')))
            self.table.setItem(row, 5, QTableWidgetItem(f"{item.get('closing_qty', 0):.2f}"))
            self.table.setItem(row, 6, QTableWidgetItem(f"{item.get('purchase_rate', 0):.2f}"))
            self.table.setItem(row, 7, QTableWidgetItem(f"{item.get('sale_price', 0):.2f}"))

        self.table.resizeColumnsToContents()

    def populate_low_stock_table(self, data):
        """Populate low stock table."""
        columns = ["SL No", "Product", "Barcode", "Category", "Unit",
                   "Reorder Level", "Closing Qty", "Purchase Rate", "Sales Rate"]
        self.table.setColumnCount(len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setRowCount(len(data))

        for row, item in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.table.setItem(row, 1, QTableWidgetItem(item.get('name', '')))
            self.table.setItem(row, 2, QTableWidgetItem(item.get('barcode', '')))
            self.table.setItem(row, 3, QTableWidgetItem(item.get('category', '')))
            self.table.setItem(row, 4, QTableWidgetItem(item.get('unit', '')))
            self.table.setItem(row, 5, QTableWidgetItem(f"{item.get('reorder_level', 0):.2f}"))
            self.table.setItem(row, 6, QTableWidgetItem(f"{item.get('closing_qty', 0):.2f}"))
            self.table.setItem(row, 7, QTableWidgetItem(f"{item.get('purchase_rate', 0):.2f}"))
            self.table.setItem(row, 8, QTableWidgetItem(f"{item.get('sale_price', 0):.2f}"))

        self.table.resizeColumnsToContents()

    def update_pagination(self):
        """Update pagination controls."""
        total_pages = (self.total_count + self.page_size - 1) // self.page_size if self.total_count > 0 else 0
        self.page_label.setText(f"Page {self.current_page + 1} of {total_pages}")

        self.prev_btn.setEnabled(self.current_page > 0)
        self.next_btn.setEnabled(self.current_page < total_pages - 1)

    def prev_page(self):
        """Go to previous page."""
        if self.current_page > 0:
            self.current_page -= 1
            self.load_report()

    def next_page(self):
        """Go to next page."""
        total_pages = (self.total_count + self.page_size - 1) // self.page_size
        if self.current_page < total_pages - 1:
            self.current_page += 1
            self.load_report()

    def on_report_type_changed(self, text):
        """Handle report type change."""
        self.selected_product_id = None
        self.current_page = 0
        self.status_combo.setEnabled(text == "Stock Summary")

    def on_table_double_click(self, row, column):
        """Handle table double-click for drill-down."""
        if self.current_report_type == "Stock Summary" and self.table.rowCount() > 0:
            # Get product ID from row (stored in item data)
            item = self.table.item(row, 0)
            if item:
                # For now, just switch to Stock Ledger
                # In future, we can open product details
                self.selected_product_id = None  # Would be set from row data
                self.report_type_combo.setCurrentText("Stock Ledger")

    def reset_filters(self):
        """Reset all filters."""
        self.product_search.clear()
        self.from_date_edit.setDate(QDate.currentDate().addMonths(-1))
        self.to_date_edit.setDate(QDate.currentDate())
        self.status_combo.setCurrentText("All")
        self.current_page = 0
        self.load_report()

    def on_page_size_changed(self, text):
        """Handle page size change."""
        self.page_size = int(text)
        self.current_page = 0
        self.load_report()

    def export_excel(self):
        """Export current report to Excel."""
        if not self.company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        report_type = self.current_report_type
        filters = {
            'search_text': self.product_search.text().strip(),
            'date_from': self.from_date_edit.date().toString("yyyy-MM-dd"),
            'date_to': self.to_date_edit.date().toString("yyyy-MM-dd"),
            'stock_status': self.status_combo.currentText()
        }

        result = self.stock_logic.export_stock_report_excel(self.company_id, report_type, filters)
        if result['success']:
            QMessageBox.information(self, "Export", f"Excel exported successfully to: {result['data']}")
        else:
            QMessageBox.warning(self, "Export Error", result['message'])

    def export_pdf(self):
        """Export current report to PDF."""
        if not self.company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        report_type = self.current_report_type
        filters = {
            'search_text': self.product_search.text().strip(),
            'date_from': self.from_date_edit.date().toString("yyyy-MM-dd"),
            'date_to': self.to_date_edit.date().toString("yyyy-MM-dd"),
            'stock_status': self.status_combo.currentText()
        }

        result = self.stock_logic.export_stock_report_pdf(self.company_id, report_type, filters)
        if result['success']:
            QMessageBox.information(self, "Export", f"PDF exported successfully to: {result['data']}")
        else:
            QMessageBox.warning(self, "Export Error", result['message'])

    def refresh_report(self):
        """Refresh current report."""
        self.load_summary_stats()
        self.load_report()

    def export_report(self):
        """Export current report (placeholder for future)."""
        QMessageBox.information(self, "Export", "Export functionality to be implemented.")
