"""
View Company dialog for the Accounting Desktop Application.
Provides a professional interface to view complete company details with logo and signature previews.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QFrame, QScrollArea, QGridLayout, QTextEdit, QLineEdit, QWidget
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QFont
import os

from config import COLORS


class ViewCompanyDialog(QDialog):
    """Dialog to view complete company details with professional layout."""
    
    def __init__(self, company_data, parent=None):
        super().__init__(parent)
        self.company_data = company_data
        self.setWindowTitle(f"View Company - {company_data['business_name']}")
        self.setMinimumSize(600, 500)
        # Use Qt.Window for native titlebar with full window controls
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        self.setup_ui()
        self.load_company_data()
    
    def setup_ui(self):
        """Setup the dialog UI."""
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
            }}
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 13px;
            }}
            QLabel.section {{
                color: {COLORS['primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
            QLabel.field {{
                color: {COLORS['text_secondary']};
                font-weight: bold;
                margin-top: 5px;
            }}
            QLabel.value {{
                color: {COLORS['text_primary']};
                background-color: {COLORS['surface']};
                padding: 8px;
                border-radius: 4px;
                border: 1px solid {COLORS['border']};
            }}
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Create scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet(f"""
            QScrollArea {{
                border: none;
                background-color: transparent;
            }}
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setSpacing(20)
        
        # Company header
        self.create_header(content_layout)
        
        # Company details sections
        self.create_basic_info_section(content_layout)
        self.create_business_details_section(content_layout)
        self.create_address_section(content_layout)
        self.create_media_section(content_layout)
        
        # Close button
        self.create_close_button(content_layout)
        
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
    
    def create_header(self, layout):
        """Create company header section."""
        header_frame = QFrame()
        header_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        header_layout = QVBoxLayout(header_frame)
        
        # Company name
        title = QLabel(self.company_data['business_name'])
        title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['primary']};
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
            }}
        """)
        header_layout.addWidget(title)
        
        # Status
        status = "Active" if self.company_data['is_active'] else "Inactive"
        status_color = COLORS['success'] if self.company_data['is_active'] else COLORS['warning']
        status_label = QLabel(f"Status: {status}")
        status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-weight: bold;
                font-size: 14px;
            }}
        """)
        header_layout.addWidget(status_label)
        
        layout.addWidget(header_frame)
    
    def create_basic_info_section(self, layout):
        """Create basic company information section."""
        section_label = QLabel("Basic Information")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        info_layout = QGridLayout(info_frame)
        info_layout.setSpacing(10)
        
        # GSTIN
        gstin_label = QLabel("GSTIN:")
        gstin_label.setProperty("class", "field")
        info_layout.addWidget(gstin_label, 0, 0)
        
        gstin_value = QLabel(self.company_data['gstin'] or "N/A")
        gstin_value.setProperty("class", "value")
        info_layout.addWidget(gstin_value, 0, 1)
        
        # Phone
        phone_label = QLabel("Phone:")
        phone_label.setProperty("class", "field")
        info_layout.addWidget(phone_label, 1, 0)
        
        phone_value = QLabel(self.company_data['phone_number'] or "N/A")
        phone_value.setProperty("class", "value")
        info_layout.addWidget(phone_value, 1, 1)
        
        # Email
        email_label = QLabel("Email:")
        email_label.setProperty("class", "field")
        info_layout.addWidget(email_label, 2, 0)
        
        email_value = QLabel(self.company_data['email'] or "N/A")
        email_value.setProperty("class", "value")
        email_value.setWordWrap(True)
        info_layout.addWidget(email_value, 2, 1)
        
        layout.addWidget(info_frame)
    
    def create_business_details_section(self, layout):
        """Create business details section."""
        section_label = QLabel("Business Details")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        info_layout = QGridLayout(info_frame)
        info_layout.setSpacing(10)
        
        # Business Type
        type_label = QLabel("Business Type:")
        type_label.setProperty("class", "field")
        info_layout.addWidget(type_label, 0, 0)
        
        type_value = QLabel(self.company_data['business_type'] or "N/A")
        type_value.setProperty("class", "value")
        info_layout.addWidget(type_value, 0, 1)
        
        # Business Category
        category_label = QLabel("Business Category:")
        category_label.setProperty("class", "field")
        info_layout.addWidget(category_label, 1, 0)
        
        category_value = QLabel(self.company_data['business_category'] or "N/A")
        category_value.setProperty("class", "value")
        info_layout.addWidget(category_value, 1, 1)
        
        layout.addWidget(info_frame)
    
    def create_address_section(self, layout):
        """Create address section."""
        section_label = QLabel("Address Information")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        info_layout = QGridLayout(info_frame)
        info_layout.setSpacing(10)
        
        # Address
        address_label = QLabel("Address:")
        address_label.setProperty("class", "field")
        info_layout.addWidget(address_label, 0, 0, Qt.AlignTop)
        
        address_text = QTextEdit()
        address_text.setPlainText(self.company_data['address'] or "N/A")
        address_text.setReadOnly(True)
        address_text.setMaximumHeight(80)
        address_text.setStyleSheet(f"""
            QTextEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        info_layout.addWidget(address_text, 0, 1)
        
        # State
        state_label = QLabel("State:")
        state_label.setProperty("class", "field")
        info_layout.addWidget(state_label, 1, 0)
        
        state_value = QLabel(self.company_data['state'] or "N/A")
        state_value.setProperty("class", "value")
        info_layout.addWidget(state_value, 1, 1)
        
        # Pincode
        pincode_label = QLabel("Pincode:")
        pincode_label.setProperty("class", "field")
        info_layout.addWidget(pincode_label, 2, 0)
        
        pincode_value = QLabel(self.company_data['pincode'] or "N/A")
        pincode_value.setProperty("class", "value")
        info_layout.addWidget(pincode_value, 2, 1)
        
        layout.addWidget(info_frame)
    
    def create_media_section(self, layout):
        """Create logo and signature preview section."""
        section_label = QLabel("Company Media")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        media_frame = QFrame()
        media_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        media_layout = QHBoxLayout(media_frame)
        media_layout.setSpacing(20)
        
        # Logo section
        logo_section = self.create_preview_section("Logo", 180, 120)
        media_layout.addWidget(logo_section)
        
        # Signature section
        signature_section = self.create_preview_section("Signature", 180, 120)
        media_layout.addWidget(signature_section)
        
        layout.addWidget(media_frame)
    
    def create_preview_section(self, title, width, height):
        """Create a preview section for logo or signature."""
        section = QFrame()
        section.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['background']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
                padding: 10px;
            }}
        """)
        
        layout = QVBoxLayout(section)
        layout.setSpacing(5)
        
        # Title
        title_label = QLabel(title)
        title_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-weight: bold;
                font-size: 12px;
            }}
        """)
        layout.addWidget(title_label, alignment=Qt.AlignCenter)
        
        # Preview
        preview = QLabel()
        preview.setFixedSize(width, height)
        preview.setStyleSheet(f"""
            QLabel {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                color: {COLORS['text_secondary']};
                font-size: 11px;
            }}
        """)
        preview.setAlignment(Qt.AlignCenter)
        
        if title == "Logo":
            self.logo_preview = preview
        else:
            self.signature_preview = preview
        
        layout.addWidget(preview, alignment=Qt.AlignCenter)
        
        return section
    
    def create_close_button(self, layout):
        """Create close button."""
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        button_layout.addWidget(close_button)
        
        layout.addLayout(button_layout)
    
    def load_company_data(self):
        """Load company data into the UI."""
        # Load logo if available
        logo_path = self.company_data.get('logo_path', '')
        
        if logo_path and logo_path.strip():
            if os.path.exists(logo_path):
                # Check if it's a PDF file
                if logo_path.lower().endswith('.pdf'):
                    self.logo_preview.setText("PDF Uploaded\n(Logo)")
                    self.logo_preview.setStyleSheet(f"""
                        QLabel {{
                            background-color: {COLORS['surface']};
                            border: 1px solid {COLORS['border']};
                            border-radius: 4px;
                            color: {COLORS['primary']};
                            font-size: 12px;
                            font-weight: bold;
                        }}
                    """)
                else:
                    # Try to load as image
                    try:
                        pixmap = QPixmap(logo_path)
                        if not pixmap.isNull():
                            # Get preview size and scale image properly
                            preview_size = self.logo_preview.size()
                            scaled_pixmap = pixmap.scaled(
                                preview_size.width() - 10,  # Leave some padding
                                preview_size.height() - 10,
                                Qt.KeepAspectRatio,
                                Qt.SmoothTransformation
                            )
                            self.logo_preview.setPixmap(scaled_pixmap)
                            self.logo_preview.setText("")
                        else:
                            self.logo_preview.setText("No Logo Available")
                    except Exception as e:
                        print(f"Error loading logo: {e}")
                        self.logo_preview.setText("No Logo Available")
            else:
                self.logo_preview.setText("No Logo Available")
        else:
            self.logo_preview.setText("No Logo Available")
        
        # Load signature if available
        signature_path = self.company_data.get('signature_path', '')
        
        if signature_path and signature_path.strip():
            if os.path.exists(signature_path):
                # Check if it's a PDF file
                if signature_path.lower().endswith('.pdf'):
                    self.signature_preview.setText("PDF Uploaded\n(Signature)")
                    self.signature_preview.setStyleSheet(f"""
                        QLabel {{
                            background-color: {COLORS['surface']};
                            border: 1px solid {COLORS['border']};
                            border-radius: 4px;
                            color: {COLORS['primary']};
                            font-size: 12px;
                            font-weight: bold;
                        }}
                    """)
                else:
                    # Try to load as image
                    try:
                        pixmap = QPixmap(signature_path)
                        if not pixmap.isNull():
                            # Get preview size and scale image properly
                            preview_size = self.signature_preview.size()
                            scaled_pixmap = pixmap.scaled(
                                preview_size.width() - 10,  # Leave some padding
                                preview_size.height() - 10,
                                Qt.KeepAspectRatio,
                                Qt.SmoothTransformation
                            )
                            self.signature_preview.setPixmap(scaled_pixmap)
                            self.signature_preview.setText("")
                        else:
                            self.signature_preview.setText("No Signature Available")
                    except Exception as e:
                        print(f"Error loading signature: {e}")
                        self.signature_preview.setText("No Signature Available")
            else:
                self.signature_preview.setText("No Signature Available")
        else:
            self.signature_preview.setText("No Signature Available")
