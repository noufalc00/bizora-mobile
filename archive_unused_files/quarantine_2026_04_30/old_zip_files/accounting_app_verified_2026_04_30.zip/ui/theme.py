"""
Shared UI theme module for the Accounting Desktop application.

This module centralises the per-widget stylesheet fragments and small
parsing helpers that were previously duplicated across several UI files.

Design goals:
  - Single source of truth for widget-level colours / typography.
  - No behavioural change for existing widgets — the style strings
    returned here are byte-equivalent to the in-file versions they
    replace.
  - Safe, side-effect-free helpers. No Qt objects are created here.

Two colour families are used by the app:
  * "master" palette — #374151 background, #fbbf24 label — used by the
    Products, Debitor/Creditor and Bank Account master pages.
  * "sales"  palette — #334155 background, #fbbf24 label — used by the
    Sales Entry widget (see sales_entry_ui.py).

When you add a new master-data page, prefer the master_* helpers.
When you add or change a Sales Entry sub-block, use the sales_* helpers.
"""

from __future__ import annotations


# =============================================================================
# Shared constants
# =============================================================================

GST_STATE_CODES = {
    "01": "Jammu and Kashmir",
    "02": "Himachal Pradesh",
    "03": "Punjab",
    "04": "Chandigarh",
    "05": "Uttarakhand",
    "06": "Haryana",
    "07": "Delhi",
    "08": "Rajasthan",
    "09": "Uttar Pradesh",
    "10": "Bihar",
    "11": "Sikkim",
    "12": "Arunachal Pradesh",
    "13": "Nagaland",
    "14": "Manipur",
    "15": "Mizoram",
    "16": "Tripura",
    "17": "Meghalaya",
    "18": "Assam",
    "19": "West Bengal",
    "20": "Jharkhand",
    "21": "Odisha",
    "22": "Chhattisgarh",
    "23": "Madhya Pradesh",
    "24": "Gujarat",
    "25": "Daman and Diu",
    "26": "Dadra and Nagar Haveli",
    "27": "Maharashtra",
    "28": "Andhra Pradesh",
    "29": "Karnataka",
    "30": "Goa",
    "31": "Lakshadweep",
    "32": "Kerala",
    "33": "Tamil Nadu",
    "34": "Puducherry",
    "35": "Andaman and Nicobar Islands",
    "36": "Telangana",
    "37": "Andhra Pradesh (New)",
}


# =============================================================================
# Safe parsing helpers
# =============================================================================

def safe_float(value, default: float = 0.0) -> float:
    """Return float(value) or ``default`` on any parse / type error.

    Accepts ``None``, empty strings, numeric types, and strings with
    surrounding whitespace or a trailing percent sign.
    """
    if value is None:
        return default
    try:
        if isinstance(value, (int, float)):
            return float(value)
        text = str(value).strip().rstrip('%').strip()
        if not text:
            return default
        return float(text)
    except (TypeError, ValueError):
        return default


def safe_int(value, default: int = 0) -> int:
    """Return int(value) or ``default`` on any parse / type error."""
    if value is None:
        return default
    try:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return int(value)
        text = str(value).strip()
        if not text:
            return default
        # Allow "12.0" style strings by going through float first.
        return int(float(text))
    except (TypeError, ValueError):
        return default


# =============================================================================
# Master-data palette (products / debitor-creditor / bank accounts)
# =============================================================================

_MASTER_INPUT_BASE = """
    QLineEdit {{
        background-color: #374151;
        color: #f3f4f6;
        border: 1px solid #4b5563;
        border-radius: 3px;
        padding: {padding};
        font-size: 12px;
        min-height: {min_height}px;
        height: {height}px;
        max-width: {max_width}px;{extra}
    }}
    QLineEdit:focus {{
        border-color: #60a5fa;
        outline: none;
    }}
"""


def master_input_style(max_width: int = 110) -> str:
    """Compact input field (default 110 px wide). Matches the legacy
    ``compact_input_style`` used in products / debitor_creditor /
    bank_accounts pages.
    """
    return _MASTER_INPUT_BASE.format(
        padding="4px 8px",
        min_height=16,
        height=16,
        max_width=max_width,
        extra="",
    )


def master_wide_input_style() -> str:
    """Wide input field (~210 px). Legacy ``wide_input_style``."""
    return _MASTER_INPUT_BASE.format(
        padding="5px 8px",
        min_height=18,
        height=18,
        max_width=210,
        extra="\n        text-align: left;",
    )


def master_extra_wide_input_style() -> str:
    """Extra-wide input field (~380 px). Legacy ``extra_wide_input_style``."""
    return _MASTER_INPUT_BASE.format(
        padding="4px 8px",
        min_height=16,
        height=16,
        max_width=380,
        extra="",
    )


def master_label_style() -> str:
    """Compact amber master-data label. Legacy ``compact_label_style``."""
    return """
        QLabel {
            color: #fbbf24;
            font-size: 12px;
            font-weight: bold;
            background: transparent;
            border: none;
            padding: 1px 0px;
            margin: 0px;
            min-height: 14px;
            height: 14px;
        }
    """


# =============================================================================
# Sales Entry palette
# =============================================================================
# These functions are used by sales_entry_ui.py / sales_entry.py as thin
# wrappers. Method names on the widget classes remain unchanged so the
# ~100+ call sites keep working.

def sales_compact_input_style() -> str:
    return """
        QLineEdit, QComboBox, QDateEdit {
            background-color: #1e293b;
            border: 1px solid #475569;
            border-radius: 3px;
            color: #f1f5f9;
            font-size: 11px;
            padding: 2px 4px;
        }
        QLineEdit:focus, QComboBox:focus, QDateEdit:focus {
            border: 1px solid #60a5fa;
        }
        QLineEdit:disabled {
            background-color: #0f172a;
            color: #64748b;
        }
        QComboBox::drop-down {
            border: none;
            width: 20px;
        }
        QComboBox::down-arrow {
            image: none;
            border-left: 4px solid transparent;
            border-right: 4px solid transparent;
            border-top: 4px solid #94a3b8;
            margin-right: 4px;
        }
    """


def sales_barcode_input_style() -> str:
    return """
        QLineEdit {
            background-color: #1e293b;
            border: 1px solid #fbbf24;
            border-radius: 3px;
            color: #fbbf24;
            font-size: 11px;
            font-weight: bold;
            padding: 2px 4px;
        }
        QLineEdit:focus {
            border: 1px solid #fbbf24;
        }
    """


def sales_totals_input_style() -> str:
    return """
        QLineEdit {
            background-color: #1e293b;
            color: #10b981;
            border: 1px solid #334155;
            border-radius: 2px;
            padding: 3px 6px;
            font-size: 11px;
            font-weight: bold;
            min-height: 22px;
        }
        QLineEdit:disabled {
            background-color: #0f172a;
            color: #64748b;
        }
    """


def sales_micro_label_style() -> str:
    return """
    QLabel {
        color: #facc15;
        font-weight: bold;
        font-size: 11px;
        padding: 0px 2px;
    }
    """


def sales_status_label_style() -> str:
    return """
    QLabel {
        color: #94a3b8;
        font-size: 11px;
        font-weight: bold;
    }
    """


def sales_status_value_style() -> str:
    return "color: #00ff00; font-weight: bold; font-size: 11px;"


def sales_status_checkbox_style() -> str:
    return "font-size:11px; color:#fbbf24; font-weight:bold;"


def sales_checkbox_style() -> str:
    return """
    QCheckBox {
        color: #94a3b8;
        font-size: 11px;
        font-weight: bold;
    }
    QCheckBox::indicator {
        width: 13px;
        height: 13px;
        border: 1px solid #475569;
        border-radius: 2px;
        background: #1e293b;
    }
    QCheckBox::indicator:checked {
        background-color: #3b82f6;
        border: 1px solid #3b82f6;
    }
    """


def sales_grand_label_style() -> str:
    return "font-size:11px; font-weight:bold; color:#f1f5f9; background:transparent; border:none;"


def sales_grand_amount_style() -> str:
    return "font-size:22px; font-weight:bold; color:#10b981; background:transparent; border:none;"


# ---- Sales Entry frame styles -----------------------------------------------

def _basic_dark_frame(bg: str = "#1e293b", border: str = "#334155",
                     radius: int = 3) -> str:
    return f"""
        QFrame {{
            background-color: {bg};
            border: 1px solid {border};
            border-radius: {radius}px;
        }}
    """


def sales_bottom_panel_style() -> str:
    return _basic_dark_frame(bg="#1e293b", border="#334155", radius=3)


def sales_table_zone_style() -> str:
    return _basic_dark_frame(bg="#1e293b", border="#334155", radius=3)


def sales_action_frame_style() -> str:
    return _basic_dark_frame(bg="#0f172a", border="#334155", radius=3)


def sales_adj_frame_style() -> str:
    return _basic_dark_frame(bg="#0f172a", border="#334155", radius=3)


def sales_totals_frame_style() -> str:
    return _basic_dark_frame(bg="#0f172a", border="#334155", radius=3)


def sales_grand_total_frame_style() -> str:
    return """
        QFrame {
            background-color: #064e3b;
            border: 2px solid #10b981;
            border-radius: 4px;
        }
    """


def sales_nav_box_style() -> str:
    return """
        QFrame {
            background-color: transparent;
            border: none;
        }
    """


# ---- Sales Entry button styles ----------------------------------------------

def sales_nav_button_style() -> str:
    return """
        QPushButton {
            background-color: transparent;
            color: #94a3b8;
            border: none;
            font-size: 7px;
            font-weight: bold;
            padding: 0px;
        }
        QPushButton:hover {
            color: #facc15;
            background-color: transparent;
        }
        QPushButton:pressed {
            color: #f1f5f9;
            background-color: transparent;
        }
    """


def sales_compact_button_style() -> str:
    return """
        QPushButton {
            background-color: #334155;
            color: #f1f5f9;
            border: 1px solid #475569;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            padding: 3px 6px;
        }
        QPushButton:hover { background-color: #475569; }
        QPushButton:pressed { background-color: #1e293b; }
    """


def sales_primary_button_style() -> str:
    return """
        QPushButton {
            background-color: #3b82f6;
            color: white;
            border: none;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            padding: 3px 6px;
        }
        QPushButton:hover { background-color: #2563eb; }
        QPushButton:pressed { background-color: #1d4ed8; }
    """


def sales_danger_button_style() -> str:
    return """
        QPushButton {
            background-color: #ef4444;
            color: white;
            border: none;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            padding: 3px 6px;
        }
        QPushButton:hover { background-color: #dc2626; }
        QPushButton:pressed { background-color: #b91c1c; }
    """
