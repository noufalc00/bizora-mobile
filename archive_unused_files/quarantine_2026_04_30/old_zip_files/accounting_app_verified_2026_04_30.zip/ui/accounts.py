"""
Accounts widget for the Accounting Desktop Application.
Manages bank accounts, credit cards, and other financial accounts.
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView
from PySide6.QtCore import Qt

from config import COLORS


class AccountsWidget(QWidget):
    """Accounts widget for managing financial accounts."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup accounts UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header with title and add button
        header_layout = QHBoxLayout()
        
        title = QLabel("Accounts")
        title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 24px;
                font-weight: bold;
            }}
        """)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        add_btn = QPushButton("Add Account")
        add_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        header_layout.addWidget(add_btn)
        
        layout.addLayout(header_layout)
        
        # Accounts table
        self.accounts_table = QTableWidget()
        self.accounts_table.setColumnCount(5)
        self.accounts_table.setHorizontalHeaderLabels(["Account Name", "Type", "Balance", "Currency", "Actions"])
        
        # Style table
        self.accounts_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 8px;
                gridline-color: {COLORS['border']};
                selection-background-color: {COLORS['primary']};
            }}
            QTableWidget::item {{
                padding: 8px;
                color: {COLORS['text_primary']};
            }}
            QTableWidget::item:selected {{
                background-color: {COLORS['primary']};
            }}
            QHeaderView::section {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                padding: 10px;
                border: none;
                font-weight: bold;
            }}
        """)
        
        # Disable inline editing - table is for display with action buttons only
        self.accounts_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        # Set column widths
        header = self.accounts_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        
        # Add sample data
        self.add_sample_accounts()
        
        layout.addWidget(self.accounts_table)
        
        # Summary section
        summary_frame = QFrame()
        summary_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                padding: 16px;
            }}
        """)
        
        summary_layout = QHBoxLayout(summary_frame)
        
        total_balance = QLabel("Total Balance: $12,450.00")
        total_balance.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
            }}
        """)
        summary_layout.addWidget(total_balance)
        
        summary_layout.addStretch()
        
        account_count = QLabel("Accounts: 4")
        account_count.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-size: 14px;
            }}
        """)
        summary_layout.addWidget(account_count)
        
        layout.addWidget(summary_frame)
    
    def add_sample_accounts(self):
        """Add sample account data."""
        accounts = [
            ["Checking Account", "Checking", "$5,230.50", "USD"],
            ["Savings Account", "Savings", "$7,219.50", "USD"],
            ["Credit Card", "Credit", "-$1,250.00", "USD"],
            ["Cash Wallet", "Cash", "$250.00", "USD"]
        ]
        
        self.accounts_table.setRowCount(len(accounts))
        
        for row, account in enumerate(accounts):
            for col, value in enumerate(account):
                item = QTableWidgetItem(value)
                if col == 2:  # Balance column
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.accounts_table.setItem(row, col, item)
            
            # Add action buttons
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(0, 0, 0, 0)
            actions_layout.setSpacing(5)
            
            edit_btn = QPushButton("Edit")
            edit_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['info']};
                    color: white;
                    border: none;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                }}
            """)
            actions_layout.addWidget(edit_btn)
            
            delete_btn = QPushButton("Delete")
            delete_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['error']};
                    color: white;
                    border: none;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                }}
            """)
            actions_layout.addWidget(delete_btn)
            
            self.accounts_table.setCellWidget(row, 4, actions_widget)
