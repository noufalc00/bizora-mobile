"""
Table delegate for Sales Return widget.

Column map (matches SalesReturnHelpersMixin):
  0=SL  1=SalesRate  2=Product  3=HSN  4=CGST%  5=SGST%  6=IGST%  7=CESS%
  8=Rate  9=Qty  10=Gross  11=Disc  12=Net  13=Tax  14=Total

Editable columns  : 8=Rate, 9=Qty, 11=Disc
Read-only calc cols: 10=Gross, 12=Net, 13=Tax, 14=Total

Enter flow  : Qty(9) → Gross(10) → Disc(11) → Product(2) of next row
Esc flow    : Product(2)→barcode | Qty(9)→Rate(8) | Rate(8)→Product(2)
              Gross(10)→Qty(9)   | Disc(11)→Gross(10)
"""

from PySide6.QtWidgets import (
    QStyledItemDelegate, QLineEdit, QAbstractItemDelegate
)
from PySide6.QtCore import Qt, QEvent, QTimer
from PySide6.QtGui import QDoubleValidator

from ui import theme

# Editable columns
_EDIT_COLS = {8, 9, 11}          # Rate, Qty, Disc

# Enter navigation: col → next col (same row), or None = next row Product
_ENTER_NEXT = {
    8: 9,    # Rate  → Qty
    9: 10,   # Qty   → Gross  (read-only, so we just focus it; Gross→Disc handled too)
    10: 11,  # Gross → Disc
    11: None # Disc  → next row Product(2)
}

# Esc navigation: col → (same_row_col | 'barcode')
_ESC_NEXT = {
    2:  'barcode',  # Product → barcode field
    8:  2,          # Rate    → Product same row
    9:  8,          # Qty     → Rate same row
    10: 9,          # Gross   → Qty  same row
    11: 10,         # Disc    → Gross same row
}

_EDITOR_STYLE = f"""
QLineEdit {{
    background-color: #0f172a;
    color: #f1f5f9;
    border: 1px solid #60a5fa;
    border-radius: 2px;
    padding: 2px 4px;
    font-size: 11px;
    font-weight: bold;
}}
"""


class SalesReturnDelegate(QStyledItemDelegate):
    """Delegate that handles Enter/Esc keyboard flow for the Sales Return table."""

    def __init__(self, table_widget, page_widget):
        """
        table_widget : the QTableWidget (items_table)
        page_widget  : the SalesReturnPageWidget (has .barcode_input, .product_input,
                       .focus_table_cell_editor(), .recalculate_row())
        """
        super().__init__(table_widget)
        self._table = table_widget
        self._page = page_widget
        self.current_editor = None
        self.current_index = None

    # ------------------------------------------------------------------ #
    #  Editor creation                                                     #
    # ------------------------------------------------------------------ #

    def createEditor(self, parent, option, index):
        col = index.column()
        if col not in _EDIT_COLS:
            return None                      # non-editable cell
        editor = QLineEdit(parent)
        editor.setStyleSheet(_EDITOR_STYLE)
        validator = QDoubleValidator(0.0, 9_999_999.99, 3)
        validator.setNotation(QDoubleValidator.StandardNotation)
        editor.setValidator(validator)
        return editor

    def setEditorData(self, editor, index):
        value = index.data(Qt.DisplayRole) or ''
        editor.setText(str(value))
        # Select-all after the event loop settles
        QTimer.singleShot(0, editor.selectAll)
        self.current_editor = editor
        self.current_index = index
        # Live recalculation as user types
        col = index.column()
        if col in _EDIT_COLS:
            editor.textChanged.connect(
                lambda text, r=index.row(), c=col: self._on_editor_changed(r, c, text)
            )

    def destroyEditor(self, editor, index):
        self.current_editor = None
        self.current_index = None
        super().destroyEditor(editor, index)

    def _on_editor_changed(self, row, col, text):
        """Live recalculation as user types in an editable cell."""
        if self._page:
            self._page.recalculate_row_live(row, col, text)

    def setModelData(self, editor, model, index):
        text = editor.text().strip()
        try:
            num = float(text)
            model.setData(index, f"{num:.3f}", Qt.EditRole)
        except ValueError:
            pass

    # ------------------------------------------------------------------ #
    #  Key routing                                                         #
    # ------------------------------------------------------------------ #

    def eventFilter(self, editor, event):
        if event.type() != QEvent.KeyPress:
            return super().eventFilter(editor, event)

        key = event.key()

        # ---- Enter / Return ----
        if key in (Qt.Key_Return, Qt.Key_Enter):
            # MUST read row/col BEFORE closeEditor — Qt resets currentIndex after close
            row = self._table.currentIndex().row()
            col = self._table.currentIndex().column()
            self._commit(editor)
            next_col = _ENTER_NEXT.get(col)
            if next_col is None:
                # Disc(11) → next row Product(2)
                next_row = row + 1
                if next_row < self._table.rowCount():
                    QTimer.singleShot(0, lambda r=next_row: self._page.focus_table_cell_editor(r, 2))
                else:
                    QTimer.singleShot(0, self._page.barcode_input.setFocus)
            else:
                # Skip non-editable columns: Gross(10) is read-only, jump straight to Disc(11)
                target = next_col
                while target not in _EDIT_COLS and target in _ENTER_NEXT and _ENTER_NEXT[target] is not None:
                    target = _ENTER_NEXT[target]
                QTimer.singleShot(0, lambda r=row, c=target: self._page.focus_table_cell_editor(r, c))
            return True

        # ---- Escape ----
        if key == Qt.Key_Escape:
            # MUST read row/col BEFORE closeEditor
            row = self._table.currentIndex().row()
            col = self._table.currentIndex().column()
            self._revert(editor)
            dest = _ESC_NEXT.get(col, 'barcode')
            if dest == 'barcode':
                QTimer.singleShot(0, self._page.barcode_input.setFocus)
            else:
                QTimer.singleShot(0, lambda r=row, c=dest: self._page.focus_table_cell_editor(r, c))
            return True

        return super().eventFilter(editor, event)

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    def _commit(self, editor):
        self._table.commitData(editor)
        self._table.closeEditor(editor, QAbstractItemDelegate.SubmitModelCache)

    def _revert(self, editor):
        self._table.closeEditor(editor, QAbstractItemDelegate.RevertModelCache)
