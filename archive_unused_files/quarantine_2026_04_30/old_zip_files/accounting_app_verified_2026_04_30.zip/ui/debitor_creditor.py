"""
Debitor/Creditor widget for the Accounting Desktop Application.
Manages debtors, creditors, and parties with company-wise data storage.
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QTextCursor

from config import COLORS, active_company_manager
from db import Database
from logic.party_logic import PartyLogic
from ui import theme

# Export libraries - safe import handling
PDF_AVAILABLE = False
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
    from reportlab.lib.styles import getSampleStyleSheet
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from docx import Document
    from docx.shared import Pt
    WORD_AVAILABLE = True
except ImportError:
    WORD_AVAILABLE = False

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False


class DebitorCreditorWidget(QWidget):
    # Signal emitted when a party is saved
    party_saved = Signal()

    def __init__(self, db=None):
        super().__init__()
        self.db = db or Database()
        self.party_logic = PartyLogic(self.db)
        self.current_party_id = None
        self.parties_data = []
        self.current_filter = "All"
        self.visible_parties = []
        self.pdf_available = PDF_AVAILABLE
        self.word_available = WORD_AVAILABLE
        self.excel_available = EXCEL_AVAILABLE
        self.setup_ui()
        self.load_parties()
        self.clear_form()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Debitor / Creditor")
        title.setStyleSheet("font-size:24px; font-weight:bold; color:#60a5fa;")
        layout.addWidget(title)

        # Create navigation buttons
        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(0, 10, 0, 10)
        
        self.entry_btn = QPushButton("Party Entry")
        self.entry_btn.setStyleSheet("""
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        self.entry_btn.clicked.connect(self.show_entry_page)
        
        self.list_btn = QPushButton("Party List")
        self.list_btn.setStyleSheet("""
            QPushButton {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
        """)
        self.list_btn.clicked.connect(self.show_list_page)
        
        nav_layout.addWidget(self.entry_btn)
        nav_layout.addWidget(self.list_btn)
        nav_layout.addStretch()
        
        layout.addLayout(nav_layout)

        # Create stacked widget for internal pages
        self.stack_widget = QStackedWidget()
        
        # Create pages
        self.entry_page = self.create_entry_page()
        self.list_page = self.create_list_page()
        
        self.stack_widget.addWidget(self.entry_page)
        self.stack_widget.addWidget(self.list_page)
        
        layout.addWidget(self.stack_widget)

    def show_entry_page(self, clear_form=True):
        """Switch to Party Entry page."""
        self.stack_widget.setCurrentWidget(self.entry_page)
        self.entry_btn.setStyleSheet("""
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        self.list_btn.setStyleSheet("""
            QPushButton {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
        """)
        
        # Clear form when opening normally (not for editing)
        if clear_form:
            self.clear_form()

    def show_list_page(self):
        """Switch to Party List page."""
        self.stack_widget.setCurrentWidget(self.list_page)
        self.list_btn.setStyleSheet("""
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        self.entry_btn.setStyleSheet("""
            QPushButton {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
        """)
        # Refresh party list when switching to list page
        self.load_parties()

    def label(self, text):
        lbl = QLabel(text)
        lbl.setStyleSheet("""
            QLabel {
                color: #fbbf24;
                font-size: 16px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 8px 0px;
                margin: 0px;
                min-height: 24px;
                height: 24px;
            }
        """)
        return lbl

    def create_entry_page(self):
        # Create container without scroll area for compact fit
        container = QFrame()
        container.setStyleSheet("""
            QFrame {
                background-color: #1f2937;
                border-radius: 8px;
                padding: 8px;
            }
        """)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 5, 10, 10)
        layout.setSpacing(3)

        # Master-data field styles (centralised in ui/theme.py)
        compact_input_style = theme.master_input_style()
        wide_input_style = theme.master_wide_input_style()
        extra_wide_input_style = theme.master_extra_wide_input_style()
        compact_label_style = theme.master_label_style()

        # Top Section - Party Name (wide)
        party_name_label = QLabel("Party Name *")
        party_name_label.setStyleSheet(compact_label_style)
        party_name_label.setFixedWidth(100)
        self.party_name_input = QLineEdit()
        self.party_name_input.setStyleSheet(extra_wide_input_style)
        self.party_name_input.textChanged.connect(lambda text: self.on_text_changed(self.party_name_input, text))
        layout.addWidget(party_name_label)
        layout.addWidget(self.party_name_input)
        layout.addSpacing(3)

        # Party Type (wide)
        party_type_label = QLabel("Party Type *")
        party_type_label.setStyleSheet(compact_label_style)
        party_type_label.setFixedWidth(100)
        self.party_type_combo = QComboBox()
        self.party_type_combo.addItems(["Debitor", "Creditor", "Both"])
        self.party_type_combo.setStyleSheet("""
            QComboBox {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                border-radius: 3px;
                padding: 5px 8px;
                font-size: 12px;
                min-height: 18px;
                height: 18px;
                max-width: 210px;
            }
            QComboBox:focus {
                border-color: #60a5fa;
                outline: none;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 4px solid #f3f4f6;
            }
        """)
        layout.addWidget(party_type_label)
        layout.addWidget(self.party_type_combo)
        layout.addSpacing(3)

        # Opening Balance + Mobile Number row
        balance_mobile_row = QHBoxLayout()
        balance_mobile_row.setSpacing(8)
        
        opening_balance_label = QLabel("Opening Balance")
        opening_balance_label.setStyleSheet(compact_label_style)
        opening_balance_label.setFixedWidth(100)
        self.opening_balance_input = QLineEdit()
        self.opening_balance_input.setStyleSheet(compact_input_style)
        self.opening_balance_input.setFixedWidth(120)
        
        mobile_label = QLabel("Mobile Number")
        mobile_label.setStyleSheet(compact_label_style)
        mobile_label.setFixedWidth(80)
        self.mobile_input = QLineEdit()
        self.mobile_input.setStyleSheet(wide_input_style)
        
        balance_mobile_row.addWidget(opening_balance_label)
        balance_mobile_row.addWidget(self.opening_balance_input)
        balance_mobile_row.addSpacing(10)
        balance_mobile_row.addWidget(mobile_label)
        balance_mobile_row.addWidget(self.mobile_input)
        balance_mobile_row.addStretch()
        layout.addLayout(balance_mobile_row)
        layout.addSpacing(3)

        # Email + Credit Limit row
        email_credit_row = QHBoxLayout()
        email_credit_row.setSpacing(8)
        
        email_label = QLabel("Email")
        email_label.setStyleSheet(compact_label_style)
        email_label.setFixedWidth(50)
        self.email_input = QLineEdit()
        self.email_input.setStyleSheet(wide_input_style)
        
        credit_limit_label = QLabel("Credit Limit")
        credit_limit_label.setStyleSheet(compact_label_style)
        credit_limit_label.setFixedWidth(70)
        self.credit_limit_input = QLineEdit()
        self.credit_limit_input.setStyleSheet(compact_input_style)
        self.credit_limit_input.setFixedWidth(120)
        
        email_credit_row.addWidget(email_label)
        email_credit_row.addWidget(self.email_input)
        email_credit_row.addSpacing(10)
        email_credit_row.addWidget(credit_limit_label)
        email_credit_row.addWidget(self.credit_limit_input)
        email_credit_row.addStretch()
        layout.addLayout(email_credit_row)
        layout.addSpacing(3)

        # GSTIN (wide)
        gstin_label = QLabel("GSTIN")
        gstin_label.setStyleSheet(compact_label_style)
        gstin_label.setFixedWidth(50)
        self.gstin_input = QLineEdit()
        self.gstin_input.setStyleSheet(wide_input_style)
        self.gstin_input.setMaxLength(15)
        self.gstin_input.textChanged.connect(self.on_gstin_changed)
        layout.addWidget(gstin_label)
        layout.addWidget(self.gstin_input)
        layout.addSpacing(3)

        # State
        state_label = QLabel("State")
        state_label.setStyleSheet(compact_label_style)
        state_label.setFixedWidth(50)
        self.state_combo = QComboBox()
        self.state_combo.setEditable(True)
        self.state_combo.setStyleSheet(wide_input_style)
        self.state_combo.setFixedWidth(150)
        self.state_combo.addItems([""])
        from .theme import GST_STATE_CODES
        for state in sorted(GST_STATE_CODES.values()):
            self.state_combo.addItem(state)
        layout.addWidget(state_label)
        layout.addWidget(self.state_combo)
        layout.addSpacing(3)

        # Contact Person (extra wide)
        contact_person_label = QLabel("Contact Person")
        contact_person_label.setStyleSheet(compact_label_style)
        contact_person_label.setFixedWidth(100)
        self.contact_person_input = QLineEdit()
        self.contact_person_input.setStyleSheet(extra_wide_input_style)
        self.contact_person_input.textChanged.connect(lambda text: self.on_text_changed(self.contact_person_input, text))
        layout.addWidget(contact_person_label)
        layout.addWidget(self.contact_person_input)
        layout.addSpacing(3)

        # Address (extra wide)
        address_label = QLabel("Address")
        address_label.setStyleSheet(compact_label_style)
        address_label.setFixedWidth(80)
        self.address_input = QLineEdit()
        self.address_input.setStyleSheet(extra_wide_input_style)
        self.address_input.textChanged.connect(lambda text: self.on_text_changed(self.address_input, text))
        layout.addWidget(address_label)
        layout.addWidget(self.address_input)
        layout.addSpacing(3)

        # Notes (extra wide)
        notes_label = QLabel("Notes")
        notes_label.setStyleSheet(compact_label_style)
        notes_label.setFixedWidth(50)
        self.notes_input = QLineEdit()
        self.notes_input.setStyleSheet(extra_wide_input_style)
        self.notes_input.textChanged.connect(lambda text: self.on_text_changed(self.notes_input, text))
        layout.addWidget(notes_label)
        layout.addWidget(self.notes_input)
        layout.addSpacing(3)

        # Action buttons row
        actions_row = QHBoxLayout()
        actions_row.setSpacing(5)
        
        self.save_btn = QPushButton("Save")
        self.save_btn.setObjectName("save_btn")
        self.save_btn.clicked.connect(self.save)
        self.save_btn.setStyleSheet("""
            QPushButton {
                background-color: #10b981;
                color: white;
                border: none;
                padding: 6px 16px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
                min-height: 16px;
                height: 16px;
            }
            QPushButton:hover {
                background-color: #059669;
            }
            QPushButton:pressed {
                background-color: #047857;
            }
        """)
        
        clear_btn = QPushButton("Clear")
        clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #6b7280;
                color: white;
                border: none;
                padding: 6px 16px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
                min-height: 16px;
                height: 16px;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
            QPushButton:pressed {
                background-color: #374151;
            }
        """)
        clear_btn.clicked.connect(self.clear_form)
        
        actions_row.addWidget(self.save_btn)
        actions_row.addWidget(clear_btn)
        actions_row.addStretch()
        
        layout.addLayout(actions_row)
        layout.addStretch()

        return container

    def create_list_page(self):
        # Create container for the list page
        container = QFrame()
        container.setObjectName("partyListOuterFrame")
        container.setStyleSheet("""
            QFrame#partyListOuterFrame {
                background-color: #1f2937;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        list_title = QLabel("Party List")
        list_title.setStyleSheet("""
            QLabel {
                color: #fbbf24;
                font-size: 18px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        layout.addWidget(list_title)

        # Search and filter row
        search_filter_layout = QHBoxLayout()
        search_filter_layout.setContentsMargins(0, 0, 0, 10)

        search_label = QLabel("Search:")
        search_label.setStyleSheet("""
            QLabel {
                color: #fbbf24;
                font-size: 14px;
                font-weight: bold;
                background: transparent;
                border: none;
                margin-right: 10px;
            }
        """)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by party name or mobile number...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 14px;
                min-width: 250px;
            }
            QLineEdit:focus {
                border-color: #60a5fa;
                outline: none;
            }
        """)
        self.search_input.textChanged.connect(self.apply_filters)

        filter_label = QLabel("Filter:")
        filter_label.setStyleSheet("""
            QLabel {
                color: #fbbf24;
                font-size: 14px;
                font-weight: bold;
                background: transparent;
                border: none;
                margin-left: 15px;
                margin-right: 10px;
            }
        """)

        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["All", "Debitor", "Creditor"])
        self.filter_combo.setStyleSheet("""
            QComboBox {
                background-color: #374151;
                color: #f3f4f6;
                border: 1px solid #4b5563;
                border-radius: 6px;
                padding: 8px 12px;
                font-size: 14px;
                min-width: 120px;
            }
            QComboBox:focus {
                border-color: #60a5fa;
                outline: none;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 4px solid #f3f4f6;
            }
        """)
        self.filter_combo.currentTextChanged.connect(self.on_filter_changed)

        export_btn = QPushButton("Export")
        export_btn.setStyleSheet("""
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        export_btn.clicked.connect(self.show_export_menu)

        search_filter_layout.addWidget(search_label)
        search_filter_layout.addWidget(self.search_input)
        search_filter_layout.addWidget(filter_label)
        search_filter_layout.addWidget(self.filter_combo)
        search_filter_layout.addWidget(export_btn)
        search_filter_layout.addStretch()
        layout.addLayout(search_filter_layout)

        # Table container
        table_container = QFrame()
        table_container.setObjectName("partyListTableContainer")
        table_container.setStyleSheet("""
            QFrame#partyListTableContainer {
                background-color: #1f2937;
                border: 1px solid #4b5563;
                border-radius: 6px;
            }
        """)

        table_layout = QVBoxLayout(table_container)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.setSpacing(0)

        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "SL No",
            "Party Name",
            "Party Type",
            "Opening Balance",
            "Mobile Number",
            "Email"
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.on_table_selection_changed)
        self.table.itemDoubleClicked.connect(self.on_table_double_click)
        self.table.setCornerButtonEnabled(False)
        self.table.verticalHeader().setVisible(False)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_party_list_context_menu)

        # Make table fully flat
        self.table.setFrameShape(QFrame.NoFrame)
        self.table.setFrameShadow(QFrame.Plain)
        self.table.setLineWidth(0)
        self.table.setMidLineWidth(0)
        self.table.setContentsMargins(0, 0, 0, 0)
        self.table.setViewportMargins(0, 0, 0, 0)

        self.table.setStyleSheet("""
            QTableWidget {
                background-color: #1f2937;
                color: #f3f4f6;
                border: none;
                gridline-color: #4b5563;
                selection-background-color: #60a5fa;
                selection-color: white;
                font-size: 14px;
            }
            QTableWidget::item {
                padding: 6px;
                border-bottom: 1px solid #4b5563;
            }
            QTableWidget::item:selected {
                background-color: #60a5fa;
                color: white;
            }
            QHeaderView::section {
                background-color: #374151;
                color: #fbbf24;
                font-weight: bold;
                font-size: 14px;
                border: none;
                border-right: 1px solid #4b5563;
                border-bottom: 1px solid #4b5563;
                padding-left: 8px;
                padding-right: 8px;
            }
            QTableCornerButton::section {
                background-color: #374151;
                border: none;
            }
        """)

        header = self.table.horizontalHeader()
        header.setVisible(True)
        header.setFixedHeight(36)
        header.setMinimumHeight(36)
        header.setDefaultSectionSize(36)
        header.setHighlightSections(False)
        header.setDefaultAlignment(Qt.AlignCenter)
        header.setStretchLastSection(False)
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setMinimumSectionSize(60)

        # Set fixed column widths as specified
        self.table.setColumnWidth(0, 80)   # SL No
        self.table.setColumnWidth(1, 260)  # Party Name
        self.table.setColumnWidth(2, 140)  # Party Type
        self.table.setColumnWidth(3, 140)  # Opening Balance
        self.table.setColumnWidth(4, 150)  # Mobile Number
        self.table.setColumnWidth(5, 220)  # Email
        table_layout.addWidget(self.table)
        layout.addWidget(table_container)

        # Action buttons
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(0, 10, 0, 0)

        edit_btn = QPushButton("Edit Selected")
        edit_btn.setStyleSheet("""
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        edit_btn.clicked.connect(self.edit_selected_party)

        delete_btn = QPushButton("Delete Selected")
        delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #ef4444;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #dc2626;
            }
        """)
        delete_btn.clicked.connect(self.delete_selected_party)

        button_layout.addWidget(edit_btn)
        button_layout.addWidget(delete_btn)
        button_layout.addStretch()

        layout.addLayout(button_layout)

        return container

    def on_text_changed(self, widget, text):
        """Handle text change to capitalize first letter for relevant fields."""
        if widget and hasattr(widget, 'cursorPosition'):
            cursor_pos = widget.cursorPosition()
            # Capitalize first letter
            capitalized_text = self.capitalize_first_letter(text)
            # Update text without disturbing cursor
            if capitalized_text != text:
                widget.blockSignals(True)
                widget.setText(capitalized_text)
                widget.setCursorPosition(cursor_pos)
                widget.blockSignals(False)

    def on_gstin_changed(self, text):
        """Handle GSTIN text change to convert to uppercase and auto-fill state."""
        if self.gstin_input and hasattr(self.gstin_input, 'cursorPosition'):
            cursor_pos = self.gstin_input.cursorPosition()
            uppercase_text = text.upper()
            if uppercase_text != text:
                self.gstin_input.blockSignals(True)
                self.gstin_input.setText(uppercase_text)
                self.gstin_input.setCursorPosition(cursor_pos)
                self.gstin_input.blockSignals(False)

            # Auto-fill State from GSTIN first two digits
            if len(uppercase_text) >= 2 and hasattr(self, 'state_combo'):
                from .theme import GST_STATE_CODES
                state_code = uppercase_text[:2]
                if state_code in GST_STATE_CODES:
                    derived_state = GST_STATE_CODES[state_code]
                    current_state = self.state_combo.currentText()
                    if not current_state:  # Only auto-fill if state is empty
                        self.state_combo.blockSignals(True)
                        self.state_combo.setCurrentText(derived_state)
                        self.state_combo.blockSignals(False)

    def capitalize_first_letter(self, text):
        """Capitalize the first letter of the text."""
        if not text:
            return text
        return text[0].upper() + text[1:]

    def clear_form(self):
        self.party_name_input.clear()
        self.party_type_combo.setCurrentIndex(0)
        self.opening_balance_input.clear()
        self.mobile_input.clear()
        self.email_input.clear()
        self.gstin_input.clear()
        self.state_combo.setCurrentIndex(0)
        self.credit_limit_input.clear()
        self.contact_person_input.clear()
        self.address_input.clear()
        self.notes_input.clear()
        self.current_party_id = None
        # Reset save button text to "Save"
        if hasattr(self, 'save_btn'):
            self.save_btn.setText("Save")

    def save(self):
        # Check if company is active
        active_company = active_company_manager.get_active_company()
        if not active_company:
            QMessageBox.warning(self, "No Active Company", "Please open a company first.")
            return
        
        # Validate required fields
        party_name = self.party_name_input.text().strip()
        if not party_name:
            QMessageBox.warning(self, "Validation Error", "Party Name is required.")
            self.party_name_input.setFocus()
            return

        party_type = self.party_type_combo.currentText()
        if not party_type:
            QMessageBox.warning(self, "Validation Error", "Party Type is required.")
            self.party_type_combo.setFocus()
            return

        try:
            # Collect party data
            party_data = {
                'name': party_name,
                'party_type': party_type,
                'opening_balance': self.opening_balance_input.text() or "0",
                'mobile_number': self.mobile_input.text().strip(),
                'email': self.email_input.text().strip(),
                'gstin': self.gstin_input.text().strip(),
                'state': self.state_combo.currentText().strip(),
                'credit_limit': self.credit_limit_input.text() or "0",
                'contact_person': self.contact_person_input.text().strip(),
                'address': self.address_input.text().strip(),
                'notes': self.notes_input.text().strip()
            }

            # Validate party data
            validation_result = self.party_logic.validate_party_data(
                party_data, self.current_party_id, active_company['id']
            )
            
            if not validation_result['success']:
                QMessageBox.warning(self, "Validation Error", validation_result['message'])
                return

            # Save party
            save_result = self.party_logic.save_party(
                active_company['id'], party_data, self.current_party_id
            )
            
            if save_result['success']:
                QMessageBox.information(self, "Success", "Party saved successfully.")
                self.clear_form()
                # Set focus to Party Name field after clear
                QTimer.singleShot(0, lambda: self.party_name_input.setFocus())
                # Refresh party list in background
                self.load_parties()
                # Emit signal to notify other widgets
                self.party_saved.emit()
            else:
                QMessageBox.warning(self, "Error", save_result['message'])

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save party: {str(e)}")

    def load_parties(self):
        """Load all parties from database into memory."""
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                self.parties_data = []
                self.visible_parties = []
                self.render_parties([])
                return

            result = self.party_logic.get_parties(active_company['id'])
            
            if result['success']:
                self.parties_data = result['data']
                # Apply filters to set visible parties
                self.apply_filters()
            else:
                QMessageBox.critical(self, "Error", result['message'])
                self.parties_data = []
                self.visible_parties = []
                self.render_parties([])

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load parties: {str(e)}")
            self.parties_data = []
            self.visible_parties = []
            self.render_parties([])

    def render_parties(self, parties):
        """Render parties in table."""
        self.table.setRowCount(len(parties))

        for row, party in enumerate(parties):
            sl_no_item = QTableWidgetItem(str(row + 1))
            sl_no_item.setData(Qt.UserRole, party['id'])
            self.table.setItem(row, 0, sl_no_item)

            name_item = QTableWidgetItem(party['name'])
            name_item.setData(Qt.UserRole, party['id'])
            self.table.setItem(row, 1, name_item)

            party_type_item = QTableWidgetItem(party['party_type'])
            party_type_item.setData(Qt.UserRole, party['id'])
            self.table.setItem(row, 2, party_type_item)

            opening_balance = float(party['opening_balance'] or 0)
            balance_item = QTableWidgetItem(f"{opening_balance:.2f}")
            balance_item.setData(Qt.UserRole, party['id'])
            balance_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 3, balance_item)

            mobile_item = QTableWidgetItem(party['mobile_number'] or "")
            mobile_item.setData(Qt.UserRole, party['id'])
            self.table.setItem(row, 4, mobile_item)

            email_item = QTableWidgetItem(party['email'] or "")
            email_item.setData(Qt.UserRole, party['id'])
            self.table.setItem(row, 5, email_item)

    def on_filter_changed(self, filter_value):
        """Handle filter dropdown change."""
        self.current_filter = filter_value
        self.apply_filters()

    def apply_filters(self):
        """Apply both search and filter to parties."""
        search_term = self.search_input.text().strip()
        filter_value = self.current_filter
        
        filtered_parties = []
        
        for party in self.parties_data:
            # Apply party type filter
            if filter_value != "All":
                if party['party_type'] != filter_value:
                    continue
            
            # Apply search filter
            if search_term:
                name_match = search_term.lower() in (party['name'] or "").lower()
                mobile_match = search_term.lower() in (party['mobile_number'] or "").lower()
                if not (name_match or mobile_match):
                    continue
            
            filtered_parties.append(party)
        
        self.visible_parties = filtered_parties
        self.render_parties(filtered_parties)
    
    def on_table_selection_changed(self):
        """Handle table row selection change."""
        pass

    def on_table_double_click(self, item):
        """Handle double-click on table row to edit party."""
        self.edit_selected_party()

    def edit_selected_party(self):
        """Edit the selected party by switching to entry page."""
        selected_items = self.table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a party to edit.")
            return

        # Get party ID from UserRole data of the first selected item
        party_id = selected_items[0].data(Qt.UserRole)
        if not party_id:
            QMessageBox.warning(self, "Error", "Unable to identify selected party.")
            return
        
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return
            
            result = self.party_logic.get_party_by_id(active_company['id'], party_id)
            
            if result['success'] and result['data']:
                self.load_party_to_form(result['data'])
                self.show_entry_page(clear_form=False)
            else:
                QMessageBox.warning(self, "Error", "Party not found.")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load party: {str(e)}")

    def delete_selected_party(self):
        """Delete the selected party."""
        selected_items = self.table.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a party to delete.")
            return

        # Get party ID and name from selected row
        party_id = selected_items[0].data(Qt.UserRole)
        selected_row = self.table.currentRow()
        party_name_item = self.table.item(selected_row, 1)
        party_name = party_name_item.text() if party_name_item else "selected party"
        
        if not party_id:
            QMessageBox.warning(self, "Error", "Unable to identify selected party.")
            return
        
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return
            
            # Confirm deletion
            reply = QMessageBox.question(
                self, "Confirm Delete",
                f"Are you sure you want to delete '{party_name}'?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                result = self.party_logic.delete_party(active_company['id'], party_id)
                
                if result['success']:
                    QMessageBox.information(self, "Success", "Party deleted successfully.")
                    # Refresh party list and reapply filters
                    self.load_parties()
                else:
                    QMessageBox.warning(self, "Error", result['message'])
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to delete party: {str(e)}")

    def load_party_to_form(self, party):
        """Load party data into form fields."""
        self.current_party_id = party['id']
        self.party_name_input.setText(party['name'])
        self.party_type_combo.setCurrentText(party['party_type'])
        self.opening_balance_input.setText(str(party['opening_balance']))
        self.mobile_input.setText(party['mobile_number'] or "")
        self.email_input.setText(party['email'] or "")
        self.gstin_input.setText(party['gstin'] or "")
        self.state_combo.setCurrentText(party.get('state', ''))
        self.credit_limit_input.setText(str(party['credit_limit']))
        self.contact_person_input.setText(party['contact_person'] or "")
        self.address_input.setText(party['address'] or "")
        self.notes_input.setText(party['notes'] or "")

    def load_party_for_edit(self, party_id):
        """Load party by ID for editing from Purchase Entry."""
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            result = self.party_logic.get_party_by_id(active_company['id'], party_id)
            if result['success'] and result['data']:
                party = result['data']
                self.load_party_to_form(party)
                # Change button text to Update
                if hasattr(self, 'save_btn'):
                    self.save_btn.setText("Update")
        except Exception as e:
            print(f"Error loading party for edit: {e}")

    def keyPressEvent(self, event):
        """Handle key press events for Enter and Esc navigation."""
        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            # Get current focus widget
            focus_widget = self.focusWidget()
            
            # Define tab order for form fields
            field_order = [
                self.party_name_input,
                self.party_type_combo,
                self.opening_balance_input,
                self.mobile_input,
                self.email_input,
                self.credit_limit_input,
                self.gstin_input,
                self.contact_person_input,
                self.address_input,
                self.notes_input
            ]
            
            if focus_widget in field_order:
                # Normal field navigation
                current_index = field_order.index(focus_widget)
                if current_index < len(field_order) - 1:
                    next_field = field_order[current_index + 1]
                    self.focus_and_force_select(next_field)
                else:
                    # If at last field, trigger save
                    self.save()
            elif focus_widget == self.save_btn:
                # If Save button has focus, trigger save
                self.save()
        elif event.key() == Qt.Key_Escape:
            # Get current focus widget
            focus_widget = self.focusWidget()
            
            # If Save button has focus, move back to Notes
            if focus_widget == self.save_btn:
                self.focus_and_force_select(self.notes_input)
                return
            
            # Define tab order for form fields
            field_order = [
                self.party_name_input,
                self.party_type_combo,
                self.opening_balance_input,
                self.mobile_input,
                self.email_input,
                self.credit_limit_input,
                self.gstin_input,
                self.contact_person_input,
                self.address_input,
                self.notes_input
            ]
            
            # Find current field in order and move to previous
            if focus_widget in field_order:
                current_index = field_order.index(focus_widget)
                if current_index > 0:
                    prev_field = field_order[current_index - 1]
                    self.focus_and_force_select(prev_field)
        else:
            super().keyPressEvent(event)

    def focus_and_force_select(self, widget):
        """Set focus and select all text with proper timing."""
        widget.setFocus()
        # QComboBox doesn't have selectAll(), only QLineEdit does
        if isinstance(widget, QLineEdit):
            QTimer.singleShot(0, widget.selectAll)

    def focus_and_select(self, widget):
        """Set focus and select all text with proper timing."""
        widget.setFocus()
        # QComboBox doesn't have selectAll(), only QLineEdit does
        if isinstance(widget, QLineEdit):
            QTimer.singleShot(0, widget.selectAll)

    def show_party_list_context_menu(self, position):
        """Show context menu for party list table."""
        menu = QMenu(self)
        
        select_all_action = menu.addAction("Select All")
        select_all_action.triggered.connect(self.select_all_visible_rows)
        
        clear_selection_action = menu.addAction("Clear Selection")
        clear_selection_action.triggered.connect(self.clear_selection)
        
        menu.exec(self.table.mapToGlobal(position))

    def select_all_visible_rows(self):
        """Select all visible rows in the table."""
        self.table.selectAll()

    def clear_selection(self):
        """Clear all selections in the table."""
        self.table.clearSelection()

    def get_visible_table_data(self):
        """Extract visible table data for export."""
        data = []
        headers = []

        for col in range(self.table.columnCount()):
            headers.append(self.table.horizontalHeaderItem(col).text())

        for row in range(self.table.rowCount()):
            row_data = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                row_data.append(item.text() if item else "")
            data.append(row_data)

        return headers, data

    def show_export_menu(self):
        """Show export format selection dialog."""
        if not self.visible_parties:
            QMessageBox.warning(self, "No Data", "No parties to export.")
            return
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Export Party List")
        dialog.setStyleSheet("""
            QDialog {
                background-color: #1f2937;
            }
            QLabel {
                color: #f3f4f6;
                font-size: 14px;
            }
            QPushButton {
                background-color: #60a5fa;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
            QPushButton:pressed {
                background-color: #2563eb;
            }
            QPushButton:disabled {
                background-color: #4b5563;
                color: #9ca3af;
            }
            QPushButton:checked {
                background-color: #3b82f6;
                border: 2px solid #60a5fa;
            }
        """)
        dialog.setFixedSize(350, 150)
        
        layout = QVBoxLayout(dialog)
        layout.setSpacing(15)
        
        title_label = QLabel("Select Export Format:")
        title_label.setStyleSheet("font-weight: bold; font-size: 16px; color: #fbbf24;")
        layout.addWidget(title_label)
        
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)
        
        pdf_btn = QPushButton("PDF")
        pdf_btn.setCheckable(True)
        pdf_btn.setEnabled(self.pdf_available)
        pdf_btn.clicked.connect(lambda: self.export_to_pdf(dialog))
        
        excel_btn = QPushButton("Excel")
        excel_btn.setCheckable(True)
        excel_btn.setEnabled(self.excel_available)
        excel_btn.clicked.connect(lambda: self.export_to_excel(dialog))
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(dialog.reject)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #6b7280;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #4b5563;
            }
        """)
        
        button_layout.addWidget(pdf_btn)
        button_layout.addWidget(excel_btn)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
        
        dialog.exec()

    def export_to_pdf(self, dialog=None):
        """Export visible parties to PDF."""
        if not self.pdf_available:
            QMessageBox.warning(
                self,
                "Library Not Installed",
                "Required library not installed.\n\nTo enable PDF export, install:\npip install reportlab"
            )
            return
        
        try:
            headers, data = self.get_visible_table_data()
            
            if not data:
                QMessageBox.warning(self, "No Data", "No data available to export.")
                return
            
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save PDF", "party_list.pdf", "PDF Files (*.pdf)"
            )
            if not file_path:
                return
            
            table_data = [headers] + data
            
            doc = SimpleDocTemplate(file_path, pagesize=letter)
            table = Table(table_data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
            ]))
            
            doc.build([table])
            
            QMessageBox.information(self, "Success", "PDF exported successfully.")
            if dialog:
                dialog.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to export PDF: {str(e)}")

    def export_to_excel(self, dialog=None):
        """Export visible parties to Excel."""
        if not self.excel_available:
            QMessageBox.warning(
                self,
                "Library Not Installed",
                "Required library not installed.\n\nTo enable Excel export, install:\npip install openpyxl"
            )
            return
        
        try:
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save Excel", "party_list.xlsx", "Excel Files (*.xlsx)"
            )
            if not file_path:
                return
            
            wb = Workbook()
            ws = wb.active
            ws.title = "Party List"
            
            # Headers
            headers = ["SL No", "Party Name", "Party Type", "Opening Balance", "Mobile Number", "Email"]
            ws.append(headers)
            
            # Style headers
            header_fill = PatternFill(start_color="374151", end_color="374151", fill_type="solid")
            header_font = Font(bold=True, color="FFFFFF", size=12)
            border = Border(
                left=Side(style='thin', color='4b5563'),
                right=Side(style='thin', color='4b5563'),
                top=Side(style='thin', color='4b5563'),
                bottom=Side(style='thin', color='4b5563')
            )
            
            for col in range(1, 7):
                cell = ws.cell(row=1, column=col)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border
            
            # Data
            for idx, party in enumerate(self.visible_parties):
                row = idx + 2
                ws.cell(row=row, column=1, value=idx + 1)
                ws.cell(row=row, column=2, value=party['name'] or "")
                ws.cell(row=row, column=3, value=party['party_type'] or "")
                ws.cell(row=row, column=4, value=float(party['opening_balance'] or 0))
                ws.cell(row=row, column=5, value=party['mobile_number'] or "")
                ws.cell(row=row, column=6, value=party['email'] or "")
                
                # Style data cells
                for col in range(1, 7):
                    cell = ws.cell(row=row, column=col)
                    cell.border = border
                    if col == 4:  # Opening Balance - right align
                        cell.alignment = Alignment(horizontal='right', vertical='center')
                    else:
                        cell.alignment = Alignment(horizontal='left', vertical='center')
            
            # Adjust column widths
            ws.column_dimensions['A'].width = 10
            ws.column_dimensions['B'].width = 30
            ws.column_dimensions['C'].width = 15
            ws.column_dimensions['D'].width = 15
            ws.column_dimensions['E'].width = 18
            ws.column_dimensions['F'].width = 25
            
            wb.save(file_path)
            QMessageBox.information(self, "Success", "Excel file exported successfully.")
            if dialog:
                dialog.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to export Excel: {str(e)}")
