"""
Popup components for Sales Return widget.
- Party popup: search Debtor/Both parties, dark theme, no preload.
- Product popup: limited search (max 100 results), no preload on open, dark theme.
- Double-click or Enter selects. Prevents duplicate product add guard is in caller.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QComboBox, QPushButton, QTableWidget, QTableWidgetItem,
    QAbstractItemView, QMessageBox, QHeaderView
)
from PySide6.QtCore import Qt, QTimer


_POPUP_STYLE = """
QDialog {
    background-color: #0f172a;
    color: #f1f5f9;
}
QLabel {
    color: #facc15;
    font-size: 11px;
    font-weight: bold;
}
QLineEdit, QComboBox {
    background-color: #1e293b;
    border: 1px solid #475569;
    border-radius: 3px;
    color: #f1f5f9;
    font-size: 11px;
    padding: 3px 6px;
}
QLineEdit:focus, QComboBox:focus {
    border: 1px solid #60a5fa;
}
QTableWidget {
    background-color: #1e293b;
    color: #f1f5f9;
    gridline-color: #334155;
    border: 1px solid #334155;
    font-size: 11px;
    selection-background-color: #1d4ed8;
    selection-color: #ffffff;
}
QTableWidget::item { padding: 3px; }
QTableWidget::item:selected {
    background-color: #1d4ed8;
    color: #ffffff;
}
QHeaderView::section {
    background-color: #334155;
    color: #f1f5f9;
    font-size: 10px;
    font-weight: bold;
    padding: 3px;
    border: 1px solid #475569;
}
QPushButton {
    background-color: #334155;
    color: #f1f5f9;
    border: 1px solid #475569;
    border-radius: 3px;
    font-size: 11px;
    padding: 5px 12px;
}
QPushButton:hover { background-color: #475569; }
"""

_SELECT_BTN_STYLE = """
QPushButton {
    background-color: #3b82f6;
    color: white;
    border: none;
    border-radius: 3px;
    font-size: 11px;
    font-weight: bold;
    padding: 5px 14px;
}
QPushButton:hover { background-color: #2563eb; }
"""


class SalesReturnPopupMixin:
    """Mixin class containing popup methods for Sales Return."""

    # ==================== PARTY POPUP ====================

    def show_party_popup(self):
        company_id = self.get_current_company_id()
        if not company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        popup = QDialog(self)
        popup.setWindowTitle("Select Customer / Debtor")
        popup.resize(560, 420)
        popup.setStyleSheet(_POPUP_STYLE)
        layout = QVBoxLayout(popup)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(6)

        top = QHBoxLayout()
        search_lbl = QLabel("Search:")
        search_input = QLineEdit()
        search_input.setPlaceholderText("Name or mobile…")
        search_input.setFixedWidth(250)
        type_lbl = QLabel("Type:")
        type_filter = QComboBox()
        type_filter.addItems(["Debitor", "Both", "All"])
        type_filter.setFixedWidth(100)
        top.addWidget(search_lbl)
        top.addWidget(search_input)
        top.addSpacing(10)
        top.addWidget(type_lbl)
        top.addWidget(type_filter)
        top.addStretch()
        layout.addLayout(top)

        tbl = QTableWidget()
        tbl.setColumnCount(4)
        tbl.setHorizontalHeaderLabels(["Name", "Mobile", "Type", "GSTIN"])
        tbl.verticalHeader().setVisible(False)
        tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.horizontalHeader().setStretchLastSection(True)
        tbl.setColumnWidth(0, 180)
        tbl.setColumnWidth(1, 110)
        tbl.setColumnWidth(2, 80)
        layout.addWidget(tbl)

        def do_search():
            search_text = search_input.text().strip()
            type_text = type_filter.currentText()
            tbl.setRowCount(0)
            parties = self.db.get_parties_by_company(company_id)
            for party in parties:
                ptype = party.get('party_type', '')
                if type_text == "Debitor" and ptype not in ("Debitor", "debitor", "Debtor", "debtor"):
                    continue
                elif type_text == "Both" and ptype not in ("Both", "both"):
                    continue
                name = party.get('name', '')
                mobile = str(party.get('mobile_number', '') or '')
                if search_text and (search_text.lower() not in name.lower()
                                    and search_text.lower() not in mobile.lower()):
                    continue
                row = tbl.rowCount()
                tbl.insertRow(row)
                name_item = QTableWidgetItem(name)
                name_item.setData(Qt.UserRole, party.get('id'))
                tbl.setItem(row, 0, name_item)
                tbl.setItem(row, 1, QTableWidgetItem(mobile))
                tbl.setItem(row, 2, QTableWidgetItem(ptype))
                tbl.setItem(row, 3, QTableWidgetItem(str(party.get('gstin', '') or '')))
            if tbl.rowCount() > 0:
                tbl.selectRow(0)

        do_search()
        search_input.textChanged.connect(do_search)
        type_filter.currentTextChanged.connect(do_search)
        search_input.setFocus()

        def select_party():
            row = tbl.currentRow()
            if row < 0:
                return
            party_id = tbl.item(row, 0).data(Qt.UserRole)
            self.current_party_id = party_id
            company_id2 = self.get_current_company_id()
            party_data = self.db.get_party_by_id(company_id2, party_id) if company_id2 else None
            if party_data:
                self.populate_party_details(party_data)
            else:
                self.customer_name_input.blockSignals(True)
                self.customer_name_input.setText(tbl.item(row, 0).text())
                self.customer_name_input.blockSignals(False)
            popup.accept()

        tbl.doubleClicked.connect(select_party)

        btns = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(popup.reject)
        select_btn = QPushButton("Select")
        select_btn.setStyleSheet(_SELECT_BTN_STYLE)
        select_btn.clicked.connect(select_party)
        btns.addStretch()
        btns.addWidget(cancel_btn)
        btns.addWidget(select_btn)
        layout.addLayout(btns)

        def key_press(event):
            if event.key() in (Qt.Key_Return, Qt.Key_Enter):
                select_party()
            elif event.key() == Qt.Key_Escape:
                popup.reject()
            else:
                QDialog.keyPressEvent(popup, event)

        popup.keyPressEvent = key_press
        popup.exec()

    # ==================== PRODUCT POPUP ====================

    def show_product_popup(self):
        company_id = self.get_current_company_id()
        if not company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        popup = QDialog(self)
        popup.setWindowTitle("Select Product")
        popup.resize(620, 440)
        popup.setStyleSheet(_POPUP_STYLE)
        layout = QVBoxLayout(popup)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(6)

        top = QHBoxLayout()
        search_lbl = QLabel("Search (name / barcode):")
        search_input = QLineEdit()
        search_input.setPlaceholderText("Type at least 1 character…")
        top.addWidget(search_lbl)
        top.addWidget(search_input)
        layout.addLayout(top)

        hint = QLabel("Type to search. Max 100 results shown.")
        hint.setStyleSheet("color: #64748b; font-size: 10px;")
        layout.addWidget(hint)

        tbl = QTableWidget()
        tbl.setColumnCount(5)
        tbl.setHorizontalHeaderLabels(["Name", "Barcode", "Code", "Rate", "Stock"])
        tbl.verticalHeader().setVisible(False)
        tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setColumnWidth(0, 220)
        tbl.setColumnWidth(1, 110)
        tbl.setColumnWidth(2, 80)
        tbl.setColumnWidth(3, 80)
        tbl.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(tbl)

        _search_timer = QTimer()
        _search_timer.setSingleShot(True)
        _search_timer.setInterval(200)

        def do_search():
            term = search_input.text().strip()
            tbl.setRowCount(0)
            if not term:
                return
            results = self.db.search_products_limited(company_id, term, limit=100)
            tbl.setUpdatesEnabled(False)
            tbl.blockSignals(True)
            for product in results:
                row = tbl.rowCount()
                tbl.insertRow(row)
                name_item = QTableWidgetItem(product.get('name', ''))
                name_item.setData(Qt.UserRole, product.get('id'))
                tbl.setItem(row, 0, name_item)
                tbl.setItem(row, 1, QTableWidgetItem(str(product.get('barcode', '') or '')))
                tbl.setItem(row, 2, QTableWidgetItem(str(product.get('code', '') or '')))
                rate = float(product.get('sale_price') or product.get('mrp') or
                             product.get('wholesale_rate') or product.get('purchase_rate') or 0.0)
                tbl.setItem(row, 3, QTableWidgetItem(f"{rate:.2f}"))
                # quantity already computed by search_products_limited SQL subquery
                stock = float(product.get('quantity') or 0.0)
                tbl.setItem(row, 4, QTableWidgetItem(f"{stock:.3f}"))
            tbl.blockSignals(False)
            tbl.setUpdatesEnabled(True)
            if tbl.rowCount() > 0:
                tbl.selectRow(0)

        _search_timer.timeout.connect(do_search)
        search_input.textChanged.connect(lambda: _search_timer.start())
        # Pre-seed with whatever is already typed in product_input
        initial_term = self.product_input.text().strip() if hasattr(self, 'product_input') else ''
        search_input.setText(initial_term)
        search_input.setFocus()
        if initial_term:
            search_input.selectAll()

        def select_product():
            row = tbl.currentRow()
            if row < 0:
                return
            product_id = tbl.item(row, 0).data(Qt.UserRole)
            product_name = tbl.item(row, 0).text()
            try:
                stock_val = float(tbl.item(row, 4).text())
            except (ValueError, AttributeError):
                stock_val = 0.0
            try:
                rate_val = float(tbl.item(row, 3).text())
            except (ValueError, AttributeError):
                rate_val = 0.0
            code_val = tbl.item(row, 2).text() if tbl.item(row, 2) else ''

            self._popup_product_selected = True
            self.current_product_id = product_id
            company_id2 = self.get_current_company_id()
            full_product = self.db.get_product_by_id(company_id2, product_id) if company_id2 else None
            if full_product:
                self.current_product_data = full_product
            else:
                self.current_product_data = {
                    'id': product_id, 'name': product_name,
                    'rate': rate_val, 'code': code_val
                }

            self.product_input.blockSignals(True)
            self.product_input.setText(product_name)
            self.product_input.blockSignals(False)
            self.stock_display.setText(f"{stock_val:.3f}")
            self.code_display.setText(code_val)
            popup.accept()
            self.add_product_to_items()

        tbl.doubleClicked.connect(select_product)

        btns = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(popup.reject)
        select_btn = QPushButton("Select")
        select_btn.setStyleSheet(_SELECT_BTN_STYLE)
        select_btn.clicked.connect(select_product)
        btns.addStretch()
        btns.addWidget(cancel_btn)
        btns.addWidget(select_btn)
        layout.addLayout(btns)

        def key_press(event):
            if event.key() in (Qt.Key_Return, Qt.Key_Enter):
                select_product()
            elif event.key() == Qt.Key_Escape:
                popup.reject()
            else:
                QDialog.keyPressEvent(popup, event)

        popup.keyPressEvent = key_press
        popup.exec()

    # ==================== DEBITOR BUTTONS ====================

    def add_new_debitor(self):
        QMessageBox.information(self, "Info",
                                "Add New Debtor - open Debitor/Creditor module to add.")

    def edit_current_debitor(self):
        if hasattr(self, 'current_party_id') and self.current_party_id:
            QMessageBox.information(self, "Info",
                                    "Edit Debtor - open Debitor/Creditor module to edit.")
        else:
            QMessageBox.warning(self, "Warning", "No party selected. Select a customer first.")
