from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QTextEdit, QComboBox, QFileDialog, QMessageBox,
    QFrame, QScrollArea, QGridLayout
)
from PySide6.QtCore import Qt, Signal, QObject, QEvent
from PySide6.QtGui import QPixmap
import os

from db import Database
from logic.company_logic import CompanyLogic
from ui.theme import GST_STATE_CODES


class ClickablePreviewLabel(QLabel):
    def __init__(self, text="No file selected"):
        super().__init__(text)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(110)
        self.setMaximumHeight(110)
        self.setWordWrap(True)
        self.setStyleSheet("""
            QLabel {
                background-color: #1f2937;
                color: #9ca3af;
                border: 1px solid #374151;
                border-radius: 10px;
                font-size: 13px;
                padding: 10px;
            }
        """)


class FormNavigationFilter(QObject):
    def __init__(self, parent_page, field_order):
        super().__init__(parent_page)
        self.parent_page = parent_page
        self.field_order = field_order

    def eventFilter(self, obj, event):
        if event.type() != QEvent.KeyPress:
            return False

        key = event.key()

        # Enter = move forward
        if key in (Qt.Key_Return, Qt.Key_Enter):
            # Address must remain multiline
            if obj is self.parent_page.address:
                return False
            
            # Upload buttons should not open dialogs on Enter
            if obj in (self.parent_page.logo_button, self.parent_page.signature_button):
                current_index = self._index_of(obj)
                if current_index != -1 and current_index < len(self.field_order) - 1:
                    next_field = self.field_order[current_index + 1]
                    if next_field:
                        next_field.setFocus()
                        return True
                return True

            current_index = self._index_of(obj)
            if current_index != -1 and current_index < len(self.field_order) - 1:
                next_field = self.field_order[current_index + 1]
                if next_field:
                    next_field.setFocus()
                    return True
            return True

        # Esc = move backward
        if key == Qt.Key_Escape:
            current_index = self._index_of(obj)
            if current_index > 0:
                prev_field = self.field_order[current_index - 1]
                if prev_field:
                    prev_field.setFocus()
                    return True
            return True

        return False

    def _index_of(self, widget):
        for i, field in enumerate(self.field_order):
            if field is widget:
                return i
        return -1


class NewCompanyPageWidget(QWidget):
    company_created = Signal(dict)
    company_saved = Signal(dict)

    def __init__(self, db=None):
        super().__init__()

        self.logo_path = ""
        self.signature_path = ""
        self.db = db or Database()
        self.company_logic = CompanyLogic(self.db)

        # Use shared GST state codes from theme module
        self.gst_state_codes = GST_STATE_CODES

        self.setObjectName("NewCompanyPageWidget")
        self.setStyleSheet("""
            QWidget#NewCompanyPageWidget {
                background-color: #111827;
            }
        """)

        self.build_ui()

    # =========================================================
    # 1. MAIN UI
    # =========================================================
    def build_ui(self):
        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #111827;
            }
            QScrollBar:vertical {
                background: #1f2937;
                width: 12px;
                margin: 0px;
                border: none;
            }
            QScrollBar::handle:vertical {
                background: #6b7280;
                min-height: 35px;
                border-radius: 6px;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
                background: none;
                border: none;
            }
            QScrollBar::add-page:vertical,
            QScrollBar::sub-page:vertical {
                background: none;
            }
        """)

        self.content_widget = QWidget()
        self.content_widget.setStyleSheet("background-color: #111827;")

        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(28, 22, 28, 22)
        self.content_layout.setSpacing(10)

        self.build_header()
        self.build_company_info_section()
        self.build_business_details_section()
        self.build_upload_section()
        self.build_action_buttons()

        # Connect text field change handlers
        self.gstin.textChanged.connect(self.on_gstin_changed)
        self.business_name.textChanged.connect(self.on_business_name_changed)
        self.state.textChanged.connect(self.on_state_changed)
        self.address.textChanged.connect(self.on_address_changed)

        # Set up Enter / Esc navigation
        self.setup_field_navigation()

        self.scroll_area.setWidget(self.content_widget)
        root_layout.addWidget(self.scroll_area)

    # =========================================================
    # 2. HEADER
    # =========================================================
    def build_header(self):
        title = QLabel("Create New Company")
        title.setStyleSheet("""
            QLabel {
                color: #60a5fa;
                font-size: 28px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        self.content_layout.addWidget(title, alignment=Qt.AlignLeft)
        self.content_layout.addSpacing(2)

    # =========================================================
    # 3. SECTION HEADING
    # =========================================================
    def section_heading(self, text):
        label = QLabel(text)
        label.setStyleSheet("""
            QLabel {
                color: #fbbf24;
                font-size: 16px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        return label

    # =========================================================
    # 4. FIELD LABEL
    # =========================================================
    def field_label(self, text):
        label = QLabel(text)
        label.setStyleSheet("""
            QLabel {
                color: #d1d5db;
                font-size: 13px;
                font-weight: bold;
                background: transparent;
                border: none;
                padding: 0px;
                margin: 0px;
            }
        """)
        return label

    # =========================================================
    # 5. INPUT HELPERS
    # =========================================================
    def create_line_edit(self, placeholder=""):
        line_edit = QLineEdit()
        line_edit.setPlaceholderText(placeholder)
        line_edit.setMinimumHeight(42)
        line_edit.setStyleSheet("""
            QLineEdit {
                background-color: #1f2937;
                color: #f3f4f6;
                border: 1px solid #374151;
                border-radius: 8px;
                padding: 10px 12px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 2px solid #3b82f6;
            }
        """)
        return line_edit

    def create_text_edit(self, placeholder=""):
        text_edit = QTextEdit()
        text_edit.setPlaceholderText(placeholder)
        text_edit.setMinimumHeight(55)
        text_edit.setMaximumHeight(70)
        text_edit.setMinimumWidth(260)
        text_edit.setMaximumWidth(360)
        text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1f2937;
                color: #f3f4f6;
                border: 1px solid #374151;
                border-radius: 8px;
                padding: 6px 10px;
                font-size: 13px;
            }
            QTextEdit:focus {
                border: 2px solid #3b82f6;
            }
        """)
        return text_edit

    def create_combo_box(self, items):
        combo = QComboBox()
        combo.addItems(items)
        combo.setMinimumHeight(42)
        combo.setStyleSheet("""
            QComboBox {
                background-color: #1f2937;
                color: #f3f4f6;
                border: 1px solid #374151;
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QComboBox:focus {
                border: 2px solid #3b82f6;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
                background-color: #1f2937;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #9ca3af;
                margin-right: 5px;
            }
            QComboBox QAbstractItemView {
                background-color: #1f2937;
                color: #f3f4f6;
                border: 1px solid #374151;
                selection-background-color: #3b82f6;
            }
        """)
        return combo

    def create_button(self, text, primary=False):
        button = QPushButton(text)
        button.setMinimumHeight(42)
        button.setAutoDefault(False)
        button.setDefault(False)

        if primary:
            button.setStyleSheet("""
                QPushButton {
                    background-color: #3b82f6;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 13px;
                    font-weight: bold;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background-color: #2563eb;
                }
            """)
        else:
            button.setStyleSheet("""
                QPushButton {
                    background-color: #374151;
                    color: #f3f4f6;
                    border: none;
                    border-radius: 8px;
                    font-size: 13px;
                    font-weight: bold;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background-color: #4b5563;
                }
            """)
        return button

    # =========================================================
    # 6. FIELD BLOCK
    # =========================================================
    def field_block(self, label_text, widget):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        layout.addWidget(self.field_label(label_text))
        layout.addWidget(widget)
        return layout

    # =========================================================
    # 7. COMPANY INFORMATION
    # =========================================================
    def build_company_info_section(self):
        self.content_layout.addWidget(self.section_heading("Company Information"))
        self.content_layout.addSpacing(2)

        self.business_name = self.create_line_edit("Enter your business name")
        self.phone = self.create_line_edit("Enter phone number")
        self.gstin = self.create_line_edit("Enter GSTIN")
        self.email = self.create_line_edit("Enter email address")

        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(8)

        grid.addLayout(self.field_block("Business Name *", self.business_name), 0, 0, 1, 3)
        grid.addLayout(self.field_block("Phone Number", self.phone), 1, 0)
        grid.addLayout(self.field_block("GSTIN", self.gstin), 1, 1)
        grid.addLayout(self.field_block("Email", self.email), 1, 2)

        self.content_layout.addLayout(grid)
        self.content_layout.addSpacing(8)

    # =========================================================
    # 8. BUSINESS DETAILS
    # =========================================================
    def build_business_details_section(self):
        self.content_layout.addWidget(self.section_heading("Business Details"))
        self.content_layout.addSpacing(2)

        self.business_type = self.create_combo_box([
            "Select Business Type",
            "Retail",
            "Wholesale",
            "Service",
            "Manufacturing",
            "Trading",
            "Other"
        ])

        self.business_category = self.create_combo_box([
            "Select Business Category",
            "General",
            "Electronics",
            "Grocery",
            "Textile",
            "Medical",
            "Restaurant",
            "Other"
        ])

        self.address = self.create_text_edit("Enter address")
        self.state = self.create_line_edit("Enter state")
        self.pincode = self.create_line_edit("Enter pincode")
        self.opening_balance = self.create_line_edit("Enter opening balance")

        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(8)

        grid.addLayout(self.field_block("Business Type", self.business_type), 0, 0)
        grid.addLayout(self.field_block("Business Category", self.business_category), 0, 1)
        grid.addLayout(self.field_block("Opening Balance", self.opening_balance), 0, 2)
        grid.addLayout(self.field_block("Address", self.address), 1, 0, 1, 2)
        grid.addLayout(self.field_block("State", self.state), 2, 0)
        grid.addLayout(self.field_block("Pincode", self.pincode), 2, 1)

        self.content_layout.addLayout(grid)
        self.content_layout.addSpacing(8)

    # =========================================================
    # 9. UPLOAD SECTION
    # =========================================================
    def build_upload_section(self):
        self.content_layout.addWidget(self.section_heading("Upload Details"))
        self.content_layout.addSpacing(2)

        self.logo_preview = ClickablePreviewLabel("Logo preview")
        self.signature_preview = ClickablePreviewLabel("Signature preview")

        self.logo_button = self.create_button("Upload Logo")
        self.signature_button = self.create_button("Upload Signature")

        self.logo_button.clicked.connect(self.upload_logo)
        self.signature_button.clicked.connect(self.upload_signature)

        upload_grid = QGridLayout()
        upload_grid.setContentsMargins(0, 0, 0, 0)
        upload_grid.setHorizontalSpacing(16)
        upload_grid.setVerticalSpacing(8)

        logo_layout = QVBoxLayout()
        logo_layout.setContentsMargins(0, 0, 0, 0)
        logo_layout.setSpacing(4)
        logo_layout.addWidget(self.field_label("Logo"))
        logo_layout.addWidget(self.logo_button)

        logo_conditions = QLabel("Formats: PNG, JPG, JPEG, PDF\nMax size: 2 MB")
        logo_conditions.setStyleSheet("""
            QLabel {
                color: #60a5fa;
                font-size: 11px;
                font-weight: bold;
                margin: 2px 0;
            }
        """)
        logo_layout.addWidget(logo_conditions)
        logo_layout.addWidget(self.logo_preview)

        signature_layout = QVBoxLayout()
        signature_layout.setContentsMargins(0, 0, 0, 0)
        signature_layout.setSpacing(4)
        signature_layout.addWidget(self.field_label("Signature"))
        signature_layout.addWidget(self.signature_button)

        signature_conditions = QLabel("Formats: PNG, JPG, JPEG, PDF\nMax size: 2 MB")
        signature_conditions.setStyleSheet("""
            QLabel {
                color: #60a5fa;
                font-size: 11px;
                font-weight: bold;
                margin: 2px 0;
            }
        """)
        signature_layout.addWidget(signature_conditions)
        signature_layout.addWidget(self.signature_preview)

        upload_grid.addLayout(logo_layout, 0, 0)
        upload_grid.addLayout(signature_layout, 0, 1)

        self.content_layout.addLayout(upload_grid)
        self.content_layout.addSpacing(12)

    # =========================================================
    # 10. ACTION BUTTONS
    # =========================================================
    def build_action_buttons(self):
        button_row = QHBoxLayout()
        button_row.setContentsMargins(0, 0, 0, 0)
        button_row.setSpacing(10)
        button_row.addStretch()

        self.clear_btn = self.create_button("Clear")
        self.create_btn = self.create_button("Create Company", primary=True)

        self.clear_btn.clicked.connect(self.clear_form)
        self.create_btn.clicked.connect(self.create_company)

        button_row.addWidget(self.clear_btn)
        button_row.addWidget(self.create_btn)

        self.content_layout.addLayout(button_row)
        self.content_layout.addStretch()

    # =========================================================
    # 11. UPLOAD FUNCTIONS
    # =========================================================
    def upload_logo(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Logo",
            "",
            "Supported Files (*.png *.jpg *.jpeg *.pdf)"
        )
        if file_path and self.validate_file(file_path, "Logo"):
            self.logo_path = file_path
            self.set_preview_image(self.logo_preview, file_path)

    def upload_signature(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Signature",
            "",
            "Supported Files (*.png *.jpg *.jpeg *.pdf)"
        )
        if file_path and self.validate_file(file_path, "Signature"):
            self.signature_path = file_path
            self.set_preview_image(self.signature_preview, file_path)

    def validate_file(self, file_path, file_type):
        allowed_extensions = [".png", ".jpg", ".jpeg", ".pdf"]
        file_ext = os.path.splitext(file_path)[1].lower()

        if file_ext not in allowed_extensions:
            QMessageBox.warning(
                self,
                "Invalid File Type",
                f"{file_type} must be one of: PNG, JPG, JPEG, or PDF.\n\nSelected file: {file_ext}"
            )
            return False

        max_size = 2 * 1024 * 1024
        try:
            file_size = os.path.getsize(file_path)
            if file_size > max_size:
                size_mb = file_size / (1024 * 1024)
                QMessageBox.warning(
                    self,
                    "File Too Large",
                    f"{file_type} file size must be less than 2MB.\n\nSelected file size: {size_mb:.2f}MB"
                )
                return False
        except Exception as e:
            QMessageBox.warning(
                self,
                "File Error",
                f"Could not check {file_type} file size: {str(e)}"
            )
            return False

        return True

    def set_preview_image(self, label, file_path):
        file_ext = os.path.splitext(file_path)[1].lower()

        if file_ext == ".pdf":
            label.setPixmap(QPixmap())
            label.setText("PDF selected")
            return

        pixmap = QPixmap(file_path)
        if not pixmap.isNull():
            scaled = pixmap.scaled(
                max(50, label.width() - 20),
                max(50, label.height() - 20),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            label.setPixmap(scaled)
            label.setText("")
        else:
            label.setPixmap(QPixmap())
            label.setText("Preview not available")

    # =========================================================
    # 12. FORM ACTIONS
    # =========================================================
    def create_company(self):
        business_name = self.business_name.text().strip()

        if not business_name:
            QMessageBox.warning(self, "Validation Error", "Business Name is required.")
            self.business_name.setFocus()
            return

        company_data = {
            "business_name": business_name,
            "phone": self.phone.text().strip(),
            "gstin": self.gstin.text().strip().upper(),
            "email": self.email.text().strip(),
            "business_type": self.business_type.currentText(),
            "business_category": self.business_category.currentText(),
            "address": self.address.toPlainText().strip(),
            "state": self.state.text().strip(),
            "pincode": self.pincode.text().strip(),
            "opening_balance": self.opening_balance.text().strip(),
            "logo_path": self.logo_path,
            "signature_path": self.signature_path,
        }

        # Validate company data
        validation_result = self.company_logic.validate_company_data(company_data)
        
        if not validation_result['success']:
            QMessageBox.warning(self, "Validation Error", validation_result['message'])
            self.business_name.setFocus()
            return
        
        # Create company
        create_result = self.company_logic.create_company(company_data)
        
        if create_result['success']:
            self.company_created.emit(company_data)
            self.company_saved.emit(company_data)

            QMessageBox.information(self, "Success", "Company details saved successfully.")

            self.clear_form()
        else:
            QMessageBox.critical(self, "Error", create_result['message'])

    def clear_form(self):
        self.business_name.clear()
        self.phone.clear()
        self.gstin.clear()
        self.email.clear()
        self.address.clear()
        self.state.clear()
        self.pincode.clear()
        self.opening_balance.clear()

        if self.business_type.count() > 0:
            self.business_type.setCurrentIndex(0)
        if self.business_category.count() > 0:
            self.business_category.setCurrentIndex(0)

        self.logo_path = ""
        self.signature_path = ""

        self.logo_preview.setPixmap(QPixmap())
        self.logo_preview.setText("Logo preview")

        self.signature_preview.setPixmap(QPixmap())
        self.signature_preview.setText("Signature preview")

    # =========================================================
    # 13. TEXT / VALIDATION HANDLERS
    # =========================================================
    def on_gstin_changed(self, text):
        max_gstin_length = 15
        cursor_pos = self.gstin.cursorPosition()

        filtered_text = "".join(char for char in text if char.isalnum())
        filtered_text = filtered_text[:max_gstin_length]
        upper_text = filtered_text.upper()

        if upper_text != text:
            self.gstin.blockSignals(True)
            self.gstin.setText(upper_text)
            self.gstin.setCursorPosition(min(cursor_pos, len(upper_text)))
            self.gstin.blockSignals(False)

        # Clear State field first, then autofill if valid GSTIN state code exists
        self.state.blockSignals(True)
        self.state.setText("")
        self.state.blockSignals(False)
        
        if len(upper_text) >= 2 and upper_text[:2].isdigit():
            state_code = upper_text[:2]
            if state_code in self.gst_state_codes:
                expected_state = self.gst_state_codes[state_code]
                self.state.blockSignals(True)
                self.state.setText(expected_state)
                self.state.blockSignals(False)

    def on_business_name_changed(self, text):
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []

        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)

        if new_text != text:
            cursor_pos = self.business_name.cursorPosition()
            self.business_name.blockSignals(True)
            self.business_name.setText(new_text)
            self.business_name.setCursorPosition(min(cursor_pos, len(new_text)))
            self.business_name.blockSignals(False)

    def on_state_changed(self, text):
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []

        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)

        if new_text != text:
            cursor_pos = self.state.cursorPosition()
            self.state.blockSignals(True)
            self.state.setText(new_text)
            self.state.setCursorPosition(min(cursor_pos, len(new_text)))
            self.state.blockSignals(False)

    def on_address_changed(self):
        text = self.address.toPlainText()
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []

        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)

        if new_text != text:
            cursor = self.address.textCursor()
            cursor_pos = cursor.position()
            self.address.blockSignals(True)
            self.address.setText(new_text)
            cursor.setPosition(min(cursor_pos, len(new_text)))
            self.address.setTextCursor(cursor)
            self.address.blockSignals(False)

    # =========================================================
    # 14. FIELD NAVIGATION
    # =========================================================
    def setup_field_navigation(self):
        # Field order: Business Name -> Phone -> GSTIN -> Email -> Business Type -> Business Category -> Opening Balance -> Address -> State -> Pincode -> Upload Logo -> Upload Signature -> Save Button
        self.field_order = [
            self.business_name,
            self.phone,
            self.gstin,
            self.email,
            self.business_type,
            self.business_category,
            self.opening_balance,
            self.address,
            self.state,
            self.pincode,
            self.logo_button,
            self.signature_button,
            self.create_btn
        ]

        for field in self.field_order:
            if field is not None:
                field.setFocusPolicy(Qt.StrongFocus)

        self.logo_button.setAutoDefault(False)
        self.logo_button.setDefault(False)
        self.signature_button.setAutoDefault(False)
        self.signature_button.setDefault(False)

        self.enter_filter = FormNavigationFilter(self, self.field_order)
        for field in self.field_order:
            if field is not None:
                field.installEventFilter(self.enter_filter)
        
        # Also install event filter on Upload buttons to prevent Enter from triggering dialogs
        self.logo_button.installEventFilter(self.enter_filter)
        self.signature_button.installEventFilter(self.enter_filter)


NewCompanyPage = NewCompanyPageWidget