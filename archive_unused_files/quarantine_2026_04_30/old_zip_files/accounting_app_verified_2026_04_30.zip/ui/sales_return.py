"""
Sales Return main widget.
Full implementation: barcode/product flow, table keyboard nav, GST nature,
return type logic, save/update/delete, prev/next navigation.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidgetItem, QMessageBox, QAbstractItemView
)
from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QKeyEvent

from logic.sales_return_logic import SalesReturnLogic
from logic.party_balance_engine import PartyBalanceEngine
from .sales_return_ui import SalesReturnUIMixin
from .sales_return_calculations import SalesReturnCalculationsMixin
from .sales_return_helpers import SalesReturnHelpersMixin
from .sales_return_popup import SalesReturnPopupMixin
from .sales_return_delegate import SalesReturnDelegate


class SalesReturnPageWidget(QWidget, SalesReturnUIMixin, SalesReturnCalculationsMixin,
                              SalesReturnHelpersMixin, SalesReturnPopupMixin):
    """Main Sales Return widget."""

    def __init__(self, main_window, db, company_id=None,
                 opened_from_sales_entry=False, sales_entry_widget=None,
                 sales_grand_total=0.0):
        super().__init__()
        self.main_window = main_window
        self.db = db
        self.company_id = company_id
        self.sales_return_logic = SalesReturnLogic(db)
        self.balance_engine = PartyBalanceEngine(db)
        from logic.product_logic import ProductLogic
        self.product_logic = ProductLogic(db)
        from logic.stock_logic import StockLogic
        self.stock_logic = StockLogic(db)

        self.current_return_id = None
        self.current_party_id = None
        self.current_product_id = None
        self.current_product_data = {}
        self.returns_list = []
        self.current_index = -1
        self.selected_sl_row = -1
        self._popup_product_selected = False

        # Sales Entry integration
        self._opened_from_sales_entry = opened_from_sales_entry
        self._sales_entry_widget = sales_entry_widget
        self._sales_entry_original_total = sales_grand_total
        self._on_sales_entry_save_callback = None  # Set by caller after init
        self._sales_entry_window = None  # Reference to Sales Entry window

        from . import theme
        self.gst_state_codes = theme.GST_STATE_CODES

        self.setup_ui()
        self.setup_connections()
        self.load_returns_list()

    # ==================== SETUP ====================

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(3, 3, 3, 3)
        layout.setSpacing(2)
        layout.addWidget(self.build_page_header_strip())
        layout.addWidget(self.build_return_command_strip())
        layout.addWidget(self.build_party_information_matrix())
        layout.addWidget(self.build_product_entry_matrix())
        layout.addWidget(self.build_bill_options_strip())
        layout.addWidget(self.build_items_table(), 1)
        layout.addWidget(self.build_footer_summary_strip())
        # Install delegate AFTER table is built
        self._delegate = SalesReturnDelegate(self.items_table, self)
        self.items_table.setItemDelegate(self._delegate)
        # Intercept table-level key presses (for non-editor navigation)
        self.items_table.installEventFilter(self)

    def setup_connections(self):
        self.return_no_input.returnPressed.connect(self.load_return_by_no)
        self.nature_combo.currentTextChanged.connect(self.on_nature_changed)
        self.return_type_combo.currentTextChanged.connect(self.on_return_type_changed)
        self.amount_refunded_input.editingFinished.connect(self.on_amount_refunded_changed)
        self.round_off_input.editingFinished.connect(self.on_round_off_changed)
        self.items_table.itemSelectionChanged.connect(self.on_item_selection_changed)
        self.items_table.itemChanged.connect(self.on_item_changed)
        self.items_table.cellClicked.connect(self.on_cell_clicked)

        # Customer name: clicking opens popup
        self.customer_name_input.returnPressed.connect(self.show_party_popup)
        # product_input Esc → back to barcode
        self.product_input.installEventFilter(self)

    # ==================== FOCUS HELPER ====================

    def focus_table_cell_editor(self, row: int, col: int):
        """Set current cell, scroll to it, open editor (only for editable cols), select-all text."""
        if row < 0 or row >= self.items_table.rowCount():
            return
        self.items_table.setCurrentCell(row, col)
        item = self.items_table.item(row, col)
        if item:
            self.items_table.scrollToItem(item)
        # Only editable columns: Rate=8, Qty=9, Disc=11
        if col in (self.COL_RATE, self.COL_QTY, self.COL_DISC):
            self.items_table.edit(self.items_table.currentIndex())
            QTimer.singleShot(30, self._select_all_in_current_editor)

    def _select_all_in_current_editor(self):
        editor = self.items_table.focusWidget()
        from PySide6.QtWidgets import QLineEdit
        if isinstance(editor, QLineEdit):
            editor.selectAll()

    # ==================== NAVIGATION ====================

    def load_returns_list(self):
        company_id = self.get_current_company_id()
        if not company_id:
            return
        result = self.sales_return_logic.get_sales_returns(company_id)
        if result['success']:
            self.returns_list = result['data']

    def load_return_by_no(self):
        return_no = self.return_no_input.text().strip()
        if not return_no:
            return
        for idx, r in enumerate(self.returns_list):
            if str(r.get('return_no', '')) == return_no:
                self.current_index = idx
                self._load_full_return(r)
                return
        QMessageBox.warning(self, "Not Found", f"Return No '{return_no}' not found.")

    def previous_return(self):
        if not self.returns_list:
            return
        if self.current_index <= 0:
            self.current_index = 0
        else:
            self.current_index -= 1
        self._load_full_return(self.returns_list[self.current_index])

    def next_return(self):
        if not self.returns_list:
            return
        if self.current_index >= len(self.returns_list) - 1:
            self.current_index = len(self.returns_list) - 1
        else:
            self.current_index += 1
        self._load_full_return(self.returns_list[self.current_index])

    def _load_full_return(self, header_data: dict):
        rid = header_data['id']
        company_id = self.get_current_company_id()
        items_result = self.sales_return_logic.get_sales_return_items(rid)
        items = items_result.get('data', []) if items_result.get('success') else []
        full_data = dict(header_data)
        full_data['items'] = []
        for it in items:
            item = dict(it)
            item['product_name'] = it.get('product_name', '')
            item['cgst'] = float(it.get('cgst', 0.0))
            item['sgst'] = float(it.get('sgst', 0.0))
            item['igst'] = float(it.get('igst', 0.0))
            item['cess'] = float(it.get('cess', 0.0))
            item['rate'] = float(it.get('rate', 0.0))
            item['quantity'] = float(it.get('quantity', 0.0))
            item['gross_value'] = float(it.get('gross_value', 0.0))
            item['discount'] = float(it.get('discount', 0.0))
            item['net_value'] = float(it.get('net_value', 0.0))
            item['tax_amount'] = float(it.get('tax_amount', 0.0))
            item['grand_total'] = float(it.get('grand_total', 0.0))
            full_data['items'].append(item)
        self.load_return_data(full_data)
        self.ok_btn.setText("Update")
        self._update_balance_display()

    # ==================== CUSTOMER / PARTY ====================

    def on_customer_name_changed(self, text):
        pass

    def on_gstin_changed(self, text):
        """Auto-uppercase GSTIN and auto-fill State from first 2 digits."""
        filtered = ''.join(c for c in text if c.isalnum())[:15].upper()
        if filtered != text:
            self.gstin_input.blockSignals(True)
            cur = self.gstin_input.cursorPosition()
            self.gstin_input.setText(filtered)
            self.gstin_input.setCursorPosition(min(cur, len(filtered)))
            self.gstin_input.blockSignals(False)
        if len(filtered) >= 2 and filtered[:2].isdigit():
            state_name = self.gst_state_codes.get(filtered[:2])
            if state_name:
                self.state_combo.blockSignals(True)
                self.state_combo.setCurrentText(state_name)
                self.state_combo.blockSignals(False)
        elif not filtered:
            self.state_combo.blockSignals(True)
            self.state_combo.setCurrentIndex(0)
            self.state_combo.blockSignals(False)

    # ==================== BARCODE / PRODUCT FLOW ====================

    def on_barcode_enter(self):
        barcode = self.barcode_input.text().strip()
        if not barcode:
            self.product_input.setFocus()
            self.product_input.selectAll()
            return
        company_id = self.get_current_company_id()
        if not company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return
        product = self.db.get_product_by_barcode(company_id, barcode)
        if product:
            self.current_product_id = product['id']
            self.current_product_data = product
            self.product_input.blockSignals(True)
            self.product_input.setText(product['name'])
            self.product_input.blockSignals(False)
            stock = self.stock_logic.get_current_stock(company_id, product['id'])
            self.stock_display.setText(f"{stock:.3f}")
            self.code_display.setText(str(product.get('code', '') or ''))
            self.barcode_input.clear()
            self.add_product_to_items()
        else:
            QMessageBox.warning(self, "Not Found", f"Barcode '{barcode}' not found.")
            self.barcode_input.selectAll()

    def on_product_enter(self):
        self._popup_product_selected = False
        self.show_product_popup()

    def add_product_to_items(self):
        if not self.current_product_id:
            return

        product = self.current_product_data
        if not product:
            company_id = self.get_current_company_id()
            if company_id:
                product = self.db.get_product_by_id(company_id, self.current_product_id) or {}
            else:
                return

        nature = self.nature_combo.currentText()
        cgst_pct = float(product.get('cgst', 0.0) or 0.0)
        sgst_pct = float(product.get('sgst', 0.0) or 0.0)
        igst_pct = float(product.get('igst', 0.0) or 0.0)
        cess_pct = float(product.get('cess', 0.0) or 0.0)

        if nature != 'Inter-state':
            igst_pct = 0.0
        else:
            cgst_pct = 0.0
            sgst_pct = 0.0

        # DB returns sale_price / wholesale_rate / mrp / purchase_rate — use sale_price as default
        rate = float(
            product.get('sale_price') or
            product.get('wholesale_rate') or
            product.get('mrp') or
            product.get('purchase_rate') or 0.0
        )
        quantity = 1.0
        discount = 0.0

        totals = self.calculate_row_totals({
            'rate': rate, 'quantity': quantity, 'discount': discount,
            'nature': nature,
            'cgst_pct': cgst_pct, 'sgst_pct': sgst_pct,
            'igst_pct': igst_pct, 'cess_pct': cess_pct
        })

        item_data = {
            'product_id': product.get('id') or self.current_product_id,
            'product_name': product.get('name', ''),
            'hsn': product.get('hsn', '') or '',
            'cgst': cgst_pct,
            'sgst': sgst_pct,
            'igst': igst_pct,
            'cess': cess_pct,
            'cgst_amount': totals.get('cgst_amt', 0.0),
            'sgst_amount': totals.get('sgst_amt', 0.0),
            'igst_amount': totals.get('igst_amt', 0.0),
            'cess_amount': totals.get('cess_amt', 0.0),
            'rate': rate,
            'quantity': quantity,
            'discount': discount,
            'gross_value': totals['gross_value'],
            'net_value': totals['net_value'],
            'tax_amount': totals['tax_amount'],
            'grand_total': totals['grand_total']
        }

        sl_no = self.items_table.rowCount() + 1
        self.add_item_to_table(item_data, sl_no)
        self.recalculate_summary()
        self.clear_product_fields()

        last_row = self.items_table.rowCount() - 1
        QTimer.singleShot(0, lambda r=last_row: self.focus_table_cell_editor(r, self.COL_QTY))

    # ==================== TABLE INTERACTIONS ====================

    def on_cell_clicked(self, row, col):
        if col == self.COL_SL:
            self.selected_sl_row = row
            self.items_table.selectRow(row)
        else:
            if self.selected_sl_row != row:
                self.selected_sl_row = -1

    def on_item_selection_changed(self):
        pass

    def on_item_changed(self, item):
        if item is None:
            return
        row = item.row()
        col = item.column()
        if col in (self.COL_RATE, self.COL_QTY, self.COL_DISC):
            # Skip if the delegate's live editor is still open for this exact cell.
            delegate = self.items_table.itemDelegate()
            if (delegate is not None
                    and getattr(delegate, 'current_editor', None) is not None
                    and getattr(delegate, 'current_index', None) is not None
                    and delegate.current_index.row() == row
                    and delegate.current_index.column() == col):
                return
            self._recalculate_row_in_table(row)

    def _recalculate_row_in_table(self, row):
        self.items_table.blockSignals(True)
        try:
            product_cell = self.items_table.item(row, self.COL_PRODUCT)
            if not product_cell or not product_cell.text().strip():
                self.items_table.blockSignals(False)
                return

            rate = self._safe_float(self.items_table.item(row, self.COL_RATE))
            qty = self._safe_float(self.items_table.item(row, self.COL_QTY))
            disc = self._safe_float(self.items_table.item(row, self.COL_DISC))
            cgst_pct = self._safe_pct(self.items_table.item(row, self.COL_CGST))
            sgst_pct = self._safe_pct(self.items_table.item(row, self.COL_SGST))
            igst_pct = self._safe_pct(self.items_table.item(row, self.COL_IGST))
            cess_pct = self._safe_pct(self.items_table.item(row, self.COL_CESS))
            nature = self.nature_combo.currentText()

            totals = self.calculate_row_totals({
                'rate': rate, 'quantity': qty, 'discount': disc,
                'nature': nature,
                'cgst_pct': cgst_pct, 'sgst_pct': sgst_pct,
                'igst_pct': igst_pct, 'cess_pct': cess_pct
            })

            def _set(c, val):
                cell = self.items_table.item(row, c)
                if cell:
                    cell.setText(f"{val:.2f}")
                else:
                    ni = QTableWidgetItem(f"{val:.2f}")
                    ni.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    self.items_table.setItem(row, c, ni)

            _set(self.COL_GROSS, totals['gross_value'])
            _set(self.COL_NET, totals['net_value'])
            _set(self.COL_TAX, totals['tax_amount'])
            _set(self.COL_TOTAL, totals['grand_total'])
        finally:
            self.items_table.blockSignals(False)
        self.recalculate_summary()

    def recalculate_row(self, row):
        self._recalculate_row_in_table(row)

    def recalculate_row_live(self, row, source_col, live_text):
        """Called by delegate on every keystroke for live footer updates.

        Reads live_text for source_col; reads committed table values for all other cols.
        """
        from PySide6.QtWidgets import QTableWidgetItem as _QTI

        product_cell = self.items_table.item(row, self.COL_PRODUCT)
        if not product_cell or not product_cell.text().strip():
            return

        def _sf(cell):
            if cell is None:
                return 0.0
            try:
                return float(cell.text().replace('%', '').replace('₹', '').replace(',', '').strip() or '0')
            except (ValueError, AttributeError):
                return 0.0

        def _live(col, default):
            if col == source_col and live_text is not None:
                t = live_text.strip()
                return float(t) if t else 0.0
            return default

        rate = _live(self.COL_RATE, _sf(self.items_table.item(row, self.COL_RATE)))
        qty  = _live(self.COL_QTY,  _sf(self.items_table.item(row, self.COL_QTY)))
        disc = _live(self.COL_DISC, _sf(self.items_table.item(row, self.COL_DISC)))
        cgst_pct = _sf(self.items_table.item(row, self.COL_CGST))
        sgst_pct = _sf(self.items_table.item(row, self.COL_SGST))
        igst_pct = _sf(self.items_table.item(row, self.COL_IGST))
        cess_pct = _sf(self.items_table.item(row, self.COL_CESS))
        nature = self.nature_combo.currentText()

        totals = self.calculate_row_totals({
            'rate': rate, 'quantity': qty, 'discount': disc,
            'nature': nature,
            'cgst_pct': cgst_pct, 'sgst_pct': sgst_pct,
            'igst_pct': igst_pct, 'cess_pct': cess_pct,
        })

        self.items_table.blockSignals(True)
        try:
            def _set(c, val):
                cell = self.items_table.item(row, c)
                if cell:
                    cell.setText(f"{val:.2f}")
                else:
                    ni = _QTI(f"{val:.2f}")
                    ni.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    self.items_table.setItem(row, c, ni)

            _set(self.COL_GROSS, totals['gross_value'])
            _set(self.COL_NET,   totals['net_value'])
            _set(self.COL_TAX,   totals['tax_amount'])
            _set(self.COL_TOTAL, totals['grand_total'])
        finally:
            self.items_table.blockSignals(False)

        self.recalculate_summary()

    def on_nature_changed(self):
        nature = self.nature_combo.currentText()
        self.items_table.blockSignals(True)
        for row in range(self.items_table.rowCount()):
            product_cell = self.items_table.item(row, self.COL_PRODUCT)
            if not product_cell or not product_cell.text().strip():
                continue
            product_id = product_cell.data(Qt.UserRole)
            company_id = self.get_current_company_id()
            product = self.db.get_product_by_id(company_id, product_id) if company_id and product_id else {}
            if not product:
                continue

            cgst_pct = float(product.get('cgst', 0.0) or 0.0)
            sgst_pct = float(product.get('sgst', 0.0) or 0.0)
            igst_pct = float(product.get('igst', 0.0) or 0.0)
            cess_pct = float(product.get('cess', 0.0) or 0.0)

            if nature != 'Inter-state':
                igst_pct = 0.0
                active_cgst, active_sgst, active_igst, active_cess = cgst_pct, sgst_pct, 0.0, cess_pct
            else:
                active_cgst, active_sgst, active_igst, active_cess = 0.0, 0.0, igst_pct, cess_pct

            def _set_pct(c, v):
                cell = self.items_table.item(row, c)
                if cell:
                    cell.setText(f"{v:.2f}%")
                else:
                    ni = QTableWidgetItem(f"{v:.2f}%")
                    ni.setFlags(ni.flags() & ~Qt.ItemIsEditable)
                    ni.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    self.items_table.setItem(row, c, ni)

            _set_pct(self.COL_CGST, active_cgst)
            _set_pct(self.COL_SGST, active_sgst)
            _set_pct(self.COL_IGST, active_igst)
            _set_pct(self.COL_CESS, active_cess)

        self.items_table.blockSignals(False)
        self.recalculate_all_rows()

    def recalculate_all_rows(self):
        for row in range(self.items_table.rowCount()):
            self._recalculate_row_in_table(row)

    def recalculate_summary(self):
        items = self.get_items_data()
        summary = self.calculate_summary_totals(items)

        self.net_value_display.setText(self.format_num(summary['net_value']))
        self.cgst_display.setText(self.format_num(summary['cgst_total']))
        self.sgst_display.setText(self.format_num(summary['sgst_total']))
        self.igst_display.setText(self.format_num(summary['igst_total']))
        self.cess_display.setText(self.format_num(summary['cess_total']))
        self.tax_amount_display.setText(self.format_num(summary['tax_total']))
        self.grand_total_input.setText(self.format_num(summary['grand_total']))
        self.round_off_display.setText(self.format_num(summary['round_off']))
        final_amount = summary['rounded_total']
        self.final_amount_display.setText(f"₹ {final_amount:.2f}")

        self._update_refunded_from_type(final_amount)

    def _update_refunded_from_type(self, final_amount: float):
        """Set Amt Refunded and Balance based on return type.

        Cash  → Amt Refunded = final_amount, Balance = 0
        Credit → Amt Refunded = 0.00, Balance = final_amount
        """
        return_type = self.return_type_combo.currentText().strip().lower()
        is_cash = (return_type == 'cash')

        self.amount_refunded_input.blockSignals(True)
        try:
            if is_cash:
                self.amount_refunded_input.setText(self.format_num(final_amount))
            else:
                self.amount_refunded_input.setText("0.00")
        finally:
            self.amount_refunded_input.blockSignals(False)

        self._update_balance_display()

    def on_return_type_changed(self, *args):
        """Called when return type combo changes — re-apply refunded logic."""
        try:
            final_amount = float(
                self.final_amount_display.text().replace('₹', '').replace(',', '').strip() or '0'
            )
        except ValueError:
            final_amount = 0.0
        self._update_refunded_from_type(final_amount)

    def on_amount_refunded_changed(self):
        self._update_balance_display()

    def on_round_off_changed(self):
        self.recalculate_summary()

    def _update_balance_display(self):
        """Update balance display using PartyBalanceEngine for proper Previous Balance calculation.

        For Sales Return:
        - Previous Balance: Balance before current sales return voucher
        - Closing Balance = Previous Balance - Return Net Amount + Amount Refunded
        """
        try:
            final_amount = float(
                self.final_amount_display.text().replace('₹', '').replace(',', '').strip() or '0'
            )
        except ValueError:
            final_amount = 0.0
        try:
            refunded = float(self.amount_refunded_input.text() or '0')
        except ValueError:
            refunded = 0.0

        # Get Previous Balance using PartyBalanceEngine
        previous_balance = self.get_previous_party_balance()

        # Calculate Closing Balance using PartyBalanceEngine
        # Sales Return reduces debitor balance: Closing Balance = Previous Balance - Return Net Amount + Amount Refunded
        closing_balance = self.balance_engine.calculate_closing_balance(
            previous_balance, final_amount, refunded, 'sales_return'
        )

        self.balance_display.setText(self.format_num(closing_balance))

    def get_previous_party_balance(self):
        """Return the Previous Balance (balance before current voucher) of the selected party.

        Uses PartyBalanceEngine to calculate:
        Previous Balance = party opening_balance + unpaid previous sales - previous receipts/returns

        Excludes current return when editing/viewing old returns via voucher_id.
        Excludes future vouchers (after current voucher date/id).

        Returns 0.00 when no party found / blank / error.
        """
        try:
            if not hasattr(self, 'customer_name_input'):
                return 0.0
            name = self.customer_name_input.text().strip().lower()
            if not name:
                return 0.0
            if not hasattr(self, 'current_party_id') or not self.current_party_id:
                return 0.0

            active_company = None
            if self.main_window and hasattr(self.main_window, 'active_company'):
                active_company = self.main_window.active_company
            if not active_company:
                from config import active_company_manager
                active_company = active_company_manager.get_active_company()
            if not active_company:
                return 0.0

            # Use PartyBalanceEngine for proper Previous Balance calculation
            voucher_id = self.current_return_id
            voucher_date = None
            # If we have a saved return loaded, get its date for proper exclusion
            if voucher_id and hasattr(self, 'return_date_input'):
                voucher_date = self.return_date_input.date().toString("yyyy-MM-dd")
            balance_result = self.balance_engine.get_party_balance_before_voucher(
                active_company['id'], self.current_party_id, 'sales_return',
                voucher_id=voucher_id, voucher_date=voucher_date
            )
            return balance_result.get('previous_balance', 0.0)
        except Exception:
            return 0.0

    # ==================== REMOVE ITEM ====================

    def remove_current_item(self):
        if self.selected_sl_row < 0:
            QMessageBox.information(self, "Select Row",
                                    "Click on the SL No cell of the row you want to remove first.")
            return
        row = self.selected_sl_row
        if row >= self.items_table.rowCount():
            self.selected_sl_row = -1
            return
        product_cell = self.items_table.item(row, self.COL_PRODUCT)
        product_name = product_cell.text() if product_cell else f"Row {row + 1}"
        reply = QMessageBox.question(
            self, "Remove Item",
            f"Remove '{product_name}' from the table?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.items_table.blockSignals(True)
            self.items_table.removeRow(row)
            for r in range(self.items_table.rowCount()):
                sl = self.items_table.item(r, self.COL_SL)
                if sl:
                    sl.setText(str(r + 1))
            self.items_table.blockSignals(False)
            self.selected_sl_row = -1
            self.recalculate_summary()

    # ==================== SAVE / UPDATE / DELETE ====================

    def _validate_and_collect(self):
        company_id = self.get_current_company_id()
        if not company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return None
        return_type = self.return_type_combo.currentText()
        # Credit return MUST have a customer; Cash return can proceed without one
        if return_type == 'Credit' and not getattr(self, 'current_party_id', None):
            QMessageBox.warning(self, "Customer Required",
                                "Credit return requires a customer.\nPlease select a customer first.")
            self.customer_name_input.setFocus()
            return None
        form_data = self.get_form_data()
        if not form_data['items']:
            QMessageBox.warning(self, "Error", "Add at least one item with quantity > 0.")
            return None
        return form_data

    def save_return(self):
        if self.current_return_id:
            self.update_return()
            return
        form_data = self._validate_and_collect()
        if form_data is None:
            return
        result = self.sales_return_logic.save_sales_return(form_data)
        if result['success']:
            return_id = result.get('sales_return_id')
            # Calculate total return amount from items
            return_total = 0.0
            items = form_data.get('items', [])
            for item in items:
                item_total = float(item.get('grand_total', 0) or 0)
                return_total += item_total

            QMessageBox.information(self, "Saved",
                                    f"Sales Return saved successfully.\n"
                                    f"Return No: {form_data['return_no']}")

            # If opened from Sales Entry, call back with return details
            if self._opened_from_sales_entry and self._on_sales_entry_save_callback and return_id:
                self._on_sales_entry_save_callback(return_id, return_total)
                # Close this window since we're done
                window = self.window()
                if window:
                    window.close()
                return
            self.load_returns_list()
            self.clear_form()
            self.barcode_input.setFocus()
        else:
            QMessageBox.critical(self, "Error", result['message'])

    def update_return(self):
        if not self.current_return_id:
            QMessageBox.warning(self, "Error", "No return loaded for update.")
            return
        form_data = self._validate_and_collect()
        if form_data is None:
            return
        result = self.sales_return_logic.update_sales_return(self.current_return_id, form_data)
        if result['success']:
            QMessageBox.information(self, "Updated", "Sales Return updated successfully.")
            self.load_returns_list()
            self.ok_btn.setText("Save")
            self.current_return_id = None
            self.clear_form()
            self.barcode_input.setFocus()
        else:
            QMessageBox.critical(self, "Error", result['message'])

    def delete_return(self):
        if not self.current_return_id:
            QMessageBox.warning(self, "Error", "No saved return is currently loaded.")
            return
        company_id = self.get_current_company_id()
        reply = QMessageBox.question(
            self, "Delete Return",
            "Permanently delete this Sales Return and reverse stock movements?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            result = self.sales_return_logic.delete_sales_return(company_id, self.current_return_id)
            if result['success']:
                QMessageBox.information(self, "Deleted", "Sales Return deleted successfully.")
                self.load_returns_list()
                self.ok_btn.setText("Save")
                self.clear_form()
                self.barcode_input.setFocus()
            else:
                QMessageBox.critical(self, "Error", result['message'])

    # ==================== MISC ====================

    def print_return(self):
        QMessageBox.information(self, "Print", "Print feature — coming soon.")

    def refresh(self):
        self.load_returns_list()
        if self.current_return_id:
            for r in self.returns_list:
                if r['id'] == self.current_return_id:
                    self._load_full_return(r)
                    break

    def eventFilter(self, obj, event):
        """Handle Esc on table (no editor) and product_input."""
        from PySide6.QtCore import QEvent as QEv
        if event.type() == QEv.KeyPress and event.key() == Qt.Key_Escape:
            if obj is self.items_table or obj is self.product_input:
                self.barcode_input.setFocus()
                self.barcode_input.selectAll()
                return True
        return super().eventFilter(obj, event)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_F5:
            self.refresh()
        else:
            # Do NOT handle Esc here — delegate and eventFilter handle it
            super().keyPressEvent(event)
