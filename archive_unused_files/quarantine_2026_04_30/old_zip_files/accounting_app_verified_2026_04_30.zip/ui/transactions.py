"""
Transactions widget for the Accounting Desktop Application.
Manages income, expenses, and transfers between accounts.
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QComboBox, QLineEdit, QDateEdit, QAbstractItemView
from PySide6.QtCore import Qt, QDate

from config import COLORS


class TransactionsWidget(QWidget):
    """Transactions widget for managing financial transactions."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup transactions UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header with title and add button
        header_layout = QHBoxLayout()
        
        title = QLabel("Transactions")
        title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 24px;
                font-weight: bold;
            }}
        """)
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        add_btn = QPushButton("Add Transaction")
        add_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        header_layout.addWidget(add_btn)
        
        layout.addLayout(header_layout)
        
        # Transaction form
        form_frame = QFrame()
        form_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                padding: 16px;
            }}
        """)
        
        form_layout = QHBoxLayout(form_frame)
        
        # Form fields
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setStyleSheet(f"""
            QDateEdit {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
            }}
        """)
        form_layout.addWidget(QLabel("Date:"))
        form_layout.addWidget(self.date_edit)
        
        self.type_combo = QComboBox()
        self.type_combo.addItems(["Income", "Expense", "Transfer"])
        self.type_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
            }}
        """)
        form_layout.addWidget(QLabel("Type:"))
        form_layout.addWidget(self.type_combo)
        
        self.amount_edit = QLineEdit()
        self.amount_edit.setPlaceholderText("0.00")
        self.amount_edit.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
            }}
        """)
        form_layout.addWidget(QLabel("Amount:"))
        form_layout.addWidget(self.amount_edit)
        
        self.description_edit = QLineEdit()
        self.description_edit.setPlaceholderText("Description")
        self.description_edit.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
            }}
        """)
        form_layout.addWidget(QLabel("Description:"))
        form_layout.addWidget(self.description_edit)
        
        save_btn = QPushButton("Save")
        save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['success']};
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }}
        """)
        form_layout.addWidget(save_btn)
        
        form_layout.addStretch()
        layout.addWidget(form_frame)
        
        # Transactions table
        self.transactions_table = QTableWidget()
        self.transactions_table.setColumnCount(6)
        self.transactions_table.setHorizontalHeaderLabels(["Date", "Type", "Description", "Account", "Amount", "Actions"])
        
        # Style table
        self.transactions_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 8px;
                gridline-color: {COLORS['border']};
                selection-background-color: {COLORS['primary']};
            }}
            QTableWidget::item {{
                padding: 8px;
                color: {COLORS['text_primary']};
            }}
            QTableWidget::item:selected {{
                background-color: {COLORS['primary']};
            }}
            QHeaderView::section {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                padding: 10px;
                border: none;
                font-weight: bold;
            }}
        """)
        
        # Disable inline editing - table is for display with action buttons only
        self.transactions_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        
        # Set column widths
        header = self.transactions_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        
        # Add sample data
        self.add_sample_transactions()
        
        layout.addWidget(self.transactions_table)
    
    def add_sample_transactions(self):
        """Add sample transaction data."""
        transactions = [
            ["2024-01-15", "Income", "Salary", "Checking", "$3,250.00"],
            ["2024-01-14", "Expense", "Grocery Store", "Checking", "-$125.50"],
            ["2024-01-13", "Expense", "Gas Station", "Credit Card", "-$45.00"],
            ["2024-01-12", "Income", "Freelance Project", "Checking", "$500.00"],
            ["2024-01-11", "Expense", "Restaurant", "Credit Card", "-$67.80"]
        ]
        
        self.transactions_table.setRowCount(len(transactions))
        
        for row, transaction in enumerate(transactions):
            for col, value in enumerate(transaction):
                item = QTableWidgetItem(value)
                if col == 4:  # Amount column
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.transactions_table.setItem(row, col, item)
            
            # Add action buttons
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(0, 0, 0, 0)
            actions_layout.setSpacing(5)
            
            edit_btn = QPushButton("Edit")
            edit_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['info']};
                    color: white;
                    border: none;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                }}
            """)
            actions_layout.addWidget(edit_btn)
            
            delete_btn = QPushButton("Delete")
            delete_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: {COLORS['error']};
                    color: white;
                    border: none;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 12px;
                }}
            """)
            actions_layout.addWidget(delete_btn)
            
            self.transactions_table.setCellWidget(row, 5, actions_widget)
