"""
UI package for the Accounting Desktop Application.
Contains all UI components and main window classes.
"""

from .main_window import MainWindow

__all__ = ['MainWindow']
