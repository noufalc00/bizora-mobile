"""
Trial Balance Page Widget

Displays Trial Balance computed entirely from ledger_accounts + ledger_entries.
Matches the dark professional theme used across the application.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QDateEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QLineEdit, QSizePolicy, QMessageBox,
    QAbstractItemView
)
from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QFont, QColor

from config import COLORS, active_company_manager
from logic.trial_balance_logic import TrialBalanceLogic, FILTER_MAP


# Column indices
COL_SL       = 0
COL_ACCOUNT  = 1
COL_TYPE     = 2
COL_OB_DR    = 3
COL_OB_CR    = 4
COL_PER_DR   = 5
COL_PER_CR   = 6
COL_CL_DR    = 7
COL_CL_CR    = 8
COL_COUNT    = 9

HEADERS = [
    "#", "Ledger Account", "Type",
    "Opening\nDebit", "Opening\nCredit",
    "Period\nDebit", "Period\nCredit",
    "Closing\nDebit", "Closing\nCredit",
]


def _fmt(v: float) -> str:
    """Format monetary value; blank for zero."""
    return f"{v:,.2f}" if v > 0.001 else ""


def _fmt_total(v: float) -> str:
    return f"{v:,.2f}"


class TrialBalancePageWidget(QWidget):
    """Trial Balance report page."""

    def __init__(self, db=None):
        super().__init__()
        self.db = db
        self._tb_logic = TrialBalanceLogic(db) if db else None
        self._company_id = None
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(300)
        self._search_timer.timeout.connect(self._on_search_timer)
        self._setup_ui()

    # ------------------------------------------------------------------
    # UI SETUP
    # ------------------------------------------------------------------

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        # Title row
        title_lbl = QLabel("Trial Balance")
        title_lbl.setStyleSheet(
            f"font-size:22px; font-weight:bold; color:{COLORS['text_primary']};"
        )
        root.addWidget(title_lbl)

        # Filter bar
        root.addWidget(self._build_filter_bar())

        # Summary footer frame (above table for quick scan)
        root.addWidget(self._build_summary_frame())

        # Table
        root.addWidget(self._build_table(), 1)

    def _build_filter_bar(self) -> QFrame:
        bar = QFrame()
        bar.setStyleSheet(
            f"QFrame{{background:{COLORS['surface']};border:1px solid {COLORS['border']};"
            f"border-radius:6px;padding:6px;}}"
        )
        lay = QHBoxLayout(bar)
        lay.setSpacing(12)
        lay.setContentsMargins(10, 6, 10, 6)

        lbl_style = f"color:{COLORS['text_secondary']};font-size:13px;"
        date_style = (
            f"QDateEdit{{background:{COLORS['surface']};color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['border']};border-radius:4px;padding:6px;}}"
            f"QDateEdit:hover{{border:1px solid {COLORS['border_focus']};}}"
        )
        combo_style = (
            f"QComboBox{{background:{COLORS['surface']};color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['border']};border-radius:4px;padding:6px;}}"
            f"QComboBox:hover{{border:1px solid {COLORS['border_focus']};}}"
            f"QComboBox QAbstractItemView{{background:{COLORS['surface']};"
            f"color:{COLORS['text_primary']};selection-background-color:{COLORS['primary']};}}"
        )
        search_style = (
            f"QLineEdit{{background:{COLORS['surface']};color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['border']};border-radius:4px;padding:6px;}}"
            f"QLineEdit:hover{{border:1px solid {COLORS['border_focus']};}}"
        )

        # From date
        lay.addWidget(QLabel("From:", styleSheet=lbl_style))
        self.from_date = QDateEdit(calendarPopup=True)
        self.from_date.setStyleSheet(date_style)
        # Default: start of current financial year (April 1)
        today = QDate.currentDate()
        fy_start = QDate(today.year() if today.month() >= 4 else today.year() - 1, 4, 1)
        self.from_date.setDate(fy_start)
        lay.addWidget(self.from_date)

        lay.addWidget(QLabel("To:", styleSheet=lbl_style))
        self.to_date = QDateEdit(calendarPopup=True)
        self.to_date.setStyleSheet(date_style)
        self.to_date.setDate(today)
        lay.addWidget(self.to_date)

        # Account type filter
        lay.addWidget(QLabel("Type:", styleSheet=lbl_style))
        self.type_combo = QComboBox()
        self.type_combo.setStyleSheet(combo_style)
        self.type_combo.setMinimumWidth(120)
        for label in FILTER_MAP.keys():
            self.type_combo.addItem(label)
        lay.addWidget(self.type_combo)

        # Search
        lay.addWidget(QLabel("Search:", styleSheet=lbl_style))
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Account name…")
        self.search_box.setStyleSheet(search_style)
        self.search_box.setMinimumWidth(160)
        self.search_box.textChanged.connect(self._search_timer.start)
        lay.addWidget(self.search_box)

        # Load button
        self.load_btn = QPushButton("Load")
        self.load_btn.setStyleSheet(
            f"QPushButton{{background:{COLORS['primary']};color:white;border:none;"
            f"border-radius:4px;padding:8px 20px;font-weight:bold;}}"
            f"QPushButton:hover{{background:{COLORS['primary_dark']};}}"
            f"QPushButton:pressed{{background:{COLORS['primary_light']};}}"
        )
        self.load_btn.clicked.connect(self.load_trial_balance)
        lay.addWidget(self.load_btn)

        # Excel export
        self.export_btn = QPushButton("Export Excel")
        self.export_btn.setStyleSheet(
            f"QPushButton{{background:{COLORS['surface']};color:{COLORS['text_primary']};"
            f"border:1px solid {COLORS['border']};border-radius:4px;padding:8px 16px;}}"
            f"QPushButton:hover{{background:{COLORS['button_hover']};}}"
        )
        self.export_btn.clicked.connect(self._export_excel)
        lay.addWidget(self.export_btn)

        lay.addStretch()
        return bar

    def _build_summary_frame(self) -> QFrame:
        frame = QFrame()
        frame.setStyleSheet(
            f"QFrame{{background:{COLORS['surface']};border:1px solid {COLORS['border']};"
            f"border-radius:6px;}}"
        )
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(16, 8, 16, 8)
        lay.setSpacing(30)

        def _stat(title):
            col = QVBoxLayout()
            lbl_t = QLabel(title)
            lbl_t.setStyleSheet(f"color:{COLORS['text_secondary']};font-size:11px;")
            lbl_v = QLabel("0.00")
            lbl_v.setStyleSheet(
                f"color:{COLORS['text_primary']};font-size:14px;font-weight:bold;"
            )
            col.addWidget(lbl_t)
            col.addWidget(lbl_v)
            lay.addLayout(col)
            return lbl_v

        self.lbl_ob_dr   = _stat("Opening Debit")
        self.lbl_ob_cr   = _stat("Opening Credit")
        self._add_vsep(lay)
        self.lbl_per_dr  = _stat("Period Debit")
        self.lbl_per_cr  = _stat("Period Credit")
        self._add_vsep(lay)
        self.lbl_cl_dr   = _stat("Closing Debit")
        self.lbl_cl_cr   = _stat("Closing Credit")
        self._add_vsep(lay)

        # Status label (BALANCED / NOT BALANCED)
        self.lbl_status = QLabel("—")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet(
            f"font-size:15px;font-weight:bold;color:{COLORS['text_secondary']};"
            f"border:1px solid {COLORS['border']};border-radius:4px;padding:6px 14px;"
        )
        lay.addWidget(self.lbl_status)
        lay.addStretch()
        return frame

    @staticmethod
    def _add_vsep(lay):
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color:#334155;")
        lay.addWidget(sep)

    def _build_table(self) -> QTableWidget:
        self.table = QTableWidget(0, COL_COUNT)
        self.table.setHorizontalHeaderLabels(HEADERS)
        self.table.setStyleSheet(
            f"QTableWidget{{background:{COLORS['surface']};"
            f"border:1px solid {COLORS['border']};border-radius:6px;"
            f"gridline-color:{COLORS['border']};}}"
            f"QTableWidget::item{{padding:6px;border-bottom:1px solid {COLORS['border']};}}"
            f"QHeaderView::section{{background:{COLORS['primary']};color:white;"
            f"padding:8px;border:none;border-bottom:2px solid {COLORS['primary_dark']};"
            f"font-weight:bold;font-size:12px;}}"
            f"QTableWidget::item:selected{{background:{COLORS['primary']};color:white;}}"
            f"QTableWidget::item:alternate{{background:#1e293b;}}"
        )
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setWordWrap(False)
        self.table.verticalHeader().setVisible(False)

        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(COL_SL,      QHeaderView.ResizeToContents)
        hdr.setSectionResizeMode(COL_ACCOUNT, QHeaderView.Stretch)
        hdr.setSectionResizeMode(COL_TYPE,    QHeaderView.ResizeToContents)
        for col in (COL_OB_DR, COL_OB_CR, COL_PER_DR, COL_PER_CR, COL_CL_DR, COL_CL_CR):
            hdr.setSectionResizeMode(col, QHeaderView.ResizeToContents)

        return self.table

    # ------------------------------------------------------------------
    # DATA LOADING
    # ------------------------------------------------------------------

    def refresh(self):
        """Called when company changes or window is focused."""
        self._company_id = (
            active_company_manager.get_active_company_id()
            if active_company_manager else None
        )
        if self._company_id and self.db and not self._tb_logic:
            self._tb_logic = TrialBalanceLogic(self.db)
        self.table.setRowCount(0)
        self._reset_summary()

    def load_trial_balance(self):
        """Load and display trial balance for current filters."""
        self._company_id = (
            active_company_manager.get_active_company_id()
            if active_company_manager else None
        )
        if not self._company_id:
            QMessageBox.warning(self, "No Company", "Please open a company first.")
            return
        if not self._tb_logic:
            self._tb_logic = TrialBalanceLogic(self.db)

        from_date = self.from_date.date().toPython()
        to_date   = self.to_date.date().toPython()
        type_filter = self.type_combo.currentText()
        search = self.search_box.text().strip()

        result = self._tb_logic.get_trial_balance(
            self._company_id, from_date, to_date,
            account_type_filter=type_filter if type_filter != 'All' else None,
            search_term=search or None,
        )
        self._populate_table(result['rows'])
        self._update_summary(result['totals'])

    def _on_search_timer(self):
        """Debounced search — reload if data already displayed."""
        if self.table.rowCount() > 0 or self._company_id:
            self.load_trial_balance()

    # ------------------------------------------------------------------
    # TABLE POPULATION
    # ------------------------------------------------------------------

    def _populate_table(self, rows):
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)

        type_color = {
            'cash_bank':     '#38bdf8',
            'party':         '#a78bfa',
            'income':        '#4ade80',
            'expense':       '#f87171',
            'tax_liability': '#fbbf24',
            'capital':       '#fb923c',
            'stock':         '#22d3ee',
        }

        for row_data in rows:
            row = self.table.rowCount()
            self.table.insertRow(row)

            # SL
            self._set_item(row, COL_SL, str(row_data['sl']), Qt.AlignCenter)

            # Account name
            self._set_item(row, COL_ACCOUNT, row_data['account_name'])

            # Type (with color)
            atype = row_data['account_type']
            cat   = row_data['category']
            ti = QTableWidgetItem(cat)
            ti.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
            color = type_color.get(atype, COLORS['text_secondary'])
            ti.setForeground(QColor(color))
            self.table.setItem(row, COL_TYPE, ti)

            # Numeric columns
            self._set_amount(row, COL_OB_DR,  row_data['ob_dr'])
            self._set_amount(row, COL_OB_CR,  row_data['ob_cr'])
            self._set_amount(row, COL_PER_DR, row_data['period_dr'])
            self._set_amount(row, COL_PER_CR, row_data['period_cr'])
            self._set_amount(row, COL_CL_DR,  row_data['closing_dr'])
            self._set_amount(row, COL_CL_CR,  row_data['closing_cr'])

        self.table.setUpdatesEnabled(True)

    def _set_item(self, row, col, text, align=Qt.AlignLeft | Qt.AlignVCenter):
        item = QTableWidgetItem(text)
        item.setTextAlignment(align)
        self.table.setItem(row, col, item)

    def _set_amount(self, row, col, value: float):
        text = _fmt(value)
        item = QTableWidgetItem(text)
        item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        if value > 0.001:
            item.setForeground(QColor(COLORS['text_primary']))
        self.table.setItem(row, col, item)

    # ------------------------------------------------------------------
    # SUMMARY
    # ------------------------------------------------------------------

    def _update_summary(self, totals: dict):
        self.lbl_ob_dr.setText(_fmt_total(totals['ob_dr']))
        self.lbl_ob_cr.setText(_fmt_total(totals['ob_cr']))
        self.lbl_per_dr.setText(_fmt_total(totals['period_dr']))
        self.lbl_per_cr.setText(_fmt_total(totals['period_cr']))
        self.lbl_cl_dr.setText(_fmt_total(totals['closing_dr']))
        self.lbl_cl_cr.setText(_fmt_total(totals['closing_cr']))

        if totals['balanced']:
            self.lbl_status.setText("BALANCED ✓")
            self.lbl_status.setStyleSheet(
                "font-size:14px;font-weight:bold;color:#4ade80;"
                "border:1px solid #4ade80;border-radius:4px;padding:6px 14px;"
            )
        else:
            diff = totals['difference']
            self.lbl_status.setText(f"NOT BALANCED\n±{diff:,.2f}")
            self.lbl_status.setStyleSheet(
                "font-size:13px;font-weight:bold;color:#f87171;"
                "border:1px solid #f87171;border-radius:4px;padding:6px 14px;"
            )

    def _reset_summary(self):
        for lbl in (self.lbl_ob_dr, self.lbl_ob_cr, self.lbl_per_dr,
                    self.lbl_per_cr, self.lbl_cl_dr, self.lbl_cl_cr):
            lbl.setText("0.00")
        self.lbl_status.setText("—")
        self.lbl_status.setStyleSheet(
            f"font-size:15px;font-weight:bold;color:{COLORS['text_secondary']};"
            "border:1px solid #334155;border-radius:4px;padding:6px 14px;"
        )

    # ------------------------------------------------------------------
    # EXPORT
    # ------------------------------------------------------------------

    def _export_excel(self):
        """Export trial balance to Excel via openpyxl (if available)."""
        if self.table.rowCount() == 0:
            QMessageBox.information(self, "No Data", "Load trial balance first.")
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
        except ImportError:
            QMessageBox.warning(
                self, "Export Unavailable",
                "Install openpyxl to enable Excel export:\n  pip install openpyxl"
            )
            return

        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Trial Balance", "trial_balance.xlsx",
            "Excel Files (*.xlsx)"
        )
        if not path:
            return

        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Trial Balance"

            header_fill = PatternFill("solid", fgColor="1e3a5f")
            header_font = Font(color="FFFFFF", bold=True, size=11)
            border = Border(
                bottom=Side(style='thin', color='334155')
            )

            # Write headers
            for col_i, h in enumerate(HEADERS, 1):
                cell = ws.cell(row=1, column=col_i, value=h.replace('\n', ' '))
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center', vertical='center')

            # Write data rows
            for row_i in range(self.table.rowCount()):
                for col_i in range(COL_COUNT):
                    item = self.table.item(row_i, col_i)
                    val = item.text().replace(',', '') if item else ''
                    # Try numeric
                    if col_i >= COL_OB_DR:
                        try:
                            val = float(val) if val else 0.0
                        except ValueError:
                            pass
                    cell = ws.cell(row=row_i + 2, column=col_i + 1, value=val)
                    cell.border = border
                    if col_i >= COL_OB_DR:
                        cell.alignment = Alignment(horizontal='right')
                        cell.number_format = '#,##0.00'

            # Auto-width
            for col in ws.columns:
                max_len = max((len(str(c.value or '')) for c in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 30)

            wb.save(path)
            QMessageBox.information(self, "Exported", f"Saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))
