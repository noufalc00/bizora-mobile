"""
Sales Entry widget for the Accounting Desktop Application.
Manages sales invoice creation with compact desktop layout.
Refactored into modular structure for better maintainability.
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate, QEvent, QTimer, Signal
from PySide6.QtGui import QDoubleValidator

from config import active_company_manager
from db import Database
from logic.sales_logic import SalesLogic
from logic.party_logic import PartyLogic
from logic.product_logic import ProductLogic
from logic.party_balance_engine import PartyBalanceEngine
from logic.stock_logic import StockLogic

from .sales_entry_ui import SalesEntryUIMixin
from .sales_entry_delegate import SalesBillDelegate
from .sales_entry_helpers import safe_item_text as _safe_item_text, safe_float_from_cell as _safe_float_from_cell, ensure_row_items_initialized as _ensure_row_items_initialized, clear_product_linked_row_data
from .sales_entry_calculations import recalculate_row as _recalculate_row, calculate_totals as _calculate_totals, _write_totals_to_widgets as _write_totals_to_widgets
from .sales_entry_popup import setup_party_completer
from . import theme


class SalesEntryWidget(SalesEntryUIMixin, QWidget):
    window_closed = Signal()

    def __init__(self, db=None):
        super().__init__()
        self.db = db or Database()
        self.sales_logic = SalesLogic(self.db)
        self.party_logic = PartyLogic(self.db)
        self.product_logic = ProductLogic(self.db)
        self.balance_engine = PartyBalanceEngine(self.db)
        self.stock_logic = StockLogic(self.db)
        self.current_sale_id = None
        self.sale_items = []
        self.products_data = []
        self.parties_data = []
        self.last_barcode_filled_row = -1  # Track last row filled by barcode for F1 targeting
        self.manually_selected_row = -1  # Track row manually selected by mouse for rewrite
        self._amt_recvd_user_edited = False  # Track if user manually edited Amt Recvd in credit mode
        self._suppress_amt_recvd_signal = False  # Guard to avoid programmatic writes marking user-edited
        self._row_discount_total = 0.0  # Row-level discount sum (set by calculate_totals)
        self._sales_nav_ids = []  # Cached list of saved sale ids for prev/next navigation
        self._update_confirmed = False  # True once user confirms editing a saved bill via barcode
        # Invoice-no duplicate handling: blinking red + focus lock
        self._invoice_dup_lock = False
        self._invoice_blink_on = False
        self._invoice_blink_timer = QTimer(self)
        self._invoice_blink_timer.setInterval(400)
        self._invoice_blink_timer.timeout.connect(self._toggle_invoice_blink)
        # Linked Sales Return state (when Return button opens Sales Return)
        self._linked_sales_return_id = None
        self._linked_sales_return_amount = 0.0
        self._sales_return_window = None  # Reference to open Sales Return window
        # Stock check warning: blinking red
        self._stock_blink_on = False
        self._stock_blink_timer = QTimer(self)
        self._stock_blink_timer.setInterval(400)
        self._stock_blink_timer.timeout.connect(self._toggle_stock_blink)
        # Stock warning state tracking
        self._stock_warning_active = False
        self._stock_warning_row = -1

        # Use shared GST state codes from theme module
        self.gst_state_codes = theme.GST_STATE_CODES

        self.setup_ui()
        self.load_parties()
        self.load_products()
        self.clear_form()
        self._install_event_filters()
        self._wire_signals()
        self._initialize_state()
        self._setup_customer_completer()

    # ==================== INITIALIZATION HELPERS ====================

    def _install_event_filters(self):
        """Install event filters for keyboard navigation and select-all-on-focus."""
        # Table viewport for mouse press events (clicks happen on viewport, not table)
        if hasattr(self, 'items_table'):
            self.items_table.viewport().installEventFilter(self)

        # Party section fields for Enter/Esc flow
        for field in ['customer_name_input', 'address_input', 'mobile_input',
                      'gstin_input', 'narration_input', 'barcode_input']:
            if hasattr(self, field):
                getattr(self, field).installEventFilter(self)

        # State combo (editable) needs filter on its lineEdit too
        if hasattr(self, 'state_combo'):
            self.state_combo.installEventFilter(self)
            if self.state_combo.lineEdit():
                self.state_combo.lineEdit().installEventFilter(self)

        # Discount field for Down-Arrow % trigger
        if hasattr(self, 'discount_total_input'):
            self.discount_total_input.installEventFilter(self)

        # Select-all-on-focus on every editable QLineEdit
        for le in self.findChildren(QLineEdit):
            if not le.isReadOnly():
                le.installEventFilter(self)

    def _wire_signals(self):
        """Connect all Qt signals to their handlers."""
        # Nature combo
        if hasattr(self, 'nature_combo'):
            self.nature_combo.currentTextChanged.connect(self.on_nature_changed)

        # Checkboxes
        if hasattr(self, 'check_stock_tick'):
            self.check_stock_tick.stateChanged.connect(self.on_check_stock_changed)
        if hasattr(self, 'divide_tax_tick'):
            self.divide_tax_tick.stateChanged.connect(self.on_divide_tax_changed)
        if hasattr(self, 'invoice_checkbox'):
            self.invoice_checkbox.toggled.connect(self.on_invoice_checkbox_toggled)

        # Footer payment fields
        if hasattr(self, 'sales_type_combo'):
            self.sales_type_combo.currentTextChanged.connect(self.on_sales_type_changed)
        if hasattr(self, 'customer_name_input'):
            self.customer_name_input.textChanged.connect(self.on_party_name_changed)
        if hasattr(self, 'amount_receive_input'):
            self.amount_receive_input.textEdited.connect(self.on_amt_recvd_edited)

        # Product search field
        if hasattr(self, 'product_input'):
            self.product_input.returnPressed.connect(self.on_product_enter)

        # Return button - opens Sales Return with context
        if hasattr(self, 'return_btn'):
            self.return_btn.clicked.connect(self.on_return_button_clicked)

        # Adjustment fields
        if hasattr(self, 'freight_input'):
            self.freight_input.textChanged.connect(self.calculate_totals)
        if hasattr(self, 'discount_total_input'):
            self.discount_total_input.textChanged.connect(self.on_footer_discount_changed)

        # Invoice duplicate check and focus lock
        if hasattr(self, 'invoice_no_input'):
            self.invoice_no_input.textChanged.connect(self.on_invoice_no_changed)
            app = QApplication.instance()
            if app is not None:
                app.focusChanged.connect(self._on_global_focus_changed)

    def _initialize_state(self):
        """Set initial UI state after wiring signals."""
        self._sync_invoice_input_editable()
        self.update_footer_payment_fields()
        self._sync_print_ob_visibility()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(2)
        layout.setContentsMargins(3, 3, 3, 3)

        # ZONE A - Page Header Strip
        header_strip = self.build_page_header_strip()
        layout.addWidget(header_strip)

        # ZONE B - Top Invoice Command Strip
        invoice_strip = self.build_invoice_command_strip()
        layout.addWidget(invoice_strip)

        # ZONE C - Party/Customer Information Matrix
        party_matrix = self.build_party_information_matrix()
        layout.addWidget(party_matrix)

        # ZONE D - Product Entry Strip
        product_strip = self.build_product_entry_strip()
        layout.addWidget(product_strip)

        # ZONE E - Bill Options/Live Status Strip
        status_strip = self.build_status_options_strip()
        layout.addWidget(status_strip)

        # ZONE F - Main Billing Table Zone
        table_zone = self.build_items_table_zone()
        layout.addWidget(table_zone, 1)

        # ZONE G + H - Lower Control Panel with Totals
        bottom_zone = self.build_lower_control_panel()
        layout.addWidget(bottom_zone)

    # ==================== WRAPPER METHODS FOR IMPORTED FUNCTIONS ====================
    
    def calculate_totals(self):
        """Wrapper for imported calculate_totals function."""
        totals = _calculate_totals(self)
        _write_totals_to_widgets(self, totals)
        # Also update return adjustment display if present
        self.update_return_adjustment_display()
        # Refresh payment-related footer fields (Amt Recvd / O/B / C/B / Balance)
        if hasattr(self, 'update_footer_payment_fields'):
            self.update_footer_payment_fields()
    
    def recalculate_row(self, row, source_column=None, live_value=None):
        """Wrapper for imported recalculate_row function."""
        _recalculate_row(self, row, source_column, live_value)
    
    def safe_item_text(self, row, col, default=""):
        """Wrapper for imported safe_item_text function."""
        return _safe_item_text(self.items_table, row, col, default)
    
    def safe_float_from_cell(self, row, col, default=0.0):
        """Wrapper for imported safe_float_from_cell function."""
        return _safe_float_from_cell(self.items_table, row, col, default)
    
    def ensure_row_items_initialized(self, row):
        """Wrapper for imported ensure_row_items_initialized function."""
        _ensure_row_items_initialized(self.items_table, row)


    # ==================== LOGIC METHODS (all preserved) ====================

    def load_parties(self):
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            result = self.party_logic.get_parties(active_company['id'])
            if result['success']:
                # Filter for Debitors and Both for sales entry
                self.parties_data = [p for p in result['data'] if p.get('party_type') in ['Debitor', 'Both']]
        except Exception as e:
            print(f"Failed to load parties: {e}")

    def refresh_parties(self):
        """Refresh parties list from database - called after new party is saved."""
        self.load_parties()
        # Re-setup customer completer with updated parties
        self._setup_customer_completer()

    def load_products(self):
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            result = self.product_logic.get_products(active_company['id'])
            if result['success']:
                self.products_data = result['data']
                self.products_dict = {p['id']: p for p in self.products_data}
                # Fast lookup caches for high-volume product catalogs
                self.products_by_barcode = {}
                self.products_by_name_exact = {}
                for p in self.products_data:
                    bc = str(p.get('barcode', '')).strip()
                    if bc:
                        self.products_by_barcode[bc] = p
                    name_key = str(p.get('name', '')).strip().lower()
                    if name_key:
                        self.products_by_name_exact[name_key] = p
        except Exception as e:
            print(f"Failed to load products: {e}")

    def update_affected_products_stock(self, affected_product_ids):
        """Update stock quantities only for affected products after a sale/purchase.

        This is much faster than load_products() which reloads ALL products.
        Uses batch query to get all balances in a single database call.
        """
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            # Filter out None values and convert to list
            product_ids = [pid for pid in affected_product_ids if pid]
            if not product_ids:
                return

            # Get all balances in a single query (much faster than individual queries)
            balances = self.db.get_stock_balances_for_products(
                active_company['id'], product_ids
            )

            # Update local cache with new balances
            for product_id, new_stock in balances.items():
                # Update in products_dict cache
                if product_id in self.products_dict:
                    self.products_dict[product_id]['quantity'] = new_stock
                # Also update in products_data list
                for p in self.products_data:
                    if p.get('id') == product_id:
                        p['quantity'] = new_stock
                        break
        except Exception as e:
            print(f"Failed to update affected products stock: {e}")

    # ==================== SIGNAL HANDLERS ====================

    def on_gstin_changed(self, text):
        max_gstin_length = 15
        cursor_pos = self.gstin_input.cursorPosition()

        filtered_text = "".join(char for char in text if char.isalnum())
        filtered_text = filtered_text[:max_gstin_length]
        upper_text = filtered_text.upper()

        if upper_text != text:
            self.gstin_input.blockSignals(True)
            self.gstin_input.setText(upper_text)
            self.gstin_input.setCursorPosition(min(cursor_pos, len(upper_text)))
            self.gstin_input.blockSignals(False)

        # Auto-fill State from GSTIN state code
        if len(upper_text) >= 2 and upper_text[:2].isdigit():
            state_code = upper_text[:2]
            if state_code in self.gst_state_codes:
                expected_state = self.gst_state_codes[state_code]
                self.state_combo.blockSignals(True)
                self.state_combo.setCurrentText(expected_state)
                self.state_combo.blockSignals(False)
        else:
            # GSTIN is blank or less than 2 digits - clear state field immediately
            self.state_combo.blockSignals(True)
            self.state_combo.setCurrentIndex(0)
            self.state_combo.blockSignals(False)

    def on_state_changed(self, text):
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []
        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)
        if new_text != text:
            cursor_pos = self.state_combo.cursorPosition()
            self.state_combo.blockSignals(True)
            self.state_combo.setText(new_text)
            self.state_combo.setCursorPosition(min(cursor_pos, len(new_text)))
            self.state_combo.blockSignals(False)

    def on_customer_name_changed(self, text):
        """Handle customer name text change - apply title case formatting."""
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []
        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)
        if new_text != text:
            cursor_pos = self.customer_name_input.cursorPosition()
            self.customer_name_input.blockSignals(True)
            self.customer_name_input.setText(new_text)
            self.customer_name_input.setCursorPosition(min(cursor_pos, len(new_text)))
            self.customer_name_input.blockSignals(False)

    def _setup_customer_completer(self):
        """Set up party completer for customer name field."""
        if not hasattr(self, 'customer_name_input') or not hasattr(self, 'parties_data'):
            return
        setup_party_completer(self.customer_name_input, self, self.on_party_selected)

    def on_party_selected(self, model_idx, editor):
        """Handle party selection from completer popup."""
        party = model_idx.data(Qt.UserRole)
        if not party:
            return

        # Update editor text with party name ONLY
        editor.setText(party.get('name', ''))

        # Auto-fill related fields if they exist
        if hasattr(self, 'address_input'):
            self.address_input.setText(party.get('address', ''))

        if hasattr(self, 'mobile_input'):
            self.mobile_input.setText(party.get('mobile_number', ''))

        if hasattr(self, 'gstin_input'):
            self.gstin_input.setText(party.get('gstin', ''))

        # Update O/B display from party data immediately when party is selected
        self.update_footer_payment_fields()

    def on_address_changed(self, text):
        """Handle address text change - apply title case formatting."""
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []
        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)
        if new_text != text:
            cursor_pos = self.address_input.cursorPosition()
            self.address_input.blockSignals(True)
            self.address_input.setText(new_text)
            self.address_input.setCursorPosition(min(cursor_pos, len(new_text)))
            self.address_input.blockSignals(False)

    def on_check_stock_changed(self, state):
        """Handle check_stock_tick state change - clear warning when unticked."""
        # Clear qty_invalid flag in delegate if checkbox is unticked
        if state == 0:  # Unchecked
            if hasattr(self.items_table, 'itemDelegate'):
                delegate = self.items_table.itemDelegate()
                if hasattr(delegate, 'qty_invalid'):
                    delegate.qty_invalid = False
            # Clear warning state and restore normal display
            self.clear_stock_warning_state()
            current_row = self.items_table.currentRow()
            self.update_stock_display_for_row(current_row)

    def on_divide_tax_changed(self, state):
        """Handle divide_tax_tick state change - recalculate all rows."""
        # Guard: Only process if table and sale_items are initialized
        if not hasattr(self, 'items_table') or not hasattr(self, 'sale_items'):
            return
        if self.items_table.rowCount() == 0 or len(self.sale_items) == 0:
            return
        
        # Loop through all existing rows and recalculate
        for row in range(self.items_table.rowCount()):
            if row < len(self.sale_items):
                self.recalculate_row(row)
        # Recalculate totals after all rows are updated
        self.calculate_totals()
    
    def on_nature_changed(self, text):
        """Handle Nature change to activate/deactivate tax fields based on GST type."""
        if not text:
            return

        is_local = (text == "Local")
        
        # Update tax field flags in delegate
        if hasattr(self, 'table_delegate'):
            self.table_delegate.is_local_tax = is_local
        
        # Clear disabled tax fields and repopulate enabled fields with correct tax split
        for row in range(self.items_table.rowCount()):
            if row >= len(self.sale_items):
                continue
            
            product_id = self.sale_items[row].get('product_id')
            product = self.products_dict.get(product_id) if product_id else None

            # Get tax values from product
            cgst_val = 0
            sgst_val = 0
            igst_val = 0
            cess_val = 0
            if product:
                cgst_val = product.get('cgst', 0)
                sgst_val = product.get('sgst', 0)
                igst_val = product.get('igst', 0)
                cess_val = product.get('cess', 0)
            
            if is_local:
                # Local: use product's CGST and SGST, set IGST to 0
                igst_item = self.items_table.item(row, 5)
                if igst_item:
                    igst_item.setText("0")
                
                cgst_item = self.items_table.item(row, 3)
                if cgst_item:
                    cgst_item.setText(f"{cgst_val:.2f}")
                sgst_item = self.items_table.item(row, 4)
                if sgst_item:
                    sgst_item.setText(f"{sgst_val:.2f}")
            else:
                # Inter-state: use product's IGST, set CGST and SGST to 0
                cgst_item = self.items_table.item(row, 3)
                if cgst_item:
                    cgst_item.setText("0")
                sgst_item = self.items_table.item(row, 4)
                if sgst_item:
                    sgst_item.setText("0")
                
                igst_item = self.items_table.item(row, 5)
                if igst_item:
                    igst_item.setText(f"{igst_val:.2f}")
            
            self.recalculate_row(row)

    def get_product_rate_from_selector(self, product):
        sales_rate_selection = self.rate_selector_combo.currentText()
        if sales_rate_selection == "Sales Rate":
            return product.get('sale_price', 0)
        elif sales_rate_selection == "Purchase Rate":
            return product.get('purchase_rate', 0)
        elif sales_rate_selection == "Wholesale Rate":
            return product.get('wholesale_rate', 0)
        elif sales_rate_selection == "MRP":
            return product.get('mrp', 0)
        else:
            return product.get('sale_price', 0)

    def find_row_by_barcode(self, barcode):
        """Find row index by barcode in the table."""
        for row in range(self.items_table.rowCount()):
            if row < len(self.sale_items):
                product_id = self.sale_items[row].get('product_id')
                if product_id:
                    product = self.products_dict.get(product_id)
                    if product and product.get('barcode') == barcode:
                        return row
        return -1

    def update_stock_display_for_row(self, row, warning_text=None, warning_mode=False):
        """Update stock_display for a given row with real stock quantity or warning.

        Args:
            row: Row index to get stock for
            warning_text: If provided, show this warning text instead of stock
            warning_mode: If True, show warning state (red, blinking if active)
        """
        if not hasattr(self, 'stock_display'):
            return

        if warning_text and warning_mode:
            # Show warning text
            self.stock_display.setText(warning_text)
            self.stock_display.setStyleSheet("color: #ff0000;")
            # Start blinking if not already running
            if hasattr(self, '_stock_blink_timer'):
                self._stock_blink_on = False
                if not self._stock_blink_timer.isActive():
                    self._stock_blink_timer.start()
            return

        # Normal mode: show real stock quantity
        if row < 0 or row >= len(self.sale_items):
            self.stock_display.setText("0.000")
            self.stock_display.setStyleSheet("color: #00ff00;")
            return

        product_id = self.sale_items[row].get('product_id')
        if not product_id:
            self.stock_display.setText("0.000")
            self.stock_display.setStyleSheet("color: #00ff00;")
            return

        product = self.products_dict.get(product_id)
        if not product:
            self.stock_display.setText("0.000")
            self.stock_display.setStyleSheet("color: #00ff00;")
            return

        try:
            active_company = active_company_manager.get_active_company()
            if active_company:
                stock_qty = self.db.get_stock_balance_from_movements(active_company['id'], product_id)
            else:
                stock_qty = float(product.get('quantity', 0) or 0)
        except Exception:
            stock_qty = float(product.get('quantity', 0) or 0)
        self.stock_display.setText(f"{stock_qty:.3f}")
        self.stock_display.setStyleSheet("color: #00ff00;")

    def clear_stock_warning_state(self):
        """Clear active stock warning state and restore normal display."""
        self._stock_warning_active = False
        self._stock_warning_row = -1
        if hasattr(self, '_stock_blink_timer') and self._stock_blink_timer.isActive():
            self._stock_blink_timer.stop()
            self._stock_blink_on = False
        if hasattr(self, 'stock_display'):
            self.stock_display.setStyleSheet("color: #00ff00;")

    def _trigger_stock_check_for_row(self, row):
        """Live stock check for a given row after barcode/selection fills it.

        If check_stock is enabled and row qty exceeds stock, show blinking red
        warning on stock_display, set delegate qty_invalid, and focus the Qty
        editor so Enter/Esc are locked until the user fixes the quantity.

        Returns:
            True if invalid stock warning was triggered (Qty editor is active and locked)
            False if no warning / valid state / no action
        """
        if not hasattr(self, 'check_stock_tick') or not self.check_stock_tick.isChecked():
            # Clear any existing warning if check_stock is off
            self.clear_stock_warning_state()
            return False
        if row < 0 or row >= self.items_table.rowCount():
            return False
        if row >= len(self.sale_items) or not self.sale_items[row]:
            return False
        product_id = self.sale_items[row].get('product_id')
        if not product_id:
            return False
        qty = self._safe_float(self.items_table.item(row, 8).text() if self.items_table.item(row, 8) else "0", 0.0)
        product = self.products_dict.get(product_id)
        if not product:
            return False
        try:
            active_company = active_company_manager.get_active_company()
            if active_company:
                stock_qty = self.db.get_stock_balance_from_movements(active_company['id'], product_id)
            else:
                stock_qty = float(product.get('quantity', 0) or 0)
        except Exception:
            stock_qty = float(product.get('quantity', 0) or 0)
        # Trigger warning if qty > 0 and (stock is 0 or below, or qty exceeds available stock)
        if qty > 0 and (stock_qty <= 0 or qty > stock_qty):
            # Set warning state
            self._stock_warning_active = True
            self._stock_warning_row = row
            # Lock delegate FIRST so qty_invalid is set before editor opens
            delegate = self.items_table.itemDelegate()
            if delegate:
                delegate.qty_invalid = True
            # Focus Qty cell and open editor (this triggers on_table_selection_changed
            # which would overwrite stock_display, so we must set the warning AFTER)
            self.items_table.setCurrentCell(row, 8)
            self.items_table.editItem(self.items_table.item(row, 8))
            # Re-assert qty_invalid after editor opens (createEditor/setEditorData may not touch it,
            # but be safe)
            if delegate:
                delegate.qty_invalid = True
            # Show warning in stock_display LAST so it is not overwritten by selection change
            self.update_stock_display_for_row(row, warning_text=f"OUT OF STOCK ({stock_qty:.3f})", warning_mode=True)
            return True  # Invalid state activated
        else:
            # Valid quantity - clear warning state and show normal stock
            self.clear_stock_warning_state()
            delegate = self.items_table.itemDelegate()
            if delegate:
                delegate.qty_invalid = False
            self.update_stock_display_for_row(row)
            return False  # Valid state

    def increment_row_qty(self, row):
        """Increment Qty of existing row by 1 and recalculate.

        Returns:
            True if invalid stock warning was triggered (Qty editor is active and locked)
            False if no warning / valid state / no action
        """
        if row < 0 or row >= self.items_table.rowCount():
            return False
        
        # Ensure row items are initialized
        self.ensure_row_items_initialized(row)
        
        try:
            current_qty = self._safe_float(self.items_table.item(row, 8).text() if self.items_table.item(row, 8) else "0", 0.0)
            new_qty = current_qty + 1.0
            self.items_table.item(row, 8).setText(str(new_qty))
            self.recalculate_row(row)
            self.calculate_totals()
            # Live stock check after increment - this is the final stock check decision point
            return self._trigger_stock_check_for_row(row)
        except Exception:
            return False
    
    def add_product_to_table(self, product, qty=None, rate=None):
        """Add product to table, reusing blank row if available.

        Returns:
            Tuple (row, invalid_triggered) where:
            - row: the row index where product was added
            - invalid_triggered: True if invalid stock warning was triggered (Qty editor is active and locked)
        """
        # STRICT RULE: Check if a blank row already exists before creating a new row
        blank_row = self.find_blank_row()
        if blank_row >= 0:
            # Blank row already exists, fill it instead of creating a new row
            invalid_triggered = self.fill_blank_row_with_product(blank_row, product)
            return blank_row, invalid_triggered
        
        # Get qty
        if qty is None:
            qty = 1.0

        # Get rate if not provided
        if rate is None:
            rate = self.get_product_rate_from_selector(product)

        # Add item to table
        row = self.items_table.rowCount()
        self.items_table.insertRow(row)
        
        # Track this as the last barcode-filled row for F1 targeting
        self.last_barcode_filled_row = row

        # Initialize all cells with QTableWidgetItem immediately
        for col in range(15):
            if self.items_table.item(row, col) is None:
                self.items_table.setItem(row, col, QTableWidgetItem(""))

        # SL No
        sl_item = self.items_table.item(row, 0)
        sl_item.setText(str(row + 1))
        sl_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

        # Product (editable)
        product_item = self.items_table.item(row, 1)
        product_item.setText(product['name'])
        product_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # HSN (editable)
        hsn_item = self.items_table.item(row, 2)
        hsn_item.setText(product.get('hsn', ''))
        hsn_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # CGST, SGST, IGST based on Nature
        is_local = (self.nature_combo.currentText() == "Local")
        
        cgst_item = self.items_table.item(row, 3)
        cgst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
        
        sgst_item = self.items_table.item(row, 4)
        sgst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
        
        igst_item = self.items_table.item(row, 5)
        igst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
        
        if is_local:
            # Local: use product's CGST and SGST, set IGST to 0
            cgst_item.setText(f"{product.get('cgst', 0):.2f}")
            sgst_item.setText(f"{product.get('sgst', 0):.2f}")
            igst_item.setText("0")
        else:
            # Inter-state: use product's IGST, set CGST and SGST to 0
            cgst_item.setText("0")
            sgst_item.setText("0")
            igst_item.setText(f"{product.get('igst', 0):.2f}")

        # CESS (editable)
        cess_item = self.items_table.item(row, 6)
        cess_item.setText(str(product.get('cess', 0)))
        cess_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # Rate (editable)
        rate_item = self.items_table.item(row, 7)
        rate_item.setText(str(rate))
        rate_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # Qty (editable)
        qty_item = self.items_table.item(row, 8)
        qty_item.setText(str(qty))
        qty_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # Gross (editable)
        gross_item = self.items_table.item(row, 9)
        gross_item.setText(str(rate))
        gross_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # Discount (editable)
        discount_item = self.items_table.item(row, 10)
        discount_item.setText("0")
        discount_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

        # Net, Tax, Grand Total will be calculated by recalculate_row
        net_item = self.items_table.item(row, 11)
        net_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

        tax_item = self.items_table.item(row, 12)
        tax_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

        grand_total_item = self.items_table.item(row, 13)
        grand_total_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

        # Calculate total tax percent
        tax_percent = product.get('cgst', 0) + product.get('sgst', 0) + product.get('igst', 0) + product.get('cess', 0)

        # Store product data for this row
        self.sale_items.append({
            'product_id': product['id'],
            'hsn': product.get('hsn', ''),
            'cgst': product.get('cgst', 0),
            'sgst': product.get('sgst', 0),
            'igst': product.get('igst', 0),
            'cess': product.get('cess', 0),
            'tax_percent': tax_percent,
            'rate': rate
        })

        # Recalculate row to compute tax and total correctly
        # Do NOT pass source_column to avoid zeroing tax values
        self.recalculate_row(row)

        # Do NOT set current cell to prevent automatic row selection
        # Keyboard workflow should not cause row highlighting
        
        self.calculate_totals()
        self.on_table_selection_changed()
        
        # Scroll to filled row to ensure it's visible
        from PySide6.QtWidgets import QAbstractItemView
        filled_row_item = self.items_table.item(row, 0)
        if filled_row_item:
            self.items_table.scrollToItem(filled_row_item, QAbstractItemView.PositionAtCenter)

        # Live stock check for new rows too - this is the final stock check decision point
        invalid_triggered = self._trigger_stock_check_for_row(row)

        return row, invalid_triggered

    def add_blank_row(self):
        """Add a blank row to the table for manual entry.
        
        STRICT RULE: If a blank row already exists, return it instead of creating a duplicate.
        This ensures only one blank row exists at any time.
        """
        # Check if a blank row already exists
        if self.is_last_row_blank():
            # Blank row already exists, return it
            return self.items_table.rowCount() - 1
        
        # Add item to table
        row = self.items_table.rowCount()
        self.items_table.insertRow(row)

        # Block signals to prevent cellChanged from triggering recalculation during row creation
        was_blocked = self.items_table.blockSignals(True)
        try:
            # Initialize all cells with QTableWidgetItem immediately
            for col in range(14):
                if self.items_table.item(row, col) is None:
                    self.items_table.setItem(row, col, QTableWidgetItem(""))

            # SL No
            sl_item = self.items_table.item(row, 0)
            sl_item.setText(str(row + 1))
            sl_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

            # Product (editable)
            product_item = self.items_table.item(row, 1)
            product_item.setText("")
            product_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # HSN (editable)
            hsn_item = self.items_table.item(row, 2)
            hsn_item.setText("")
            hsn_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # CGST (editable)
            cgst_item = self.items_table.item(row, 3)
            cgst_item.setText("")
            cgst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # SGST (editable)
            sgst_item = self.items_table.item(row, 4)
            sgst_item.setText("")
            sgst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # IGST (editable)
            igst_item = self.items_table.item(row, 5)
            igst_item.setText("")
            igst_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # CESS (editable)
            cess_item = self.items_table.item(row, 6)
            cess_item.setText("")
            cess_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # Rate (editable)
            rate_item = self.items_table.item(row, 7)
            rate_item.setText("")
            rate_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # Qty (editable) - blank rows should have empty qty
            qty_item = self.items_table.item(row, 8)
            qty_item.setText("")
            qty_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # Gross (editable)
            gross_item = self.items_table.item(row, 9)
            gross_item.setText("")
            gross_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # Discount (editable)
            discount_item = self.items_table.item(row, 10)
            discount_item.setText("")
            discount_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)

            # Net (calculated)
            net_item = self.items_table.item(row, 11)
            net_item.setText("")
            net_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

            # Tax (calculated)
            tax_item = self.items_table.item(row, 12)
            tax_item.setText("")
            tax_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

            # Grand Total (calculated)
            grand_total_item = self.items_table.item(row, 13)
            grand_total_item.setText("")
            grand_total_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)

            # Store empty product data for this row
            self.sale_items.append({
                'product_id': None,
                'hsn': '',
                'cgst': 0,
                'sgst': 0,
                'igst': 0,
                'cess': 0,
                'tax_percent': 0,
                'rate': 0
            })

            # Do NOT set current cell to prevent automatic row selection
            # Keyboard workflow should not cause row highlighting
        finally:
            # Restore signal blocking state
            self.items_table.blockSignals(was_blocked)

        # Clear visual selection to prevent keyboard workflow from leaving blue selection
        self.items_table.clearSelection()

        # Auto-scroll to new row to keep it visible
        from PySide6.QtWidgets import QAbstractItemView
        new_row_item = self.items_table.item(row, 0)
        if new_row_item:
            self.items_table.scrollToItem(new_row_item, QAbstractItemView.PositionAtCenter)

        # Do NOT call calculate_totals or on_table_selection_changed for blank row
        # This prevents Rate, Qty, Gross from getting "0.00" values
        # These will be called when the row is actually filled with data
        
        return row

    def is_last_row_blank(self):
        """Check if the last row in the table is blank (no product)."""
        if self.items_table.rowCount() == 0:
            return False
        
        last_row = self.items_table.rowCount() - 1
        if last_row >= len(self.sale_items):
            return False
        
        # Check if product_id is None or empty
        return self.sale_items[last_row]['product_id'] is None

    def find_blank_row(self):
        """Find the first blank row in the table. Returns row index or -1 if no blank row exists."""
        for row in range(self.items_table.rowCount()):
            if row < len(self.sale_items):
                if self.sale_items[row]['product_id'] is None:
                    return row
        return -1

    def on_barcode_enter(self):
        code = str(self.barcode_input.text()).strip()

        # If we're viewing a saved bill and the user is trying to add items
        # (non-empty barcode), require an explicit confirmation before entering
        # update mode. This guards against accidental edits to posted bills.
        if code and self.current_sale_id and not self._update_confirmed:
            reply = QMessageBox.question(
                self,
                "Update Saved Bill?",
                "This is a saved bill. Do you want to update it with new items?\n\n"
                "Yes — switch to update mode and add items.\n"
                "No — keep the bill unchanged.",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply != QMessageBox.Yes:
                self.barcode_input.clear()
                self.barcode_input.setFocus()
                return
            self._update_confirmed = True
            # OK button stays labelled Update while current_sale_id is set

        if not code:
            # No barcode text entered - focus product search field
            self.product_input.setFocus()
            return

        # Ensure products are loaded
        if not self.products_data:
            self.load_products()
            if not self.products_data:
                QMessageBox.warning(self, "No Products", "No products loaded. Please add products first.")
                self.barcode_input.clear()
                self.barcode_input.setFocus()
                return

        product = None

        # Determine search mode based on checkbox
        # Use fast dict lookups instead of full-list scans for high-volume catalogs
        if self.barcode_tick.isChecked():
            # Code mode: search by product code or name (exact match)
            product = self.products_by_barcode.get(code)
            if not product:
                product = self.products_by_name_exact.get(code.lower())
        else:
            # Barcode mode: search by barcode with safe comparison
            product = self.products_by_barcode.get(code)

        if not product:
            QMessageBox.warning(self, "Product Not Found", f"No product found: {code}")
            self.barcode_input.clear()
            self.barcode_input.setFocus()
            return

        # ==================== HIGHEST PRIORITY: MANUAL MOUSE SELECTION REWRITE ====================
        # If user manually clicked a row, that row is the ONLY target - no other logic should interfere
        if self.manually_selected_row >= 0 and self.manually_selected_row < len(self.sale_items):
            target_row = self.manually_selected_row
            
            # Check if manually selected row is filled (has a product)
            if self.sale_items[target_row]['product_id'] is not None:
                # Manually selected row is filled, show confirmation dialog
                reply = QMessageBox.question(
                    self,
                    "Replace Row",
                    f"Do you want to replace row {target_row + 1}?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No
                )
                
                if reply == QMessageBox.Yes:
                    # User chose YES - replace the manually selected filled row
                    invalid_triggered = self.fill_blank_row_with_product(target_row, product)
                    # Clear manual selection after replacement
                    self.manually_selected_row = -1
                    # If stock invalid, keep Qty editor active, don't steal focus
                    if invalid_triggered:
                        self.barcode_input.clear()
                        # Do NOT set focus back to barcode_input
                        self.items_table.clearSelection()
                        return
                    # Valid stock: clear barcode and set focus normally
                    self.barcode_input.clear()
                    self.barcode_input.setFocus()
                    return
                else:
                    # User chose NO - do nothing, keep focus stable
                    self.manually_selected_row = -1
                    self.barcode_input.clear()
                    self.barcode_input.setFocus()
                    return
            else:
                # Manually selected row is blank - fill it directly
                invalid_triggered = self.fill_blank_row_with_product(target_row, product)
                # Clear manual selection after filling
                self.manually_selected_row = -1
                # If stock invalid, keep Qty editor active, don't steal focus
                if invalid_triggered:
                    self.barcode_input.clear()
                    # Do NOT set focus back to barcode_input
                    self.items_table.clearSelection()
                    return
                # Valid stock: clear barcode and set focus normally
                self.barcode_input.clear()
                self.barcode_input.setFocus()
                return
        
        # ==================== NORMAL FLOW: NO MANUAL SELECTION ====================
        # Only run this logic if no manual row was selected
        
        # Check if this barcode already exists in the table
        existing_row = self.find_row_by_barcode(product['barcode'])
        if existing_row >= 0:
            # Increment Qty of existing row
            invalid_triggered = self.increment_row_qty(existing_row)
            # If stock invalid, keep Qty editor active, don't steal focus
            if invalid_triggered:
                self.barcode_input.clear()
                # Do NOT set focus back to barcode_input
                self.items_table.clearSelection()
                return
            # Valid stock: clear barcode and set focus normally
            self.barcode_input.clear()
            self.barcode_input.setFocus()
            return
        
        # Check if there's any blank row in the table to reuse
        blank_row = self.find_blank_row()
        added_row = -1
        if blank_row >= 0:
            # Reuse the existing blank row
            invalid_triggered = self.fill_blank_row_with_product(blank_row, product)
            added_row = blank_row
        else:
            # No blank row exists, add new row
            added_row, invalid_triggered = self.add_product_to_table(product)
        
        # If stock invalid, keep Qty editor active, don't steal focus
        if invalid_triggered:
            self.barcode_input.clear()
            # Do NOT set focus back to barcode_input
            self.items_table.clearSelection()
            return
        
        # Valid stock: clear barcode and set focus normally
        self.barcode_input.clear()
        self.barcode_input.setFocus()
        # Clear table selection to prevent pre-selection after normal barcode fill
        self.items_table.clearSelection()

    def on_product_enter(self):
        """Handle product input Enter key - open product search popup."""
        self._popup_product_selected = False
        self.show_product_popup()

    def show_product_popup(self):
        """Show product search popup dialog (same pattern as sales return)."""
        from config import active_company_manager
        company_id = active_company_manager.get_active_company_id()
        if not company_id:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return

        from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QAbstractItemView
        from PySide6.QtCore import Qt, QTimer

        popup = QDialog(self)
        popup.setWindowTitle("Select Product")
        popup.resize(620, 440)
        popup.setStyleSheet("""
            QDialog { background-color: #0f172a; color: #f1f5f9; }
            QLabel { color: #facc15; font-size: 11px; font-weight: bold; }
            QLineEdit {
                background-color: #1e293b; border: 1px solid #475569; border-radius: 3px;
                color: #f1f5f9; font-size: 11px; padding: 3px 6px;
            }
            QLineEdit:focus { border: 1px solid #60a5fa; }
            QTableWidget {
                background-color: #1e293b; color: #f1f5f9; gridline-color: #334155;
                border: 1px solid #334155; font-size: 11px;
                selection-background-color: #1d4ed8; selection-color: #ffffff;
            }
            QTableWidget::item { padding: 3px; }
            QTableWidget::item:selected { background-color: #1d4ed8; color: #ffffff; }
            QHeaderView::section {
                background-color: #334155; color: #f1f5f9; font-size: 10px; font-weight: bold;
                padding: 3px; border: 1px solid #475569;
            }
            QPushButton {
                background-color: #334155; color: #f1f5f9; border: 1px solid #475569;
                border-radius: 3px; font-size: 11px; padding: 5px 12px;
            }
            QPushButton:hover { background-color: #475569; }
        """)
        layout = QVBoxLayout(popup)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(6)

        top = QHBoxLayout()
        search_lbl = QLabel("Search (name / barcode):")
        search_input = QLineEdit()
        search_input.setPlaceholderText("Type at least 2 characters…")
        top.addWidget(search_lbl)
        top.addWidget(search_input)
        layout.addLayout(top)

        hint = QLabel("Type to search. Max 100 results shown.")
        hint.setStyleSheet("color: #64748b; font-size: 10px;")
        layout.addWidget(hint)

        tbl = QTableWidget()
        tbl.setColumnCount(5)
        tbl.setHorizontalHeaderLabels(["Name", "Barcode", "Code", "Rate", "Stock"])
        tbl.verticalHeader().setVisible(False)
        tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        tbl.setColumnWidth(0, 220)
        tbl.setColumnWidth(1, 110)
        tbl.setColumnWidth(2, 80)
        tbl.setColumnWidth(3, 80)
        tbl.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(tbl)

        _search_timer = QTimer()
        _search_timer.setSingleShot(True)
        _search_timer.setInterval(200)

        def do_search():
            term = search_input.text().strip()
            tbl.setRowCount(0)
            if len(term) < 2:
                return
            results = self.db.search_products_limited(company_id, term, limit=100)
            tbl.setUpdatesEnabled(False)
            tbl.blockSignals(True)
            for product in results:
                row = tbl.rowCount()
                tbl.insertRow(row)
                name_item = QTableWidgetItem(product.get('name', ''))
                name_item.setData(Qt.UserRole, product.get('id'))
                tbl.setItem(row, 0, name_item)
                tbl.setItem(row, 1, QTableWidgetItem(str(product.get('barcode', '') or '')))
                tbl.setItem(row, 2, QTableWidgetItem(str(product.get('code', '') or '')))
                rate = float(product.get('sale_price') or product.get('mrp') or
                             product.get('wholesale_rate') or product.get('purchase_rate') or 0)
                tbl.setItem(row, 3, QTableWidgetItem(f"{rate:.2f}"))
                stock = float(product.get('quantity') or 0.0)
                tbl.setItem(row, 4, QTableWidgetItem(f"{stock:.3f}"))
            tbl.blockSignals(False)
            tbl.setUpdatesEnabled(True)
            if tbl.rowCount() > 0:
                tbl.selectRow(0)

        _search_timer.timeout.connect(do_search)
        search_input.textChanged.connect(lambda: _search_timer.start())
        # Pre-seed with whatever is already typed in product_input
        initial_term = self.product_input.text().strip() if hasattr(self, 'product_input') else ''
        search_input.setText(initial_term)
        search_input.setFocus()
        if initial_term:
            search_input.selectAll()

        def select_product():
            row = tbl.currentRow()
            if row < 0:
                return
            product_id = tbl.item(row, 0).data(Qt.UserRole)
            product_name = tbl.item(row, 0).text()
            try:
                stock_val = float(tbl.item(row, 4).text())
            except (ValueError, AttributeError):
                stock_val = 0.0
            try:
                rate_val = float(tbl.item(row, 3).text())
            except (ValueError, AttributeError):
                rate_val = 0.0
            code_val = tbl.item(row, 2).text() if tbl.item(row, 2) else ''

            self._popup_product_selected = True
            company_id2 = active_company_manager.get_active_company_id()
            full_product = self.db.get_product_by_id(company_id2, product_id) if company_id2 else None
            if full_product:
                product = full_product
            else:
                product = {'id': product_id, 'name': product_name, 'rate': rate_val, 'code': code_val}

            self.product_input.blockSignals(True)
            self.product_input.setText(product_name)
            self.product_input.blockSignals(False)
            # Update display fields
            self.category_display.setText(str(product.get('category', '')))
            self.size_display.setText(str(product.get('size', '')))
            self.color_display.setText(str(product.get('color', '')))
            popup.accept()
            self.add_product_from_popup(product)

        tbl.doubleClicked.connect(select_product)

        btns = QHBoxLayout()
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(popup.reject)
        select_btn = QPushButton("Select")
        select_btn.setStyleSheet("QPushButton { background-color: #3b82f6; color: white; border: none; border-radius: 3px; font-size: 11px; font-weight: bold; padding: 5px 14px; } QPushButton:hover { background-color: #2563eb; }")
        select_btn.clicked.connect(select_product)
        btns.addStretch()
        btns.addWidget(cancel_btn)
        btns.addWidget(select_btn)
        layout.addLayout(btns)

        def key_press(event):
            if event.key() in (Qt.Key_Return, Qt.Key_Enter):
                select_product()
            elif event.key() == Qt.Key_Escape:
                popup.reject()
            else:
                QDialog.keyPressEvent(popup, event)

        popup.keyPressEvent = key_press
        popup.exec()

    def add_product_from_popup(self, product):
        """Add product selected from popup to the items table."""
        # Use same flow as barcode - add to table with qty=1
        added_row, invalid_triggered = self.add_product_to_table(product)
        if added_row >= 0:
            self.product_input.clear()
            self.calculate_totals()
            # Focus Qty column for editing
            from .sales_entry_delegate import COL_QTY
            self.focus_table_cell_editor(added_row, COL_QTY)

    # ==================== SALES RETURN INTEGRATION ====================

    def on_return_button_clicked(self):
        """Handle Return button click - open Sales Return with current context."""
        # Check if already has a linked return
        if self._linked_sales_return_id is not None:
            reply = QMessageBox.question(
                self,
                "Return Already Linked",
                f"This bill already has a linked return (#{self._linked_sales_return_id}).\n\n"
                "Do you want to:\n"
                "• YES = Create an additional return\n"
                "• NO = Cancel and keep existing return",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return

        # Get current totals for context
        grand_total = self.get_numeric_value(self.grand_total_input)

        # Get customer details if available
        customer_name = self.customer_name_input.text().strip()
        customer_id = None
        if customer_name and hasattr(self, 'parties_data'):
            for party in self.parties_data:
                if party.get('name', '').strip() == customer_name:
                    customer_id = party.get('id')
                    break

        # Open Sales Return window with context
        self.open_sales_return_window(
            sales_entry_widget=self,
            sales_grand_total=grand_total,
            customer_id=customer_id,
            customer_name=customer_name,
            original_invoice_no=self.invoice_no_input.text().strip() if hasattr(self, 'invoice_no_input') else None
        )

    def open_sales_return_window(self, sales_entry_widget, sales_grand_total,
                                  customer_id=None, customer_name=None,
                                  original_invoice_no=None):
        """Open Sales Return window with context from Sales Entry.

        Args:
            sales_entry_widget: Reference to this SalesEntryWidget instance
            sales_grand_total: Current grand total from Sales Entry
            customer_id: Optional customer/debtor ID
            customer_name: Optional customer name
            original_invoice_no: Optional original invoice number
        """
        from PySide6.QtWidgets import QMainWindow
        from .sales_return import SalesReturnPageWidget

        # Create Sales Return widget with opened_from_sales_entry flag
        widget = SalesReturnPageWidget(
            main_window=None,  # Not needed when opened from Sales Entry
            db=self.db,
            opened_from_sales_entry=True,
            sales_entry_widget=sales_entry_widget,
            sales_grand_total=sales_grand_total
        )

        # Pre-fill customer if available
        if customer_id and hasattr(widget, 'current_party_id'):
            widget.current_party_id = customer_id
            if hasattr(widget, 'party_name_input') and customer_name:
                widget.party_name_input.setText(customer_name)
                # Trigger party details load
                if hasattr(widget, 'populate_party_details'):
                    party_data = {'id': customer_id, 'name': customer_name}
                    widget.populate_party_details(party_data)

        # Store reference to window so we can track it
        self._sales_return_window = widget

        # Create window wrapper
        window = QMainWindow(self)
        window.setWindowTitle("Sales Return (from Sales Entry)")
        window.setCentralWidget(widget)
        window.resize(1100, 750)

        # Position window offset from main window
        parent_pos = self.window().pos()
        window.move(parent_pos.x() + 40, parent_pos.y() + 40)

        # Connect to widget's save signal/callback
        widget._on_sales_entry_save_callback = self.apply_sales_return_adjustment
        widget._sales_entry_window = self

        window.show()

    def apply_sales_return_adjustment(self, return_id, return_amount):
        """Apply sales return adjustment to this Sales Entry.

        Called when Sales Return is saved successfully.

        Args:
            return_id: The saved sales return ID
            return_amount: The total return amount
        """
        print(f"[DEBUG] apply_sales_return_adjustment called: return_id={return_id}, amount={return_amount}")
        self._linked_sales_return_id = return_id
        self._linked_sales_return_amount = float(return_amount) if return_amount else 0.0
        print(f"[DEBUG] Stored: _linked_sales_return_id={self._linked_sales_return_id}, _linked_sales_return_amount={self._linked_sales_return_amount}")

        # Update display
        self.update_return_adjustment_display()

        # Show confirmation with signed net amount
        net_after = self.get_net_after_return()
        if net_after < 0:
            net_text = f"-₹ {abs(net_after):.2f}"
        else:
            net_text = f"₹ {net_after:.2f}"
        QMessageBox.information(
            self,
            "Return Linked",
            f"Sales Return #{return_id} linked successfully.\n"
            f"Return Amount: ₹ {self._linked_sales_return_amount:.2f}\n"
            f"Net After Return: {net_text}"
        )

    def update_return_adjustment_display(self):
        """Update the return adjustment display zone."""
        print(f"[DEBUG] update_return_adjustment_display: has zone={hasattr(self, 'return_adj_zone')}, return_id={self._linked_sales_return_id}, amount={self._linked_sales_return_amount}")
        if not hasattr(self, 'return_adj_zone'):
            print("[DEBUG] No return_adj_zone found!")
            return

        if self._linked_sales_return_id is None:
            # Hide return adjustment zone
            print("[DEBUG] Hiding return_adj_zone (no linked return)")
            self.return_adj_zone.setVisible(False)
            return

        # Show zone and update values
        print(f"[DEBUG] Showing return_adj_zone with amount={self._linked_sales_return_amount}")
        self.return_adj_zone.setVisible(True)

        # Return amount (negative, red)
        self.return_adj_amount.setText(f"-{self._linked_sales_return_amount:.2f}")
        print(f"[DEBUG] Set return_adj_amount text to: -{self._linked_sales_return_amount:.2f}")

        # Net after return (show minus sign if negative)
        net_after = self.get_net_after_return()
        if net_after < 0:
            self.net_after_return_amount.setText(f"-{abs(net_after):.2f}")
        else:
            self.net_after_return_amount.setText(f"{net_after:.2f}")

    def get_net_after_return(self):
        """Calculate net amount after return adjustment.
        
        Returns:
            Net amount. Can be negative if return > grand total.
        """
        # Try grand_total_input first, fallback to final_amount_display
        grand_total = self.get_numeric_value(self.grand_total_input)
        if grand_total == 0.0 and hasattr(self, 'final_amount_display'):
            grand_total = self.get_numeric_value(self.final_amount_display)
        
        # Calculate net (can be negative if return > grand total)
        net = grand_total - self._linked_sales_return_amount
        return net

    def get_numeric_value(self, widget):
        """Get numeric value from a QLineEdit or QLabel."""
        try:
            if isinstance(widget, QLineEdit):
                text = widget.text().replace('₹', '').replace(',', '').strip()
            else:
                text = str(widget.text() if hasattr(widget, 'text') else widget).replace('₹', '').replace(',', '').strip()
            return float(text) if text else 0.0
        except (ValueError, TypeError):
            return 0.0

    def fill_blank_row_with_product(self, row, product):
        """Fill an existing blank row with product details.

        Returns:
            True if invalid stock warning was triggered (Qty editor is active and locked)
            False if no warning / valid state / no action
        """
        # Track this as the last barcode-filled row for F1 targeting
        self.last_barcode_filled_row = row
        
        # Ensure all table items exist before setting values
        self.ensure_row_items_initialized(row)
        
        # Qty (editable) - ALWAYS set to 1 FIRST before any other fields
        qty_item = self.items_table.item(row, 8)
        if qty_item:
            qty_item.setText("1")
        else:
            # Create qty item if it doesn't exist
            self.items_table.setItem(row, 8, QTableWidgetItem("1"))
        qty_item = self.items_table.item(row, 8)
        qty_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
        
        # Get rate
        rate = self.get_product_rate_from_selector(product)

        # Product (editable)
        product_item = self.items_table.item(row, 1)
        if product_item:
            product_item.setText(product['name'])

        # HSN (editable)
        hsn_item = self.items_table.item(row, 2)
        if hsn_item:
            hsn_item.setText(product.get('hsn', ''))

        # CGST, SGST, IGST based on Nature
        is_local = (self.nature_combo.currentText() == "Local")
        
        cgst_item = self.items_table.item(row, 3)
        if cgst_item:
            if is_local:
                cgst_item.setText(f"{product.get('cgst', 0):.2f}")
            else:
                cgst_item.setText("0")
        
        sgst_item = self.items_table.item(row, 4)
        if sgst_item:
            if is_local:
                sgst_item.setText(f"{product.get('sgst', 0):.2f}")
            else:
                sgst_item.setText("0")
        
        igst_item = self.items_table.item(row, 5)
        if igst_item:
            if is_local:
                igst_item.setText("0")
            else:
                igst_item.setText(f"{product.get('igst', 0):.2f}")

        # CESS (editable)
        cess_item = self.items_table.item(row, 6)
        if cess_item:
            cess_item.setText(str(product.get('cess', 0)))

        # Rate (editable)
        rate_item = self.items_table.item(row, 7)
        if rate_item:
            rate_item.setText(str(rate))

        # Gross (editable)
        gross_item = self.items_table.item(row, 9)
        if gross_item:
            gross_item.setText(str(rate))

        # Discount (editable)
        discount_item = self.items_table.item(row, 10)
        if discount_item:
            discount_item.setText("0")

        # Calculate total tax percent
        tax_percent = product.get('cgst', 0) + product.get('sgst', 0) + product.get('igst', 0) + product.get('cess', 0)

        # Update sale_items for this row
        if row < len(self.sale_items):
            self.sale_items[row]['product_id'] = product['id']
            self.sale_items[row]['hsn'] = product.get('hsn', '')
            self.sale_items[row]['cgst'] = product.get('cgst', 0)
            self.sale_items[row]['sgst'] = product.get('sgst', 0)
            self.sale_items[row]['igst'] = product.get('igst', 0)
            self.sale_items[row]['cess'] = product.get('cess', 0)
            self.sale_items[row]['tax_percent'] = tax_percent
            self.sale_items[row]['rate'] = rate

        # Recalculate row
        self.recalculate_row(row)
        self.calculate_totals()
        self.on_table_selection_changed()
        # Clear visual selection to prevent keyboard workflow from leaving blue selection
        self.items_table.clearSelection()
        
        # Scroll to filled row to ensure it's visible
        from PySide6.QtWidgets import QAbstractItemView
        filled_row_item = self.items_table.item(row, 0)
        if filled_row_item:
            self.items_table.scrollToItem(filled_row_item, QAbstractItemView.PositionAtCenter)
        
        # Live stock check for default qty=1 when check_stock is enabled
        # This is the final stock check decision point
        return self._trigger_stock_check_for_row(row)

    def on_rate_refresh_clicked(self):
        """Update all current rows with the selected rate type."""
        rate_selection = self.rate_selector_combo.currentText()
        
        # Loop through all rows and update rate for rows that have products
        was_blocked = self.items_table.blockSignals(True)
        try:
            for row in range(self.items_table.rowCount()):
                if row < len(self.sale_items):
                    product_id = self.sale_items[row].get('product_id')
                    product = self.products_dict.get(product_id) if product_id else None
                    if product:
                        # Get rate based on selection
                        if rate_selection == "Sales Rate":
                            new_rate = product.get('sale_price', 0)
                        elif rate_selection == "Purchase Rate":
                            new_rate = product.get('purchase_rate', 0)
                        elif rate_selection == "Wholesale Rate":
                            new_rate = product.get('wholesale_rate', 0)
                        elif rate_selection == "MRP":
                            new_rate = product.get('mrp', 0)
                        else:
                            new_rate = product.get('sale_price', 0)
                        
                        # Update rate in table (column 7 is Rate)
                        self.items_table.setItem(row, 7, QTableWidgetItem(str(new_rate)))
                        self.sale_items[row]['rate'] = new_rate
                        # Recalculate row to update Gross, Net, Tax, Total based on new rate
                        self.recalculate_row(row)
            
            # Recalculate totals after all rows are updated
            self.calculate_totals()
        finally:
            self.items_table.blockSignals(was_blocked)

    # ==================== BILL NAVIGATION ====================

    def _refresh_sales_nav_list(self, company_id):
        """Refresh cached list of saved sale ids for prev/next navigation.

        Ordered by id ascending (i.e. chronological insertion order).
        """
        try:
            sales = self.db.get_sales_by_company(company_id) or []
            self._sales_nav_ids = sorted([s['id'] for s in sales if s.get('id') is not None])
        except Exception:
            self._sales_nav_ids = []

    def previous_bill(self):
        self._navigate_bill(-1)

    # ==================== NAVIGATION METHODS ====================

    def next_bill(self):
        self._navigate_bill(+1)

    def _navigate_bill(self, delta):
        """Move one bill in the given direction (-1 previous, +1 next)."""
        active = active_company_manager.get_active_company()
        if not active:
            QMessageBox.warning(self, "No Active Company", "Please open a company first.")
            return
        self._refresh_sales_nav_list(active['id'])
        if not getattr(self, '_sales_nav_ids', []):
            QMessageBox.information(self, "No Bills", "No saved bills are available yet.")
            return

        if self.current_sale_id in self._sales_nav_ids:
            idx = self._sales_nav_ids.index(self.current_sale_id)
        else:
            # Viewing a blank / unsaved bill:
            #   Prev → go to LAST saved bill.
            #   Next → do nothing (already past the last saved bill).
            if delta > 0:
                QMessageBox.information(
                    self,
                    "Next Bill",
                    "You are already on a new blank bill. Save it first, "
                    "then Next will take you further.",
                )
                return
            idx = len(self._sales_nav_ids)

        new_idx = idx + delta
        if new_idx < 0:
            QMessageBox.information(self, "Previous Bill", "This is the first bill.")
            return
        if new_idx >= len(self._sales_nav_ids):
            # Past the last saved bill → start a fresh blank bill with the next
            # auto-generated invoice number so the user can continue data entry.
            self.clear_form()
            try:
                next_inv = self._generate_unique_invoice_number(active['id'])
                self.invoice_no_input.setText(next_inv)
            except Exception:
                pass
            # Keep Entry-with-Specific-Invoice-No. field state consistent
            self._sync_invoice_input_editable()
            return

        self.load_sale_by_id(self._sales_nav_ids[new_idx])

    def load_sale_by_id(self, sale_id):
        """Load and display a saved sale by its id. Read-friendly population of
        all header fields, items table, and stored totals. Does not trigger a
        recompute that would overwrite stored totals with per-row summations."""
        active = active_company_manager.get_active_company()
        if not active:
            return
        try:
            sale = self.db.get_sale_by_id(active['id'], sale_id)
            if not sale:
                QMessageBox.warning(self, "Load Bill", "Could not load the selected bill.")
                return
            items = self.db.get_sale_items(sale_id) or []
        except Exception as e:
            QMessageBox.critical(self, "Load Bill", f"Failed to load bill: {e}")
            return

        # Block signals on inputs whose textChanged would trigger recalculation
        fields_to_block = [
            getattr(self, 'freight_input', None),
            getattr(self, 'discount_total_input', None),
            getattr(self, 'round_off_input', None),
            getattr(self, 'amount_receive_input', None),
        ]
        for w in fields_to_block:
            if w is not None:
                w.blockSignals(True)

        try:
            self.current_sale_id = sale.get('id')

            # Header fields
            self.invoice_no_input.setText(sale.get('invoice_number') or "")
            inv_date = sale.get('invoice_date')
            if inv_date:
                qd = QDate.fromString(str(inv_date)[:10], "yyyy-MM-dd")
                if qd.isValid():
                    self.date_input.setDate(qd)

            # Map DB sales_type → UI
            db_to_ui = {"Sales": "Cash", "Credit Sales": "Credit", "Return": "Return"}
            ui_type = db_to_ui.get(sale.get('sales_type'), "Cash")
            i = self.sales_type_combo.findText(ui_type, Qt.MatchFixedString)
            if i >= 0:
                self.sales_type_combo.setCurrentIndex(i)

            self.customer_name_input.setText(sale.get('party_name') or "")
            if hasattr(self, 'series_input'):
                self.series_input.setText(sale.get('bill_series') or "")
            nature = sale.get('nature') or ""
            i = self.nature_combo.findText(nature, Qt.MatchFixedString)
            if i >= 0:
                self.nature_combo.setCurrentIndex(i)
            due = sale.get('due_date')
            if due:
                qd = QDate.fromString(str(due)[:10], "yyyy-MM-dd")
                if qd.isValid():
                    self.due_date_input.setDate(qd)
            self.address_input.setText(sale.get('address') or "")
            self.gstin_input.setText(sale.get('gstin') or "")
            state = sale.get('state') or ""
            i = self.state_combo.findText(state, Qt.MatchFixedString)
            if i >= 0:
                self.state_combo.setCurrentIndex(i)
            if hasattr(self, 'rate_selector_combo'):
                sr = sale.get('sales_rate') or "Sales Rate"
                i = self.rate_selector_combo.findText(sr, Qt.MatchFixedString)
                if i >= 0:
                    self.rate_selector_combo.setCurrentIndex(i)
            if hasattr(self, 'narration_input'):
                self.narration_input.setText(sale.get('narration') or "")

            # Restore saved Amt Recvd for reopened saved bills
            # Mark as user-edited so update_footer_payment_fields preserves it
            if hasattr(self, 'amount_receive_input'):
                saved_amt = float(sale.get('amount_received') or 0.0)
                self.amount_receive_input.setText(f"{saved_amt:.2f}")
                self._amt_recvd_user_edited = True

            # Items table
            self.items_table.blockSignals(True)
            try:
                self.items_table.setRowCount(0)
                self.sale_items = []
                for it in items:
                    row = self.items_table.rowCount()
                    self.items_table.insertRow(row)

                    def _set(c, v):
                        self.items_table.setItem(row, c, QTableWidgetItem(str(v)))

                    _set(0, row + 1)
                    _set(1, it.get('product_name') or "")
                    _set(2, it.get('hsn') or "")
                    
                    # Load split GST values from DB or use fallback logic
                    cgst = float(it.get('cgst', 0))
                    sgst = float(it.get('sgst', 0))
                    igst = float(it.get('igst', 0))
                    cess = float(it.get('cess', 0))
                    tax_percent = float(it.get('tax_percent', 0))
                    
                    # Fallback: if split GST is missing/zero but tax_percent exists, calculate it
                    if cgst == 0 and sgst == 0 and igst == 0 and tax_percent > 0:
                        if nature == "Inter-state":
                            igst = tax_percent
                            cgst = 0
                            sgst = 0
                        else:
                            cgst = tax_percent / 2
                            sgst = tax_percent / 2
                            igst = 0
                    
                    _set(3, f"{cgst:.2f}")
                    _set(4, f"{sgst:.2f}")
                    _set(5, f"{igst:.2f}")
                    _set(6, f"{cess:.2f}")
                    _set(7, f"{float(it.get('rate') or 0):.2f}")
                    _set(8, f"{float(it.get('quantity') or 0):.3f}")
                    _set(9, f"{float(it.get('gross_value') or 0):.2f}")
                    _set(10, f"{float(it.get('discount') or 0):.2f}")
                    _set(11, f"{float(it.get('net_value') or 0):.2f}")
                    _set(12, f"{float(it.get('tax_amount') or 0):.2f}")
                    _set(13, f"{float(it.get('grand_total') or 0):.2f}")

                    self.sale_items.append({
                        'product_id': it.get('product_id'),
                        'hsn': it.get('hsn') or "",
                        'tax_percent': tax_percent,
                        'cgst': cgst,
                        'sgst': sgst,
                        'igst': igst,
                        'cess': cess,
                        'cgst_amount': float(it.get('cgst_amount', 0)),
                        'sgst_amount': float(it.get('sgst_amount', 0)),
                        'igst_amount': float(it.get('igst_amount', 0)),
                        'cess_amount': float(it.get('cess_amount', 0)),
                        'rate': float(it.get('rate') or 0),
                    })
            finally:
                self.items_table.blockSignals(False)

            # Stored totals (direct display — do not rerun calculate_totals here)
            sub = float(sale.get('sub_total') or 0)
            disc = float(sale.get('discount_total') or 0)
            tax = float(sale.get('tax_total') or 0)
            rnd = float(sale.get('round_off') or 0)
            gt = float(sale.get('grand_total') or 0)

            self._row_discount_total = 0.0  # unknown split; treat all as footer discount for display
            self.sub_total_input.setText(f"{sub:.2f}")
            if hasattr(self, 'freight_input'):
                self.freight_input.setText("0.00")
            self.discount_total_input.setText(f"{disc:.2f}")
            if hasattr(self, 'discount_percent_label'):
                self.discount_percent_label.setText("")
            self.tax_total_input.setText(f"{tax:.2f}")
            self.round_off_input.setText(f"{rnd:.2f}")
            self.grand_total_input.setText(f"{gt:.2f}")

            # Visible footer displays
            if hasattr(self, 'net_value_display'):
                self.net_value_display.setText(f"{sub:.2f}")
            if hasattr(self, 'tax_amount_display'):
                self.tax_amount_display.setText(f"{tax:.2f}")
            if hasattr(self, 'net_amount_input'):
                self.net_amount_input.setText(f"{(gt + rnd):.2f}")
            if hasattr(self, 'final_amount_display'):
                self.final_amount_display.setText(f"{gt:.2f}")
            # Calculate split GST totals from loaded items
            cgst_total = 0.0
            sgst_total = 0.0
            igst_total = 0.0
            cess_total = 0.0
            for it in items:
                cgst_total += float(it.get('cgst_amount', 0))
                sgst_total += float(it.get('sgst_amount', 0))
                igst_total += float(it.get('igst_amount', 0))
                cess_total += float(it.get('cess_amount', 0))
            
            # Display split GST totals in footer
            if hasattr(self, 'cgst_display'):
                self.cgst_display.setText(f"{cgst_total:.2f}")
            if hasattr(self, 'sgst_display'):
                self.sgst_display.setText(f"{sgst_total:.2f}")
            if hasattr(self, 'igst_display'):
                self.igst_display.setText(f"{igst_total:.2f}")
            if hasattr(self, 'cess_display'):
                self.cess_display.setText(f"{cess_total:.2f}")

            # Refresh payment fields for O/B / C/B / Balance / Amt Recvd
            if hasattr(self, 'update_footer_payment_fields'):
                try:
                    self.update_footer_payment_fields()
                except Exception:
                    pass

            # Relabel the action button to reflect Update mode
            self._update_ok_button_label()
            # Reset "update confirmed" flag — user must re-confirm when
            # scanning a barcode into a saved bill.
            self._update_confirmed = False
        finally:
            for w in fields_to_block:
                if w is not None:
                    w.blockSignals(False)

    def _update_ok_button_label(self):
        """Set OK button text to 'Update' when editing a saved bill, 'OK' otherwise."""
        if hasattr(self, 'ok_btn'):
            self.ok_btn.setText("Update" if self.current_sale_id else "OK")

    def _sync_invoice_input_editable(self):
        """The invoice-no input is ALWAYS editable so the user can freely
        correct or delete what they typed (especially when a duplicate
        warning is shown). The 'Entry with Specific Invoice No.' checkbox
        only changes the placeholder and decides — at save time — whether
        to use the user's typed value or an auto-generated one.
        """
        if not hasattr(self, 'invoice_no_input') or not hasattr(self, 'invoice_checkbox'):
            return
        self.invoice_no_input.setReadOnly(False)
        if self.invoice_checkbox.isChecked():
            self.invoice_no_input.setPlaceholderText("Enter invoice no.")
        else:
            self.invoice_no_input.setPlaceholderText("Auto")

    # ==================== INVOICE DUPLICATE HANDLING ====================

    def on_invoice_no_changed(self, _text):
        """Live check: if the currently-typed invoice number already exists
        for another bill in the active company, show an inline red warning
        next to the field and flag the input with a red border.

        The warning is suppressed when the field is empty or when the value
        belongs to the currently loaded saved bill (so no false alarm while
        simply viewing an existing bill).
        """
        if not hasattr(self, 'invoice_no_input'):
            return
        text = self.invoice_no_input.text().strip()

        def _set_valid_style():
            # Restore the compact input style
            try:
                self.invoice_no_input.setStyleSheet(self.compact_input_style())
            except Exception:
                self.invoice_no_input.setStyleSheet("")
            if hasattr(self, 'invoice_warning_label'):
                self.invoice_warning_label.setVisible(False)
                self.invoice_warning_label.setText("")

        # Empty → nothing to validate
        if not text:
            _set_valid_style()
            return

        active = active_company_manager.get_active_company()
        if not active:
            _set_valid_style()
            return

        try:
            exists = self.db.invoice_number_exists(
                active['id'], text, exclude_sale_id=self.current_sale_id
            )
        except Exception:
            exists = False

        if exists:
            # Enter "duplicate lock" mode: blinking full-red value + keep the
            # cursor trapped inside this field until the user types a
            # different number or clicks Reset.
            self._invoice_dup_lock = True
            warn_msg = "⚠ Invoice No already exists — change it or click Reset"
            # Persistent hover tooltip on the field itself
            self.invoice_no_input.setToolTip(warn_msg)
            # Floating tooltip popup anchored to the field (auto-hides when
            # the cursor moves; re-shown on each keystroke while duplicate).
            try:
                pos = self.invoice_no_input.mapToGlobal(
                    self.invoice_no_input.rect().bottomLeft()
                )
                QToolTip.showText(pos, warn_msg, self.invoice_no_input)
            except Exception:
                pass
            # Make sure focus is inside the invoice field.
            if not self.invoice_no_input.hasFocus():
                self.invoice_no_input.setFocus()
            # Start the blink timer; paint the first frame immediately.
            self._invoice_blink_on = False
            self._toggle_invoice_blink()
            if not self._invoice_blink_timer.isActive():
                self._invoice_blink_timer.start()
        else:
            _set_valid_style()
            # Clear tooltip + hide any visible floating tip.
            self.invoice_no_input.setToolTip("")
            try:
                QToolTip.hideText()
            except Exception:
                pass
            # Release the lock and stop blinking.
            self._invoice_dup_lock = False
            if self._invoice_blink_timer.isActive():
                self._invoice_blink_timer.stop()
            self._invoice_blink_on = False

    def _toggle_invoice_blink(self):
        """Alternate the invoice field between a strong red and a subdued red
        to produce a visible blinking effect while the duplicate lock is on.
        """
        if not hasattr(self, 'invoice_no_input'):
            return
        try:
            base = self.compact_input_style() or ""
        except Exception:
            base = ""
        self._invoice_blink_on = not self._invoice_blink_on
        if self._invoice_blink_on:
            style = (
                base
                + "\nQLineEdit { border: 2px solid #ff0000; background: #ff4d4f;"
                  " color: #ffffff; font-weight: bold; }"
            )
        else:
            style = (
                base
                + "\nQLineEdit { border: 2px solid #ff0000; background: #ffffff;"
                  " color: #ff0000; font-weight: bold; }"
            )
        self.invoice_no_input.setStyleSheet(style)

    def _toggle_stock_blink(self):
        """Alternate the stock display between strong red and subdued red
        to produce a visible blinking effect when stock check fails.
        """
        if not hasattr(self, 'stock_display'):
            return
        self._stock_blink_on = not self._stock_blink_on
        if self._stock_blink_on:
            self.stock_display.setStyleSheet("color: #ff0000; font-weight: bold; background-color: #ff4d4f;")
        else:
            self.stock_display.setStyleSheet("color: #ff0000; font-weight: bold; background-color: #334155;")

    def _on_global_focus_changed(self, old, new):
        """If a duplicate invoice number is unresolved, keep focus glued to
        the invoice field. The user can only escape by typing a different
        (unique) number or by clicking Reset.
        """
        if not getattr(self, '_invoice_dup_lock', False):
            return
        if not hasattr(self, 'invoice_no_input'):
            return
        # Ignore transient losses (e.g. focus goes to None while switching)
        if new is None:
            return
        if new is self.invoice_no_input:
            return
        # Refocus the invoice field on the next event-loop tick to avoid
        # fighting with Qt's own focus handling during this signal.
        QTimer.singleShot(0, self.invoice_no_input.setFocus)

    def on_invoice_checkbox_toggled(self, _checked):
        """Handler for the specific-invoice-no checkbox.

        - Toggles read-only state on the invoice no input.
        - If the user just turned the checkbox OFF, clears any typed value so
          the next save auto-generates a fresh sequential number.
        """
        self._sync_invoice_input_editable()
        if hasattr(self, 'invoice_checkbox') and not self.invoice_checkbox.isChecked():
            if hasattr(self, 'invoice_no_input') and not self.current_sale_id:
                self.invoice_no_input.clear()

    def on_table_selection_changed(self):
        current_row = self.items_table.currentRow()
        
        # Clear Qt selection to prevent full-row selection when not in rewrite mode
        # Only allow selection via SL No click (rewrite mode)
        if self.manually_selected_row == -1:
            self.items_table.clearSelection()
        
        # Check if an OUT OF STOCK warning is currently active.
        # If so, skip overwriting stock_display so the warning remains visible.
        if self._stock_warning_active and current_row == self._stock_warning_row:
            return
        
        # Also check delegate qty_invalid as fallback
        delegate = self.items_table.itemDelegate()
        if delegate and getattr(delegate, 'qty_invalid', False):
            return
        
        # Continue with normal selection logic for display updates only
        # Do NOT set manually_selected_row here - that's only done via mouse clicks
        # Do NOT write barcode to barcode_input - it must stay blank
        if current_row >= 0 and current_row < len(self.sale_items):
            # Get product data for selected row
            product_id = self.sale_items[current_row].get('product_id')
            product = self.products_dict.get(product_id) if product_id else None
            if product:
                # Do NOT write to barcode_input - keep it blank
                if hasattr(self, 'code_display'):
                    self.code_display.setText(product.get('barcode', ''))
                if hasattr(self, 'category_display'):
                    self.category_display.setText(product.get('category', ''))
                if hasattr(self, 'size_display'):
                    self.size_display.setText(product.get('size', ''))
                if hasattr(self, 'color_display'):
                    self.color_display.setText(product.get('color', ''))
                # Use helper to show real stock quantity
                self.update_stock_display_for_row(current_row)
        else:
            # Clear display fields if no valid selection
            if hasattr(self, 'code_display'):
                self.code_display.setText("")
            if hasattr(self, 'category_display'):
                self.category_display.setText("")
            if hasattr(self, 'size_display'):
                self.size_display.setText("")
            if hasattr(self, 'color_display'):
                self.color_display.setText("")
            if hasattr(self, 'stock_display'):
                self.stock_display.setText("0.000")

    # ==================== EVENT FILTER METHODS ====================

    def eventFilter(self, obj, event):
        """Event filter to capture mouse press events and keyboard events on party section fields."""
        # Auto-select-all on focus gain (click or tab) for any QLineEdit (editable fields).
        # Mirrors table-cell behaviour where one click highlights the whole value.
        if isinstance(obj, QLineEdit) and event.type() == QEvent.FocusIn:
            if not obj.isReadOnly():
                QTimer.singleShot(0, obj.selectAll)

        # Footer Discount: Down-Arrow converts current value as a percentage of the
        # pre-discount base (sub_total - row_discount + tax + freight).
        if (hasattr(self, 'discount_total_input') and obj == self.discount_total_input
                and event.type() == QEvent.KeyPress and event.key() == Qt.Key_Down):
            self.apply_discount_percent_mode()
            return True

        # Check for viewport mouse clicks (event filter is installed on viewport)
        if obj == self.items_table.viewport() and event.type() == QEvent.MouseButtonPress:
            if event.button() == Qt.LeftButton:
                # Get the item at the click position
                item = self.items_table.itemAt(event.pos())
                if item:
                    clicked_row = item.row()
                    clicked_column = item.column()
                    # Only activate rewrite selection if SL No column (column 0) is clicked
                    if clicked_column == 0:
                        # Set manually_selected_row only on SL No cell click
                        self.manually_selected_row = clicked_row
                        # Clear Qt selection to prevent default row selection
                        self.items_table.clearSelection()
                        # Update viewport to trigger custom paint
                        self.items_table.viewport().update()
                        # Update Code and Stock display fields for the clicked row
                        if clicked_row >= 0 and clicked_row < len(self.sale_items):
                            product_id = self.sale_items[clicked_row].get('product_id')
                            product = self.products_dict.get(product_id) if product_id else None
                            if product:
                                if hasattr(self, 'code_display'):
                                    self.code_display.setText(product.get('barcode', ''))
                                if hasattr(self, 'category_display'):
                                    self.category_display.setText(product.get('category', ''))
                                if hasattr(self, 'size_display'):
                                    self.size_display.setText(product.get('size', ''))
                                if hasattr(self, 'color_display'):
                                    self.color_display.setText(product.get('color', ''))
                                # Use helper to show real stock
                                self.update_stock_display_for_row(clicked_row)
                        # Do NOT set focus to barcode field - keep it blank
                        # Return True to prevent Qt from processing this mouse click
                        return True
                    else:
                        # Clicked on non-SL cell - clear rewrite selection
                        self.manually_selected_row = -1
                        # Clear Qt selection to prevent full-row selection
                        self.items_table.clearSelection()
                        # Update viewport to trigger custom paint
                        self.items_table.viewport().update()
                        # Update display fields directly for the clicked row
                        if clicked_row >= 0 and clicked_row < len(self.sale_items):
                            product_id = self.sale_items[clicked_row].get('product_id')
                            product = self.products_dict.get(product_id) if product_id else None
                            if product:
                                if hasattr(self, 'code_display'):
                                    self.code_display.setText(product.get('barcode', ''))
                                if hasattr(self, 'category_display'):
                                    self.category_display.setText(product.get('category', ''))
                                if hasattr(self, 'size_display'):
                                    self.size_display.setText(product.get('size', ''))
                                if hasattr(self, 'color_display'):
                                    self.color_display.setText(product.get('color', ''))
                                # Use helper to show real stock
                                self.update_stock_display_for_row(clicked_row)
                        # Open editor for clicked item directly
                        self.items_table.editItem(item)
                        # Return True to prevent Qt from processing this mouse click
                        return True
        
        # Handle Enter key flow for party section fields (both Return and Enter)
        if event.type() == QEvent.KeyPress and (event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter):
            if obj == self.customer_name_input:
                if hasattr(self, 'address_input'):
                    self.address_input.setFocus()
                return True
            elif obj == self.address_input:
                if hasattr(self, 'mobile_input'):
                    self.mobile_input.setFocus()
                return True
            elif obj == self.mobile_input:
                if hasattr(self, 'gstin_input'):
                    self.gstin_input.setFocus()
                return True
            elif obj == self.gstin_input:
                if hasattr(self, 'state_combo'):
                    self.state_combo.setFocus()
                return True
            elif obj == self.state_combo or (hasattr(self, 'state_combo') and obj == self.state_combo.lineEdit()):
                if hasattr(self, 'narration_input'):
                    self.narration_input.setFocus()
                return True
            elif obj == self.narration_input:
                if hasattr(self, 'barcode_input'):
                    self.barcode_input.setFocus()
                return True
        
        # Handle Esc key flow for party section fields
        if event.type() == QEvent.KeyPress and event.key() == Qt.Key_Escape:
            if obj == self.narration_input:
                if hasattr(self, 'state_combo'):
                    self.state_combo.setFocus()
                return True
            elif obj == self.state_combo or (hasattr(self, 'state_combo') and obj == self.state_combo.lineEdit()):
                if hasattr(self, 'gstin_input'):
                    self.gstin_input.setFocus()
                return True
            elif obj == self.gstin_input:
                if hasattr(self, 'mobile_input'):
                    self.mobile_input.setFocus()
                return True
            elif obj == self.mobile_input:
                if hasattr(self, 'address_input'):
                    self.address_input.setFocus()
                return True
            elif obj == self.address_input:
                if hasattr(self, 'customer_name_input'):
                    self.customer_name_input.setFocus()
                return True
        
        # Let the event propagate normally for unrelated events
        return super().eventFilter(obj, event)

    def on_table_cell_changed(self, row, column):
        # CRITICAL: Check if delegate is being initialized - skip cellChanged during editor initialization
        # This prevents clearing data when editor opens
        if hasattr(self, 'table_delegate') and self.table_delegate:
            if not self.table_delegate.editor_initialized:
                # Editor is being initialized - skip cellChanged to prevent data clearing
                return
        
        # Product column (1) handling is now fully managed by delegate
        # - Live editing: on_editor_changed -> handle_product_change
        # - Commit: setModelData
        # No duplicate handling needed here

        # Handle numeric field changes that require recalculation
        if column in [3, 4, 5, 6, 7, 8, 9, 10]:  # CGST, SGST, IGST, CESS, Rate, Qty, Gross, Disc
            # Check if delegate has an active editor for this cell - if so, skip recalculation
            # to prevent refreshing the editor while user is still typing
            if hasattr(self, 'table_delegate') and self.table_delegate:
                if (self.table_delegate.current_editor is not None and 
                    self.table_delegate.current_index is not None and
                    self.table_delegate.current_index.row() == row and
                    self.table_delegate.current_index.column() == column):
                    # Editor is still open for this cell - don't recalculate from cellChanged
                    return
            
            live_text = self.safe_item_text(row, column, "0")
            self.recalculate_row(row, source_column=column, live_value=live_text)
            # Recalculate totals to ensure C/B updates live after cell commit
            self.calculate_totals()


    def delete_row(self):
        current_row = self.items_table.currentRow()
        if current_row >= 0:
            self.items_table.removeRow(current_row)
            # Keep sale_items in sync with the table
            if 0 <= current_row < len(self.sale_items):
                del self.sale_items[current_row]
            # Reset manual selection since row indices changed
            self.manually_selected_row = -1
            # Re-number SL No
            for row in range(self.items_table.rowCount()):
                sl_item = QTableWidgetItem(str(row + 1))
                self.items_table.setItem(row, 0, sl_item)
            self.calculate_totals()

    def print_invoice(self):
        # The checkbox is only meaningful for Credit bills; for Cash bills we
        # always treat it as False (it is disabled in the UI for Cash).
        sales_type = ""
        if hasattr(self, 'sales_type_combo'):
            sales_type = (self.sales_type_combo.currentText() or "").strip().lower()
        is_credit = (sales_type == "credit")
        include_ob = bool(
            is_credit
            and hasattr(self, 'print_ob_checkbox')
            and self.print_ob_checkbox.isChecked()
        )
        # Expose a flag the print layer can read when implemented
        self._print_include_ob = include_ob

        # For Cash bills: do not show any placeholder/status dialog. The user
        # has already seen "Bill saved successfully. Print bill?" and chose
        # to print — honour that silently until real printing is wired up.
        if not is_credit:
            return

        # Credit bills: keep the O/B information message until real printing
        # is implemented.
        msg = "Print functionality to be implemented."
        if include_ob:
            msg += "\n\nO/B and Amt Received will be included on the printed bill."
        else:
            msg += "\n\nO/B and Amt Received will NOT be printed."
        QMessageBox.information(self, "Print", msg)

    # ==================== SAVE / CLEAR / RESET METHODS ====================

    def clear_form(self):
        self.current_sale_id = None
        self._amt_recvd_user_edited = False
        self.invoice_no_input.clear()
        self.date_input.setDate(QDate.currentDate())
        # Default Type to Cash on new bill
        idx_cash = self.sales_type_combo.findText("Cash", Qt.MatchFixedString)
        self.sales_type_combo.setCurrentIndex(idx_cash if idx_cash >= 0 else 0)
        self.series_input.clear()
        self.nature_combo.setCurrentIndex(0)
        if hasattr(self, 'party_type_combo'):
            self.party_type_combo.setCurrentIndex(0)
        self.customer_name_input.clear()
        self.mobile_input.clear()
        self.due_date_input.setDate(QDate.currentDate().addDays(30))
        self.address_input.clear()
        self.gstin_input.clear()
        self.state_combo.setCurrentIndex(0)
        if hasattr(self, 'rate_selector_combo'):
            self.rate_selector_combo.setCurrentIndex(0)
        self.narration_input.clear()
        self.barcode_input.clear()
        self.barcode_tick.setChecked(True)  # Reset to default ON
        if hasattr(self, 'check_stock_tick'):
            self.check_stock_tick.setChecked(True)  # Default ON
        if hasattr(self, 'divide_tax_tick'):
            self.divide_tax_tick.blockSignals(True)
            self.divide_tax_tick.setChecked(False)  # Default OFF
            self.divide_tax_tick.blockSignals(False)
        if hasattr(self, 'stock_display'):
            self.stock_display.setText("0.000")
        if hasattr(self, 'code_display'):
            self.code_display.setText("")
        if hasattr(self, 'category_display'):
            self.category_display.setText("")
        if hasattr(self, 'size_display'):
            self.size_display.setText("")
        if hasattr(self, 'color_display'):
            self.color_display.setText("")
        self.items_table.setRowCount(0)
        self.sale_items = []
        self._row_discount_total = 0.0
        # Reset linked return state
        self._linked_sales_return_id = None
        self._linked_sales_return_amount = 0.0
        self._sales_return_window = None
        if hasattr(self, 'return_adj_zone'):
            self.return_adj_zone.setVisible(False)
        self.sub_total_input.setText("0.00")
        # Reset footer adjustments (freight + user discount) without firing storm of signals
        if hasattr(self, 'freight_input'):
            self.freight_input.blockSignals(True)
            self.freight_input.setText("0.00")
            self.freight_input.blockSignals(False)
        if hasattr(self, 'discount_total_input'):
            self.discount_total_input.blockSignals(True)
            self.discount_total_input.setText("0.00")
            self.discount_total_input.blockSignals(False)
        if hasattr(self, 'discount_label'):
            self.discount_label.setText("Discount")
        if hasattr(self, 'discount_percent_label'):
            self.discount_percent_label.setText("")
        # Default-ON round-off
        if hasattr(self, 'round_off_checkbox'):
            self.round_off_checkbox.blockSignals(True)
            self.round_off_checkbox.setChecked(True)
            self.round_off_checkbox.blockSignals(False)
        self.tax_total_input.setText("0.00")
        self.round_off_input.setText("0.00")
        self.grand_total_input.setText("0.00")
        if hasattr(self, 'final_amount_display'):
            self.final_amount_display.setText("0.00")
        # Recompute with all resets in effect (writes Net Amt, Round Off, Grand Total)
        self.calculate_totals()
        # Reset footer payment fields (O/B, C/B, Balance, Amt Recvd)
        self.update_footer_payment_fields()
        # Back to new-bill mode
        self._update_confirmed = False
        self._update_ok_button_label()
        # Release any duplicate-invoice blinking / focus-lock state
        self._invoice_dup_lock = False
        if hasattr(self, '_invoice_blink_timer') and self._invoice_blink_timer.isActive():
            self._invoice_blink_timer.stop()
        if hasattr(self, 'invoice_warning_label'):
            self.invoice_warning_label.setVisible(False)
            self.invoice_warning_label.setText("")
        try:
            self.invoice_no_input.setStyleSheet(self.compact_input_style())
        except Exception:
            pass

    # ==================== FOOTER DISCOUNT / REMOVE CONFIRMATIONS ====================

    def on_footer_discount_changed(self, _text):
        """Footer Discount text changed: auto-compute effective % of the current
        base and display it in the small sub-label, then recalculate totals.

        Base = sub_total - row_discount + tax + freight.
        If the entered value is 0 or the base is 0, the % label is cleared.
        """
        if hasattr(self, 'discount_percent_label'):
            amount = self._safe_float(self.discount_total_input.text(), 0.0)
            if amount > 0:
                sub_total = self._safe_float(self.sub_total_input.text(), 0.0) if hasattr(self, 'sub_total_input') else 0.0
                tax_total = self._safe_float(self.tax_total_input.text(), 0.0) if hasattr(self, 'tax_total_input') else 0.0
                row_discount_total = float(getattr(self, '_row_discount_total', 0.0) or 0.0)
                freight = self._safe_float(self.freight_input.text(), 0.0) if hasattr(self, 'freight_input') else 0.0
                base = sub_total - row_discount_total + tax_total + freight
                if base > 0:
                    pct = (amount / base) * 100.0
                    pct_disp = f"{pct:.0f}" if float(pct).is_integer() else f"{pct:.2f}"
                    self.discount_percent_label.setText(f"({pct_disp}%)")
                else:
                    self.discount_percent_label.setText("")
            else:
                self.discount_percent_label.setText("")
        self.calculate_totals()

    def apply_discount_percent_mode(self):
        """Interpret current footer Discount value as a percentage of the pre-discount base.

        Base = sub_total - row_discount + tax + freight.
        Converts the entered number into an actual discount amount and updates
        the Discount label with the percent value (e.g. "Discount (10%)").
        """
        try:
            _sf = self._safe_float
            pct = _sf(self.discount_total_input.text(), 0.0)
            if pct <= 0:
                return

            # Compute pre-discount base (same components used in calculate_totals)
            sub_total = _sf(self.sub_total_input.text(), 0.0) if hasattr(self, 'sub_total_input') else 0.0
            tax_total = _sf(self.tax_total_input.text(), 0.0) if hasattr(self, 'tax_total_input') else 0.0
            row_discount_total = float(getattr(self, '_row_discount_total', 0.0) or 0.0)
            freight = _sf(self.freight_input.text(), 0.0) if hasattr(self, 'freight_input') else 0.0

            base = sub_total - row_discount_total + tax_total + freight
            if base <= 0:
                return

            # Clamp percent for safety
            if pct > 100:
                pct = 100.0

            amount = round(base * pct / 100.0, 2)

            # Update Discount field with amount (block our own signal to avoid resetting label)
            self.discount_total_input.blockSignals(True)
            try:
                self.discount_total_input.setText(f"{amount:.2f}")
            finally:
                self.discount_total_input.blockSignals(False)

            # Show percent in small sub-label just under the Discount label
            if hasattr(self, 'discount_percent_label'):
                pct_disp = f"{pct:.0f}" if float(pct).is_integer() else f"{pct:.2f}"
                self.discount_percent_label.setText(f"({pct_disp}%)")

            # Trigger recalculation
            self.calculate_totals()
        except Exception:
            # Safe no-op on unexpected errors
            pass

    def open_debitor_creditor_page(self):
        """Navigate to the Debitor/Creditor page (Masters menu) in the main window."""
        try:
            from PySide6.QtWidgets import QApplication

            # Step 1: Try direct parent window (works when Sales Entry is in main window)
            main_window = self.window()
            if main_window and hasattr(main_window, 'show_debitor_creditor'):
                main_window.show_debitor_creditor()
                return

            # Step 2: Search all top-level widgets for MainWindow with show_debitor_creditor
            # This handles the case when Sales Entry is in a standalone window
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'show_debitor_creditor'):
                    widget.show_debitor_creditor()
                    widget.raise_()
                    widget.activateWindow()
                    return

            # Step 3: Fallback to stack_widget + debitor_creditor_widget pattern
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'stack_widget') and hasattr(widget, 'debitor_creditor_widget'):
                    if hasattr(widget.debitor_creditor_widget, 'load_parties'):
                        widget.debitor_creditor_widget.load_parties()
                    widget.stack_widget.setCurrentWidget(widget.debitor_creditor_widget)
                    widget.raise_()
                    widget.activateWindow()
                    return

            # Step 4: If nothing found, show clear message
            QMessageBox.warning(self, "Navigation Error", "Debitor/Creditor page is not available from this window.")
        except Exception as e:
            QMessageBox.warning(self, "Navigation Error", f"Could not open Debitor/Creditor page: {e}")

    def confirm_remove_bill(self):
        """Ask for confirmation before removing the current bill.

        If it's a saved bill, delete it from the database.
        The invoice number is cleared (not overwritten) - user can manually
        specify a number using "Entry with Specific Invoice No" option.
        """
        # Check if this is a saved bill
        if self.current_sale_id:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                QMessageBox.warning(self, "No Active Company", "Please open a company first.")
                return

            reply = QMessageBox.question(
                self,
                "Remove Saved Bill",
                "This will permanently delete this bill from the database.\n\n"
                "Are you sure you want to remove this bill?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                # Delete from database
                result = self.sales_logic.delete_sale(active_company['id'], self.current_sale_id)
                if result['success']:
                    QMessageBox.information(self, "Success", "Bill removed successfully.")
                    # Refresh cached products data to reflect updated stock balances
                    try:
                        self.load_products()
                    except Exception:
                        pass
                    # Clear form and reset invoice number to blank
                    self.clear_form()
                    # Invoice number stays blank - user can manually specify if needed
                else:
                    QMessageBox.critical(self, "Error", f"Failed to remove bill: {result['message']}")
        else:
            # Not a saved bill - just clear the form
            reply = QMessageBox.question(
                self,
                "Clear Form",
                "Are you sure you want to clear this form?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                self.clear_form()

    def confirm_remove_item(self):
        """Ask for confirmation before removing an item row.

        The user must first click the SL No cell of the row (mirrors the
        Rewrite-item selection flow). If no row has been manually selected
        via SL No click, prompt the user to do so and abort.
        """
        target_row = getattr(self, 'manually_selected_row', -1)
        if target_row < 0:
            QMessageBox.information(
                self,
                "Remove Item",
                "Please click the SL No of the item you want to remove, then press Remove Item.",
            )
            return
        if target_row >= self.items_table.rowCount():
            self.manually_selected_row = -1
            return

        # If this is a saved bill, require explicit confirmation to enter
        # update mode (same contract as barcode-add on a saved bill).
        if self.current_sale_id and not self._update_confirmed:
            confirm_update = QMessageBox.question(
                self,
                "Update Saved Bill?",
                "This is a saved bill. Removing an item will modify it.\n\n"
                "Do you want to update this bill?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if confirm_update != QMessageBox.Yes:
                return
            self._update_confirmed = True

        reply = QMessageBox.question(
            self,
            "Remove Item",
            f"Are you sure you want to remove item at row {target_row + 1}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        # Set current row so delete_row operates on the correct row, then delegate.
        self.items_table.setCurrentCell(target_row, 0)
        self.delete_row()

    # ==================== FOOTER PAYMENT LOGIC ====================

    @staticmethod
    def _safe_float(text, default=0.0):
        """Parse text to float safely; blank/invalid returns default."""
        try:
            s = str(text).strip().replace(",", "").replace("₹", "")
            if not s:
                return default
            return float(s)
        except (ValueError, TypeError):
            return default

    def get_selected_party_old_balance(self):
        """Return the Previous Balance (balance before current voucher) of the selected party.

        Uses PartyBalanceEngine to calculate:
        Previous Balance = party opening_balance + unpaid previous sales - previous receipts/returns

        Excludes current bill when editing/viewing old bills via voucher_id.
        Excludes future bills (after current voucher date/id).

        Matches party name case-insensitively against self.parties_data.
        Returns 0.00 when no party found / blank / error.
        """
        try:
            if not hasattr(self, 'customer_name_input'):
                return 0.0
            name = self.customer_name_input.text().strip().lower()
            if not name:
                return 0.0
            if not getattr(self, 'parties_data', None):
                return 0.0
            for p in self.parties_data:
                p_name = (p.get('party_name') or p.get('name') or "").strip().lower()
                if p_name and p_name == name:
                    party_id = p.get('id')
                    if party_id:
                        active = active_company_manager.get_active_company()
                        if active:
                            # Use PartyBalanceEngine for proper Previous Balance calculation
                            voucher_id = self.current_sale_id if hasattr(self, 'current_sale_id') else None
                            voucher_date = None
                            # If we have a saved sale loaded, get its date for proper exclusion
                            if voucher_id and hasattr(self, 'invoice_date_input'):
                                voucher_date = self.invoice_date_input.date().toString("yyyy-MM-dd")
                            balance_result = self.balance_engine.get_party_balance_before_voucher(
                                active['id'], party_id, 'sales', voucher_id=voucher_id, voucher_date=voucher_date
                            )
                            return balance_result.get('previous_balance', 0.0)
                    # Fallback to static opening_balance if DB unavailable
                    return self._safe_float(p.get('opening_balance'), 0.0)
            return 0.0
        except Exception:
            return 0.0

    def update_footer_payment_fields(self, write_amt_recvd=True):
        """Recompute and write Opening Balance, Previous Balance, Closing Balance, and (optionally) Amt Recvd.

        Rules:
          - Opening Balance: Only from party master (parties.opening_balance), never changes while browsing.
          - Previous Balance: Balance before current voucher (excludes current and future bills).
          - Cash: Amt Recvd auto = Grand Total (always forced).
          - Credit (default state): Amt Recvd = 0.00 until user manually edits it.
          - Credit (user-edited): preserve user's Amt Recvd value.
          - Closing Balance = Previous Balance + Current Bill Amount - Amount Received.

        When called from the user's own edit of Amt Recvd, pass
        write_amt_recvd=False so we don't overwrite the field mid-typing
        (which would reset the cursor and block further input).
        """
        # Guard: ensure widgets exist
        if not hasattr(self, 'amount_receive_input'):
            return

        grand_total = self._safe_float(
            getattr(self, 'grand_total_input', None).text() if hasattr(self, 'grand_total_input') else 0.0,
            0.0,
        )
        sales_type = ""
        if hasattr(self, 'sales_type_combo'):
            sales_type = (self.sales_type_combo.currentText() or "").strip().lower()

        # Get Previous Balance (balance before current voucher)
        previous_balance = self.get_selected_party_old_balance()

        # Get Opening Balance from party master (for display if field exists)
        opening_balance = 0.0
        if hasattr(self, 'customer_name_input'):
            name = self.customer_name_input.text().strip().lower()
            if name and getattr(self, 'parties_data', None):
                for p in self.parties_data:
                    p_name = (p.get('party_name') or p.get('name') or "").strip().lower()
                    if p_name and p_name == name:
                        opening_balance = self._safe_float(p.get('opening_balance'), 0.0)
                        break

        # Determine Amt Recvd based on type + user-edit state
        if sales_type == "cash":
            amt_recvd = grand_total
        else:  # credit (or anything else → treat as credit)
            if self._amt_recvd_user_edited:
                amt_recvd = self._safe_float(self.amount_receive_input.text(), 0.0)
            else:
                amt_recvd = 0.0

        # Clamp Amt Recvd so it never exceeds grand_total (only for display/calc use).
        # Do NOT clamp the live user-typed text mid-typing.
        amt_recvd_for_calc = amt_recvd if amt_recvd <= grand_total else grand_total

        # Calculate Closing Balance using PartyBalanceEngine
        closing_balance = self.balance_engine.calculate_closing_balance(
            previous_balance, grand_total, amt_recvd_for_calc, 'sales'
        )

        # Write Amt Recvd only when caller requests it (skipped during user typing).
        if write_amt_recvd:
            self._suppress_amt_recvd_signal = True
            self.amount_receive_input.blockSignals(True)
            try:
                self.amount_receive_input.setText(f"{amt_recvd_for_calc:.2f}")
            finally:
                self.amount_receive_input.blockSignals(False)
                self._suppress_amt_recvd_signal = False

        if hasattr(self, 'db_display'):
            self.db_display.setText(f"{previous_balance:.2f}")
        if hasattr(self, 'cb_display'):
            self.cb_display.setText(f"{closing_balance:.2f}")
        if hasattr(self, 'balance_display'):
            self.balance_display.setText(f"{closing_balance:.2f}")

    def on_sales_type_changed(self, _text):
        """Type switched: reset manual-edit flag so defaults apply, then refresh."""
        self._amt_recvd_user_edited = False
        self.update_footer_payment_fields()
        self._sync_print_ob_visibility()

    def _sync_print_ob_visibility(self):
        """The 'Print O/B & Amt Rcvd' checkbox is always visible (so the
        label is never missing from the foot bar) but is only ENABLED for
        Credit bills. For Cash bills it is force-unchecked and disabled —
        Cash sales have no outstanding balance concept.
        """
        if not hasattr(self, 'print_ob_checkbox'):
            return
        # Always visible; the label stays on screen.
        self.print_ob_checkbox.setVisible(True)
        sales_type = ""
        if hasattr(self, 'sales_type_combo'):
            sales_type = (self.sales_type_combo.currentText() or "").strip().lower()
        is_credit = (sales_type == "credit")
        self.print_ob_checkbox.setEnabled(is_credit)
        if not is_credit:
            # Cash bills: ensure the option is not carried over
            self.print_ob_checkbox.blockSignals(True)
            self.print_ob_checkbox.setChecked(False)
            self.print_ob_checkbox.blockSignals(False)

    def on_party_name_changed(self, _text):
        """Party name changed: refresh O/B and recompute balance safely."""
        self.update_footer_payment_fields()

    def on_amt_recvd_edited(self, _text):
        """User manually edited Amt Recvd (only credit mode is meaningful).

        We pass write_amt_recvd=False so we do NOT rewrite the field while the
        user is still typing (which would reset the cursor and block input).
        Only C/B and Balance are refreshed live.
        """
        if self._suppress_amt_recvd_signal:
            return
        # In Cash mode, Amt Recvd is forced = Grand Total; ignore manual edits
        # by re-forcing the canonical value (safe because user won't be typing in Cash).
        sales_type = ""
        if hasattr(self, 'sales_type_combo'):
            sales_type = (self.sales_type_combo.currentText() or "").strip().lower()
        if sales_type == "cash":
            self.update_footer_payment_fields(write_amt_recvd=True)
            return
        self._amt_recvd_user_edited = True
        self.update_footer_payment_fields(write_amt_recvd=False)

    def _generate_unique_invoice_number(self, company_id):
        """Generate a unique invoice number of the form INV-YYYYMMDD-NNN.

        Increments the numeric suffix until the DB reports no existing row
        for that company. Falls back to a timestamped string on any error.
        """
        from datetime import datetime
        today = datetime.now().strftime("%Y%m%d")
        try:
            for i in range(1, 10000):
                candidate = f"INV-{today}-{i:03d}"
                if not self.db.invoice_number_exists(company_id, candidate):
                    return candidate
        except Exception:
            pass
        # Extreme fallback: microsecond-based timestamp
        return "INV-" + datetime.now().strftime("%Y%m%d%H%M%S%f")

    def _resolve_party_id(self, customer_name, ui_sales_type, company_id):
        """Resolve party_id for the given customer name (case-insensitive).

        - If name is blank and sale is Cash, use 'Cash Customer' as the default party.
        - Look up the party in the current DB. If found, return its id.
        - If not found, auto-create a Debitor party with that name and return its id.
        - Returns None only if creation fails outright.
        """
        name = (customer_name or "").strip()
        if not name:
            # Cash sales without a named customer use a shared placeholder party
            name = "Cash Customer"

        try:
            parties = self.db.get_parties_by_company(company_id) or []
            for p in parties:
                if (p.get('name') or "").strip().lower() == name.lower():
                    return p['id']

            # Not found — auto-create as Debitor
            create_result = self.party_logic.save_party(company_id, {
                'name': name,
                'party_type': 'Debitor',
                'opening_balance': 0.0,
            })
            if not create_result.get('success'):
                return None

            # Re-fetch to obtain the new id and refresh local cache
            parties = self.db.get_parties_by_company(company_id) or []
            self.parties_data = parties
            for p in parties:
                if (p.get('name') or "").strip().lower() == name.lower():
                    return p['id']
        except Exception:
            return None
        return None

    def save(self):
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                QMessageBox.warning(self, "No Active Company", "Please open a company first.")
                return

            # Validate required fields
            customer_name = self.customer_name_input.text().strip()
            ui_sales_type = (self.sales_type_combo.currentText() or "").strip()
            sales_type_lc = ui_sales_type.lower()
            # Customer name is mandatory ONLY for Credit sales; Cash sales can be saved without a name.
            if sales_type_lc != "cash" and not customer_name:
                QMessageBox.warning(self, "Please select customer", "Please select a customer for a Credit bill.")
                return

            if self.items_table.rowCount() == 0:
                QMessageBox.warning(self, "Validation Error", "Please add at least one item.")
                return

            # Validate all rows: no zero qty, no above-stock qty for products with stock tracking
            for row in range(self.items_table.rowCount()):
                if row >= len(self.sale_items):
                    continue
                row_meta = self.sale_items[row] or {}
                product_id = row_meta.get('product_id')
                if not product_id:
                    continue
                qty = self._safe_float(self.items_table.item(row, 8).text() if self.items_table.item(row, 8) else "0", 0.0)
                if qty <= 0:
                    QMessageBox.warning(self, "Validation Error", f"Row {row + 1}: Quantity must be greater than 0. Please enter a valid quantity.")
                    self.items_table.setCurrentCell(row, 8)
                    self.items_table.editItem(self.items_table.item(row, 8))
                    return
                if hasattr(self, 'check_stock_tick') and self.check_stock_tick.isChecked():
                    product = self.products_dict.get(product_id)
                    product_name = product.get('name', 'Unknown') if product else 'Unknown'
                    try:
                        stock_qty = self.stock_logic.get_current_stock(
                            active_company['id'], product_id
                        )
                    except Exception:
                        stock_qty = product.get('quantity', 0) if product else 0
                    if qty > stock_qty:
                        QMessageBox.warning(
                            self,
                            "Stock Validation Failed",
                            f"Insufficient stock for product '{product_name}' at row {row + 1}.\n\n"
                            f"Required: {qty:.3f}\n"
                            f"Available: {stock_qty:.3f}\n\n"
                            f"Please reduce quantity or uncheck 'Check quantity of stock' to proceed."
                        )
                        self.items_table.setCurrentCell(row, 8)
                        self.items_table.editItem(self.items_table.item(row, 8))
                        return

            # Resolve (or auto-create) the party_id so the DB NOT NULL constraint is satisfied
            party_id = self._resolve_party_id(customer_name, ui_sales_type, active_company['id'])
            if not party_id:
                QMessageBox.warning(self, "Customer Error", "Could not resolve/create the customer party.")
                return

            # Map UI sales_type to DB-allowed values ('Sales' / 'Credit Sales' / 'Return')
            db_sales_type_map = {
                "cash": "Sales",
                "credit": "Credit Sales",
                "return": "Return",
            }
            db_sales_type = db_sales_type_map.get(sales_type_lc, "Sales")

            # Decide invoice number based on "Entry with Specific Invoice No." checkbox:
            #   checked  → use the user's typed value (must be non-empty & unique)
            #   unchecked→ always auto-generate a fresh sequential number,
            #              even if something is in the field (e.g. left over).
            use_specific = bool(
                hasattr(self, 'invoice_checkbox') and self.invoice_checkbox.isChecked()
            )
            typed = self.invoice_no_input.text().strip()
            if use_specific:
                if not typed:
                    QMessageBox.warning(
                        self,
                        "Invoice Number Required",
                        "'Entry with Specific Invoice No.' is ticked. Please enter an invoice number.",
                    )
                    self.invoice_no_input.setFocus()
                    return
                invoice_number = typed
            else:
                # When editing a saved bill keep its existing number; otherwise auto-generate.
                if self.current_sale_id and typed:
                    invoice_number = typed
                else:
                    invoice_number = self._generate_unique_invoice_number(active_company['id'])

            # Collect sale data
            sale_data = {
                'invoice_number': invoice_number,
                'invoice_date': self.date_input.date().toString("yyyy-MM-dd"),
                'party_id': party_id,
                'sales_type': db_sales_type,
                'bill_series': self.series_input.text(),
                'nature': self.nature_combo.currentText(),
                'due_date': self.due_date_input.date().toString("yyyy-MM-dd"),
                'address': self.address_input.text(),
                'gstin': self.gstin_input.text(),
                'state': self.state_combo.currentText(),
                'sales_rate': self.rate_selector_combo.currentText() if hasattr(self, 'rate_selector_combo') else "Sales Rate",
                'narration': self.narration_input.text(),
                'sub_total': self._safe_float(self.sub_total_input.text(), 0.0),
                # Combined discount = row-level discounts + footer user discount
                'discount_total': float(getattr(self, '_row_discount_total', 0.0) or 0.0) + self._safe_float(self.discount_total_input.text(), 0.0),
                'tax_total': self._safe_float(self.tax_total_input.text(), 0.0),
                'round_off': self._safe_float(self.round_off_input.text(), 0.0),
                'grand_total': self._safe_float(self.grand_total_input.text(), 0.0),
                'amount_received': self._safe_float(self.amount_receive_input.text(), 0.0),
            }

            # Collect sale items — skip trailing blank rows and rows without a product binding
            def _cell_float(r, c, default=0.0):
                try:
                    it = self.items_table.item(r, c)
                    if it is None:
                        return default
                    return self._safe_float(it.text(), default)
                except Exception:
                    return default

            sale_items = []
            for row in range(self.items_table.rowCount()):
                # Must have a corresponding entry in self.sale_items with a product_id
                if row >= len(self.sale_items):
                    continue
                row_meta = self.sale_items[row] or {}
                product_id = row_meta.get('product_id')
                qty = _cell_float(row, 8)
                if not product_id or qty <= 0:
                    # Skip blank/placeholder row
                    continue
                # Get split GST amounts from row calculation results
                cgst_amount = row_meta.get('cgst_amount', 0.0)
                sgst_amount = row_meta.get('sgst_amount', 0.0)
                igst_amount = row_meta.get('igst_amount', 0.0)
                cess_amount = row_meta.get('cess_amount', 0.0)
                sale_items.append({
                    'sl_no': len(sale_items) + 1,
                    'product_id': product_id,
                    'hsn': row_meta.get('hsn', ''),
                    'tax_percent': row_meta.get('tax_percent', 0.0),
                    'cgst': _cell_float(row, 3),
                    'sgst': _cell_float(row, 4),
                    'igst': _cell_float(row, 5),
                    'cess': _cell_float(row, 6),
                    'cgst_amount': cgst_amount,
                    'sgst_amount': sgst_amount,
                    'igst_amount': igst_amount,
                    'cess_amount': cess_amount,
                    'rate': row_meta.get('rate', 0.0),
                    'quantity': qty,
                    'gross_value': _cell_float(row, 9),
                    'discount': _cell_float(row, 10),
                    'net_value': _cell_float(row, 11),
                    'tax_amount': _cell_float(row, 12),
                    'grand_total': _cell_float(row, 13),
                })

            if not sale_items:
                QMessageBox.warning(self, "Validation Error", "Please add at least one item with a product and quantity.")
                return

            # Save-time stock validation if check_stock is enabled
            if hasattr(self, 'check_stock_tick') and self.check_stock_tick.isChecked():
                stock_invalid = False
                invalid_row = -1
                invalid_product_name = ""
                invalid_qty = 0
                available_stock = 0

                for row_idx, item in enumerate(sale_items):
                    product_id = item.get('product_id')
                    qty = float(item.get('quantity', 0))

                    if product_id and qty > 0:
                        try:
                            stock_qty = self.stock_logic.get_current_stock(
                                active_company['id'], product_id
                            )
                        except Exception:
                            product = self.products_dict.get(product_id)
                            stock_qty = product.get('quantity', 0) if product else 0
                        if qty > stock_qty:
                            stock_invalid = True
                            invalid_row = row_idx
                            product = self.products_dict.get(product_id)
                            invalid_product_name = product.get('name', 'Unknown') if product else 'Unknown'
                            invalid_qty = qty
                            available_stock = stock_qty
                        if stock_invalid:
                            break

                if stock_invalid:
                    QMessageBox.warning(
                        self,
                        "Stock Validation Failed",
                        f"Insufficient stock for product '{invalid_product_name}'.\n\n"
                        f"Required: {invalid_qty:.3f}\n"
                        f"Available: {available_stock:.3f}\n\n"
                        f"Please reduce quantity or uncheck 'Check quantity of stock' to proceed."
                    )
                    # Focus the invalid Qty cell
                    if invalid_row >= 0:
                        self.items_table.setCurrentCell(invalid_row, 8)
                        self.items_table.editItem(self.items_table.item(invalid_row, 8))
                    return

            # Save sale with retry for concurrent invoice number conflicts
            max_retries = 3

            for attempt in range(max_retries):
                result = self.sales_logic.save_sale(active_company['id'], sale_data, sale_items, self.current_sale_id)

                if result['success']:
                    break

                # Check if error is due to duplicate invoice number (concurrent save conflict)
                error_msg = result.get('message', '').lower()
                if 'duplicate' in error_msg or 'invoice' in error_msg and 'exists' in error_msg:
                    # Regenerate invoice number for auto-generated cases only
                    if not use_specific and not self.current_sale_id:
                        invoice_number = self._generate_unique_invoice_number(active_company['id'])
                        sale_data['invoice_number'] = invoice_number
                        continue
                    else:
                        # User-specified invoice number conflict - let them know
                        QMessageBox.warning(
                            self,
                            "Invoice Number Conflict",
                            f"The invoice number '{invoice_number}' is already in use.\n\n"
                            "Please choose a different number or uncheck 'Entry with Specific Invoice No.' to auto-generate."
                        )
                        return
                else:
                    # Other error - no retry
                    break

            if result['success']:
                new_sale_id = None
                data = result.get('data')
                if isinstance(data, dict):
                    new_sale_id = data.get('sale_id')
                # Refresh ONLY affected products' stock (much faster than load_products)
                # This updates local cache without reloading all products from DB
                try:
                    affected_product_ids = {item.get('product_id') for item in sale_items if item.get('product_id')}
                    self.update_affected_products_stock(affected_product_ids)
                except Exception:
                    pass

                # Prompt user to print the bill
                reply = QMessageBox.question(
                    self,
                    "Saved",
                    "Bill saved successfully. Print bill?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if reply == QMessageBox.Yes:
                    self.print_invoice()

                # Always reset to a fresh blank bill after a successful save,
                # so the user can immediately start entering the next bill.
                # (The saved bill is still accessible via Prev/Next navigation.)
                self.clear_form()
            else:
                QMessageBox.warning(self, "Error", result['message'])

        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            print("[SalesEntry.save] EXCEPTION:\n" + tb)
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to save sale: {type(e).__name__}: {e}\n\n"
                "(Details have been printed to the console.)"
            )

    def closeEvent(self, event):
        """Handle window close event to notify parent."""
        self.window_closed.emit()
        super().closeEvent(event)

    def keyPressEvent(self, event):
        # F1 key: Move focus to Qty field in the last barcode-filled row (not trailing blank row)
        if event.key() == Qt.Key_F1:
            # Use last_barcode_filled_row if available, otherwise fall back to current row
            target_row = self.last_barcode_filled_row
            if target_row < 0 or target_row >= self.items_table.rowCount():
                target_row = self.items_table.currentRow()
            
            if target_row >= 0:
                # Scroll to target row to ensure it's visible before editing
                from PySide6.QtWidgets import QAbstractItemView
                target_item = self.items_table.item(target_row, 0)
                if target_item:
                    self.items_table.scrollToItem(target_item, QAbstractItemView.PositionAtCenter)
                
                # Update Code and Stock display fields for the target row
                if target_row < len(self.sale_items):
                    product_id = self.sale_items[target_row].get('product_id')
                    product = self.products_dict.get(product_id) if product_id else None
                    if product:
                        if hasattr(self, 'code_display'):
                            self.code_display.setText(product.get('barcode', ''))
                        if hasattr(self, 'category_display'):
                            self.category_display.setText(product.get('category', ''))
                        if hasattr(self, 'size_display'):
                            self.size_display.setText(product.get('size', ''))
                        if hasattr(self, 'color_display'):
                            self.color_display.setText(product.get('color', ''))
                        # Use helper to show real stock
                        self.update_stock_display_for_row(target_row)
                
                # Edit Qty field
                qty_item = self.items_table.item(target_row, 8)  # Qty is now column 8
                if qty_item:
                    self.items_table.editItem(qty_item)
            return

        super().keyPressEvent(event)


