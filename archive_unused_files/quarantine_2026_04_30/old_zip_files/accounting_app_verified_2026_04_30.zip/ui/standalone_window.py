"""
Standalone window shell for module pages.
Provides a QMainWindow wrapper with native titlebar and window controls.
"""

from PySide6.QtWidgets import QMainWindow, QWidget, QVBoxLayout
from PySide6.QtCore import Qt


class StandaloneModuleWindow(QMainWindow):
    """QMainWindow shell for module pages with native titlebar and window controls."""

    def __init__(self, widget, title, parent=None):
        """
        Initialize standalone window.

        Args:
            widget: The page widget to display as central widget
            title: Window title
            parent: Parent window (usually MainWindow)
        """
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)

        # Set widget as central widget
        central_widget = QWidget()
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(widget)

        self.setCentralWidget(central_widget)

        # Apply dark theme styling
        self.setStyleSheet("""
            QMainWindow {
                background-color: #111827;
            }
        """)
