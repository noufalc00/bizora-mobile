"""
Edit Company dialog for the Accounting Desktop Application.
Provides a professional interface to edit existing company details.
"""

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QFrame, QScrollArea, QGridLayout, QTextEdit, QLineEdit, QWidget,
    QMessageBox, QFileDialog
)
from PySide6.QtCore import Qt, Signal, QObject, QEvent
from PySide6.QtGui import QPixmap
import os

from config import COLORS
from db import Database
from logic.company_logic import CompanyLogic
from ui.theme import GST_STATE_CODES


class FormNavigationFilter(QObject):
    def __init__(self, parent_dialog, field_order):
        super().__init__(parent_dialog)
        self.parent_dialog = parent_dialog
        self.field_order = field_order

    def eventFilter(self, obj, event):
        if event.type() != QEvent.KeyPress:
            return False

        key = event.key()

        # Enter = move forward
        if key in (Qt.Key_Return, Qt.Key_Enter):
            # Address must remain multiline
            if obj is self.parent_dialog.address:
                return False
            
            # Upload buttons should not open dialogs on Enter
            if obj in (self.parent_dialog.logo_button, self.parent_dialog.signature_button):
                current_index = self._index_of(obj)
                if current_index != -1 and current_index < len(self.field_order) - 1:
                    next_field = self.field_order[current_index + 1]
                    if next_field:
                        next_field.setFocus()
                        return True
                return True

            current_index = self._index_of(obj)
            if current_index != -1 and current_index < len(self.field_order) - 1:
                next_field = self.field_order[current_index + 1]
                if next_field:
                    next_field.setFocus()
                    return True
            return True

        # Esc = move backward
        if key == Qt.Key_Escape:
            current_index = self._index_of(obj)
            if current_index > 0:
                prev_field = self.field_order[current_index - 1]
                if prev_field:
                    prev_field.setFocus()
                    return True
            return True

        return False

    def _index_of(self, widget):
        for i, field in enumerate(self.field_order):
            if field is widget:
                return i
        return -1


class ClickablePreviewLabel(QLabel):
    def __init__(self, text="No file selected"):
        super().__init__(text)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(110)
        self.setMaximumHeight(110)
        self.setWordWrap(True)
        self.setStyleSheet("""
            QLabel {
                background-color: #1f2937;
                color: #9ca3af;
                border: 1px solid #374151;
                border-radius: 10px;
                font-size: 13px;
                padding: 10px;
            }
        """)


class EditCompanyDialog(QDialog):
    """Dialog to edit existing company details with professional layout."""
    company_updated = Signal(dict)
    
    def __init__(self, company_data, db=None, parent=None):
        super().__init__(parent)
        self.company_data = company_data
        self.company_id = company_data['id']
        self.setWindowTitle(f"Edit Company - {company_data['business_name']}")
        self.setMinimumSize(800, 700)
        # Use Qt.Window for native titlebar with full window controls
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowMinimizeButtonHint | Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowCloseButtonHint)
        
        self.db = db or Database()
        self.company_logic = CompanyLogic(self.db)
        
        # File paths
        self.logo_path = company_data.get('logo_path', '')
        self.signature_path = company_data.get('signature_path', '')

        # Use shared GST state codes from theme module
        self.gst_state_codes = GST_STATE_CODES
        
        self.setup_ui()
        self.load_company_data()
        self.connect_signals()
    
    def setup_ui(self):
        """Setup the dialog UI."""
        self.setStyleSheet(f"""
            QDialog {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
            }}
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 13px;
            }}
            QLabel.section {{
                color: {COLORS['primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
            QLabel.field {{
                color: {COLORS['text_secondary']};
                font-weight: bold;
                margin-top: 5px;
            }}
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
            QPushButton:secondary {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
            }}
            QPushButton:secondary:hover {{
                background-color: {COLORS['border']};
            }}
        """)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Create scroll area for content
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)
        scroll_area.setStyleSheet(f"""
            QScrollArea {{
                border: none;
                background-color: transparent;
            }}
        """)
        
        # Content widget
        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setSpacing(20)
        
        # Company sections
        self.create_company_info_section(content_layout)
        self.create_business_details_section(content_layout)
        self.create_upload_section(content_layout)
        self.create_action_buttons(content_layout)
        
        scroll_area.setWidget(content_widget)
        layout.addWidget(scroll_area)
    
    def create_company_info_section(self, layout):
        """Create company information section."""
        section_label = QLabel("Company Information")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        info_layout = QGridLayout(info_frame)
        info_layout.setSpacing(15)
        
        # Business Name
        business_name_label = QLabel("Business Name *:")
        business_name_label.setProperty("class", "field")
        info_layout.addWidget(business_name_label, 0, 0)
        
        self.business_name = QLineEdit()
        self.business_name.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
            QLineEdit:focus {{
                border: 2px solid {COLORS['primary']};
            }}
        """)
        info_layout.addWidget(self.business_name, 0, 1)
        
        # Phone
        phone_label = QLabel("Phone:")
        phone_label.setProperty("class", "field")
        info_layout.addWidget(phone_label, 1, 0)
        
        self.phone = QLineEdit()
        self.phone.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        info_layout.addWidget(self.phone, 1, 1)
        
        # GSTIN
        gstin_label = QLabel("GSTIN:")
        gstin_label.setProperty("class", "field")
        info_layout.addWidget(gstin_label, 2, 0)
        
        self.gstin = QLineEdit()
        self.gstin.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        info_layout.addWidget(self.gstin, 2, 1)
        
        # Email
        email_label = QLabel("Email:")
        email_label.setProperty("class", "field")
        info_layout.addWidget(email_label, 3, 0)
        
        self.email = QLineEdit()
        self.email.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        info_layout.addWidget(self.email, 3, 1)
        
        layout.addWidget(info_frame)
    
    def create_business_details_section(self, layout):
        """Create business details section."""
        section_label = QLabel("Business Details")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        details_frame = QFrame()
        details_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        details_layout = QGridLayout(details_frame)
        details_layout.setSpacing(15)
        
        # Business Type
        type_label = QLabel("Business Type:")
        type_label.setProperty("class", "field")
        details_layout.addWidget(type_label, 0, 0)
        
        self.business_type = self.create_combo_box([
            "Select Business Type",
            "Retail",
            "Wholesale",
            "Service",
            "Manufacturing",
            "Trading",
            "Other"
        ])
        details_layout.addWidget(self.business_type, 0, 1)
        
        # Business Category
        category_label = QLabel("Business Category:")
        category_label.setProperty("class", "field")
        details_layout.addWidget(category_label, 1, 0)
        
        self.business_category = self.create_combo_box([
            "Select Business Category",
            "General",
            "Electronics",
            "Grocery",
            "Textile",
            "Medical",
            "Restaurant",
            "Other"
        ])
        details_layout.addWidget(self.business_category, 1, 1)
        
        # Address
        address_label = QLabel("Address:")
        address_label.setProperty("class", "field")
        details_layout.addWidget(address_label, 2, 0, Qt.AlignTop)
        
        self.address = QTextEdit()
        self.address.setMinimumHeight(80)
        self.address.setMaximumHeight(120)
        self.address.setStyleSheet(f"""
            QTextEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        details_layout.addWidget(self.address, 2, 1)
        
        # State
        state_label = QLabel("State:")
        state_label.setProperty("class", "field")
        details_layout.addWidget(state_label, 3, 0)
        
        self.state = QLineEdit()
        self.state.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        details_layout.addWidget(self.state, 3, 1)
        
        # Pincode
        pincode_label = QLabel("Pincode:")
        pincode_label.setProperty("class", "field")
        details_layout.addWidget(pincode_label, 4, 0)
        
        self.pincode = QLineEdit()
        self.pincode.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        details_layout.addWidget(self.pincode, 4, 1)
        
        # Opening Balance
        balance_label = QLabel("Opening Balance:")
        balance_label.setProperty("class", "field")
        details_layout.addWidget(balance_label, 5, 0)
        
        self.opening_balance = QLineEdit()
        self.opening_balance.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
        """)
        details_layout.addWidget(self.opening_balance, 5, 1)
        
        layout.addWidget(details_frame)
    
    def create_upload_section(self, layout):
        """Create upload section for logo and signature."""
        section_label = QLabel("Upload Details")
        section_label.setProperty("class", "section")
        layout.addWidget(section_label)
        
        upload_frame = QFrame()
        upload_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border-radius: 8px;
                border: 1px solid {COLORS['border']};
                padding: 15px;
            }}
        """)
        
        upload_layout = QHBoxLayout(upload_frame)
        upload_layout.setSpacing(30)
        
        # Logo section
        logo_section = self.create_upload_section_item("Logo")
        upload_layout.addWidget(logo_section)
        
        # Signature section
        signature_section = self.create_upload_section_item("Signature")
        upload_layout.addWidget(signature_section)
        
        layout.addWidget(upload_frame)
    
    def create_upload_section_item(self, upload_type):
        """Create individual upload section item."""
        section = QFrame()
        section.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['background']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        
        layout = QVBoxLayout(section)
        layout.setSpacing(10)
        
        # Label
        label = QLabel(f"{upload_type}:")
        label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-weight: bold;
                font-size: 12px;
                margin-bottom: 5px;
            }}
        """)
        layout.addWidget(label)
        
        # Upload button
        upload_button = QPushButton(f"Upload {upload_type}")
        upload_button.setMinimumHeight(35)
        layout.addWidget(upload_button)
        
        # Upload conditions
        conditions = QLabel("Formats: PNG, JPG, JPEG, PDF\nMax size: 2 MB")
        conditions.setStyleSheet(f"""
            QLabel {{
                color: #60a5fa;
                font-size: 11px;
                font-weight: bold;
                margin: 2px 0;
            }}
        """)
        layout.addWidget(conditions)
        
        # Preview
        preview = ClickablePreviewLabel(f"{upload_type} preview")
        layout.addWidget(preview)
        
        # Connect signals and store button reference
        if upload_type == "Logo":
            upload_button.clicked.connect(self.upload_logo)
            self.logo_button = upload_button
            self.logo_preview = preview
        else:
            upload_button.clicked.connect(self.upload_signature)
            self.signature_button = upload_button
            self.signature_preview = preview
        
        return section
    
    def create_combo_box(self, items):
        """Create a styled combo box."""
        from PySide6.QtWidgets import QComboBox
        combo = QComboBox()
        combo.addItems(items)
        combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px;
                font-size: 13px;
            }}
            QComboBox::drop-down {{
                border: none;
                width: 20px;
            }}
            QComboBox::down-arrow {{
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 4px solid {COLORS['text_secondary']};
            }}
        """)
        return combo
    
    def create_action_buttons(self, layout):
        """Create action buttons."""
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        cancel_button = QPushButton("Cancel")
        cancel_button.setProperty("class", "secondary")
        cancel_button.clicked.connect(self.reject)
        
        save_button = QPushButton("Save Changes")
        save_button.clicked.connect(self.save_company)
        self.save_button = save_button
        
        button_layout.addWidget(cancel_button)
        button_layout.addWidget(save_button)
        
        layout.addLayout(button_layout)
    
    def connect_signals(self):
        """Connect signals for form validation."""
        self.gstin.textChanged.connect(self.on_gstin_changed)
        self.business_name.textChanged.connect(self.on_business_name_changed)
        self.state.textChanged.connect(self.on_state_changed)
        
        # Set up keyboard navigation
        self.setup_field_navigation()
    
    def setup_field_navigation(self):
        """Set up keyboard navigation for Edit Company form."""
        # Field order: Business Name -> Phone -> GSTIN -> Email -> Business Type -> Business Category -> Address -> State -> Pincode -> Opening Balance -> Upload Logo -> Upload Signature -> Save Button
        self.field_order = [
            self.business_name,
            self.phone,
            self.gstin,
            self.email,
            self.business_type,
            self.business_category,
            self.address,
            self.state,
            self.pincode,
            self.opening_balance,
            self.logo_button,
            self.signature_button,
            self.save_button
        ]
        
        for field in self.field_order:
            if field is not None:
                field.setFocusPolicy(Qt.StrongFocus)
        
        # Prevent Enter from triggering Upload button dialogs
        self.logo_button.setAutoDefault(False)
        self.logo_button.setDefault(False)
        self.signature_button.setAutoDefault(False)
        self.signature_button.setDefault(False)
        
        # Install navigation filter
        self.enter_filter = FormNavigationFilter(self, self.field_order)
        for field in self.field_order:
            if field is not None:
                field.installEventFilter(self.enter_filter)
        
        # Also install event filter on Upload buttons to prevent Enter from triggering dialogs
        self.logo_button.installEventFilter(self.enter_filter)
        self.signature_button.installEventFilter(self.enter_filter)
    
    def load_company_data(self):
        """Load existing company data into form fields."""
        # Basic info
        self.business_name.setText(self.company_data.get('business_name', ''))
        self.phone.setText(self.company_data.get('phone_number', ''))
        self.gstin.setText(self.company_data.get('gstin', ''))
        self.email.setText(self.company_data.get('email', ''))
        
        # Business details
        self.business_type.setCurrentText(self.company_data.get('business_type', 'Select Business Type'))
        self.business_category.setCurrentText(self.company_data.get('business_category', 'Select Business Category'))
        self.address.setPlainText(self.company_data.get('address', ''))
        self.state.setText(self.company_data.get('state', ''))
        self.pincode.setText(self.company_data.get('pincode', ''))
        self.opening_balance.setText(self.company_data.get('opening_balance', ''))
        
        # Load logo preview
        if self.logo_path and os.path.exists(self.logo_path):
            if self.logo_path.lower().endswith('.pdf'):
                self.logo_preview.setText("PDF Uploaded\n(Logo)")
            else:
                try:
                    pixmap = QPixmap(self.logo_path)
                    if not pixmap.isNull():
                        scaled = pixmap.scaled(
                            150, 100,
                            Qt.KeepAspectRatio,
                            Qt.SmoothTransformation
                        )
                        self.logo_preview.setPixmap(scaled)
                        self.logo_preview.setText("")
                except Exception:
                    self.logo_preview.setText("Preview not available")
        
        # Load signature preview
        if self.signature_path and os.path.exists(self.signature_path):
            if self.signature_path.lower().endswith('.pdf'):
                self.signature_preview.setText("PDF Uploaded\n(Signature)")
            else:
                try:
                    pixmap = QPixmap(self.signature_path)
                    if not pixmap.isNull():
                        scaled = pixmap.scaled(
                            150, 100,
                            Qt.KeepAspectRatio,
                            Qt.SmoothTransformation
                        )
                        self.signature_preview.setPixmap(scaled)
                        self.signature_preview.setText("")
                except Exception:
                    self.signature_preview.setText("Preview not available")
    
    def upload_logo(self):
        """Handle logo upload."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Logo",
            "",
            "Supported Files (*.png *.jpg *.jpeg *.pdf)"
        )
        if file_path:
            if self.validate_file(file_path, "Logo"):
                self.logo_path = file_path
                self.set_preview_image(self.logo_preview, file_path)
    
    def upload_signature(self):
        """Handle signature upload."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Signature",
            "",
            "Supported Files (*.png *.jpg *.jpeg *.pdf)"
        )
        if file_path:
            if self.validate_file(file_path, "Signature"):
                self.signature_path = file_path
                self.set_preview_image(self.signature_preview, file_path)
    
    def validate_file(self, file_path, file_type):
        """Validate file type and size."""
        allowed_extensions = ['.png', '.jpg', '.jpeg', '.pdf']
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext not in allowed_extensions:
            QMessageBox.warning(
                self, 
                "Invalid File Type", 
                f"{file_type} must be one of: PNG, JPG, JPEG, or PDF."
            )
            return False
        
        max_size = 2 * 1024 * 1024  # 2MB
        try:
            file_size = os.path.getsize(file_path)
            if file_size > max_size:
                size_mb = file_size / (1024 * 1024)
                QMessageBox.warning(
                    self, 
                    "File Too Large", 
                    f"{file_type} file size must be less than 2MB.\nSelected file size: {size_mb:.2f}MB"
                )
                return False
        except Exception:
            QMessageBox.warning(
                self, 
                "File Error", 
                f"Could not check {file_type} file size."
            )
            return False
        
        return True
    
    def set_preview_image(self, label, file_path):
        """Set preview image for uploaded file."""
        if file_path.lower().endswith('.pdf'):
            return
        
        pixmap = QPixmap(file_path)
        if not pixmap.isNull():
            scaled = pixmap.scaled(
                150, 100,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
            label.setPixmap(scaled)
            label.setText("")
        else:
            label.setText("Preview not available")
    
    def on_gstin_changed(self, text):
        """Handle GSTIN text changes - format validation and state detection."""
        # GSTIN standard format: 15 characters
        # Format: 2 digits state code + 10 characters PAN + 3 digits
        MAX_GSTIN_LENGTH = 15
        cursor_pos = self.gstin.cursorPosition()
        
        # Filter to only allow valid GSTIN characters (alphanumeric only)
        filtered_text = ''.join(char for char in text if char.isalnum())
        
        # Enforce maximum length
        if len(filtered_text) > MAX_GSTIN_LENGTH:
            filtered_text = filtered_text[:MAX_GSTIN_LENGTH]
        
        # Convert to uppercase
        upper_text = filtered_text.upper()
        
        # Update text if changed
        if upper_text != text:
            self.gstin.blockSignals(True)
            self.gstin.setText(upper_text)
            self.gstin.setCursorPosition(min(cursor_pos, MAX_GSTIN_LENGTH))
            self.gstin.blockSignals(False)
        
        # Clear State field first, then autofill if valid GSTIN state code exists
        self.state.blockSignals(True)
        self.state.setText("")
        self.state.blockSignals(False)
        
        if len(upper_text) >= 2 and upper_text[:2].isdigit():
            state_code = upper_text[:2]
            if state_code in self.gst_state_codes:
                expected_state = self.gst_state_codes[state_code]
                self.state.blockSignals(True)
                self.state.setText(expected_state)
                self.state.blockSignals(False)
    
    def on_business_name_changed(self, text):
        """Handle business name changes - auto-capitalize first letter."""
        if not text:
            return
        
        words = text.split(" ")
        capitalized_words = []
        
        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")
        
        new_text = " ".join(capitalized_words)
        
        if new_text != text:
            cursor_pos = self.business_name.cursorPosition()
            self.business_name.blockSignals(True)
            self.business_name.setText(new_text)
            self.business_name.setCursorPosition(min(cursor_pos, len(new_text)))
            self.business_name.blockSignals(False)
    
    def on_state_changed(self, text):
        """Handle state changes - auto-capitalize."""
        if not text:
            return
        cursor_pos = self.state.cursorPosition()
        capitalized_text = ' '.join(word.capitalize() for word in text.split())
        self.state.blockSignals(True)
        self.state.setText(capitalized_text)
        self.state.setCursorPosition(cursor_pos)
        self.state.blockSignals(False)
    
    def save_company(self):
        """Save updated company data."""
        business_name = self.business_name.text().strip()
        
        if not business_name:
            QMessageBox.warning(self, "Validation Error", "Business Name is required.")
            self.business_name.setFocus()
            return
        
        # Prepare company data
        company_data = {
            "business_name": business_name,
            "phone_number": self.phone.text().strip(),
            "gstin": self.gstin.text().strip().upper(),
            "email": self.email.text().strip(),
            "business_type": self.business_type.currentText(),
            "business_category": self.business_category.currentText(),
            "address": self.address.toPlainText().strip(),
            "state": self.state.text().strip(),
            "pincode": self.pincode.text().strip(),
            "logo_path": self.logo_path,
            "signature_path": self.signature_path,
        }
        
        # Validate company data
        validation_result = self.company_logic.validate_company_data(company_data, self.company_id)
        
        if not validation_result['success']:
            QMessageBox.warning(self, "Validation Error", validation_result['message'])
            self.business_name.setFocus()
            return
        
        # Update company in database
        update_result = self.company_logic.update_company(self.company_id, company_data)
        
        if update_result['success']:
            # Add opening balance to updated data for signal
            company_data["opening_balance"] = self.opening_balance.text().strip()
            company_data["id"] = self.company_id
            
            QMessageBox.information(self, "Success", "Company details updated successfully.")
            self.company_updated.emit(company_data)
            self.accept()
        else:
            QMessageBox.critical(self, "Error", update_result['message'])
