"""
Main window implementation for the Accounting Desktop Application.
Uses QMainWindow with sidebar, topbar, and QStackedWidget for modular UI management.

PERFORMANCE NOTE: Heavy module imports are deferred using lazy imports inside
the respective show methods to improve startup time.
"""

import time
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget, QFrame, QMessageBox
)
from PySide6.QtCore import Qt, Signal

from config import APP_NAME, COLORS, WINDOW_SIZE, active_company_manager
from components.sidebar import Sidebar
from components.topbar import TopbarWidget
from .dashboard import DashboardWidget
from .company_page import CompanyPageWidget
from .new_company_page import NewCompanyPageWidget
from .open_company_page import OpenCompanyPageWidget
from .standalone_window import StandaloneModuleWindow

# Heavy imports (Products, Sales Entry, etc.) are loaded lazily inside show methods
# to improve startup performance. See: show_products(), show_sales(), etc.


class MainWindow(QMainWindow):
    """Main application window with sidebar, topbar, and stacked widgets."""
    
    def __init__(self, db=None):
        super().__init__()
        init_start = time.time()

        self.db = db
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(1200, 800)

        # Track open standalone module windows to prevent duplicates
        self._open_module_windows = {}

        # Performance tracking for lazy-loaded pages
        self._page_load_times = {}

        # Initialize UI components
        self.stack_widget = QStackedWidget()

        # Setup UI
        self.setup_ui()

        # Connect signals
        self.connect_signals()

        # Apply global message box styling
        self.setup_global_dialog_styling()

        # Show dashboard by default
        self.show_dashboard()

        init_end = time.time()
        print(f"[PERF] MainWindow init: {init_end - init_start:.3f} sec")
    
    def setup_ui(self):
        """Setup main UI layout with horizontal structure."""
        setup_start = time.time()

        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main horizontal layout: left sidebar, right main area
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Left: Sidebar (lightweight, loaded immediately)
        sidebar_start = time.time()
        self.sidebar = Sidebar()
        main_layout.addWidget(self.sidebar)
        sidebar_end = time.time()
        print(f"[PERF] Sidebar setup: {sidebar_end - sidebar_start:.3f} sec")

        # Right: Main area with vertical layout
        main_area_widget = QWidget()
        main_area_layout = QVBoxLayout(main_area_widget)
        main_area_layout.setContentsMargins(0, 0, 0, 0)
        main_area_layout.setSpacing(0)

        # Topbar at top of main area (lightweight, loaded immediately)
        topbar_start = time.time()
        self.topbar = TopbarWidget(self.db)
        main_area_layout.addWidget(self.topbar)
        topbar_end = time.time()
        print(f"[PERF] Topbar setup: {topbar_end - topbar_start:.3f} sec")

        # QStackedWidget workspace below topbar
        self.stack_widget = QStackedWidget()
        self.stack_widget.setStyleSheet(f"""
            QStackedWidget {{
                background-color: {COLORS['background']};
            }}
        """)
        main_area_layout.addWidget(self.stack_widget)

        # Add main area to main layout
        main_layout.addWidget(main_area_widget, 1)

        # Setup workspace pages (lightweight pages only)
        self.setup_workspace_pages()

        setup_end = time.time()
        print(f"[PERF] setup_ui total: {setup_end - setup_start:.3f} sec")
    
    def setup_workspace_pages(self):
        """Setup pages for the QStackedWidget workspace."""
        # Create dashboard page (initial page)
        self.dashboard_widget = DashboardWidget()
        self.stack_widget.addWidget(self.dashboard_widget)

        # Create company page
        self.company_widget = CompanyPageWidget(self.db)
        self.stack_widget.addWidget(self.company_widget)

        # New Company, Open Company, Products, Debitors/Creditors, Bank Accounts, Sales Entry, Purchase Entry, Ledger will be standalone windows, not in stack

        # Add pages dictionary (excluding standalone windows)
        self.pages = {
            'Dashboard': self.dashboard_widget,
            'Company': self.company_widget
        }
    
    def connect_signals(self):
        """Connect signals between components."""
        # Sidebar page changes
        self.sidebar.page_changed.connect(self.on_page_changed)
        self.sidebar.company_closed.connect(self.on_company_closed)

        # Topbar search
        self.topbar.search_requested.connect(self.on_search_requested)

        # Company page signals
        self.company_widget.company_saved.connect(self.on_company_saved)

        # New company and Open company signals will be connected when windows are opened
    
    def on_page_changed(self, page_name: str):
        """Handle page change from sidebar."""
        if page_name == "Company":
            self.show_company()
        elif page_name == "New Company":
            self.show_new_company()
        elif page_name == "Open Company":
            self.show_open_company()
        elif page_name == "Product/Service":
            self.show_products()
        elif page_name == "Debitor/Creditor":
            self.show_debitor_creditor()
        elif page_name == "Bank Account":
            self.show_bank_accounts()
        elif page_name == "Sales":
            self.show_sales()
        elif page_name == "Purchase":
            self.show_purchase()
        elif page_name == "Sales Return":
            self.show_sales_return()
        elif page_name == "Purchase Return":
            self.show_purchase_return()
        elif page_name == "Ledger":
            self.show_ledger()
        elif page_name == "Trial Balance":
            self.show_trial_balance()
        elif page_name == "Stock Report":
            self.show_stock_report()
        else:
            # For other pages, show dashboard for now
            self.show_dashboard()
    
    def on_search_requested(self, search_text: str):
        """Handle search request from topbar."""
        # Placeholder for search functionality
        print(f"Search requested: {search_text}")
    
    def on_company_saved(self):
        """Handle company saved event."""
        # Update topbar to show new active company
        self.topbar.update_active_company()
    
    def on_company_selected(self, company_data):
        """Handle company selection event."""
        if company_data:
            # Company was successfully opened, update topbar and show dashboard
            self.topbar.update_active_company()
            self.show_dashboard()
        else:
            # User cancelled, show dashboard
            self.show_dashboard()

    def _on_module_window_closed(self, window_key):
        """Clean up tracking when a standalone module window is closed."""
        if window_key in self._open_module_windows:
            del self._open_module_windows[window_key]
    
    def on_company_closed(self):
        """Handle company close event."""
        # Update topbar to reflect no active company
        self.topbar.update_active_company()
        self.show_dashboard()
    
    def show_dashboard(self):
        """Show dashboard page."""
        self.stack_widget.setCurrentWidget(self.dashboard_widget)
    
    def show_company(self):
        """Show company page."""
        self.stack_widget.setCurrentWidget(self.company_widget)
    
    def show_new_company(self):
        """Open new company as standalone window."""
        # Check if window already exists
        if 'new_company' in self._open_module_windows:
            window = self._open_module_windows['new_company']
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Create widget and window
        widget = NewCompanyPageWidget(self.db)
        window = StandaloneModuleWindow(widget, "Create New Company", self)
        window.setMinimumSize(900, 700)

        # Connect signals
        widget.company_saved.connect(self.on_company_saved)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('new_company'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['new_company'] = window
    
    def show_open_company(self):
        """Open open company as standalone window."""
        # Check if window already exists
        if 'open_company' in self._open_module_windows:
            window = self._open_module_windows['open_company']
            # Reload companies list when focusing existing window
            widget = window.centralWidget().findChild(NewCompanyPageWidget) or window.centralWidget().findChild(OpenCompanyPageWidget)
            if widget and hasattr(widget, 'load_companies'):
                widget.load_companies()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Create widget and window
        widget = OpenCompanyPageWidget(self.db)
        widget.load_companies()
        window = StandaloneModuleWindow(widget, "Open Company", self)
        window.setMinimumSize(900, 700)

        # Connect signals
        widget.company_selected.connect(self.on_company_selected)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('open_company'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['open_company'] = window
    
    def show_products(self):
        """Open products/services as standalone window (lazy loaded)."""
        # Check if window already exists
        if 'products' in self._open_module_windows:
            window = self._open_module_windows['products']
            # Reload products list when focusing existing window
            from .products import ProductsWidget
            widget = window.centralWidget().findChild(ProductsWidget)
            if widget:
                widget.load_products()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .products import ProductsWidget
        import_end = time.time()

        # Create widget and window
        widget = ProductsWidget(self.db)
        widget.load_products()
        window = StandaloneModuleWindow(widget, "Products / Services", self)
        window.setMinimumSize(1000, 700)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('products'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['products'] = window

        # Performance logging
        load_time = import_end - import_start
        self._page_load_times['products'] = load_time
        print(f"[PERF] First Products open: {load_time:.3f} sec (import: {load_time:.3f} sec)")
    
    def show_debitor_creditor(self):
        """Open debitor/creditor as standalone window (lazy loaded)."""
        # Check if window already exists
        if 'debitor_creditor' in self._open_module_windows:
            window = self._open_module_windows['debitor_creditor']
            # Reload parties list when focusing existing window
            from .debitor_creditor import DebitorCreditorWidget
            widget = window.centralWidget().findChild(DebitorCreditorWidget)
            if widget:
                widget.load_parties()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .debitor_creditor import DebitorCreditorWidget
        import_end = time.time()

        # Create widget and window
        widget = DebitorCreditorWidget(self.db)
        widget.load_parties()

        # Connect party_saved signal to refresh all open Sales Entry windows
        widget.party_saved.connect(self._on_party_saved)

        window = StandaloneModuleWindow(widget, "Debitors / Creditors", self)
        window.setMinimumSize(1000, 700)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('debitor_creditor'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['debitor_creditor'] = window

        # Performance logging
        load_time = import_end - import_start
        self._page_load_times['debitor_creditor'] = load_time
        print(f"[PERF] First Debitor/Creditor open: {load_time:.3f} sec")

    def _on_party_saved(self):
        """Handle party_saved signal - refresh all open Sales Entry and Purchase Return windows."""
        from .sales_entry import SalesEntryWidget
        sales_windows = [k for k in self._open_module_windows.keys() if k.startswith('sales_')]
        for window_key in sales_windows:
            window = self._open_module_windows[window_key]
            widget = window.centralWidget().findChild(SalesEntryWidget)
            if widget and hasattr(widget, 'refresh_parties'):
                widget.refresh_parties()

        # Refresh Purchase Return windows
        from .purchase_return import PurchaseReturnPageWidget
        pr_windows = [k for k in self._open_module_windows.keys() if k.startswith('purchase_return')]
        for window_key in pr_windows:
            window = self._open_module_windows[window_key]
            widget = window.centralWidget().findChild(PurchaseReturnPageWidget)
            if widget and hasattr(widget, 'refresh_creditors'):
                widget.refresh_creditors()

        # Refresh Purchase Entry windows
        from .purchase_entry import PurchaseEntryWidget
        pe_windows = [k for k in self._open_module_windows.keys() if k.startswith('purchase_')]
        for window_key in pe_windows:
            if window_key in pr_windows:
                continue
            window = self._open_module_windows[window_key]
            widget = window.centralWidget().findChild(PurchaseEntryWidget)
            if widget and hasattr(widget, 'load_creditors'):
                widget.load_creditors()
    
    def show_bank_accounts(self):
        """Open bank accounts as standalone window (lazy loaded)."""
        # Check if window already exists
        if 'bank_accounts' in self._open_module_windows:
            window = self._open_module_windows['bank_accounts']
            # Reload bank accounts list when focusing existing window
            from .bank_accounts import BankAccountWidget
            widget = window.centralWidget().findChild(BankAccountWidget)
            if widget:
                widget.load_bank_accounts()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .bank_accounts import BankAccountWidget
        import_end = time.time()

        # Create widget and window
        widget = BankAccountWidget(self.db)
        widget.load_bank_accounts()
        window = StandaloneModuleWindow(widget, "Bank Accounts", self)
        window.setMinimumSize(1000, 700)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('bank_accounts'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['bank_accounts'] = window

        # Performance logging
        load_time = import_end - import_start
        self._page_load_times['bank_accounts'] = load_time
        print(f"[PERF] First Bank Accounts open: {load_time:.3f} sec")
    
    def show_sales(self):
        """Open sales entry as standalone window (allows multiple instances, lazy loaded)."""
        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .sales_entry import SalesEntryWidget
        import_end = time.time()

        # Sales Entry allows multiple concurrent windows
        # Track all open sales windows with numbered keys
        sales_windows = [k for k in self._open_module_windows.keys() if k.startswith('sales_')]
        next_num = len(sales_windows) + 1
        window_key = f'sales_{next_num}'

        # Create widget and window
        widget = SalesEntryWidget(self.db)
        widget.load_parties()
        widget.load_products()

        # Determine window title
        if next_num == 1:
            title = "Sales Entry"
        else:
            title = f"Sales Entry ({next_num})"

        window = StandaloneModuleWindow(widget, title, self)

        # Calculate screen-fit size (90% of available screen geometry)
        screen = window.screen()
        if screen:
            available_geometry = screen.availableGeometry()
            width = int(available_geometry.width() * 0.9)
            height = int(available_geometry.height() * 0.9)
            window.resize(width, height)

            # Center window on screen
            x = available_geometry.x() + (available_geometry.width() - width) // 2
            y = available_geometry.y() + (available_geometry.height() - height) // 2
            window.move(x, y)
        else:
            window.setMinimumSize(1200, 800)

        # Connect widget close event to cleanup
        widget.window_closed.connect(lambda: self._on_sales_window_closed(window_key))

        # Show window
        window.show()

        # Track window
        self._open_module_windows[window_key] = window

        # Performance logging (only for first window)
        if next_num == 1:
            load_time = import_end - import_start
            self._page_load_times['sales_entry'] = load_time
            print(f"[PERF] First Sales Entry open: {load_time:.3f} sec")

    def _on_sales_window_closed(self, window_key):
        """Clean up tracking when a Sales Entry window is closed."""
        if window_key in self._open_module_windows:
            del self._open_module_windows[window_key]

    def show_purchase(self):
        """Open purchase entry as standalone window (allows multiple instances, lazy loaded)."""
        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .purchase_entry import PurchaseEntryWidget
        import_end = time.time()

        # Purchase Entry allows multiple concurrent windows
        # Track all open purchase windows with numbered keys
        purchase_windows = [k for k in self._open_module_windows.keys() if k.startswith('purchase_')]
        next_num = len(purchase_windows) + 1
        window_key = f'purchase_{next_num}'

        # Create widget and window
        widget = PurchaseEntryWidget(self, self.db)
        # Don't load creditors/products here - they will be loaded lazily on show

        # Determine window title - always use "Purchase Entry" without numbers
        title = "Purchase Entry"

        window = StandaloneModuleWindow(widget, title, self)

        # Calculate screen-fit size (90% of available screen geometry)
        screen = window.screen()
        if screen:
            available_geometry = screen.availableGeometry()
            width = int(available_geometry.width() * 0.9)
            height = int(available_geometry.height() * 0.9)
            window.resize(width, height)

            # Center window on screen
            x = available_geometry.x() + (available_geometry.width() - width) // 2
            y = available_geometry.y() + (available_geometry.height() - height) // 2
            window.move(x, y)
        else:
            window.setMinimumSize(1200, 800)

        # Connect widget close event to cleanup
        widget.window_closed.connect(lambda: self._on_purchase_window_closed(window_key))

        # Show window
        window.show()

        # Track window
        self._open_module_windows[window_key] = window

        # Performance logging (only for first window)
        if next_num == 1:
            load_time = import_end - import_start
            self._page_load_times['purchase_entry'] = load_time
            print(f"[PERF] First Purchase Entry open: {load_time:.3f} sec")

    def _on_purchase_window_closed(self, window_key):
        """Clean up tracking when a Purchase Entry window is closed."""
        if window_key in self._open_module_windows:
            del self._open_module_windows[window_key]

    def show_ledger(self):
        """Open ledger as standalone window (lazy loaded)."""
        # Check if window already exists
        if 'ledger' in self._open_module_windows:
            window = self._open_module_windows['ledger']
            # Refresh ledger when focusing existing window
            from .ledger_page import LedgerPageWidget
            widget = window.centralWidget().findChild(LedgerPageWidget)
            if widget and hasattr(widget, 'refresh'):
                widget.refresh()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .ledger_page import LedgerPageWidget
        import_end = time.time()

        # Create widget and window
        widget = LedgerPageWidget(self.db)
        widget.refresh()
        window = StandaloneModuleWindow(widget, "Ledger", self)
        window.setMinimumSize(1200, 700)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('ledger'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['ledger'] = window

        # Performance logging
        load_time = import_end - import_start
        self._page_load_times['ledger'] = load_time
        print(f"[PERF] First Ledger open: {load_time:.3f} sec")

    def show_trial_balance(self):
        """Open Trial Balance as standalone window (lazy loaded)."""
        if 'trial_balance' in self._open_module_windows:
            window = self._open_module_windows['trial_balance']
            from .trial_balance_page import TrialBalancePageWidget
            widget = window.centralWidget().findChild(TrialBalancePageWidget)
            if widget and hasattr(widget, 'refresh'):
                widget.refresh()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        import_start = time.time()
        from .trial_balance_page import TrialBalancePageWidget
        import_end = time.time()

        widget = TrialBalancePageWidget(self.db)
        widget.refresh()
        window = StandaloneModuleWindow(widget, "Trial Balance", self)
        window.setMinimumSize(1300, 720)

        window.destroyed.connect(lambda: self._on_module_window_closed('trial_balance'))
        window.show()
        self._open_module_windows['trial_balance'] = window

        load_time = import_end - import_start
        self._page_load_times['trial_balance'] = load_time
        print(f"[PERF] First Trial Balance open: {load_time:.3f} sec")

    def show_stock_report(self):
        """Open stock report as standalone window (lazy loaded)."""
        # Check if window already exists
        if 'stock_report' in self._open_module_windows:
            window = self._open_module_windows['stock_report']
            # Refresh stock report when focusing existing window
            from .stock_report_page import StockReportPageWidget
            widget = window.centralWidget().findChild(StockReportPageWidget)
            if widget and hasattr(widget, 'refresh_report'):
                widget.refresh_report()
            window.show()
            window.raise_()
            window.activateWindow()
            return

        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .stock_report_page import StockReportPageWidget
        import_end = time.time()

        # Create widget and window
        widget = StockReportPageWidget(self)
        window = StandaloneModuleWindow(widget, "Stock Report", self)
        window.setMinimumSize(1200, 700)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_module_window_closed('stock_report'))

        # Show window
        window.show()

        # Track window
        self._open_module_windows['stock_report'] = window

        # Performance logging
        load_time = import_end - import_start
        self._page_load_times['stock_report'] = load_time
        print(f"[PERF] First Stock Report open: {load_time:.3f} sec")

    def show_sales_return(self):
        """Open sales return as standalone window (allows multiple instances, lazy loaded)."""
        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .sales_return import SalesReturnPageWidget
        import_end = time.time()

        # Sales Return allows multiple concurrent windows
        # Track all open sales return windows with numbered keys
        sales_return_windows = [k for k in self._open_module_windows.keys() if k.startswith('sales_return_')]
        next_num = len(sales_return_windows) + 1
        window_key = f'sales_return_{next_num}'

        # Create widget and window
        widget = SalesReturnPageWidget(self, self.db)

        # Determine window title
        if next_num == 1:
            title = "Sales Return"
        else:
            title = f"Sales Return ({next_num})"

        window = StandaloneModuleWindow(widget, title, self)

        # Calculate screen-fit size (90% of available screen geometry)
        screen = window.screen()
        if screen:
            available_geometry = screen.availableGeometry()
            width = int(available_geometry.width() * 0.9)
            height = int(available_geometry.height() * 0.9)
            window.resize(width, height)

            # Center window on screen
            x = available_geometry.x() + (available_geometry.width() - width) // 2
            y = available_geometry.y() + (available_geometry.height() - height) // 2
            window.move(x, y)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_sales_return_window_closed(window_key))

        # Show window
        window.show()

        # Track window
        self._open_module_windows[window_key] = window

        # Performance logging (only for first window)
        if next_num == 1:
            load_time = import_end - import_start
            self._page_load_times['sales_return'] = load_time
            print(f"[PERF] First Sales Return open: {load_time:.3f} sec")

    def _on_sales_return_window_closed(self, window_key):
        """Clean up tracking when a Sales Return window is closed."""
        if window_key in self._open_module_windows:
            del self._open_module_windows[window_key]

    def show_purchase_return(self):
        """Open purchase return as standalone window (allows multiple instances, lazy loaded)."""
        # Lazy import: load heavy module only when needed
        import_start = time.time()
        from .purchase_return import PurchaseReturnPageWidget
        import_end = time.time()

        # Purchase Return allows multiple concurrent windows
        # Track all open purchase return windows with numbered keys
        purchase_return_windows = [k for k in self._open_module_windows.keys() if k.startswith('purchase_return_')]
        next_num = len(purchase_return_windows) + 1
        window_key = f'purchase_return_{next_num}'

        # Create widget and window
        widget = PurchaseReturnPageWidget(self, self.db)

        # Determine window title
        if next_num == 1:
            title = "Purchase Return"
        else:
            title = f"Purchase Return ({next_num})"

        window = StandaloneModuleWindow(widget, title, self)

        # Calculate screen-fit size (90% of available screen geometry)
        screen = window.screen()
        if screen:
            available_geometry = screen.availableGeometry()
            width = int(available_geometry.width() * 0.9)
            height = int(available_geometry.height() * 0.9)
            window.resize(width, height)

            # Center window on screen
            x = available_geometry.x() + (available_geometry.width() - width) // 2
            y = available_geometry.y() + (available_geometry.height() - height) // 2
            window.move(x, y)

        # Clean up when window closes
        window.destroyed.connect(lambda: self._on_purchase_return_window_closed(window_key))

        # Show window
        window.show()

        # Track window
        self._open_module_windows[window_key] = window

        # Performance logging (only for first window)
        if next_num == 1:
            load_time = import_end - import_start
            self._page_load_times['purchase_return'] = load_time
            print(f"[PERF] First Purchase Return open: {load_time:.3f} sec")

    def _on_purchase_return_window_closed(self, window_key):
        """Clean up tracking when a Purchase Return window is closed."""
        if window_key in self._open_module_windows:
            del self._open_module_windows[window_key]
    
    def setup_global_dialog_styling(self):
        """Apply global styling to all QMessageBox dialogs."""
        self.setStyleSheet("""
            QMessageBox {
                background-color: #2d3748;
                color: #ffffff;
                border: 1px solid #4b5563;
                border-radius: 6px;
                padding: 20px;
                font-size: 14px;
            }
            QMessageBox QLabel {
                color: #ffffff;
                font-size: 14px;
            }
            QMessageBox QPushButton {
                background-color: #4b5563;
                color: #ffffff;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 80px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
            QPushButton:focus {
                border: 2px solid #60a5fa;
            }
        """)
    
    def get_current_page(self) -> str:
        """Get the name of the current page."""
        current_widget = self.stack_widget.currentWidget()
        for name, widget in self.pages.items():
            if widget == current_widget:
                return name
        return "Unknown"
    
    def add_page(self, name: str, widget: QWidget):
        """Add a new page to the workspace."""
        self.pages[name] = widget
        self.stack_widget.addWidget(widget)
