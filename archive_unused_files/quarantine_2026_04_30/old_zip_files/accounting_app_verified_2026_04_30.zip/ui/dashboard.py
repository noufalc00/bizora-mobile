"""
Dashboard widget for the Accounting Desktop Application.
Main dashboard page for the QStackedWidget workspace.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QScrollArea
)
from PySide6.QtCore import Qt

from config import COLORS


class DashboardWidget(QWidget):
    """Main dashboard widget showing financial overview."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup dashboard UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header section
        header_widget = self.create_header_section()
        layout.addWidget(header_widget)
        
        # Summary cards section
        summary_widget = self.create_summary_section()
        layout.addWidget(summary_widget)
        
        # Quick actions section
        actions_widget = self.create_quick_actions_section()
        layout.addWidget(actions_widget)
        
        # Recent activity section
        activity_widget = self.create_recent_activity_section()
        layout.addWidget(activity_widget)
        
        layout.addStretch()
    
    def create_header_section(self) -> QWidget:
        """Create dashboard header section."""
        header_widget = QWidget()
        header_widget.setFixedHeight(80)
        
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        # Welcome message
        welcome_label = QLabel("Welcome to Accounting Pro")
        welcome_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 28px;
                font-weight: bold;
            }}
        """)
        header_layout.addWidget(welcome_label)
        
        header_layout.addStretch()
        
        # Date/time
        date_label = QLabel("Today: Dashboard Overview")
        date_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-size: 14px;
            }}
        """)
        header_layout.addWidget(date_label)
        
        return header_widget
    
    def create_summary_section(self) -> QWidget:
        """Create financial summary cards section."""
        summary_widget = QWidget()
        summary_widget.setFixedHeight(150)
        
        summary_layout = QHBoxLayout(summary_widget)
        summary_layout.setContentsMargins(0, 0, 0, 0)
        summary_layout.setSpacing(15)
        
        # Create summary cards
        cards_data = [
            ("Total Balance", "$12,450.00", COLORS['success']),
            ("Monthly Income", "$3,250.00", COLORS['primary']),
            ("Monthly Expenses", "$1,890.00", COLORS['error']),
            ("Active Accounts", "4", COLORS['info'])
        ]
        
        for title, value, color in cards_data:
            card = self.create_summary_card(title, value, color)
            summary_layout.addWidget(card)
        
        summary_layout.addStretch()
        
        return summary_widget
    
    def create_summary_card(self, title: str, value: str, color: str) -> QFrame:
        """Create a summary card widget."""
        card = QFrame()
        card.setFixedSize(220, 120)
        card.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 8px;
                padding: 16px;
            }}
            QFrame:hover {{
                border: 1px solid {color};
            }}
        """)
        
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)
        
        title_label = QLabel(title)
        title_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-size: 12px;
                font-weight: 500;
            }}
        """)
        layout.addWidget(title_label)
        
        value_label = QLabel(value)
        value_label.setStyleSheet(f"""
            QLabel {{
                color: {color};
                font-size: 24px;
                font-weight: bold;
            }}
        """)
        layout.addWidget(value_label)
        
        layout.addStretch()
        
        return card
    
    def create_quick_actions_section(self) -> QWidget:
        """Create quick actions section."""
        actions_widget = QWidget()
        actions_widget.setFixedHeight(100)
        
        actions_layout = QHBoxLayout(actions_widget)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(15)
        
        # Section title
        actions_title = QLabel("Quick Actions")
        actions_title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
            }}
        """)
        actions_layout.addWidget(actions_title)
        
        actions_layout.addStretch()
        
        # Quick action buttons
        actions_data = [
            ("New Transaction", COLORS['primary']),
            ("Add Account", COLORS['success']),
            ("Generate Report", COLORS['info']),
            ("Backup Data", COLORS['warning'])
        ]
        
        for text, color in actions_data:
            btn = QLabel(text)
            btn.setStyleSheet(f"""
                QLabel {{
                    background-color: {color};
                    color: white;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 13px;
                    font-weight: 500;
                }}
            """)
            actions_layout.addWidget(btn)
        
        actions_layout.addStretch()
        
        return actions_widget
    
    def create_recent_activity_section(self) -> QWidget:
        """Create recent activity section."""
        activity_widget = QFrame()
        activity_widget.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 8px;
                padding: 20px;
            }}
        """)
        
        activity_layout = QVBoxLayout(activity_widget)
        activity_layout.setContentsMargins(20, 20, 20, 20)
        activity_layout.setSpacing(15)
        
        # Section title
        activity_title = QLabel("Recent Activity")
        activity_title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 18px;
                font-weight: bold;
            }}
        """)
        activity_layout.addWidget(activity_title)
        
        # Activity items
        activity_items = [
            "New account 'Savings Account' created",
            "Transaction #1234: Salary deposit - $3,250.00",
            "Transaction #1235: Grocery purchase - $125.50",
            "Monthly report generated successfully"
        ]
        
        for item in activity_items:
            item_label = QLabel(f"  {item}")
            item_label.setStyleSheet(f"""
                QLabel {{
                    color: {COLORS['text_secondary']};
                    font-size: 13px;
                    padding: 8px 0;
                    border-bottom: 1px solid {COLORS['border']};
                }}
            """)
            activity_layout.addWidget(item_label)
        
        return activity_widget
