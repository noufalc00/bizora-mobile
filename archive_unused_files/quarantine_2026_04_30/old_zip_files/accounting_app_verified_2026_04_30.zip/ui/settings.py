"""
Settings widget for the Accounting Desktop Application.
Manages application preferences and configuration.
"""

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton, QCheckBox, QComboBox, QLineEdit, QSpinBox, QTabWidget
from PySide6.QtCore import Qt

from config import COLORS, DEFAULT_CURRENCY, DATE_FORMAT


class SettingsWidget(QWidget):
    """Settings widget for application configuration."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        """Setup settings UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header
        title = QLabel("Settings")
        title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 24px;
                font-weight: bold;
            }}
        """)
        layout.addWidget(title)
        
        # Tab widget for different setting categories
        self.tab_widget = QTabWidget()
        self.tab_widget.setStyleSheet(f"""
            QTabWidget::pane {{
                border: 1px solid {COLORS['border']};
                background-color: {COLORS['surface']};
                border-radius: 8px;
            }}
            QTabBar::tab {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                padding: 10px 20px;
                border: 1px solid {COLORS['border']};
                border-bottom: none;
            }}
            QTabBar::tab:selected {{
                background-color: {COLORS['primary']};
                color: white;
            }}
            QTabBar::tab:!selected {{
                margin-top: 2px;
            }}
        """)
        
        # Create setting tabs
        self.create_general_tab()
        self.create_appearance_tab()
        self.create_database_tab()
        self.create_advanced_tab()
        
        layout.addWidget(self.tab_widget)
        
        # Save/Cancel buttons
        buttons_layout = QHBoxLayout()
        buttons_layout.addStretch()
        
        save_btn = QPushButton("Save Settings")
        save_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
        """)
        buttons_layout.addWidget(save_btn)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['button_default']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 14px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['button_hover']};
            }}
        """)
        buttons_layout.addWidget(cancel_btn)
        
        layout.addLayout(buttons_layout)
    
    def create_general_tab(self):
        """Create general settings tab."""
        general_widget = QWidget()
        layout = QVBoxLayout(general_widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Currency settings
        currency_frame = QFrame()
        currency_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        currency_layout = QVBoxLayout(currency_frame)
        
        currency_label = QLabel("Currency Settings")
        currency_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        currency_layout.addWidget(currency_label)
        
        # Default currency
        currency_row = QHBoxLayout()
        currency_row.addWidget(QLabel("Default Currency:"))
        
        self.currency_combo = QComboBox()
        self.currency_combo.addItems(["USD", "EUR", "GBP", "JPY", "CAD", "AUD"])
        self.currency_combo.setCurrentText(DEFAULT_CURRENCY)
        self.currency_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
                min-width: 100px;
            }}
        """)
        currency_row.addWidget(self.currency_combo)
        currency_row.addStretch()
        currency_layout.addLayout(currency_row)
        
        layout.addWidget(currency_frame)
        
        # Date format settings
        date_frame = QFrame()
        date_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        date_layout = QVBoxLayout(date_frame)
        
        date_label = QLabel("Date & Time")
        date_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        date_layout.addWidget(date_label)
        
        # Date format
        date_row = QHBoxLayout()
        date_row.addWidget(QLabel("Date Format:"))
        
        self.date_format_combo = QComboBox()
        self.date_format_combo.addItems(["YYYY-MM-DD", "MM/DD/YYYY", "DD/MM/YYYY", "DD.MM.YYYY"])
        self.date_format_combo.setCurrentText(DATE_FORMAT)
        self.date_format_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
                min-width: 120px;
            }}
        """)
        date_row.addWidget(self.date_format_combo)
        date_row.addStretch()
        date_layout.addLayout(date_row)
        
        layout.addWidget(date_frame)
        
        # Auto-save settings
        autosave_frame = QFrame()
        autosave_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        autosave_layout = QVBoxLayout(autosave_frame)
        
        autosave_label = QLabel("Auto-Save")
        autosave_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        autosave_layout.addWidget(autosave_label)
        
        self.autosave_checkbox = QCheckBox("Enable auto-save")
        self.autosave_checkbox.setChecked(True)
        self.autosave_checkbox.setStyleSheet(f"""
            QCheckBox {{
                color: {COLORS['text_primary']};
                font-size: 14px;
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 2px solid {COLORS['border']};
                border-radius: 4px;
                background-color: {COLORS['surface']};
            }}
            QCheckBox::indicator:checked {{
                background-color: {COLORS['primary']};
                border-color: {COLORS['primary']};
            }}
        """)
        autosave_layout.addWidget(self.autosave_checkbox)
        
        # Auto-save interval
        interval_row = QHBoxLayout()
        interval_row.addWidget(QLabel("Interval (seconds):"))
        
        self.interval_spinbox = QSpinBox()
        self.interval_spinbox.setRange(60, 3600)
        self.interval_spinbox.setValue(300)
        self.interval_spinbox.setStyleSheet(f"""
            QSpinBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
                min-width: 80px;
            }}
        """)
        interval_row.addWidget(self.interval_spinbox)
        interval_row.addStretch()
        autosave_layout.addLayout(interval_row)
        
        layout.addWidget(autosave_frame)
        layout.addStretch()
        
        self.tab_widget.addTab(general_widget, "General")
    
    def create_appearance_tab(self):
        """Create appearance settings tab."""
        appearance_widget = QWidget()
        layout = QVBoxLayout(appearance_widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Theme settings
        theme_frame = QFrame()
        theme_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        theme_layout = QVBoxLayout(theme_frame)
        
        theme_label = QLabel("Theme")
        theme_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        theme_layout.addWidget(theme_label)
        
        # Theme selection
        theme_row = QHBoxLayout()
        theme_row.addWidget(QLabel("Application Theme:"))
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Dark", "Light", "System"])
        self.theme_combo.setCurrentText("Dark")
        self.theme_combo.setStyleSheet(f"""
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
                min-width: 120px;
            }}
        """)
        theme_row.addWidget(self.theme_combo)
        theme_row.addStretch()
        theme_layout.addLayout(theme_row)
        
        # Font settings
        font_row = QHBoxLayout()
        font_row.addWidget(QLabel("Font Size:"))
        
        self.font_spinbox = QSpinBox()
        self.font_spinbox.setRange(8, 24)
        self.font_spinbox.setValue(10)
        self.font_spinbox.setStyleSheet(f"""
            QSpinBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px;
                border-radius: 4px;
                min-width: 80px;
            }}
        """)
        font_row.addWidget(self.font_spinbox)
        font_row.addStretch()
        theme_layout.addLayout(font_row)
        
        layout.addWidget(theme_frame)
        layout.addStretch()
        
        self.tab_widget.addTab(appearance_widget, "Appearance")
    
    def create_database_tab(self):
        """Create database settings tab."""
        database_widget = QWidget()
        layout = QVBoxLayout(database_widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Database info
        info_frame = QFrame()
        info_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        info_layout = QVBoxLayout(info_frame)
        
        info_label = QLabel("Database Information")
        info_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        info_layout.addWidget(info_label)
        
        info_text = QLabel("Database Location: accounting.db\nLast Backup: Never\nDatabase Size: 0 KB")
        info_text.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-size: 12px;
                padding: 10px;
                background-color: {COLORS['surface']};
                border-radius: 4px;
            }}
        """)
        info_layout.addWidget(info_text)
        
        layout.addWidget(info_frame)
        
        # Backup settings
        backup_frame = QFrame()
        backup_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        backup_layout = QVBoxLayout(backup_frame)
        
        backup_label = QLabel("Backup Settings")
        backup_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        backup_layout.addWidget(backup_label)
        
        # Auto backup
        self.autobackup_checkbox = QCheckBox("Enable automatic backups")
        self.autobackup_checkbox.setStyleSheet(f"""
            QCheckBox {{
                color: {COLORS['text_primary']};
                font-size: 14px;
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 2px solid {COLORS['border']};
                border-radius: 4px;
                background-color: {COLORS['surface']};
            }}
            QCheckBox::indicator:checked {{
                background-color: {COLORS['primary']};
                border-color: {COLORS['primary']};
            }}
        """)
        backup_layout.addWidget(self.autobackup_checkbox)
        
        # Backup buttons
        backup_buttons = QHBoxLayout()
        
        backup_now_btn = QPushButton("Backup Now")
        backup_now_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['success']};
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }}
        """)
        backup_buttons.addWidget(backup_now_btn)
        
        restore_btn = QPushButton("Restore")
        restore_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['warning']};
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }}
        """)
        backup_buttons.addWidget(restore_btn)
        
        backup_buttons.addStretch()
        backup_layout.addLayout(backup_buttons)
        
        layout.addWidget(backup_frame)
        layout.addStretch()
        
        self.tab_widget.addTab(database_widget, "Database")
    
    def create_advanced_tab(self):
        """Create advanced settings tab."""
        advanced_widget = QWidget()
        layout = QVBoxLayout(advanced_widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Advanced options
        advanced_frame = QFrame()
        advanced_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['card']};
                border-radius: 6px;
                padding: 15px;
            }}
        """)
        advanced_layout = QVBoxLayout(advanced_frame)
        
        advanced_label = QLabel("Advanced Options")
        advanced_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }}
        """)
        advanced_layout.addWidget(advanced_label)
        
        # Debug mode
        self.debug_checkbox = QCheckBox("Enable debug mode")
        self.debug_checkbox.setStyleSheet(f"""
            QCheckBox {{
                color: {COLORS['text_primary']};
                font-size: 14px;
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 2px solid {COLORS['border']};
                border-radius: 4px;
                background-color: {COLORS['surface']};
            }}
            QCheckBox::indicator:checked {{
                background-color: {COLORS['primary']};
                border-color: {COLORS['primary']};
            }}
        """)
        advanced_layout.addWidget(self.debug_checkbox)
        
        # Confirmations
        self.confirm_delete_checkbox = QCheckBox("Confirm before deleting transactions")
        self.confirm_delete_checkbox.setChecked(True)
        self.confirm_delete_checkbox.setStyleSheet(f"""
            QCheckBox {{
                color: {COLORS['text_primary']};
                font-size: 14px;
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border: 2px solid {COLORS['border']};
                border-radius: 4px;
                background-color: {COLORS['surface']};
            }}
            QCheckBox::indicator:checked {{
                background-color: {COLORS['primary']};
                border-color: {COLORS['primary']};
            }}
        """)
        advanced_layout.addWidget(self.confirm_delete_checkbox)
        
        layout.addWidget(advanced_frame)
        layout.addStretch()
        
        self.tab_widget.addTab(advanced_widget, "Advanced")
