"""
Purchase Entry widget for the Accounting Desktop Application.
Manages purchase invoice creation with compact desktop layout.
Modular architecture following Sales Entry pattern.
"""

from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QDate, QEvent, QTimer, Signal
from PySide6.QtGui import QDoubleValidator

from config import active_company_manager
from db import Database
from logic.party_logic import PartyLogic
from logic.product_logic import ProductLogic
from logic.party_balance_engine import PartyBalanceEngine
from .purchase_entry_ui import PurchaseEntryUIMixin
from .purchase_entry_helpers import safe_item_text, safe_float_from_cell, ensure_row_items_initialized
from .purchase_entry_delegate import PurchaseBillDelegate, COL_QTY
from .theme import GST_STATE_CODES
from .purchase_entry_calculations import recalculate_row as _recalculate_row, calculate_totals as _calculate_totals
from .purchase_entry_popup import setup_creditor_completer
from . import theme


class PurchaseEntryWidget(PurchaseEntryUIMixin, QWidget):
    window_closed = Signal()

    def __init__(self, parent=None, db=None):
        super().__init__(parent)
        self.db = db or Database()
        self.product_logic = ProductLogic(self.db)
        self.party_logic = PartyLogic(self.db)
        self.balance_engine = PartyBalanceEngine(self.db)
        self.purchase_logic = None  # Lazy load purchase_logic when needed

        self.purchase_items = []
        self.selected_creditor_id = None
        self._party_fields_locked = False
        self.gst_state_codes = GST_STATE_CODES
        self._editing_creditor = False  # Track if we're editing creditor
        self._creditor_refresh_pending = False  # Track if creditor refresh is pending
        self.manually_selected_row = -1  # Track row manually selected by mouse for rewrite
        self.is_local_tax = True
        self._product_selection_in_progress = False
        self._product_search_selection_committed = False
        self.products_data = []
        self.product_count = 0
        self._large_product_mode = False
        # Fast lookup caches for small/medium datasets
        self.products_dict = {}  # by id
        self.products_by_barcode = {}  # by barcode
        self.products_by_name_exact = {}  # by exact name
        self.creditors_data = []  # Initialize creditors_data
        self._row_discount_total = 0.0
        self._creditor_selection_in_progress = False  # Flag to prevent unlocking during selection
        self._product_entry_context = None  # Track context when opening Product Entry: {'mode': 'new'|'edit', 'row': int, 'product_id': int|None}
        self._creditor_refresh_timer = None  # Timer for periodic creditor refresh
        self._last_creditor_refresh_time = 0  # Track last refresh time to avoid too frequent refreshes
        self._amt_paid_user_edited = False  # Track if user manually edited amount paid
        self._updating_amt_paid_programmatically = False  # Guard against recursive updates

        self.setup_ui()
        self.load_creditors()
        self.load_products()
        self.clear_form()
        self._wire_signals()

    def _get_purchase_logic(self):
        """Lazy load purchase_logic."""
        if self.purchase_logic is None:
            from logic.purchase_logic import PurchaseLogic
            self.purchase_logic = PurchaseLogic(self.db)
        return self.purchase_logic

    def showEvent(self, event):
        """Handle show event - refresh creditor if returning from edit."""
        super().showEvent(event)
        # Always refresh creditors list and completer to ensure live updates
        import time
        current_time = time.time()
        # Refresh if: pending flag set OR more than 2 seconds have passed
        if self._creditor_refresh_pending or current_time - self._last_creditor_refresh_time > 2.0:
            self._creditor_refresh_pending = False
            self.load_creditors()
            self._last_creditor_refresh_time = current_time

    def changeEvent(self, event):
        """Handle change event - detect window activation."""
        super().changeEvent(event)
        # If window becomes active, always refresh creditors to get latest data
        if event.type() == QEvent.ActivationChange and self.isActiveWindow():
            import time
            current_time = time.time()
            # Only refresh if more than 1 second has passed since last refresh (avoid too frequent refreshes)
            if current_time - self._last_creditor_refresh_time > 1.0:
                self.load_creditors()
                self._last_creditor_refresh_time = current_time

    def _delayed_creditor_refresh(self):
        """Delayed refresh of creditor to ensure UI is ready."""
        if self._editing_creditor and self.selected_creditor_id:
            self.refresh_selected_creditor_from_db()
            self._editing_creditor = False
        elif self._editing_creditor:
            # If editing but no creditor selected, just reload creditors list
            self.load_creditors()
            self._editing_creditor = False

    def _start_creditor_refresh_timer(self):
        """Start a timer to periodically refresh creditors list after editing."""
        # Stop any existing timer
        if self._creditor_refresh_timer:
            self._creditor_refresh_timer.stop()
            self._creditor_refresh_timer.deleteLater()

        # Create new timer that checks every 1 second for up to 10 seconds
        self._creditor_refresh_timer = QTimer(self)
        self._creditor_refresh_timer.setInterval(1000)  # 1 second
        self._creditor_refresh_timer.timeout.connect(self._check_and_refresh_creditors)
        self._creditor_refresh_count = 0
        self._creditor_refresh_timer.start()

    def _check_and_refresh_creditors(self):
        """Check if we should refresh creditors and stop timer after 10 checks."""
        self._creditor_refresh_count += 1

        # Refresh creditors list
        self.load_creditors()

        # Stop timer after 10 checks (10 seconds)
        if self._creditor_refresh_count >= 10:
            if self._creditor_refresh_timer:
                self._creditor_refresh_timer.stop()
                self._creditor_refresh_timer = None
            self._editing_creditor = False

    def _wire_signals(self):
        """Wire up all signal connections once only."""
        if getattr(self, "_signals_wired", False):
            return
        self._signals_wired = True

        # Table signals
        self.items_table.cellChanged.connect(self.on_table_cell_changed)
        self.items_table.itemSelectionChanged.connect(self.on_table_selection_changed)

        # Nature combo signal
        self.nature_combo.currentTextChanged.connect(self.on_nature_changed)

        # Purchase type combo signal
        self.purchase_type_combo.currentTextChanged.connect(self.on_purchase_type_changed)

        # Barcode input
        self.barcode_input.returnPressed.connect(self.on_barcode_enter)

        # Product input
        self.product_input.returnPressed.connect(self.on_product_enter)

        # Purchase number checkbox
        self.purchase_checkbox.toggled.connect(self.on_purchase_checkbox_toggled)

        # Footer input signals for live calculations
        if hasattr(self, 'round_off_input'):
            self.round_off_input.textChanged.connect(self.on_footer_discount_changed)
        if hasattr(self, 'purchase_expense_input'):
            self.purchase_expense_input.textChanged.connect(self.on_purchase_expense_changed)
        if hasattr(self, 'amt_paid_input'):
            self.amt_paid_input.editingFinished.connect(self.on_amt_paid_edited)

        # Install event filters for keyboard/mouse flow
        self.items_table.installEventFilter(self)
        self.items_table.viewport().installEventFilter(self)

        # Setup creditor completer
        setup_creditor_completer(self.creditor_name_input, self, self.on_creditor_selected)

        # Setup product completer (always, even for large DB mode with lazy search)
        from .purchase_entry_popup import setup_product_completer
        setup_product_completer(self.product_input, self, None, self.on_product_selected)

        # Text field signal handlers for title case formatting
        self.creditor_name_input.textChanged.connect(self.on_creditor_name_changed)
        self.creditor_name_input.editingFinished.connect(self.on_creditor_editing_finished)
        self.creditor_name_input.mousePressEvent = self._on_creditor_mouse_press
        self.creditor_name_input.focusInEvent = self._on_creditor_focus_in
        self.address_input.textChanged.connect(self.on_address_changed)
        self.narration_input.textChanged.connect(self.on_narration_changed)

        # Install event filters for locked party fields and top-field select-all
        for widget in (
            self.creditor_name_input,
            self.address_input,
            self.mobile_input,
            self.gstin_input,
            self.state_combo,
            self.narration_input,
            self.barcode_input,
            self.product_input,
        ):
            widget.installEventFilter(self)

    def setup_ui(self):
        """Build the Purchase Entry UI."""
        layout = QVBoxLayout(self)
        layout.setSpacing(4)
        layout.setContentsMargins(4, 4, 4, 4)

        # ZONE A - Page Header Strip
        layout.addWidget(self.build_page_header_strip())

        # ZONE B - Top Purchase Command Strip
        layout.addWidget(self.build_purchase_command_strip())

        # ZONE C - Creditor / Supplier Information Matrix
        layout.addWidget(self.build_creditor_information_matrix())

        # ZONE D - Product Entry Strip
        layout.addWidget(self.build_product_entry_strip())

        # ZONE E - Bill Options / Live Status Strip
        layout.addWidget(self.build_bill_options_strip())

        # ZONE F - Main Billing Table Zone
        layout.addWidget(self.build_billing_table_zone())

        # ZONE G + H - Lower Control Panel with Totals
        layout.addWidget(self.build_lower_control_panel())

        # Install delegate on table
        self.items_table.setItemDelegate(PurchaseBillDelegate(self))

        # Install event filter on table viewport for SL No click handling
        self.items_table.viewport().installEventFilter(self)

        # Initialize table with blank rows
        for _ in range(10):
            self.add_blank_row()

    def load_creditors(self):
        """Load creditors from database - handle dict or list return, case-insensitive filtering."""
        active_company = active_company_manager.get_active_company()
        if active_company:
            result = self.party_logic.get_parties(active_company['id'])
            # Handle both dict result format and direct list format
            if isinstance(result, dict) and 'data' in result:
                all_parties = result['data']
            elif isinstance(result, list):
                all_parties = result
            else:
                all_parties = []

            # Filter for Creditor/Both case-insensitively, handle missing party_type
            self.creditors_data = []
            for party in all_parties:
                if not isinstance(party, dict):
                    continue
                party_type = party.get('party_type', '')
                if party_type and isinstance(party_type, str):
                    if party_type.lower() in ['creditor', 'both']:
                        self.creditors_data.append(party)
                # If party_type is missing or empty, include it (backward compatibility)
                elif not party_type:
                    self.creditors_data.append(party)

            # Refresh creditor completer after loading creditors
            from .purchase_entry_popup import setup_creditor_completer
            setup_creditor_completer(self.creditor_name_input, self, self.on_creditor_selected)

            # Update last refresh time
            import time
            self._last_creditor_refresh_time = time.time()

    def load_products(self):
        """Load products from database - only for small datasets."""
        active_company = active_company_manager.get_active_company()
        if active_company:
            # First get product count (lightweight query)
            count_result = self.product_logic.get_product_count(active_company['id'])
            product_count = count_result.get('data', 0) if isinstance(count_result, dict) else 0
            self.product_count = product_count
            self._large_product_mode = product_count >= 1000

            # Only preload if small dataset (< 1000)
            if product_count < 1000:
                result = self.product_logic.get_products(active_company['id'])
                # Handle both dict result format and direct list format
                if isinstance(result, dict) and 'data' in result:
                    products = result['data']
                elif isinstance(result, list):
                    products = result
                else:
                    products = []

                self.products_data = products
                # Build fast lookup caches
                self.products_dict = {}
                self.products_by_barcode = {}
                self.products_by_name_exact = {}
                for product in products:
                    if product.get('id'):
                        self.products_dict[product['id']] = product
                    if product.get('barcode'):
                        self.products_by_barcode[product['barcode']] = product
                    if product.get('name'):
                        self.products_by_name_exact[product['name']] = product
            else:
                # For large datasets (>= 1000), don't preload - use DB-backed search
                self.products_data = []
                self.products_dict = {}
                self.products_by_barcode = {}
                self.products_by_name_exact = {}

    def update_affected_products_stock(self, affected_product_ids):
        """Update stock quantities only for affected products after a purchase.

        Uses batch query to get all balances in a single database call.
        """
        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            # Filter out None values and convert to list
            product_ids = [pid for pid in affected_product_ids if pid]
            if not product_ids:
                return

            # Get all balances in a single query (much faster than individual queries)
            balances = self.db.get_stock_balances_for_products(
                active_company['id'], product_ids
            )

            # Update local cache with new balances
            for product_id, new_stock in balances.items():
                if product_id in self.products_dict:
                    self.products_dict[product_id]['quantity'] = new_stock
                for p in self.products_data:
                    if p.get('id') == product_id:
                        p['quantity'] = new_stock
                        break
        except Exception as e:
            print(f"Failed to update affected products stock: {e}")

    def on_nature_changed(self, text):
        """Apply Indian GST purchase nature rules live for all product rows.

        Local: use product CGST + SGST, IGST must be 0.
        Inter-state: use product IGST, CGST and SGST must be 0.
        CESS is preserved in both cases.
        """
        self.is_local_tax = "inter" not in str(text).strip().lower()

        for row in range(self.items_table.rowCount()):
            if row >= len(self.purchase_items):
                continue
            item_data = self.purchase_items[row]
            if not item_data.get('product_id'):
                continue
            product = self._get_product_for_row(row)
            self._apply_nature_tax_to_row(row, product)
            self.recalculate_row(row)

        self.calculate_totals()

    def on_purchase_type_changed(self, text):
        """Handle purchase type combo change (Cash/Credit)."""
        # Reset user edited flag when type changes
        self._amt_paid_user_edited = False
        # Apply payment mode based on new type
        self.apply_purchase_payment_mode()

    def generate_purchase_number(self):
        """Auto-generate purchase number based on series."""
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return
        
        if self.purchase_checkbox.isChecked():
            # Use manual purchase number
            return
        
        series = self.series_input.text()
        next_number = self.db.get_next_purchase_number(active_company['id'], series)
        self.purchase_no_input.setText(next_number)

    def on_purchase_checkbox_toggled(self, checked):
        """Handle purchase number checkbox toggle."""
        if checked:
            # Allow manual entry
            self.purchase_no_input.setPlaceholderText("")
        else:
            # Auto-generate
            self.purchase_no_input.setPlaceholderText("Auto")
            self.generate_purchase_number()

    def on_barcode_enter(self):
        """Handle barcode input Enter key."""
        barcode = self.barcode_input.text().strip()
        if not barcode:
            # If barcode is blank, focus product input field
            self.product_input.setFocus()
            return

        # Find product by barcode using DB lookup (not loop through products_data)
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return

        product = None
        # Try exact barcode match from DB first (indexed lookup)
        result = self.product_logic.get_product_by_barcode(active_company['id'], barcode)
        if result and result.get('success') and result.get('data'):
            product = result['data']
        else:
            # Fallback to products_data if small dataset
            if self.products_data:
                for p in self.products_data:
                    if str(p.get('barcode')) == barcode:
                        product = p
                        break

        if product:
            # Add product and get the row index, then focus Qty for direct typing
            added_row = self._add_product_to_table_with_row(product, default_qty=0)
            if added_row >= 0:
                self.barcode_input.clear()
                self.calculate_totals()
                self.focus_table_cell_editor(added_row, COL_QTY)
        else:
            QMessageBox.warning(self, "Product Not Found", f"No product found with barcode: {barcode}")
            self.barcode_input.clear()

    def focus_table_cell_editor(self, row, col):
        """Focus table cell editor and select all text with a single mouse click."""
        if row < 0 or col < 0:
            return
        ensure_row_items_initialized(self.items_table, row)
        item = self.items_table.item(row, col)
        if not item:
            return

        self.manually_selected_row = -1
        self.items_table.clearSelection()
        self.items_table.setCurrentCell(row, col)
        self.items_table.scrollToItem(item)
        self.items_table.setFocus(Qt.MouseFocusReason)
        self.items_table.editItem(item)

        QTimer.singleShot(0, self._select_current_editor)
        QTimer.singleShot(50, self._select_current_editor)
        QTimer.singleShot(120, self._select_current_editor)

    def _select_current_editor(self):
        """Select all text in the current table editor."""
        editor = self.items_table.focusWidget()
        if editor and isinstance(editor, QLineEdit):
            editor.setFocus(Qt.MouseFocusReason)
            editor.selectAll()

    def _select_disc_field_text(self, row, col):
        """Select all text in the Disc field editor with proper focus."""
        item = self.items_table.item(row, col)
        if item:
            self.items_table.setCurrentCell(row, col)
            self.items_table.scrollToItem(item)
            # Open editor
            self.items_table.editItem(item)
            # Select all text in editor after it opens
            QTimer.singleShot(0, self._select_current_editor)

    def _activate_and_focus_disc(self, row):
        """Activate window and focus Disc field."""
        # Force window to be active
        self.show()
        self.raise_()
        self.activateWindow()
        self.setFocus()
        # Use longer delay to ensure window is fully activated before focusing Disc field
        QTimer.singleShot(200, lambda: self._focus_disc_after_activation(row))

    def _focus_disc_after_activation(self, row):
        """Focus Disc field after window activation."""
        # Ensure window is still active
        self.raise_()
        self.activateWindow()
        # Focus the table first
        self.items_table.setFocus()
        # Move to Disc field and select all with proper focus using delegate
        from .purchase_entry_delegate import PurchaseBillDelegate, COL_DISC
        delegate = self.items_table.itemDelegate()
        if hasattr(delegate, 'move_to_cell_and_select_all'):
            delegate.move_to_cell_and_select_all(row, COL_DISC)

    def _force_disc_focus_with_editor(self, row):
        """Force Disc field focus with editor open."""
        from PySide6.QtWidgets import QApplication
        # Force window to be active using QApplication
        QApplication.instance().setActiveWindow(self)
        self.show()
        self.raise_()
        self.activateWindow()
        self.setFocus()
        # Use delay to ensure window is fully activated
        QTimer.singleShot(300, lambda: self._open_disc_editor(row))

    def _open_disc_editor(self, row):
        """Open Disc field editor."""
        from .purchase_entry_delegate import PurchaseBillDelegate, COL_DISC
        # Ensure window is still active
        self.raise_()
        self.activateWindow()
        # Focus table
        self.items_table.setFocus()
        # Set current cell
        self.items_table.setCurrentCell(row, COL_DISC)
        item = self.items_table.item(row, COL_DISC)
        if item:
            self.items_table.scrollToItem(item)
            # Open editor
            self.items_table.editItem(item)

    def _simulate_disc_click(self, row):
        """Simulate mouse click on Disc field to force editor focus."""
        from .purchase_entry_delegate import PurchaseBillDelegate, COL_DISC
        from PySide6.QtCore import Qt, QPoint
        from PySide6.QtGui import QMouseEvent
        from PySide6.QtWidgets import QApplication
        
        # Temporarily set window to always on top to force it to foreground
        original_flags = self.windowFlags()
        self.setWindowFlags(original_flags | Qt.WindowStaysOnTopHint)
        self.show()
        
        # Force window to be active using multiple methods
        self.showNormal()
        self.raise_()
        self.activateWindow()
        QApplication.instance().setActiveWindow(self)
        self.setFocus()
        
        # Set current cell
        self.items_table.setCurrentCell(row, COL_DISC)
        item = self.items_table.item(row, COL_DISC)
        if item:
            self.items_table.scrollToItem(item)
            # Get cell rect
            rect = self.items_table.visualItemRect(item)
            # Calculate center of cell
            center = rect.center()
            # Create mouse press event
            press_event = QMouseEvent(
                QMouseEvent.MouseButtonPress,
                center,
                Qt.LeftButton,
                Qt.LeftButton,
                Qt.NoModifier
            )
            # Create mouse release event
            release_event = QMouseEvent(
                QMouseEvent.MouseButtonRelease,
                center,
                Qt.LeftButton,
                Qt.LeftButton,
                Qt.NoModifier
            )
            # Send events to table viewport
            QApplication.postEvent(self.items_table.viewport(), press_event)
            QApplication.postEvent(self.items_table.viewport(), release_event)
            # Force focus after click with longer delay
            QTimer.singleShot(100, lambda: self._force_disc_focus_after_click(row, original_flags))

    def _force_disc_focus_after_click(self, row, original_flags):
        """Force Disc field focus after simulated click."""
        from .purchase_entry_delegate import PurchaseBillDelegate, COL_DISC
        from PySide6.QtCore import Qt
        
        # Restore original window flags
        self.setWindowFlags(original_flags)
        self.show()
        
        # Ensure window is still active
        self.raise_()
        self.activateWindow()
        # Ensure table has focus
        self.items_table.setFocus()
        # Try to open editor again
        item = self.items_table.item(row, COL_DISC)
        if item:
            self.items_table.editItem(item)
            # Force editor focus with longer delay
            QTimer.singleShot(100, self._force_editor_focus_simple)

    def _force_editor_focus_simple(self):
        """Force editor focus with simple approach."""
        from PySide6.QtWidgets import QApplication
        # Ensure window is still active
        self.activateWindow()
        self.raise_()
        editor = self.items_table.focusWidget()
        if editor and isinstance(editor, QLineEdit):
            editor.setFocus()
            editor.selectAll()
            # Force keyboard focus
            QApplication.instance().focusWidget()

    def _focus_and_select_qty(self, row):
        """Focus Qty field and select all text."""
        self.focus_table_cell_editor(row, 8)

    def open_product_entry_edit_from_row(self, row, product_id):
        """Open Product Entry in edit mode for the specified product."""
        try:
            from PySide6.QtWidgets import QApplication

            # Step 1: Try direct parent window
            main_window = self.window()
            if main_window and hasattr(main_window, 'show_products'):
                main_window.show_products()
                # Find the products widget and load the product in edit mode
                for widget in QApplication.topLevelWidgets():
                    from .products import ProductsWidget
                    products_widget = widget.findChild(ProductsWidget)
                    if products_widget and hasattr(products_widget, 'open_for_edit_from_purchase'):
                        products_widget.open_for_edit_from_purchase(product_id, self, row)
                        break
                return

            # Step 2: Search all top-level widgets for MainWindow with show_products
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'show_products'):
                    widget.show_products()
                    widget.raise_()
                    widget.activateWindow()
                    # Find the products widget and load the product in edit mode
                    for top_widget in QApplication.topLevelWidgets():
                        from .products import ProductsWidget
                        products_widget = top_widget.findChild(ProductsWidget)
                        if products_widget and hasattr(products_widget, 'open_for_edit_from_purchase'):
                            products_widget.open_for_edit_from_purchase(product_id, self, row)
                            break
                    return

            # Step 3: Fallback to stack_widget + products_widget pattern
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'stack_widget') and hasattr(widget, 'products_widget'):
                    if hasattr(widget.products_widget, 'open_for_edit_from_purchase'):
                        widget.products_widget.open_for_edit_from_purchase(product_id, self, row)
                    widget.stack_widget.setCurrentWidget(widget.products_widget)
                    widget.raise_()
                    widget.activateWindow()
                    return
        except Exception as e:
            QMessageBox.warning(self, "Navigation Error", f"Could not open Product Entry: {e}")

    def open_product_entry_new_from_row(self, row):
        """Open Product Entry in new mode for adding a new product."""
        try:
            from PySide6.QtWidgets import QApplication

            # Step 1: Try direct parent window
            main_window = self.window()
            if main_window and hasattr(main_window, 'show_products'):
                main_window.show_products()
                # Find the products widget and open in new mode from Purchase Entry
                for widget in QApplication.topLevelWidgets():
                    from .products import ProductsWidget
                    products_widget = widget.findChild(ProductsWidget)
                    if products_widget and hasattr(products_widget, 'open_for_new_from_purchase'):
                        products_widget.open_for_new_from_purchase(self, row)
                        break
                return

            # Step 2: Search all top-level widgets for MainWindow with show_products
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'show_products'):
                    widget.show_products()
                    widget.raise_()
                    widget.activateWindow()
                    # Find the products widget and open in new mode from Purchase Entry
                    for top_widget in QApplication.topLevelWidgets():
                        from .products import ProductsWidget
                        products_widget = top_widget.findChild(ProductsWidget)
                        if products_widget and hasattr(products_widget, 'open_for_new_from_purchase'):
                            products_widget.open_for_new_from_purchase(self, row)
                            break
                    return

            # Step 3: Fallback to stack_widget + products_widget pattern
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'stack_widget') and hasattr(widget, 'products_widget'):
                    if hasattr(widget.products_widget, 'open_for_new_from_purchase'):
                        widget.products_widget.open_for_new_from_purchase(self, row)
                    widget.stack_widget.setCurrentWidget(widget.products_widget)
                    widget.raise_()
                    widget.activateWindow()
                    return
        except Exception as e:
            QMessageBox.warning(self, "Navigation Error", f"Could not open Product Entry: {e}")

    def receive_product_from_product_page(self, product, qty, row):
        """Receive product data from Product Entry page and populate table row."""
        try:
            table = self.items_table

            # Convert qty to float
            qty_value = 0.0
            if qty:
                try:
                    qty_value = float(qty) if qty else 0.0
                except (ValueError, TypeError):
                    qty_value = 0.0

            # Populate row with product data
            # Sales Rate (read-only display)
            sales_rate = float(product.get('sale_price', 0) or product.get('sales_rate', 0) or 0)
            sr_item = table.item(row, 1)  # COL_SALES_RATE
            if sr_item:
                sr_item.setText(f"{sales_rate:.2f}")

            # Product name
            product_item = table.item(row, 2)  # COL_PRODUCT
            if product_item:
                product_item.setText(product.get('name', ''))

            # HSN
            hsn_item = table.item(row, 3)  # COL_HSN
            if hsn_item:
                hsn_item.setText(product.get('hsn', ''))

            # Rate (purchase rate)
            rate_item = table.item(row, 8)  # COL_RATE
            if rate_item:
                rate_item.setText(str(product.get('purchase_rate', 0)))

            # Qty (set from Product page qty)
            qty_item = table.item(row, 9)  # COL_QTY
            if qty_item:
                qty_item.setText(str(qty_value))

            # Update purchase_items base data
            if row < len(self.purchase_items):
                self.purchase_items[row]['product_id'] = product.get('id')
                self.purchase_items[row]['name'] = product.get('name', '')
                self.purchase_items[row]['hsn'] = product.get('hsn', '')
                self.purchase_items[row]['hsn_code'] = product.get('hsn', '')
                # Store raw source GST values from product (before nature filter)
                self.purchase_items[row]['source_cgst'] = float(product.get('cgst', 0) or 0)
                self.purchase_items[row]['source_sgst'] = float(product.get('sgst', 0) or 0)
                self.purchase_items[row]['source_igst'] = float(product.get('igst', 0) or 0)
                self.purchase_items[row]['source_cess'] = float(product.get('cess', 0) or 0)
                self.purchase_items[row]['rate'] = float(product.get('purchase_rate', 0) or 0)
                self.purchase_items[row]['quantity'] = qty_value

            # Refresh products_dict with latest product data so on_nature_changed uses fresh values
            product_id = product.get('id')
            if product_id:
                self.products_dict[product_id] = product
                for i, p in enumerate(self.products_data):
                    if p.get('id') == product_id:
                        self.products_data[i] = product
                        break

            # Apply tax based on current nature (Local/Inter-state)
            self._apply_nature_tax_to_row(row, product)

            # Recalculate row totals
            from .purchase_entry_delegate import COL_QTY
            self.recalculate_row(row, source_column=COL_QTY, live_value=qty_value)

            # Recalculate footer totals
            self.calculate_totals()
            self.apply_purchase_payment_mode()

            self._product_entry_context = None
            if qty_value > 0:
                from .purchase_entry_delegate import COL_DISC
                delegate = self.items_table.itemDelegate()
                if hasattr(delegate, 'move_to_cell_and_select_all'):
                    delegate.move_to_cell_and_select_all(row, COL_DISC)
                else:
                    self.focus_table_cell_editor(row, COL_DISC)
            else:
                self.focus_table_cell_editor(row, 9)

        except Exception as e:
            print(f"Error receiving product from product page: {e}")
            QMessageBox.warning(self, "Error", f"Failed to load product into purchase table: {e}")

    def _add_product_to_table_with_row(self, product, custom_rate=None, default_qty=0):
        """Add product to table and return the row index."""
        blank_row = -1
        for row in range(self.items_table.rowCount()):
            prod_name = self.safe_item_text(row, 2)
            if not prod_name:
                blank_row = row
                break

        if blank_row == -1:
            blank_row = self.add_blank_row()

        ensure_row_items_initialized(self.items_table, blank_row)

        rate = custom_rate if custom_rate is not None else product.get('purchase_rate', 0)
        try:
            rate = float(rate or 0)
        except (TypeError, ValueError):
            rate = 0.0
        try:
            qty_value = float(default_qty or 0)
        except (TypeError, ValueError):
            qty_value = 0.0

        was_blocked = self.items_table.blockSignals(True)
        try:
            # Set product name, HSN, Rate (tax applied separately via nature helper)
            sales_rate = float(product.get('sale_price', 0) or product.get('sales_rate', 0) or 0)
            values = {
                1: f"{sales_rate:.2f}",
                2: product.get('name', ''),
                3: product.get('hsn', ''),
                8: f"{rate:.2f}",
                9: "" if qty_value == 0 else f"{qty_value:.2f}",
            }
            for col, text in values.items():
                item = self.items_table.item(blank_row, col)
                if item:
                    item.setText(str(text))

            self.purchase_items[blank_row] = {
                'product_id': product.get('id'),
                'name': product.get('name', ''),
                'hsn': product.get('hsn', ''),
                'hsn_code': product.get('hsn', ''),
                'source_cgst': float(product.get('cgst', 0) or 0),
                'source_sgst': float(product.get('sgst', 0) or 0),
                'source_igst': float(product.get('igst', 0) or 0),
                'source_cess': float(product.get('cess', 0) or 0),
                'cgst': 0,
                'sgst': 0,
                'igst': 0,
                'cess': 0,
                'rate': rate,
                'tax_percent': 0,
                'quantity': qty_value,
            }
        finally:
            self.items_table.blockSignals(was_blocked)

        # Ensure products_dict has this product (may be new or updated)
        pid = product.get('id')
        if pid:
            self.products_dict[pid] = product

        # Apply tax based on current nature (Local/Inter-state)
        self._apply_nature_tax_to_row(blank_row, product)

        self.recalculate_row(blank_row, source_column=9, live_value=qty_value)
        self.calculate_totals()
        self.apply_purchase_payment_mode()
        return blank_row

    def on_product_enter(self):
        """Handle product input Enter key - add product to table."""
        # Guard: popup selection already committed the product via on_product_selected
        if self._product_search_selection_committed:
            self._product_search_selection_committed = False
            return

        product_name = self.product_input.text().strip()
        if not product_name:
            return

        # Find product by name
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return

        product = None
        # If products_data has preload data (small DB), use it
        if self.products_data:
            for p in self.products_data:
                if p.get('name', '').lower() == product_name.lower():
                    product = p
                    break
        else:
            # For large DB mode, use DB-backed exact name lookup
            result = self.product_logic.get_product_by_exact_name(active_company['id'], product_name)
            if result and result.get('success') and result.get('data'):
                product = result['data']

        if product:
            self.add_product_to_table(product)
            self.product_input.clear()
        else:
            QMessageBox.warning(self, "Product Not Found", f"No product found with name: {product_name}")

    def on_product_selected(self, index, model_idx, editor):
        """Handle product selection from completer popup."""
        # Guard against duplicate calls
        if self._product_selection_in_progress:
            return

        product = model_idx.data(Qt.UserRole)
        if product:
            self._product_selection_in_progress = True
            try:
                added_row = self._add_product_to_table_with_row(product, default_qty=0)
                self.product_input.clear()
                if added_row >= 0:
                    self.focus_table_cell_editor(added_row, 8)
            finally:
                self._product_selection_in_progress = False
                self._product_search_selection_committed = False

    def add_product_to_table(self, product, custom_rate=None):
        """Add product to table at first blank row or new row."""
        return self._add_product_to_table_with_row(product, custom_rate)

    def on_creditor_selected(self, model_idx, editor):
        """Handle creditor selection from completer popup."""
        creditor = model_idx.data(Qt.UserRole)
        if creditor:
            # Set flag to prevent textChanged from unlocking during selection
            self._creditor_selection_in_progress = True

            # Handle both dict and string cases
            if isinstance(creditor, dict):
                # Update creditor fields from dict
                self.creditor_name_input.setText(creditor.get('name', ''))
                self.address_input.setText(creditor.get('address', ''))
                self.mobile_input.setText(creditor.get('mobile_number', ''))
                gstin = creditor.get('gstin', '')
                self.gstin_input.setText(gstin)

                # Store creditor ID
                self.selected_creditor_id = creditor.get('id')

                # Fix State auto-fill
                state = creditor.get('state', '')
                if state:
                    self.state_combo.setCurrentText(state)
                elif gstin and len(gstin) >= 2:
                    # Derive state from GSTIN first two digits
                    state_code = gstin[:2].upper()
                    if state_code in self.gst_state_codes:
                        derived_state = self.gst_state_codes[state_code]
                        self.state_combo.setCurrentText(derived_state)

                # Lock party detail fields after creditor selection
                self._lock_party_fields()
            else:
                # creditor is a string (name only)
                self.creditor_name_input.setText(str(creditor))

            # Reset flag after selection is complete
            self._creditor_selection_in_progress = False

    def _lock_party_fields(self):
        """Lock party detail fields after creditor selection (except name field)."""
        self._party_fields_locked = True
        # Do NOT lock creditor_name_input - keep it searchable
        self.address_input.setReadOnly(True)
        self.mobile_input.setReadOnly(True)
        self.gstin_input.setReadOnly(True)
        self.state_combo.setEnabled(False)

    def _unlock_party_fields(self):
        """Unlock party detail fields for editing or new creditor selection."""
        self._party_fields_locked = False
        self.creditor_name_input.setReadOnly(False)
        self.address_input.setReadOnly(False)
        self.mobile_input.setReadOnly(False)
        self.gstin_input.setReadOnly(False)
        self.state_combo.setEnabled(True)

    def on_edit_creditor_clicked(self):
        """Handle Edit Creditor button click."""
        if not self.selected_creditor_id:
            QMessageBox.warning(self, "No Creditor Selected", "Please select a creditor first.")
            return

        # Set flag to refresh creditor when returning
        self._editing_creditor = True

        # Use reliable navigation pattern to open Debitor/Creditor page in edit mode
        try:
            from PySide6.QtWidgets import QApplication

            # Step 1: Try direct parent window
            main_window = self.window()
            if main_window and hasattr(main_window, 'show_debitor_creditor'):
                main_window.show_debitor_creditor()
                # Find the debitor_creditor widget and load the party in edit mode
                for widget in QApplication.topLevelWidgets():
                    from .debitor_creditor import DebitorCreditorWidget
                    dc_widget = widget.findChild(DebitorCreditorWidget)
                    if dc_widget and hasattr(dc_widget, 'load_party_for_edit'):
                        dc_widget.load_party_for_edit(self.selected_creditor_id)
                        break
                # Start a timer to periodically check and refresh creditors
                self._start_creditor_refresh_timer()
                return

            # Step 2: Search all top-level widgets for MainWindow with show_debitor_creditor
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'show_debitor_creditor'):
                    widget.show_debitor_creditor()
                    widget.raise_()
                    widget.activateWindow()
                    # Find the debitor_creditor widget and load the party in edit mode
                    for top_widget in QApplication.topLevelWidgets():
                        from .debitor_creditor import DebitorCreditorWidget
                        dc_widget = top_widget.findChild(DebitorCreditorWidget)
                        if dc_widget and hasattr(dc_widget, 'load_party_for_edit'):
                            dc_widget.load_party_for_edit(self.selected_creditor_id)
                            break
                    # Start a timer to periodically check and refresh creditors
                    self._start_creditor_refresh_timer()
                    return

            # Step 3: Fallback to stack_widget + debitor_creditor_widget pattern
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'stack_widget') and hasattr(widget, 'debitor_creditor_widget'):
                    if hasattr(widget.debitor_creditor_widget, 'load_party_for_edit'):
                        widget.debitor_creditor_widget.load_party_for_edit(self.selected_creditor_id)
                    widget.stack_widget.setCurrentWidget(widget.debitor_creditor_widget)
                    widget.raise_()
                    widget.activateWindow()
                    # Start a timer to periodically check and refresh creditors
                    self._start_creditor_refresh_timer()
                    return
        except Exception as e:
            QMessageBox.warning(self, "Navigation Error", f"Could not open Debitor/Creditor page: {e}")
            self._editing_creditor = False

    def refresh_selected_creditor_from_db(self):
        """Refresh the selected creditor from database without resetting purchase bill/table."""
        if not self.selected_creditor_id:
            return

        try:
            active_company = active_company_manager.get_active_company()
            if not active_company:
                return

            # Reload creditors list
            self.load_creditors()

            # Refresh creditor completer model with updated data
            from .purchase_entry_popup import setup_creditor_completer
            setup_creditor_completer(self.creditor_name_input, self, self.on_creditor_selected)

            # Fetch the selected creditor from DB
            result = self.party_logic.get_party_by_id(active_company['id'], self.selected_creditor_id)
            if result['success'] and result['data']:
                creditor = result['data']

                # Block signals to prevent triggering textChanged during refresh
                self._creditor_selection_in_progress = True

                # Update visible fields
                self.creditor_name_input.setText(creditor.get('name', ''))
                self.address_input.setText(creditor.get('address', ''))
                self.mobile_input.setText(creditor.get('mobile_number', ''))
                gstin = creditor.get('gstin', '')
                self.gstin_input.setText(gstin)
                state = creditor.get('state', '')
                if state:
                    self.state_combo.setCurrentText(state)
                elif gstin and len(gstin) >= 2:
                    # Derive state from GSTIN if saved state is empty
                    state_code = gstin[:2].upper()
                    if state_code in self.gst_state_codes:
                        derived_state = self.gst_state_codes[state_code]
                        self.state_combo.setCurrentText(derived_state)

                # Reset flag after refresh
                self._creditor_selection_in_progress = False
        except Exception as e:
            print(f"Error refreshing creditor from DB: {e}")
            self._creditor_selection_in_progress = False

    def on_address_changed(self, text):
        """Handle address text change - apply title case formatting."""
        if not text:
            return
        was_blocked = self.address_input.blockSignals(True)
        try:
            self.address_input.setText(text.title())
        finally:
            self.address_input.blockSignals(was_blocked)

    def on_gstin_changed(self, text):
        """Handle GSTIN text change - convert to uppercase and validate."""
        was_blocked = self.gstin_input.blockSignals(True)
        try:
            self.gstin_input.setText(text.upper())

            # Clear state if GSTIN is empty
            if not text or not text.strip():
                self.state_combo.blockSignals(True)
                self.state_combo.setCurrentText("")
                self.state_combo.blockSignals(False)
                return

            # Extract state code from GSTIN (first 2 characters)
            if len(text) >= 2:
                state_code = text[:2].upper()
                # Auto-fill state based on GSTIN code if state is empty
                if not self.state_combo.currentText():
                    state_name = self.get_state_name_from_code(state_code)
                    if state_name:
                        self.state_combo.setCurrentText(state_name)
        finally:
            self.gstin_input.blockSignals(was_blocked)

    def get_state_name_from_code(self, state_code):
        """Get state name from GSTIN state code using shared GST_STATE_CODES."""
        return self.gst_state_codes.get(state_code)

    def on_state_changed(self, text):
        if not text:
            return

        words = text.split(" ")
        capitalized_words = []
        for word in words:
            if word:
                capitalized_words.append(word[:1].upper() + word[1:])
            else:
                capitalized_words.append("")

        new_text = " ".join(capitalized_words)
        if new_text != text:
            cursor_pos = self.state_combo.cursorPosition()
            self.state_combo.blockSignals(True)
            self.state_combo.setText(new_text)
            self.state_combo.setCursorPosition(min(cursor_pos, len(new_text)))
            self.state_combo.blockSignals(False)

    def on_creditor_name_changed(self, text):
        """Handle creditor name text change - apply title case and unlock for new creditor selection."""
        if not text:
            return

        # If party fields are locked and user types in name field, unlock for new creditor selection
        # Skip if creditor selection is in progress (completer is setting text)
        if self._party_fields_locked and self.selected_creditor_id and not self._creditor_selection_in_progress:
            # Unlock party detail fields
            self._unlock_party_fields()
            # Clear selected creditor ID to allow new creditor selection
            self.selected_creditor_id = None
            # Clear detail fields
            self.address_input.clear()
            self.mobile_input.clear()
            self.gstin_input.clear()
            self.state_combo.setCurrentIndex(0)
            # Re-setup completer to ensure it works after unlocking
            from .purchase_entry_popup import setup_creditor_completer
            setup_creditor_completer(self.creditor_name_input, self, self.on_creditor_selected)

        # Apply title case formatting (only if not during creditor selection)
        if not self._creditor_selection_in_progress:
            was_blocked = self.creditor_name_input.blockSignals(True)
            try:
                self.creditor_name_input.setText(text.title())
            finally:
                self.creditor_name_input.blockSignals(was_blocked)

    def on_creditor_editing_finished(self):
        """Handle creditor name editing finished - refresh creditors list to get latest data."""
        # Refresh creditors list and completer to ensure latest data is available
        # Use a small delay to ensure the edit is complete
        QTimer.singleShot(50, self.load_creditors)

    def _on_creditor_mouse_press(self, event):
        """Handle creditor name input mouse press - refresh creditors list to get latest data."""
        # Refresh creditors list when user clicks on creditor name field
        # This ensures latest data after returning from creditor edit
        self.load_creditors()
        # Call the original mousePressEvent
        QLineEdit.mousePressEvent(self.creditor_name_input, event)

    def _on_creditor_focus_in(self, event):
        """Handle creditor name input focus in - refresh creditors list to get latest data."""
        # Refresh creditors list when user focuses on creditor name field
        # This ensures latest data after returning from creditor edit
        self.load_creditors()
        # Call the original focusInEvent
        QLineEdit.focusInEvent(self.creditor_name_input, event)

    def on_narration_changed(self, text):
        """Handle narration text change - apply title case formatting."""
        if not text:
            return
        was_blocked = self.narration_input.blockSignals(True)
        try:
            self.narration_input.setText(text.title())
        finally:
            self.narration_input.blockSignals(was_blocked)


    def on_table_selection_changed(self):
        """Keep Qt selection from forcing full-row blue selection.

        Manual row selection is controlled only by clicking the SL column.
        Normal editable-cell clicks open an editor and must not mark the whole row.
        """
        if getattr(self, "_suppress_table_selection_changed", False):
            return
        self.items_table.clearSelection()
        self.items_table.viewport().update()

    def on_table_cell_changed(self, row, column):
        """Handle table cell change."""
        # Recalculate row when editable cells change (including tax columns)
        # Note: recalculate_row now always calls calculate_totals, so no need to call it here
        if column in [4, 5, 6, 7, 8, 9, 10, 11]:  # CGST, SGST, IGST, CESS, Rate, Qty, Gross, Disc
            self.recalculate_row(row, source_column=column, live_value=self.safe_item_text(row, column))

    def add_blank_row(self):
        """Add a blank row to the table and return its row index."""
        row = self.items_table.rowCount()
        self.items_table.insertRow(row)

        # Initialize row items with empty strings (not zeros)
        for col in range(15):  # 0-14 columns
            item = QTableWidgetItem("")
            self.items_table.setItem(row, col, item)

        # Initialize purchase_items for this row with default tax values (only once)
        self.purchase_items.append({
            'product_id': None,
            'name': '',
            'hsn': '',
            'hsn_code': '',
            'source_cgst': 0,
            'source_sgst': 0,
            'source_igst': 0,
            'source_cess': 0,
            'cgst': 0,
            'sgst': 0,
            'igst': 0,
            'cess': 0,
            'rate': 0,
            'tax_percent': 0,
            'quantity': 0,
            'cgst_amount': 0,
            'sgst_amount': 0,
            'igst_amount': 0,
            'cess_amount': 0,
        })

        # Set SL No
        sl_item = self.items_table.item(row, 0)
        if sl_item:
            sl_item.setText(str(row + 1))

        # Style Sales Rate cell as read-only (grey background, no edit)
        sr_item = self.items_table.item(row, 1)
        if sr_item:
            from PySide6.QtGui import QColor
            sr_item.setBackground(QColor("#0f172a"))
            sr_item.setForeground(QColor("#64748b"))
            sr_item.setFlags(sr_item.flags() & ~Qt.ItemIsEditable)

        return row

    def recalculate_row(self, row, source_column=None, live_value=None):
        """Wrapper for recalculate_row function."""
        _recalculate_row(self, row, source_column, live_value)

    def calculate_totals(self):
        """Wrapper for calculate_totals function."""
        _calculate_totals(self)

    def safe_item_text(self, row, col, default=""):
        """Wrapper for safe_item_text function."""
        return safe_item_text(self.items_table, row, col, default)

    def safe_float_from_cell(self, row, col, default=0.0):
        """Wrapper for safe_float_from_cell function."""
        return safe_float_from_cell(self.items_table, row, col, default)

    def ensure_row_items_initialized(self, row):
        """Wrapper for ensure_row_items_initialized function."""
        ensure_row_items_initialized(self.items_table, row)

    def clear_form(self):
        """Clear all form fields and reset to blank state."""
        self.current_purchase_id = None
        self.purchase_items = []
        self._purchase_nav_ids = []
        self._amt_paid_user_edited = False  # Reset user edited flag

        # Clear top fields
        self.purchase_no_input.clear()
        self.purchase_no_input.setPlaceholderText("Auto")
        self.date_input.setDate(QDate.currentDate())
        self.purchase_type_combo.setCurrentIndex(0)
        self.series_input.clear()
        self.nature_combo.setCurrentIndex(0)
        self.party_type_combo.setCurrentText("Creditor")  # Default to Creditor
        self.due_date_input.setDate(QDate.currentDate().addDays(30))

        # Auto-generate purchase number
        self.generate_purchase_number()

        # Clear creditor fields
        self.creditor_name_input.clear()
        self.address_input.clear()
        self.mobile_input.clear()
        self.gstin_input.clear()
        self.state_combo.setCurrentIndex(0)

        # Unlock party fields and reset creditor ID
        self._unlock_party_fields()
        self.selected_creditor_id = None
        self.supplier_invoice_input.clear()
        self.narration_input.clear()
        
        # Clear product strip
        self.barcode_input.clear()
        self.product_input.clear()
        
        # Clear table
        self.items_table.setRowCount(0)
        for _ in range(10):
            self.add_blank_row()
        
        # Clear footer
        self.amt_paid_input.clear()
        
        # Reset checkboxes
        self.purchase_checkbox.setChecked(False)
        
        # Recalculate totals
        self.calculate_totals()

    def previous_bill(self):
        """Navigate to previous purchase."""
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return
        
        # Load nav IDs if not loaded
        if not self._purchase_nav_ids:
            self._purchase_nav_ids = self.db.get_purchase_nav_ids(active_company['id'])
        
        if not self._purchase_nav_ids:
            QMessageBox.information(self, "Info", "No purchases found.")
            return
        
        # Find current position
        current_pos = -1
        if self.current_purchase_id:
            try:
                current_pos = self._purchase_nav_ids.index(self.current_purchase_id)
            except ValueError:
                current_pos = -1
        
        # Move to previous
        if current_pos > 0:
            prev_id = self._purchase_nav_ids[current_pos - 1]
            self.load_purchase(prev_id)
        elif current_pos == -1:
            # No current purchase, load most recent
            self.load_purchase(self._purchase_nav_ids[0])
        else:
            QMessageBox.information(self, "Info", "This is the first purchase.")

    def next_bill(self):
        """Navigate to next purchase."""
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return
        
        # Load nav IDs if not loaded
        if not self._purchase_nav_ids:
            self._purchase_nav_ids = self.db.get_purchase_nav_ids(active_company['id'])
        
        if not self._purchase_nav_ids:
            QMessageBox.information(self, "Info", "No purchases found.")
            return
        
        # Find current position
        current_pos = -1
        if self.current_purchase_id:
            try:
                current_pos = self._purchase_nav_ids.index(self.current_purchase_id)
            except ValueError:
                current_pos = -1
        
        # Move to next
        if current_pos >= 0 and current_pos < len(self._purchase_nav_ids) - 1:
            next_id = self._purchase_nav_ids[current_pos + 1]
            self.load_purchase(next_id)
        elif current_pos == -1:
            # No current purchase, load most recent
            self.load_purchase(self._purchase_nav_ids[0])
        else:
            QMessageBox.information(self, "Info", "This is the last purchase.")

    def load_purchase(self, purchase_id):
        """Load a purchase into the form."""
        active_company = active_company_manager.get_active_company()
        if not active_company:
            return
        
        # Get purchase header
        purchase_logic = self._get_purchase_logic()
        result = purchase_logic.get_purchase_by_id(active_company['id'], purchase_id)
        if not result or not result.get('success') or not result.get('data'):
            QMessageBox.warning(self, "Error", "Purchase not found.")
            return
        purchase = result['data']
        
        # Block signals during load
        self.blockSignals(True)
        
        try:
            self.current_purchase_id = purchase_id
            
            # Load header fields
            self.purchase_no_input.setText(purchase.get('purchase_number', ''))
            self.date_input.setDate(QDate.fromString(purchase.get('purchase_date', ''), "yyyy-MM-dd"))
            self.purchase_type_combo.setCurrentText(purchase.get('purchase_type', 'Cash'))
            self.series_input.setText(purchase.get('bill_series', ''))
            self.nature_combo.setCurrentText(purchase.get('nature', 'Local'))
            self.party_type_combo.setCurrentText('Creditor')  # Purchase is always creditor
            self.due_date_input.setDate(QDate.fromString(purchase.get('due_date', ''), "yyyy-MM-dd"))
            
            # Load creditor
            creditor_id = purchase.get('party_id')
            creditor = self.db.get_party_by_id(active_company['id'], creditor_id)
            if creditor:
                self.creditor_name_input.setText(creditor.get('name', ''))
                self.address_input.setText(creditor.get('address', ''))
                self.mobile_input.setText(creditor.get('mobile_number', ''))
                self.gstin_input.setText(creditor.get('gstin', ''))
                self.state_combo.setCurrentText(creditor.get('state', ''))
            
            self.narration_input.setText(purchase.get('narration', ''))
            self.supplier_invoice_input.setText(purchase.get('supplier_invoice_no', ''))
            
            # Load footer
            self.round_off_input.setText(str(purchase.get('round_off', 0)))
            self.amt_paid_input.setText(str(purchase.get('amount_paid', 0)))
            
            # Clear and load table
            self.items_table.setRowCount(0)
            self.purchase_items = []
            
            purchase_logic = self._get_purchase_logic()
            items_result = purchase_logic.get_purchase_items(purchase_id)
            purchase_items_data = items_result.get('data', []) if items_result and items_result.get('success') else []
            for idx, item in enumerate(purchase_items_data):
                self.add_blank_row()
                row = idx
                
                # Load product name
                product_id = item.get('product_id')
                product = self.db.get_product_by_id(active_company['id'], product_id)
                if product:
                    product_name_item = self.items_table.item(row, 2)
                    if product_name_item:
                        product_name_item.setText(product.get('name', ''))
                    sales_rate = float(product.get('sale_price', 0) or product.get('sales_rate', 0) or 0)
                    sr_item = self.items_table.item(row, 1)
                    if sr_item:
                        sr_item.setText(f"{sales_rate:.2f}")
                
                # Load row data
                nature = purchase.get('nature', 'Local')
                
                # Load split GST values from DB or use fallback logic
                cgst = float(item.get('cgst', 0))
                sgst = float(item.get('sgst', 0))
                igst = float(item.get('igst', 0))
                cess = float(item.get('cess', 0))
                tax_percent = float(item.get('tax_percent', 0))
                
                # Fallback: if split GST is missing/zero but tax_percent exists, calculate it
                if cgst == 0 and sgst == 0 and igst == 0 and tax_percent > 0:
                    if nature == "Inter-state":
                        igst = tax_percent
                        cgst = 0
                        sgst = 0
                    else:
                        cgst = tax_percent / 2
                        sgst = tax_percent / 2
                        igst = 0
                
                self.items_table.item(row, 3).setText(item.get('hsn', ''))
                self.items_table.item(row, 4).setText(f"{cgst:.2f}")
                self.items_table.item(row, 5).setText(f"{sgst:.2f}")
                self.items_table.item(row, 6).setText(f"{igst:.2f}")
                self.items_table.item(row, 7).setText(f"{cess:.2f}")
                self.items_table.item(row, 8).setText(str(item.get('rate', 0)))
                self.items_table.item(row, 9).setText(str(item.get('quantity', 0)))
                self.items_table.item(row, 10).setText(str(item.get('gross_value', 0)))
                self.items_table.item(row, 11).setText(str(item.get('discount', 0)))
                self.items_table.item(row, 12).setText(str(item.get('net_value', 0)))
                self.items_table.item(row, 13).setText(str(item.get('tax_amount', 0)))
                self.items_table.item(row, 14).setText(str(item.get('grand_total', 0)))
                
                # Update internal purchase_items
                self.purchase_items[row] = {
                    'product_id': product_id,
                    'hsn': item.get('hsn', ''),
                    'source_cgst': cgst,
                    'source_sgst': sgst,
                    'source_igst': igst,
                    'source_cess': cess,
                    'cgst': cgst,
                    'sgst': sgst,
                    'igst': igst,
                    'cess': cess,
                    'cgst_amount': float(item.get('cgst_amount', 0)),
                    'sgst_amount': float(item.get('sgst_amount', 0)),
                    'igst_amount': float(item.get('igst_amount', 0)),
                    'cess_amount': float(item.get('cess_amount', 0)),
                    'rate': item.get('rate', 0),
                    'tax_percent': tax_percent,
                    'quantity': float(item.get('quantity', 0)),
                }
            
            # Add blank rows at end
            for _ in range(5):
                self.add_blank_row()
            
            # Calculate totals
            self.calculate_totals()
            
        finally:
            self.blockSignals(False)

    def confirm_remove_purchase(self):
        """Confirm and remove current purchase."""
        if self.current_purchase_id:
            reply = QMessageBox.question(
                self,
                "Confirm Remove",
                "Are you sure you want to remove this purchase?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                active_company = active_company_manager.get_active_company()
                if active_company:
                    purchase_logic = self._get_purchase_logic()
                    result = purchase_logic.delete_purchase(active_company['id'], self.current_purchase_id)
                    if result['success']:
                        QMessageBox.information(self, "Success", result['message'])
                        self.clear_form()
                        # Refresh nav IDs
                        self._purchase_nav_ids = self.db.get_purchase_nav_ids(active_company['id'])
                    else:
                        QMessageBox.warning(self, "Error", result['message'])
        else:
            QMessageBox.information(self, "Info", "No purchase to remove.")

    def confirm_remove_item(self):
        """Confirm and remove selected item - only works if SL No was clicked first."""
        row = getattr(self, "manually_selected_row", -1)

        if row < 0 or row >= self.items_table.rowCount():
            QMessageBox.information(
                self,
                "Remove Item",
                "Please click the SL No of the item you want to remove, then press Remove Item."
            )
            return

        product_name = self.safe_item_text(row, 1)
        if not product_name:
            QMessageBox.information(
                self,
                "Remove Item",
                "Selected row is blank."
            )
            return

        reply = QMessageBox.question(
            self,
            "Confirm Remove Item",
            f"Are you sure you want to remove row {row + 1}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if reply != QMessageBox.Yes:
            return

        self.delete_row(row)
        self.manually_selected_row = -1
        self.items_table.clearSelection()
        self.items_table.viewport().update()
        self.calculate_totals()

    def delete_row(self, row):
        """Delete specified row from table."""
        if row < 0 or row >= self.items_table.rowCount():
            return

        self.items_table.removeRow(row)
        if row < len(self.purchase_items):
            del self.purchase_items[row]

        # Re-number SL column
        for r in range(self.items_table.rowCount()):
            sl_item = self.items_table.item(r, 0)
            if sl_item:
                sl_item.setText(str(r + 1))

        self.calculate_totals()

    def print_invoice(self):
        """Print purchase invoice."""
        # Placeholder for print logic
        QMessageBox.information(self, "Print", "Print functionality to be implemented.")

    def on_footer_discount_changed(self, text):
        """Handle footer discount/round-off change."""
        self.calculate_totals()

    def on_purchase_expense_changed(self, text):
        """Handle purchase expense change - recalculate totals."""
        self.calculate_totals()

    def on_amt_paid_edited(self, *args):
        """Handle amount paid field edit. Accepts *args for signal compatibility."""
        # Skip if updating programmatically
        if self._updating_amt_paid_programmatically:
            return
        # Mark as user-edited
        self._amt_paid_user_edited = True
        self.update_footer_payment_fields(write_amt_recvd=False)

    def update_footer_payment_fields(self, write_amt_recvd=True):
        """Update payment-related footer fields based on purchase type using PartyBalanceEngine.

        Rules:
          - Opening Balance: Only from party master (parties.opening_balance), never changes while browsing.
          - Previous Balance: Balance before current voucher (excludes current and future bills).
          - Cash: Amount Paid auto = Grand Total (always forced).
          - Credit (default state): Amount Paid = 0.00 until user manually edits it.
          - Credit (user-edited): preserve user's Amount Paid value.
          - Closing Payable = Previous Balance + Purchase Net Amount - Amount Paid.
        """
        grand_total = self._safe_float(self.grand_total_input.text())
        purchase_type = self.purchase_type_combo.currentText()

        # Get Previous Balance (balance before current voucher)
        previous_balance = self.get_previous_creditor_balance()

        # Determine Amount Paid based on type + user-edit state
        if purchase_type == "Cash":
            amt_paid = grand_total
        else:  # Credit (or anything else → treat as credit)
            if getattr(self, '_amt_paid_user_edited', False):
                amt_paid = self._safe_float(self.amt_paid_input.text())
            else:
                amt_paid = 0.0

        # Clamp Amount Paid so it never exceeds grand_total (only for display/calc use)
        amt_paid_for_calc = amt_paid if amt_paid <= grand_total else grand_total

        # Calculate Closing Payable using PartyBalanceEngine
        closing_balance = self.balance_engine.calculate_closing_balance(
            previous_balance, grand_total, amt_paid_for_calc, 'purchase'
        )

        # Write Amount Paid only when caller requests it (skipped during user typing)
        if write_amt_recvd:
            if purchase_type == "Cash":
                if not getattr(self, '_amt_paid_user_edited', False):
                    self._updating_amt_paid_programmatically = True
                    self.amt_paid_input.setText(f"{amt_paid_for_calc:.2f}")
                    self._updating_amt_paid_programmatically = False
            elif purchase_type == "Credit":
                if not getattr(self, '_amt_paid_user_edited', False):
                    self._updating_amt_paid_programmatically = True
                    self.amt_paid_input.setText("0.00")
                    self._updating_amt_paid_programmatically = False

        # Update balance display
        if hasattr(self, 'balance_display'):
            self.balance_display.setText(f"{closing_balance:.2f}")

    def get_previous_creditor_balance(self):
        """Return the Previous Balance (balance before current voucher) of the selected creditor.

        Uses PartyBalanceEngine to calculate:
        Previous Balance = party opening_balance + unpaid previous purchases - previous payments/returns

        Excludes current bill when editing/viewing old bills via voucher_id.
        Excludes future bills (after current voucher date/id).

        Returns 0.00 when no creditor found / blank / error.
        """
        try:
            if not hasattr(self, 'creditor_name_input'):
                return 0.0
            name = self.creditor_name_input.text().strip().lower()
            if not name:
                return 0.0
            if not getattr(self, 'creditors_data', None):
                return 0.0
            for c in self.creditors_data:
                c_name = (c.get('party_name') or c.get('name') or "").strip().lower()
                if c_name and c_name == name:
                    party_id = c.get('id')
                    if party_id:
                        active = active_company_manager.get_active_company()
                        if active:
                            # Use PartyBalanceEngine for proper Previous Balance calculation
                            voucher_id = self.current_purchase_id if hasattr(self, 'current_purchase_id') else None
                            voucher_date = None
                            # If we have a saved purchase loaded, get its date for proper exclusion
                            if voucher_id and hasattr(self, 'bill_date_input'):
                                voucher_date = self.bill_date_input.date().toString("yyyy-MM-dd")
                            balance_result = self.balance_engine.get_party_balance_before_voucher(
                                active['id'], party_id, 'purchase', voucher_id=voucher_id, voucher_date=voucher_date
                            )
                            return balance_result.get('previous_balance', 0.0)
                    # Fallback to static opening_balance if DB unavailable
                    return self._safe_float(c.get('opening_balance'), 0.0)
            return 0.0
        except Exception:
            return 0.0

    def apply_purchase_payment_mode(self):
        """Apply payment mode based on purchase type (Cash/Credit)."""
        grand_total = self._safe_float(self.grand_total_input.text())
        purchase_type = self.purchase_type_combo.currentText()

        if purchase_type == "Cash":
            # Cash: Amount Paid = Grand Total, Balance = 0.00
            self._updating_amt_paid_programmatically = True
            self.amt_paid_input.setText(f"{grand_total:.2f}")
            self._updating_amt_paid_programmatically = False
            self.balance_display.setText("0.00")
            # Optionally make read-only (if needed in future)
            # self.amt_paid_input.setReadOnly(True)
        elif purchase_type == "Credit":
            # Credit: Amount Paid = 0.00 unless user manually edited
            if not getattr(self, '_amt_paid_user_edited', False):
                self._updating_amt_paid_programmatically = True
                self.amt_paid_input.setText("0.00")
                self._updating_amt_paid_programmatically = False
            # Make editable
            # self.amt_paid_input.setReadOnly(False)
            # Calculate balance
            amt_paid = self._safe_float(self.amt_paid_input.text())
            balance = grand_total - amt_paid
            self.balance_display.setText(f"{balance:.2f}")

    def _safe_float(self, text, default=0.0):
        """Parse text to float safely."""
        try:
            return float(str(text).strip().replace(",", "").replace("₹", ""))
        except (ValueError, TypeError):
            return default

    def open_creditor_page(self):
        """Open Debitor/Creditor module for adding new creditor."""
        # Mark that we need a fresh creditor reload when we return
        self._creditor_refresh_pending = True
        self._last_creditor_refresh_time = 0  # Reset throttle so showEvent always refreshes on return
        try:
            from PySide6.QtWidgets import QApplication

            # Step 1: Try direct parent window (works when Purchase Entry is in main window)
            main_window = self.window()
            if main_window and hasattr(main_window, 'show_debitor_creditor'):
                main_window.show_debitor_creditor()
                return

            # Step 2: Search all top-level widgets for MainWindow with show_debitor_creditor
            # This handles the case when Purchase Entry is in a standalone window
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'show_debitor_creditor'):
                    widget.show_debitor_creditor()
                    widget.raise_()
                    widget.activateWindow()
                    return

            # Step 3: Fallback to stack_widget + debitor_creditor_widget pattern
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'stack_widget') and hasattr(widget, 'debitor_creditor_widget'):
                    if hasattr(widget.debitor_creditor_widget, 'load_parties'):
                        widget.debitor_creditor_widget.load_parties()
                    widget.stack_widget.setCurrentWidget(widget.debitor_creditor_widget)
                    widget.raise_()
                    widget.activateWindow()
                    return

            # Step 4: If nothing found, show clear message
            QMessageBox.warning(self, "Navigation Error", "Debitor/Creditor page is not available from this window.")
        except Exception as e:
            QMessageBox.warning(self, "Navigation Error", f"Could not open Debitor/Creditor page: {e}")

    def save(self):
        """Save purchase bill."""
        active_company = active_company_manager.get_active_company()
        if not active_company:
            QMessageBox.warning(self, "Error", "No active company selected.")
            return
        
        # Collect header data
        purchase_no = self.purchase_no_input.text()
        date = self.date_input.date().toString("yyyy-MM-dd")
        purchase_type = self.purchase_type_combo.currentText()
        series = self.series_input.text()
        nature = self.nature_combo.currentText()
        creditor_name = self.creditor_name_input.text()
        address = self.address_input.text()
        mobile = self.mobile_input.text()
        gstin = self.gstin_input.text()
        state = self.state_combo.currentText()
        supplier_invoice_no = self.supplier_invoice_input.text()
        due_date = self.due_date_input.date().toString("yyyy-MM-dd")
        narration = self.narration_input.text()
        
        # Validate required fields
        if not creditor_name:
            QMessageBox.warning(self, "Validation Error", "Please enter creditor name.")
            return
        
        if not purchase_no:
            QMessageBox.warning(self, "Validation Error", "Please enter purchase number.")
            return
        
        # Find or create creditor
        creditor = None
        for c in self.creditors_data:
            if c.get('name') == creditor_name:
                creditor = c
                break
        
        party_id = None
        if creditor:
            party_id = creditor.get('id')
        else:
            # Create new creditor
            new_creditor_data = {
                'name': creditor_name,
                'party_type': 'Creditor',
                'opening_balance': 0.0,
                'mobile_number': mobile,
                'address': address,
                'gstin': gstin,
                'credit_limit': 0.0,
                'contact_person': '',
                'notes': ''
            }
            party_id = self.db.insert_party(active_company['id'], new_creditor_data)
            if party_id:
                # Reload creditors
                self.load_creditors()
            else:
                QMessageBox.warning(self, "Error", "Failed to create creditor.")
                return

        # Force recalculation of every nonblank product row to ensure fresh split GST amounts
        for row in range(self.items_table.rowCount()):
            product_name = self.safe_item_text(row, 2)
            if product_name and product_name.strip():
                self.recalculate_row(row, source_column=None)

        # Collect table data
        purchase_items = []
        for row in range(self.items_table.rowCount()):
            product_name = self.safe_item_text(row, 2)
            if product_name:
                qty = self.safe_float_from_cell(row, 9)
                if qty > 0:
                    row_meta = self.purchase_items[row] if row < len(self.purchase_items) else {}
                    # Get split GST amounts from row calculation results (now fresh)
                    cgst_amount = row_meta.get('cgst_amount', 0.0)
                    sgst_amount = row_meta.get('sgst_amount', 0.0)
                    igst_amount = row_meta.get('igst_amount', 0.0)
                    cess_amount = row_meta.get('cess_amount', 0.0)
                    purchase_items.append({
                        'sl_no': row + 1,
                        'product_id': self.purchase_items[row].get('product_id'),
                        'hsn': self.safe_item_text(row, 3),
                        'tax_percent': (
                            self.safe_float_from_cell(row, 4)
                            + self.safe_float_from_cell(row, 5)
                            + self.safe_float_from_cell(row, 6)
                            + self.safe_float_from_cell(row, 7)
                        ),
                        'cgst': self.safe_float_from_cell(row, 4),
                        'sgst': self.safe_float_from_cell(row, 5),
                        'igst': self.safe_float_from_cell(row, 6),
                        'cess': self.safe_float_from_cell(row, 7),
                        'cgst_amount': cgst_amount,
                        'sgst_amount': sgst_amount,
                        'igst_amount': igst_amount,
                        'cess_amount': cess_amount,
                        'unit': '',  # Would come from product
                        'rate': self.safe_float_from_cell(row, 8),
                        'quantity': qty,
                        'gross_value': self.safe_float_from_cell(row, 10),
                        'discount': self.safe_float_from_cell(row, 11),
                        'net_value': self.safe_float_from_cell(row, 12),
                        'tax_amount': self.safe_float_from_cell(row, 13),
                        'grand_total': self.safe_float_from_cell(row, 14),
                    })
        
        if not purchase_items:
            QMessageBox.warning(self, "Validation Error", "Please add at least one item with a product and quantity.")
            return
        
        # Check for duplicate purchase number
        if self.db.purchase_number_exists(active_company['id'], purchase_no, self.current_purchase_id):
            QMessageBox.warning(self, "Validation Error", f"Purchase number '{purchase_no}' already exists.")
            return
        
        # Prepare purchase header data
        # Calculate actual totals from purchase_items
        sub_total = 0.0
        discount_total = 0.0
        tax_total = 0.0
        for item in purchase_items:
            sub_total += item.get('gross_value', 0.0)
            discount_total += item.get('discount', 0.0)
            tax_total += item.get('tax_amount', 0.0)

        purchase_data = {
            'purchase_number': purchase_no,
            'purchase_date': date,
            'party_id': party_id,
            'purchase_type': purchase_type,
            'bill_series': series,
            'nature': nature,
            'due_date': due_date,
            'address': address,
            'gstin': gstin,
            'state': state,
            'supplier_invoice_no': supplier_invoice_no,
            'narration': narration,
            'sub_total': sub_total,
            'discount_total': discount_total,
            'tax_total': tax_total,
            'round_off': self._safe_float(self.round_off_input.text()),
            'purchase_expense': self._safe_float(self.purchase_expense_input.text()) if hasattr(self, 'purchase_expense_input') else 0.0,
            'grand_total': self._safe_float(self.grand_total_input.text()),
            'amount_paid': self._safe_float(self.amt_paid_input.text())
        }
        
        # Save or update using logic layer
        purchase_logic = self._get_purchase_logic()
        result = purchase_logic.save_purchase(active_company['id'], purchase_data, purchase_items, self.current_purchase_id)

        if result['success']:
            QMessageBox.information(self, "Success", result['message'])
            # Refresh nav IDs
            self._purchase_nav_ids = self.db.get_purchase_nav_ids(active_company['id'])
            if not self.current_purchase_id and result.get('data', {}).get('purchase_id'):
                self.current_purchase_id = result['data']['purchase_id']
            # Clear form for next entry and generate next number
            self.clear_form()
            self.generate_purchase_number()
            # Focus barcode input for next entry
            QTimer.singleShot(0, lambda: self.barcode_input.setFocus())
        else:
            QMessageBox.warning(self, "Error", result['message'])

    def _get_product_for_row(self, row):
        """Return product data for a purchase row, with stored source tax fallback."""
        if row < 0 or row >= len(self.purchase_items):
            return {}

        item_data = self.purchase_items[row]
        product_id = item_data.get('product_id')
        product = None

        if product_id:
            product = self.products_dict.get(product_id)
            if not product:
                for p in getattr(self, 'products_data', []):
                    if p.get('id') == product_id:
                        product = p
                        break

        if not product:
            product = {
                'id': product_id,
                'name': item_data.get('name', self.safe_item_text(row, 1)),
                'hsn': item_data.get('hsn', item_data.get('hsn_code', self.safe_item_text(row, 2))),
                'purchase_rate': item_data.get('rate', self.safe_float_from_cell(row, 7)),
                'cgst': item_data.get('source_cgst', item_data.get('cgst', 0)),
                'sgst': item_data.get('source_sgst', item_data.get('sgst', 0)),
                'igst': item_data.get('source_igst', item_data.get('igst', 0)),
                'cess': item_data.get('source_cess', item_data.get('cess', 0)),
            }

        return product

    def _apply_nature_tax_to_row(self, row, product):
        """Apply Indian GST purchase tax rule to a row.

        Product master may store CGST, SGST, IGST and CESS together.
        Purchase Entry must choose the active taxes by Nature:
        - Local: CGST + SGST + CESS, IGST = 0
        - Inter-state: IGST + CESS, CGST = SGST = 0
        """
        if row < 0 or row >= self.items_table.rowCount():
            return
        if row >= len(self.purchase_items):
            return

        if not product:
            product = self._get_product_for_row(row)
        if not product:
            return

        def to_float(value):
            try:
                return float(value or 0)
            except (TypeError, ValueError):
                return 0.0

        source_cgst = to_float(product.get('cgst', self.purchase_items[row].get('source_cgst', 0)))
        source_sgst = to_float(product.get('sgst', self.purchase_items[row].get('source_sgst', 0)))
        source_igst = to_float(product.get('igst', self.purchase_items[row].get('source_igst', 0)))
        source_cess = to_float(product.get('cess', self.purchase_items[row].get('source_cess', 0)))

        is_inter = 'inter' in self.nature_combo.currentText().strip().lower()
        if is_inter:
            cgst = 0.0
            sgst = 0.0
            igst = source_igst
        else:
            cgst = source_cgst
            sgst = source_sgst
            igst = 0.0
        cess = source_cess

        was_blocked = self.items_table.blockSignals(True)
        try:
            for col, value in ((4, cgst), (5, sgst), (6, igst), (7, cess)):
                cell = self.items_table.item(row, col)
                if cell:
                    cell.setText(f"{value:.2f}")
        finally:
            self.items_table.blockSignals(was_blocked)

        self.purchase_items[row].update({
            'source_cgst': source_cgst,
            'source_sgst': source_sgst,
            'source_igst': source_igst,
            'source_cess': source_cess,
            'cgst': cgst,
            'sgst': sgst,
            'igst': igst,
            'cess': cess,
            'tax_percent': (igst + cess) if is_inter else (cgst + sgst + cess),
        })

    def _update_purchase_row_status_display(self, row):
        """Update Code and Stock displays for the given purchase row."""
        if row < 0 or row >= len(self.purchase_items):
            if hasattr(self, 'code_display'):
                self.code_display.setText("")
            if hasattr(self, 'stock_display'):
                self.stock_display.setText("0.000")
            return

        product_id = self.purchase_items[row].get('product_id')
        product = None
        if product_id:
            product = self.products_dict.get(product_id)
            if not product:
                for p in getattr(self, 'products_data', []):
                    if p.get('id') == product_id:
                        product = p
                        break

        if product:
            if hasattr(self, 'code_display'):
                self.code_display.setText(str(product.get('barcode', '') or ''))
            if hasattr(self, 'stock_display'):
                try:
                    active_company = active_company_manager.get_active_company()
                    if active_company and product_id:
                        stock_qty = self.db.get_stock_balance_from_movements(
                            active_company['id'], product_id
                        )
                    else:
                        stock_qty = float(product.get('quantity', 0) or 0)
                except (TypeError, ValueError, Exception):
                    stock_qty = 0.0
                self.stock_display.setText(f"{stock_qty:.3f}")
        else:
            if hasattr(self, 'code_display'):
                self.code_display.setText("")
            if hasattr(self, 'stock_display'):
                self.stock_display.setText("0.000")

    def eventFilter(self, obj, event):
        """Unified event filter for Purchase Entry.

        - Editable table cells open editor with select-all on one click.
        - SL column click marks the row for Remove Item only.
        - No row is deleted from a mouse click.
        - Locked party fields stay protected.
        """
        if isinstance(obj, QLineEdit) and event.type() == QEvent.FocusIn:
            if not obj.isReadOnly():
                QTimer.singleShot(0, obj.selectAll)

        if obj == self.items_table.viewport() and event.type() == QEvent.MouseButtonPress:
            if event.button() == Qt.LeftButton:
                item = self.items_table.itemAt(event.pos())
                if not item:
                    return False

                clicked_row = item.row()
                clicked_column = item.column()

                if clicked_column == 0:
                    self.manually_selected_row = clicked_row
                    self.items_table.clearSelection()
                    self.items_table.setCurrentCell(clicked_row, clicked_column)
                    self._update_purchase_row_status_display(clicked_row)
                    self.items_table.viewport().update()
                    return True

                self.manually_selected_row = -1
                self.items_table.clearSelection()
                self._update_purchase_row_status_display(clicked_row)
                self.items_table.viewport().update()
                self.focus_table_cell_editor(clicked_row, clicked_column)
                return True

        if event.type() == QEvent.KeyPress and event.key() == Qt.Key_F2:
            current_row = self.items_table.currentRow()
            current_col = self.items_table.currentColumn()
            if current_col == 8:
                self.on_f2_in_qty_field(current_row)
                return True

        if self._party_fields_locked and event.type() in (QEvent.KeyPress, QEvent.MouseButtonPress):
            if obj in (self.address_input, self.mobile_input, self.gstin_input, self.state_combo):
                QMessageBox.information(self, "Field Locked", "Update creditor using Edit Creditor.")
                return True

        return super().eventFilter(obj, event)

    def on_sl_no_clicked(self, row):
        """Mark a row from the SL column. Deletion is only from Remove Item button."""
        if row < 0 or row >= self.items_table.rowCount():
            return
        self.manually_selected_row = row
        self.items_table.clearSelection()
        self.items_table.setCurrentCell(row, 0)
        self._update_purchase_row_status_display(row)
        self.items_table.viewport().update()

    def on_f2_in_qty_field(self, row):
        """Handle F2 key press in Qty field to open Product Entry in edit mode."""
        # Get product_id from the row
        product_id = None
        if row < len(self.purchase_items):
            product_id = self.purchase_items[row].get('product_id')

        if not product_id:
            QMessageBox.warning(self, "No Product", "No product selected in this row.")
            return

        # Store context for return
        self._product_entry_context = {
            'mode': 'edit',
            'row': row,
            'product_id': product_id
        }

        # Open Product Entry in edit mode
        self.open_product_entry_edit_from_row(row, product_id)

    def closeEvent(self, event):
        """Handle window close event."""
        self.window_closed.emit()
        event.accept()

    def keyPressEvent(self, event):
        """Handle key press events."""
        # Do not close window on Esc - Esc is handled by delegate for backward navigation
        super().keyPressEvent(event)
