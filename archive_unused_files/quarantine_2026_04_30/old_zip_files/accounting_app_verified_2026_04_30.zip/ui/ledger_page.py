"""
Ledger Page Widget - Fixed Version
Displays ledger entries and account summaries with proper dark theme.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QDateEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QMessageBox, QAbstractItemView
)
from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtGui import QColor
from datetime import date

from config import COLORS, active_company_manager
from logic.ledger_logic import LedgerLogic

# Ledger Type options with their corresponding account filters
LEDGER_TYPES = [
    ("All Ledgers", None),
    ("Sundry Debtors", "sundry_debtors"),
    ("Sundry Creditors", "sundry_creditors"),
    ("Cash / Bank", "cash_bank"),
    ("Sales", "sales"),
    ("Purchase", "purchase"),
    ("Sales Return", "sales_return"),
    ("Purchase Return", "purchase_return"),
    ("GST / Tax", "tax"),
    ("Stock", "stock"),
    ("Expenses", "expense"),
    ("Income", "income"),
]


class LedgerPageWidget(QWidget):
    """Widget for displaying ledger entries and account summaries."""

    def __init__(self, db=None):
        super().__init__()
        self.db = db
        self.ledger_logic = LedgerLogic(self.db) if self.db else None
        self.company_id = active_company_manager.get_active_company_id() if active_company_manager else None
        self.all_accounts = []  # Cache for all accounts
        self.setup_ui()
        self._apply_dark_styles()

    def _apply_dark_styles(self):
        """Apply comprehensive dark theme to all widgets."""
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {COLORS['background']};
                color: {COLORS['text_primary']};
            }}
            QComboBox {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 6px 10px;
                min-height: 20px;
            }}
            QComboBox:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
            QComboBox::drop-down {{
                border: none;
                width: 24px;
            }}
            QComboBox::down-arrow {{
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid {COLORS['text_secondary']};
                width: 0;
                height: 0;
            }}
            QComboBox QAbstractItemView {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                selection-background-color: {COLORS['primary']};
                selection-color: white;
            }}
            QDateEdit {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 6px 10px;
                min-height: 20px;
            }}
            QDateEdit:hover {{
                border: 1px solid {COLORS['border_focus']};
            }}
            QDateEdit::drop-down {{
                border: none;
                width: 24px;
            }}
            QCalendarWidget {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
            }}
            QCalendarWidget QTableView {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                selection-background-color: {COLORS['primary']};
            }}
            QCalendarWidget QHeaderView::section {{
                background-color: {COLORS['primary']};
                color: white;
            }}
        """)

    def setup_ui(self):
        """Setup the ledger page UI with new filter design."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        title_label = QLabel("Ledger")
        title_label.setStyleSheet(f"""
            QLabel {{
                font-size: 24px;
                font-weight: bold;
                color: {COLORS['text_primary']};
                background-color: transparent;
            }}
        """)
        layout.addWidget(title_label)

        # Filter section - styled frame
        filter_frame = QFrame()
        filter_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
            }}
        """)
        filter_layout = QHBoxLayout(filter_frame)
        filter_layout.setSpacing(15)
        filter_layout.setContentsMargins(15, 15, 15, 15)

        # Ledger Type dropdown
        ledger_type_label = QLabel("Ledger Type:")
        ledger_type_label.setStyleSheet(f"color: {COLORS['text_secondary']}; background-color: transparent;")
        self.ledger_type_combo = QComboBox()
        self.ledger_type_combo.setMinimumWidth(180)
        for label, _ in LEDGER_TYPES:
            self.ledger_type_combo.addItem(label)
        self.ledger_type_combo.currentIndexChanged.connect(self.on_ledger_type_changed)
        filter_layout.addWidget(ledger_type_label)
        filter_layout.addWidget(self.ledger_type_combo)

        # Account dropdown
        account_label = QLabel("Account:")
        account_label.setStyleSheet(f"color: {COLORS['text_secondary']}; background-color: transparent;")
        self.account_combo = QComboBox()
        self.account_combo.setMinimumWidth(250)
        self.account_combo.setEnabled(False)  # Disabled until ledger type selected
        filter_layout.addWidget(account_label)
        filter_layout.addWidget(self.account_combo)

        # From date
        from_date_label = QLabel("From:")
        from_date_label.setStyleSheet(f"color: {COLORS['text_secondary']}; background-color: transparent;")
        self.from_date_edit = QDateEdit()
        self.from_date_edit.setCalendarPopup(True)
        # Default: start of current financial year (April 1)
        today = QDate.currentDate()
        fy_start = QDate(today.year() if today.month() >= 4 else today.year() - 1, 4, 1)
        self.from_date_edit.setDate(fy_start)
        filter_layout.addWidget(from_date_label)
        filter_layout.addWidget(self.from_date_edit)

        # To date
        to_date_label = QLabel("To:")
        to_date_label.setStyleSheet(f"color: {COLORS['text_secondary']}; background-color: transparent;")
        self.to_date_edit = QDateEdit()
        self.to_date_edit.setCalendarPopup(True)
        self.to_date_edit.setDate(today)
        filter_layout.addWidget(to_date_label)
        filter_layout.addWidget(self.to_date_edit)

        # Buttons
        self.load_button = QPushButton("Load")
        self.load_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 20px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
            QPushButton:pressed {{
                background-color: {COLORS['primary_light']};
            }}
        """)
        self.load_button.clicked.connect(self.load_ledger)
        filter_layout.addWidget(self.load_button)

        self.refresh_button = QPushButton("Refresh")
        self.refresh_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['button_hover']};
            }}
        """)
        self.refresh_button.clicked.connect(self.refresh)
        filter_layout.addWidget(self.refresh_button)

        self.export_button = QPushButton("Export Excel")
        self.export_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 4px;
                padding: 8px 16px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['button_hover']};
            }}
        """)
        self.export_button.clicked.connect(self.export_excel)
        filter_layout.addWidget(self.export_button)

        filter_layout.addStretch()
        layout.addWidget(filter_frame)

        # Summary section
        summary_frame = QFrame()
        summary_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['surface']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
            }}
        """)
        summary_layout = QHBoxLayout(summary_frame)
        summary_layout.setSpacing(30)
        summary_layout.setContentsMargins(15, 10, 15, 10)

        self.opening_balance_label = QLabel("Opening: 0.00")
        self.opening_balance_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-weight: bold;
                font-size: 13px;
                background-color: transparent;
            }}
        """)
        summary_layout.addWidget(self.opening_balance_label)

        self.total_debit_label = QLabel("Debit: 0.00")
        self.total_debit_label.setStyleSheet(f"""
            QLabel {{
                color: #4ade80;
                font-weight: bold;
                font-size: 13px;
                background-color: transparent;
            }}
        """)
        summary_layout.addWidget(self.total_debit_label)

        self.total_credit_label = QLabel("Credit: 0.00")
        self.total_credit_label.setStyleSheet(f"""
            QLabel {{
                color: #f87171;
                font-weight: bold;
                font-size: 13px;
                background-color: transparent;
            }}
        """)
        summary_layout.addWidget(self.total_credit_label)

        self.closing_balance_label = QLabel("Closing: 0.00")
        self.closing_balance_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-weight: bold;
                font-size: 13px;
                background-color: transparent;
            }}
        """)
        summary_layout.addWidget(self.closing_balance_label)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_secondary']};
                font-size: 13px;
                background-color: transparent;
            }}
        """)
        summary_layout.addWidget(self.status_label)

        summary_layout.addStretch()
        layout.addWidget(summary_frame)

        # Ledger table
        self.ledger_table = QTableWidget()
        self.ledger_table.setColumnCount(7)
        self.ledger_table.setHorizontalHeaderLabels([
            "Date", "Voucher Type", "Voucher No", "Narration",
            "Debit", "Credit", "Running Balance"
        ])
        self.ledger_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                border-radius: 6px;
                gridline-color: {COLORS['border']};
            }}
            QTableWidget::item {{
                background-color: {COLORS['surface']};
                color: {COLORS['text_primary']};
                padding: 8px;
                border-bottom: 1px solid {COLORS['border']};
            }}
            QTableWidget::item:alternate {{
                background-color: #1e293b;
            }}
            QTableWidget::item:selected {{
                background-color: {COLORS['primary']};
                color: white;
            }}
            QHeaderView::section {{
                background-color: {COLORS['primary']};
                color: white;
                padding: 10px;
                border: none;
                border-bottom: 2px solid {COLORS['primary_dark']};
                font-weight: bold;
            }}
            QTableCornerButton::section {{
                background-color: {COLORS['primary']};
                border: none;
            }}
        """)
        self.ledger_table.horizontalHeader().setStretchLastSection(True)
        self.ledger_table.setAlternatingRowColors(True)
        self.ledger_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.ledger_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ledger_table.verticalHeader().setVisible(False)

        # Set column widths
        header = self.ledger_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # Date
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # Voucher Type
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Voucher No
        header.setSectionResizeMode(3, QHeaderView.Stretch)  # Narration
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Debit
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)  # Credit
        header.setSectionResizeMode(6, QHeaderView.ResizeToContents)  # Running Balance

        layout.addWidget(self.ledger_table, 1)

        # Load accounts if company is active
        if self.company_id and self.ledger_logic:
            self.load_accounts()
            self.on_ledger_type_changed()  # Populate account combo based on default selection

    def on_ledger_type_changed(self):
        """Handle ledger type selection change - populate Account dropdown."""
        if not self.ledger_logic or not self.company_id:
            self.account_combo.clear()
            self.account_combo.addItem("-- No Company Selected --", None)
            self.account_combo.setEnabled(False)
            return

        ledger_type = LEDGER_TYPES[self.ledger_type_combo.currentIndex()][1]

        # Clear and populate account combo based on ledger type
        self.account_combo.clear()

        if ledger_type is None:
            # "All Accounts" - show all accounts individually
            self.account_combo.addItem("-- All Accounts (Summary View) --", "all_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "sundry_debtors":
            # Show all debtor party accounts (from parties table)
            self.account_combo.addItem("-- All Debtors (Summary View) --", "debtors_summary")
            self.account_combo.setEnabled(True)
            debtors = self.ledger_logic.get_debtor_accounts(self.company_id) or []
            for acct in sorted(debtors, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "sundry_creditors":
            # Show all creditor party accounts (from parties table)
            self.account_combo.addItem("-- All Creditors (Summary View) --", "creditors_summary")
            self.account_combo.setEnabled(True)
            creditors = self.ledger_logic.get_creditor_accounts(self.company_id) or []
            for acct in sorted(creditors, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "cash_bank":
            self.account_combo.addItem("-- All Cash/Bank (Summary View) --", "cash_bank_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='cash_bank', is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "sales":
            self.account_combo.addItem("-- All Sales (Summary View) --", "sales_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='income', is_active=True) or []
            accounts = [a for a in accounts if 'sales' in a.get('account_name', '').lower()]
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "purchase":
            self.account_combo.addItem("-- All Purchase (Summary View) --", "purchase_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='expense', is_active=True) or []
            accounts = [a for a in accounts if 'purchase' in a.get('account_name', '').lower()]
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "sales_return":
            self.account_combo.addItem("-- All Sales Return (Summary View) --", "sales_return_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='expense', is_active=True) or []
            accounts = [a for a in accounts if 'sales return' in a.get('account_name', '').lower()]
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "purchase_return":
            self.account_combo.addItem("-- All Purchase Return (Summary View) --", "purchase_return_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='income', is_active=True) or []
            accounts = [a for a in accounts if 'purchase return' in a.get('account_name', '').lower()]
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "tax":
            self.account_combo.addItem("-- All GST/Tax (Summary View) --", "tax_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='tax_liability', is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "stock":
            self.account_combo.addItem("-- All Stock (Summary View) --", "stock_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='stock', is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "expense":
            self.account_combo.addItem("-- All Expenses (Summary View) --", "expense_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='expense', is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])
        elif ledger_type == "income":
            self.account_combo.addItem("-- All Income (Summary View) --", "income_summary")
            self.account_combo.setEnabled(True)
            accounts = self.ledger_logic.search_accounts(self.company_id, account_type='income', is_active=True) or []
            for acct in sorted(accounts, key=lambda x: x['account_name']):
                self.account_combo.addItem(acct['account_name'], acct['id'])

    def load_accounts(self):
        """Load all ledger accounts into cache."""
        if not self.ledger_logic or not self.company_id:
            return
        try:
            self.ledger_logic.ensure_system_accounts(self.company_id)
            self.all_accounts = self.ledger_logic.search_accounts(self.company_id, is_active=True) or []
        except Exception as e:
            print(f"Error loading accounts: {e}")
            self.all_accounts = []

    @staticmethod
    def _fmt_balance(net: float) -> str:
        """Format a net balance with Dr/Cr suffix."""
        if net > 0.001:
            return f"{net:,.2f} Dr"
        elif net < -0.001:
            return f"{abs(net):,.2f} Cr"
        else:
            return "0.00"

    def load_ledger(self):
        """Load ledger based on selected type and account."""
        if not self.ledger_logic or not self.company_id:
            QMessageBox.warning(self, "Error", "No company selected.")
            return

        account_data = self.account_combo.currentData()
        if account_data is None:
            QMessageBox.information(self, "Select Account", "Please select an account or summary view.")
            return

        from_date = self.from_date_edit.date().toPython()
        to_date = self.to_date_edit.date().toPython()

        try:
            # Check if it's a summary view
            if isinstance(account_data, str) and account_data.endswith('_summary'):
                self._load_summary_view(account_data, from_date, to_date)
            else:
                # Individual account - show detailed ledger
                self._load_detailed_ledger(int(account_data), from_date, to_date)
        except Exception as e:
            print(f"Error loading ledger: {e}")
            QMessageBox.critical(self, "Error", f"Failed to load ledger: {str(e)}")

    def _load_summary_view(self, summary_type: str, from_date: date, to_date: date):
        """Load summary view for multiple accounts using get_group_account_summary."""
        group_map = {
            'all_summary': 'all',
            'debtors_summary': 'debtors',
            'creditors_summary': 'creditors',
            'cash_bank_summary': 'cash_bank',
            'sales_summary': 'sales',
            'purchase_summary': 'purchase',
            'sales_return_summary': 'sales_return',
            'purchase_return_summary': 'purchase_return',
            'tax_summary': 'tax',
            'stock_summary': 'stock',
            'expense_summary': 'expense',
            'income_summary': 'income',
        }
        group = group_map.get(summary_type, 'all')

        summary_data = self.ledger_logic.get_group_account_summary(
            self.company_id, group, from_date, to_date
        )
        accounts = summary_data.get('accounts', [])
        totals = summary_data.get('totals', {})

        if not accounts:
            self.ledger_table.setRowCount(0)
            self._reset_summary()
            self.status_label.setText("No accounts found")
            return

        # Setup table for summary view
        self.ledger_table.setColumnCount(7)
        self.ledger_table.setHorizontalHeaderLabels([
            "SL No", "Account Name", "Type", "Opening Balance", "Debit", "Credit", "Closing Balance"
        ])

        self.ledger_table.setRowCount(len(accounts))
        for row, acct in enumerate(accounts):
            sl_item = QTableWidgetItem(str(row + 1))
            sl_item.setForeground(QColor(COLORS['text_secondary']))
            sl_item.setTextAlignment(Qt.AlignCenter)
            self.ledger_table.setItem(row, 0, sl_item)

            name_item = QTableWidgetItem(acct.get('account_name', ''))
            name_item.setForeground(QColor(COLORS['text_primary']))
            self.ledger_table.setItem(row, 1, name_item)

            type_item = QTableWidgetItem(acct.get('account_type', ''))
            type_item.setForeground(QColor(COLORS['text_secondary']))
            type_item.setTextAlignment(Qt.AlignCenter)
            self.ledger_table.setItem(row, 2, type_item)

            opening_item = QTableWidgetItem(acct.get('opening_formatted', '0.00'))
            opening_item.setForeground(QColor(COLORS['text_primary']))
            opening_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 3, opening_item)

            debit_item = QTableWidgetItem(f"{acct.get('period_debit', 0):,.2f}" if acct.get('period_debit', 0) > 0.001 else "")
            debit_item.setForeground(QColor("#4ade80"))
            debit_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 4, debit_item)

            credit_item = QTableWidgetItem(f"{acct.get('period_credit', 0):,.2f}" if acct.get('period_credit', 0) > 0.001 else "")
            credit_item.setForeground(QColor("#f87171"))
            credit_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 5, credit_item)

            closing_item = QTableWidgetItem(acct.get('closing_formatted', '0.00'))
            closing_item.setForeground(QColor(COLORS['text_primary']))
            closing_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 6, closing_item)

        self.opening_balance_label.setText("Opening: —")
        self.total_debit_label.setText(f"Debit: {totals.get('debit', 0):,.2f}")
        self.total_credit_label.setText(f"Credit: {totals.get('credit', 0):,.2f}")
        self.closing_balance_label.setText("Closing: —")
        self.status_label.setText(f"Showing {len(accounts)} accounts")

    def _load_detailed_ledger(self, account_id: int, from_date: date, to_date: date):
        """Load detailed ledger entries for a single account using get_account_ledger."""
        self.ledger_table.setColumnCount(7)
        self.ledger_table.setHorizontalHeaderLabels([
            "Date", "Voucher Type", "Voucher No", "Particulars/Narration",
            "Debit", "Credit", "Running Balance"
        ])

        ledger_data = self.ledger_logic.get_account_ledger(
            self.company_id, account_id, from_date, to_date
        )
        entries = ledger_data.get('entries', [])

        self.ledger_table.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            date_item = QTableWidgetItem(str(entry.get('voucher_date', '')))
            date_item.setForeground(QColor(COLORS['text_primary']))
            date_item.setTextAlignment(Qt.AlignCenter)
            self.ledger_table.setItem(row, 0, date_item)

            vtype_raw = str(entry.get('voucher_type', ''))
            vtype_display = vtype_raw.replace('_', ' ').title()
            vtype_item = QTableWidgetItem(vtype_display)
            vtype_item.setForeground(QColor(COLORS['text_secondary']))
            vtype_item.setTextAlignment(Qt.AlignCenter)
            self.ledger_table.setItem(row, 1, vtype_item)

            vno_item = QTableWidgetItem(entry.get('voucher_no', '') or '')
            vno_item.setForeground(QColor(COLORS['text_primary']))
            vno_item.setTextAlignment(Qt.AlignCenter)
            self.ledger_table.setItem(row, 2, vno_item)

            narr_item = QTableWidgetItem(entry.get('narration', '') or '')
            narr_item.setForeground(QColor(COLORS['text_primary']))
            self.ledger_table.setItem(row, 3, narr_item)

            debit = float(entry.get('debit', 0.0) or 0.0)
            debit_item = QTableWidgetItem(f"{debit:,.2f}" if debit > 0.001 else "")
            debit_item.setForeground(QColor("#4ade80"))
            debit_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 4, debit_item)

            credit = float(entry.get('credit', 0.0) or 0.0)
            credit_item = QTableWidgetItem(f"{credit:,.2f}" if credit > 0.001 else "")
            credit_item.setForeground(QColor("#f87171"))
            credit_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 5, credit_item)

            running_balance = float(entry.get('running_balance', 0.0) or 0.0)
            balance_item = QTableWidgetItem(self._fmt_balance(running_balance))
            balance_item.setForeground(QColor(COLORS['text_primary']))
            balance_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.ledger_table.setItem(row, 6, balance_item)

        self.opening_balance_label.setText(f"Opening: {ledger_data.get('opening_formatted', '0.00')}")
        self.total_debit_label.setText(f"Debit: {ledger_data.get('period_debit', 0):,.2f}")
        self.total_credit_label.setText(f"Credit: {ledger_data.get('period_credit', 0):,.2f}")
        self.closing_balance_label.setText(f"Closing: {ledger_data.get('closing_formatted', '0.00')}")
        self.status_label.setText(f"Showing {len(entries)} entries")

    def _reset_summary(self):
        """Reset summary labels."""
        self.opening_balance_label.setText("Opening: 0.00")
        self.total_debit_label.setText("Debit: 0.00")
        self.total_credit_label.setText("Credit: 0.00")
        self.closing_balance_label.setText("Closing: 0.00")
        self.status_label.setText("")

    def export_excel(self):
        """Export current ledger view to Excel."""
        if self.ledger_table.rowCount() == 0:
            QMessageBox.information(self, "No Data", "Please load ledger data first.")
            return

        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
        except ImportError:
            QMessageBox.warning(self, "Export Error", "Please install openpyxl:\npip install openpyxl")
            return

        from PySide6.QtWidgets import QFileDialog
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Ledger", "ledger.xlsx", "Excel Files (*.xlsx)"
        )
        if not file_path:
            return

        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Ledger"

            # Header style
            header_fill = PatternFill(start_color="1e3a5f", end_color="1e3a5f", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)
            thin_border = Border(bottom=Side(style='thin'))

            # Write headers
            headers = []
            for col in range(self.ledger_table.columnCount()):
                header_item = self.ledger_table.horizontalHeaderItem(col)
                headers.append(header_item.text() if header_item else "")
                cell = ws.cell(row=1, column=col + 1, value=headers[-1])
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center')

            # Write data
            for row in range(self.ledger_table.rowCount()):
                for col in range(self.ledger_table.columnCount()):
                    item = self.ledger_table.item(row, col)
                    value = item.text() if item else ""
                    cell = ws.cell(row=row + 2, column=col + 1, value=value)
                    cell.border = thin_border
                    if col >= 4:  # Numeric columns
                        cell.alignment = Alignment(horizontal='right')

            wb.save(file_path)
            QMessageBox.information(self, "Success", f"Ledger exported to:\n{file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))

    def refresh(self):
        """Refresh the ledger page."""
        self.company_id = active_company_manager.get_active_company_id() if active_company_manager else None
        if self.company_id:
            if not self.ledger_logic:
                self.ledger_logic = LedgerLogic(self.db)
            self.load_accounts()
            self.on_ledger_type_changed()
            self.ledger_table.setRowCount(0)
            self._reset_summary()
        else:
            self.account_combo.clear()
            self.ledger_table.setRowCount(0)
            self._reset_summary()
