#!/usr/bin/env python3
"""
Main entry point for the Accounting Desktop Application.
Uses PySide6 with Qt Widgets and SQLite database.
"""

import sys
import os
from PySide6.QtWidgets import QApplication, QMainWindow, QStackedWidget
from PySide6.QtCore import QSize
from PySide6.QtGui import QIcon

from config import APP_NAME, WINDOW_SIZE, MIN_WINDOW_SIZE, DATABASE_TYPE
from db import Database
from ui.main_window import MainWindow
from assets.styles.dark_theme import get_dark_stylesheet


def setup_application():
    """Initialize the QApplication with basic settings."""
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("Accounting Software")
    
    # Set application icon (if available)
    icon_path = os.path.join("assets", "icons", "app_icon.png")
    if os.path.exists(icon_path):
        app.setWindowIcon(QIcon(icon_path))
    
    return app


def main():
    """Main function to run the accounting application."""
    # Create QApplication
    app = setup_application()
    
    # Initialize database
    try:
        db = Database(db_type=DATABASE_TYPE)
        db.initialize_database()
        if db.db_type == "sqlite":
            print(f"Database initialized successfully (SQLite) at: {db.db_path}")
        else:
            print(f"Database initialized successfully (MySQL) at: {db.mysql_config['host']}:{db.mysql_config['port']}/{db.mysql_config['database']}")
    except Exception as e:
        print(f"Error initializing database: {e}")
        return 1
    
    # Create and show main window
    try:
        main_window = MainWindow(db)
        main_window.setWindowTitle(APP_NAME)
        main_window.resize(WINDOW_SIZE[0], WINDOW_SIZE[1])
        main_window.setMinimumSize(MIN_WINDOW_SIZE[0], MIN_WINDOW_SIZE[1])
        
        # Apply dark theme
        dark_stylesheet = get_dark_stylesheet()
        app.setStyleSheet(dark_stylesheet)
        
        main_window.show()
        
        # Run the application
        return app.exec()
    except Exception as e:
        print(f"Error creating main window: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
