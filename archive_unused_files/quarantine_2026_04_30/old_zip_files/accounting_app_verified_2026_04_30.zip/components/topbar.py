"""
Topbar component with app title, company info, and search functionality.
Provides the header area of the main application window.
"""

from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFrame, QSizePolicy
)
from PySide6.QtCore import Qt, Signal, QTimer
from PySide6.QtGui import QFont, QIcon

from config import COLORS, APP_NAME, active_company_manager
from db import Database


class TopbarWidget(QWidget):
    """Topbar with app title, company info, and search."""
    
    search_requested = Signal(str)
    
    def __init__(self, db=None):
        super().__init__()
        self.db = db or Database()
        self.setup_ui()
        self.setup_timer()
        self.update_title_display()
    
    def setup_ui(self):
        """Setup topbar UI."""
        self.setFixedHeight(60)
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {COLORS['surface']};
                border-bottom: 1px solid {COLORS['border']};
            }}
        """)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(20, 0, 20, 0)
        layout.setSpacing(15)
        
        # App title section
        title_section = self.create_title_section()
        layout.addWidget(title_section)
        
        # Spacer
        layout.addStretch()
        
        # Company status section removed (Active indicator now integrated in title section)
        
        # Spacer
        layout.addStretch()
        
        # Search section
        search_section = self.create_search_section()
        layout.addWidget(search_section)
        
        # User section
        user_section = self.create_user_section()
        layout.addWidget(user_section)
    
    def create_title_section(self) -> QWidget:
        """Create application title section with dynamic company name and Active indicator above."""
        title_widget = QWidget()
        title_layout = QVBoxLayout(title_widget)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(3)
        
        # Active indicator row (above company name)
        indicator_row = QWidget()
        indicator_row_layout = QHBoxLayout(indicator_row)
        indicator_row_layout.setContentsMargins(0, 0, 0, 0)
        indicator_row_layout.setSpacing(5)
        
        # Active indicator
        self.status_frame = QFrame()
        self.status_frame.setFixedSize(8, 8)
        self.status_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {COLORS['warning']};
                border-radius: 4px;
            }}
        """)
        indicator_row_layout.addWidget(self.status_frame)
        
        # Status text (optional, can be removed if not needed)
        self.status_label = QLabel("Setup Required")
        self.status_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['warning']};
                font-size: 10px;
                font-weight: 500;
            }}
        """)
        indicator_row_layout.addWidget(self.status_label)
        
        indicator_row_layout.addStretch()
        
        # Company name row
        self.app_title = QLabel(APP_NAME)
        self.app_title.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 18px;
                font-weight: bold;
            }}
        """)
        self.app_title.setMinimumWidth(200)
        self.app_title.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        
        title_layout.addWidget(indicator_row)
        title_layout.addWidget(self.app_title)
        
        return title_widget
    
    def create_company_section(self) -> QWidget:
        """Create company/status section with only Active indicator."""
        company_widget = QWidget()
        company_layout = QHBoxLayout(company_widget)
        company_layout.setContentsMargins(0, 0, 0, 0)
        company_layout.setSpacing(10)
        
        # Load active company from database
        active_company = self.db.get_active_company()
        
        # Status indicator only (no duplicate company name)
        self.status_frame = QFrame()
        self.status_frame.setFixedSize(8, 8)
        if active_company:
            status_color = COLORS['success']
            status_text = "Active"
        else:
            status_color = COLORS['warning']
            status_text = "Setup Required"
        
        self.status_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {status_color};
                border-radius: 4px;
            }}
        """)
        company_layout.addWidget(self.status_frame)
        
        # Status text
        self.status_label = QLabel(status_text)
        self.status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-size: 12px;
                font-weight: 500;
            }}
        """)
        company_layout.addWidget(self.status_label)
        
        return company_widget
    
    def setup_timer(self):
        """Setup timer for live date/time updates."""
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_datetime_display)
        self.timer.start(1000)  # Update every second
        self.update_datetime_display()  # Initial update
    
    def update_title_display(self):
        """Update title display based on active company state."""
        if active_company_manager.has_active_company():
            company_name = active_company_manager.get_active_company_name()
            self.app_title.setText(company_name)
            # Use highlight color for active company name
            self.app_title.setStyleSheet(f"""
                QLabel {{
                    color: #60a5fa;
                    font-size: 18px;
                    font-weight: bold;
                }}
            """)
        else:
            self.app_title.setText(APP_NAME)
            # Use normal style for default title
            self.app_title.setStyleSheet(f"""
                QLabel {{
                    color: {COLORS['text_primary']};
                    font-size: 18px;
                    font-weight: bold;
                }}
            """)
    
    def update_datetime_display(self):
        """Update date and time display."""
        from datetime import datetime
        now = datetime.now()
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        self.date_label.setText(date_str)
        self.time_label.setText(time_str)
    
    def update_active_company(self):
        """Update the active company display."""
        active_company = active_company_manager.get_active_company()
        
        if active_company:
            status_color = COLORS['success']
            status_text = "Active"
        else:
            status_color = COLORS['warning']
            status_text = "Setup Required"
        
        # Update status indicator
        self.status_frame.setStyleSheet(f"""
            QFrame {{
                background-color: {status_color};
                border-radius: 4px;
            }}
        """)
        
        # Update status text
        self.status_label.setText(status_text)
        self.status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-size: 10px;
                font-weight: 500;
            }}
        """)
        
        # Also update the title display
        self.update_title_display()
    
    def create_search_section(self) -> QWidget:
        """Create search section."""
        search_widget = QWidget()
        search_widget.setFixedWidth(350)  # Increased width for full visibility
        search_layout = QHBoxLayout(search_widget)
        search_layout.setContentsMargins(0, 0, 0, 0)
        search_layout.setSpacing(5)
        
        # Search input
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search transactions, accounts...")
        self.search_input.setStyleSheet(f"""
            QLineEdit {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['border']};
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 13px;
            }}
            QLineEdit:focus {{
                border-color: {COLORS['primary']};
            }}
        """)
        self.search_input.textChanged.connect(self.on_search_text_changed)
        search_layout.addWidget(self.search_input)
        
        # Search button
        search_btn = QPushButton("Search")
        search_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
            QPushButton:pressed {{
                background-color: {COLORS['primary']};
            }}
        """)
        search_btn.clicked.connect(self.perform_search)
        search_layout.addWidget(search_btn)
        
        return search_widget
    
    def create_user_section(self) -> QWidget:
        """Create user section."""
        user_widget = QWidget()
        user_layout = QHBoxLayout(user_widget)
        user_layout.setContentsMargins(0, 0, 0, 0)
        user_layout.setSpacing(10)
        
        # Date and time display (moved to far right with 2-line layout)
        datetime_widget = QWidget()
        datetime_layout = QVBoxLayout(datetime_widget)
        datetime_layout.setContentsMargins(0, 0, 0, 0)
        datetime_layout.setSpacing(2)
        
        # Date label
        self.date_label = QLabel()
        self.date_label.setStyleSheet(f"""
            QLabel {{
                color: #fbbf24;
                font-size: 12px;
                font-weight: bold;
            }}
        """)
        datetime_layout.addWidget(self.date_label)
        
        # Time label
        self.time_label = QLabel()
        self.time_label.setStyleSheet(f"""
            QLabel {{
                color: #fbbf24;
                font-size: 14px;
                font-weight: bold;
            }}
        """)
        datetime_layout.addWidget(self.time_label)
        
        user_layout.addWidget(datetime_widget)
        
        # User name
        user_label = QLabel("Admin User")
        user_label.setStyleSheet(f"""
            QLabel {{
                color: {COLORS['text_primary']};
                font-size: 13px;
                font-weight: 500;
            }}
        """)
        user_layout.addWidget(user_label)
        
        # Calculator button (modern accent style)
        calculator_btn = QPushButton()
        calculator_btn.setText("÷")  # Calculator symbol
        calculator_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['primary']};
                color: white;
                border: none;
                border-radius: 6px;
                padding: 8px;
                font-size: 14px;
                font-weight: bold;
                min-width: 32px;
                max-width: 32px;
                min-height: 32px;
                max-height: 32px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['primary_dark']};
            }}
            QPushButton:pressed {{
                background-color: {COLORS['primary_light']};
            }}
        """)
        calculator_btn.setToolTip("Calculator")
        calculator_btn.clicked.connect(self.open_calculator)
        user_layout.addWidget(calculator_btn)
        
        # Settings button
        settings_btn = QPushButton("Settings")
        settings_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {COLORS['text_secondary']};
                border: 1px solid {COLORS['border']};
                padding: 6px 12px;
                border-radius: 4px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {COLORS['card']};
                color: {COLORS['text_primary']};
            }}
        """)
        user_layout.addWidget(settings_btn)
        
        return user_widget
    
    def open_calculator(self):
        """Open calculator dialog."""
        from .calculator_dialog import CalculatorDialog
        calculator = CalculatorDialog(self)
        calculator.exec()
    
    def on_search_text_changed(self, text: str):
        """Handle search text changes."""
        # Could implement live search here
        pass
    
    def perform_search(self):
        """Perform search action."""
        search_text = self.search_input.text().strip()
        if search_text:
            self.search_requested.emit(search_text)
    
    def get_search_text(self) -> str:
        """Get current search text."""
        return self.search_input.text().strip()
    
    def clear_search(self):
        """Clear search input."""
        self.search_input.clear()
