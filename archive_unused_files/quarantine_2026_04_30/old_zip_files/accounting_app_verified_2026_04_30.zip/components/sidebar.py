# -*- coding: utf-8 -*-
"""
Sidebar component with accordion-style navigation menu for the Accounting Desktop Application.
Provides main menu navigation with icons and modern styling.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QFrame, QScrollArea, QLabel, QMessageBox
)
from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QIcon

from config import COLORS


class Sidebar(QWidget):
    """Sidebar with accordion-style navigation menu."""
    
    page_changed = Signal(str)
    company_closed = Signal()
    
    def __init__(self):
        super().__init__()
        self.current_open_section = None
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the sidebar UI."""
        self.setFixedWidth(280)
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {COLORS['sidebar']};
                border-right: 1px solid {COLORS['border']};
            }}
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # App title
        title_widget = self.create_app_title()
        layout.addWidget(title_widget)
        
        # Menu scroll area
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet(f"""
            QScrollArea {{
                border: none;
                background-color: transparent;
            }}
            QScrollBar:vertical {{
                background-color: {COLORS['surface']};
                width: 8px;
                border-radius: 4px;
            }}
            QScrollBar::handle:vertical {{
                background-color: {COLORS['border']};
                border-radius: 4px;
                min-height: 20px;
            }}
            QScrollBar::handle:vertical:hover {{
                background-color: {COLORS['border_focus']};
            }}
        """)
        
        menu_widget = QWidget()
        menu_layout = QVBoxLayout(menu_widget)
        menu_layout.setContentsMargins(10, 10, 10, 10)
        menu_layout.setSpacing(2)
        
        # Create menu sections
        self.menu_sections = {}
        menu_items = {
            "Dashboard": ["Dashboard Home"],
            "File": ["New Company", "Open Company", "Close Company", "Exit"],
            "Masters": ["Company", "Account", "Debitor/Creditor", "Bank Account", "Product/Service"],
            "Entry": ["Sales", "Sales Return", "Purchase", "Purchase Return", "Service Bill", "Quotation", "Purchase Order", "Cash Receipt", "Cash Payment", "Bank Receipt", "Bank Payment", "Post Dated Cheque", "Journal Entry", "Credit/Debit Note", "Van Entry", "Van Return Entry", "Opening Balance", "Opening Stock Entry", "Stock Adjustment", "Stock Transfer", "Expiration Entry", "Party Rate Entry", "Work Entry"],
            "Books": ["Ledger", "Sales Book", "GST Sales Report", "Generate GSTR-1", "Sales Return Book", "Sales Wise Profit", "Purchase Book", "GST Purchase Report", "Purchase Return Book", "Monthly Analyse", "Chart", "Sales Purchase Analyse Chart", "Service Book", "Work Book", "Quotation Book", "Purchase Order Book", "Day Book", "Cash Book", "Bank Book", "Post Dated Cheques", "Pending Bills", "Journals", "Stock Report", "Daily Stock Register", "Stock Value", "Price List", "Stock Adjustment Report", "Opening Stock"],
            "Reports": ["Trial Balance", "Profit and Loss Account", "Balance Sheet", "User Wise Report"],
            "Utilities": ["Barcode", "Stock Checker", "Backup Data", "Restore Data", "Rectify Account Balance", "Transfer Master Records", "User End Process", "Compact and Repair Data", "Win Block"],
            "Windows": ["Cascade"],
            "Settings": ["General Settings", "Tax Settings", "Invoice Settings", "User Settings"],
            "About Me": ["About Me"]
        }
        
        # Icons for main menu items - using SVG files
        menu_icons = {
            "Dashboard": "assets/icons/dashboard.svg",
            "File": "assets/icons/file.svg", 
            "Masters": "assets/icons/masters.svg",
            "Entry": "assets/icons/entry.svg",
            "Books": "assets/icons/books.svg",
            "Reports": "assets/icons/reports.svg",
            "Utilities": "assets/icons/utilities.svg",
            "Windows": "assets/icons/windows.svg",
            "Settings": "assets/icons/settings.svg",
            "About Me": "assets/icons/about.svg"
        }
        
        for section_name, subsections in menu_items.items():
            icon = menu_icons.get(section_name, "")
            section_widget = self.create_menu_section(section_name, subsections, icon)
            self.menu_sections[section_name] = section_widget
            menu_layout.addWidget(section_widget)
        
        menu_layout.addStretch()
        scroll_area.setWidget(menu_widget)
        layout.addWidget(scroll_area)
    
    def create_app_title(self) -> QWidget:
        """Create application title widget."""
        title_widget = QWidget()
        title_widget.setFixedHeight(60)
        title_widget.setStyleSheet(f"""
            QWidget {{
                background-color: {COLORS['primary']};
                border-bottom: 1px solid {COLORS['border']};
            }}
        """)
        
        title_layout = QHBoxLayout(title_widget)
        title_layout.setContentsMargins(15, 0, 15, 0)
        
        title_label = QLabel("Accounting Pro")
        title_label.setStyleSheet(f"""
            QLabel {{
                color: white;
                font-size: 16px;
                font-weight: bold;
            }}
        """)
        title_layout.addWidget(title_label)
        
        return title_widget
    
    def create_menu_section(self, section_name: str, subsections: list, icon: str = "") -> QWidget:
        """Create a menu section with accordion behavior."""
        section_widget = QFrame()
        section_widget.setStyleSheet(f"""
            QFrame {{
                background-color: transparent;
                border-radius: 6px;
                margin: 3px 0;
            }}
        """)
        
        section_layout = QVBoxLayout(section_widget)
        section_layout.setContentsMargins(0, 0, 0, 0)
        section_layout.setSpacing(0)
        
        # Section header button with icon
        header_btn = QPushButton(section_name)
        header_btn.setObjectName(f"header_{section_name}")
        
        # Set icon if available
        if icon:
            try:
                header_btn.setIcon(QIcon(icon))
                header_btn.setIconSize(QSize(24, 24))
            except Exception:
                # If icon not found, continue without icon
                pass
        
        # Store section name for active state tracking
        header_btn.section_name = section_name
        
        header_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: #cbd5e1;
                border: none;
                padding: 18px 20px 18px 20px;
                text-align: left;
                border-radius: 6px;
                font-size: 15px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: transparent;
                color: #60a5fa;
            }}
            QPushButton:pressed {{
                background-color: transparent;
                color: #2563eb;
            }}
        """)
        header_btn.clicked.connect(lambda checked, name=section_name: self.toggle_section(name))
        section_layout.addWidget(header_btn)
        
        # Subsections container
        subsections_widget = QWidget()
        subsections_widget.setObjectName(f"subsections_{section_name}")
        subsections_widget.setVisible(False)  # Initially collapsed
        
        subsections_layout = QVBoxLayout(subsections_widget)
        subsections_layout.setContentsMargins(25, 0, 0, 0)
        subsections_layout.setSpacing(1)
        
        # Create subsection buttons
        for subsection in subsections:
            sub_btn = QPushButton(subsection)
            sub_btn.setObjectName(f"sub_{subsection.replace(' ', '_')}")
            sub_btn.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: {COLORS['text_secondary']};
                    border: none;
                    padding: 14px 22px;
                    text-align: left;
                    border-radius: 4px;
                    font-size: 14px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    background-color: {COLORS['button_hover']};
                    color: {COLORS['text_primary']};
                }}
                QPushButton:pressed {{
                    background-color: {COLORS['primary']};
                    color: white;
                }}
            """)
            if subsection == "Close Company":
                sub_btn.clicked.connect(self.close_company)
            else:
                sub_btn.clicked.connect(lambda checked, name=subsection: self.page_changed.emit(name))
            subsections_layout.addWidget(sub_btn)
        
        section_layout.addWidget(subsections_widget)
        
        # Store references
        section_widget.header_btn = header_btn
        section_widget.subsections_widget = subsections_widget
        
        return section_widget
    
    def close_company(self):
        """Handle Close Company action with confirmation dialog."""
        from config import active_company_manager
        
        # Check if there's an active company to close
        if not active_company_manager.has_active_company():
            return
        
        # Show confirmation dialog with better background
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Question)
        msg_box.setWindowTitle("Close Company")
        msg_box.setText("Are you sure you want to close the active company?")
        msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg_box.setDefaultButton(QMessageBox.No)
        
        # Apply custom styling for better contrast
        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: #2d3748;
                color: #ffffff;
                border: 1px solid #4b5563;
                border-radius: 6px;
                padding: 20px;
                font-size: 14px;
            }
            QMessageBox QPushButton {
                background-color: #4b5563;
                color: #ffffff;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #3b82f6;
            }
        """)
        
        reply = msg_box.exec()
        
        if reply == QMessageBox.Yes:
            # User confirmed, close the company
            active_company_manager.clear_active_company()
            self.company_closed.emit()  # Emit signal for main window to handle
            self.page_changed.emit("Dashboard")  # Show dashboard after closing company
        # If No, do nothing and keep company open
    
    def toggle_section(self, section_name: str):
        """Toggle accordion section open/closed."""
        if self.current_open_section == section_name:
            # Close current section
            self.menu_sections[section_name].subsections_widget.setVisible(False)
            self.current_open_section = None
            self.update_button_style(self.menu_sections[section_name].header_btn, False)
        else:
            # Close previous section if open
            if self.current_open_section:
                self.menu_sections[self.current_open_section].subsections_widget.setVisible(False)
                self.update_button_style(self.menu_sections[self.current_open_section].header_btn, False)
            
            # Open new section
            self.menu_sections[section_name].subsections_widget.setVisible(True)
            self.current_open_section = section_name
            self.update_button_style(self.menu_sections[section_name].header_btn, True)
    
    def update_button_style(self, button, is_active):
        """Update button style based on active state."""
        if is_active:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: #2563eb;
                    border: none;
                    padding: 18px 20px 18px 20px;
                    text-align: left;
                    border-radius: 6px;
                    font-size: 15px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: transparent;
                    color: #60a5fa;
                }}
                QPushButton:pressed {{
                    background-color: transparent;
                    color: #2563eb;
                }}
            """)
        else:
            button.setStyleSheet(f"""
                QPushButton {{
                    background-color: transparent;
                    color: #cbd5e1;
                    border: none;
                    padding: 18px 20px 18px 20px;
                    text-align: left;
                    border-radius: 6px;
                    font-size: 15px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: transparent;
                    color: #60a5fa;
                }}
                QPushButton:pressed {{
                    background-color: transparent;
                    color: #2563eb;
                }}
            """)
    
    def open_section(self, section_name: str):
        """Open specific section."""
        if section_name in self.menu_sections:
            self.toggle_section(section_name)
