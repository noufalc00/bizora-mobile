"""
Purchase Logic Module
Handles purchase business logic and validation.
"""

from typing import Dict, Any, List, Optional
from .stock_logic import StockLogic


class PurchaseLogic:
    """Business logic for purchase operations."""

    def __init__(self, db):
        """Initialize purchase logic with database instance."""
        self.db = db
        self.stock_logic = StockLogic(db)
        self.ledger_logic = None  # Lazy load ledger_logic when needed

    def _get_ledger_logic(self):
        """Lazy load ledger_logic."""
        if self.ledger_logic is None:
            from .ledger_logic import LedgerLogic
            self.ledger_logic = LedgerLogic(self.db)
        return self.ledger_logic

    def get_purchases(self, company_id: int) -> Dict[str, Any]:
        """
        Get all purchases for a company.

        Returns:
            Dict with success status, message, and data
        """
        try:
            purchases = self.db.get_purchases_by_company(company_id)
            return {
                "success": True,
                "message": "Purchases retrieved successfully",
                "data": purchases
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchases: {str(e)}",
                "data": []
            }

    def get_purchase_by_id(self, company_id: int, purchase_id: int) -> Dict[str, Any]:
        """
        Get a specific purchase by ID.

        Returns:
            Dict with success status, message, and data
        """
        try:
            purchase = self.db.get_purchase_by_id(company_id, purchase_id)
            if purchase:
                return {
                    "success": True,
                    "message": "Purchase retrieved successfully",
                    "data": purchase
                }
            else:
                return {
                    "success": False,
                    "message": "Purchase not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchase: {str(e)}",
                "data": None
            }

    def get_purchase_items(self, purchase_id: int) -> Dict[str, Any]:
        """
        Get all items for a specific purchase.

        Returns:
            Dict with success status, message, and data
        """
        try:
            items = self.db.get_purchase_items(purchase_id)
            return {
                "success": True,
                "message": "Purchase items retrieved successfully",
                "data": items
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchase items: {str(e)}",
                "data": []
            }

    def validate_purchase_data(self, purchase_data: Dict[str, Any],
                               current_purchase_id: Optional[int] = None,
                               company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Validate purchase data.

        Returns:
            Dict with success status and message
        """
        # Check required fields
        if not purchase_data.get('purchase_number', '').strip():
            return {
                "success": False,
                "message": "Purchase Number is required"
            }

        if not purchase_data.get('purchase_date', '').strip():
            return {
                "success": False,
                "message": "Purchase Date is required"
            }

        if not purchase_data.get('party_id'):
            return {
                "success": False,
                "message": "Creditor/Party is required"
            }

        # Check for duplicate purchase number if company_id is provided
        if company_id:
            exists = self.db.purchase_number_exists(company_id, purchase_data['purchase_number'].strip(), current_purchase_id)
            if exists:
                return {
                    "success": False,
                    "message": "Purchase Number already exists"
                }

        return {
            "success": True,
            "message": "Purchase data is valid"
        }

    def normalize_purchase_data(self, purchase_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize purchase data by trimming and converting types.

        Returns:
            Normalized purchase data
        """
        return {
            'purchase_number': str(purchase_data.get('purchase_number', '')).strip(),
            'purchase_date': str(purchase_data.get('purchase_date', '')).strip(),
            'party_id': int(purchase_data.get('party_id', 0)),
            'purchase_type': str(purchase_data.get('purchase_type', 'Cash')).strip(),
            'bill_series': str(purchase_data.get('bill_series', '')).strip(),
            'nature': str(purchase_data.get('nature', '')).strip(),
            'due_date': str(purchase_data.get('due_date', '')).strip() if purchase_data.get('due_date') else None,
            'address': str(purchase_data.get('address', '')).strip(),
            'gstin': str(purchase_data.get('gstin', '')).strip().upper(),
            'state': str(purchase_data.get('state', '')).strip(),
            'narration': str(purchase_data.get('narration', '')).strip(),
            'sub_total': float(purchase_data.get('sub_total', 0.0)),
            'discount_total': float(purchase_data.get('discount_total', 0.0)),
            'tax_total': float(purchase_data.get('tax_total', 0.0)),
            'round_off': float(purchase_data.get('round_off', 0.0)),
            'purchase_expense': float(purchase_data.get('purchase_expense', 0.0)),
            'grand_total': float(purchase_data.get('grand_total', 0.0)),
            'amount_paid': float(purchase_data.get('amount_paid', 0.0))
        }

    def save_purchase(self, company_id: int, purchase_data: Dict[str, Any],
                     purchase_items: List[Dict[str, Any]],
                     current_purchase_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Save a purchase (create or update).

        Args:
            company_id: Company ID
            purchase_data: Dictionary containing purchase header information
            purchase_items: List of dictionaries containing purchase item information
            current_purchase_id: Purchase ID (None for create, ID for update)

        Returns:
            Dictionary with operation result
        """
        # Validate purchase data
        validation = self.validate_purchase_data(purchase_data, current_purchase_id, company_id)
        if not validation['success']:
            return {
                'success': False,
                'message': validation['message'],
                'errors': None,
                'data': None
            }

        # Normalize purchase data
        normalized_data = self.normalize_purchase_data(purchase_data)

        try:
            if current_purchase_id:
                # ---------- UPDATE EXISTING PURCHASE ----------
                old_items = self.db.get_purchase_items(current_purchase_id) or []

                # Replace stock movements before touching items (clean delete+insert)
                stock_result = self.stock_logic.adjust_purchase_stock_movements(
                    company_id, current_purchase_id, old_items, purchase_items
                )
                if not stock_result['success']:
                    return {
                        'success': False,
                        'message': f'Stock adjustment failed: {stock_result["message"]}',
                        'errors': None,
                        'data': None
                    }

                # Update purchase header (header-only, 3-arg call)
                self.db.update_purchase(company_id, current_purchase_id, normalized_data)

                # Replace items
                self.db.delete_purchase_items_by_purchase(current_purchase_id)
                for item_data in purchase_items:
                    self.db.insert_purchase_item(current_purchase_id, item_data)

                # Update ledger entries: delete old, then repost fresh
                try:
                    ledger_logic = self._get_ledger_logic()
                    ledger_logic.delete_voucher_entries(company_id, 'purchase', current_purchase_id)
                    ledger_logic.post_purchase_voucher(company_id, current_purchase_id, normalized_data, purchase_items)
                except Exception as e:
                    print(f"Warning: Ledger update failed: {e}")

                return {
                    'success': True,
                    'message': 'Purchase updated successfully',
                    'errors': None,
                    'data': {'purchase_id': current_purchase_id}
                }

            # ---------- CREATE NEW PURCHASE ----------
            purchase_id = self.db.save_purchase(company_id, normalized_data, purchase_items)
            if purchase_id:
                # Apply stock movements via stock_logic (authoritative)
                # Note: db.save_purchase also inserts movements for backward compat;
                # stock_logic sync corrects the products.quantity cache.
                for item in purchase_items:
                    pid = item.get('product_id')
                    if pid:
                        self.stock_logic.sync_product_quantity_from_movements(company_id, pid)

                # Post ledger entries
                try:
                    ledger_logic = self._get_ledger_logic()
                    ledger_logic.post_purchase_voucher(company_id, purchase_id, normalized_data, purchase_items)
                except Exception as e:
                    print(f"Warning: Ledger posting failed: {e}")

                return {
                    'success': True,
                    'message': 'Purchase saved successfully',
                    'errors': None,
                    'data': {'purchase_id': purchase_id}
                }
            return {
                'success': False,
                'message': 'Failed to save purchase',
                'errors': None,
                'data': None
            }

        except Exception as e:
            return {
                'success': False,
                'message': f'Error saving purchase: {str(e)}',
                'errors': None,
                'data': None
            }

    def delete_purchase(self, company_id: int, purchase_id: int) -> Dict[str, Any]:
        """
        Delete a purchase.

        Args:
            company_id: Company ID
            purchase_id: Purchase ID

        Returns:
            Dictionary with operation result
        """
        try:
            # Reverse stock movements BEFORE deleting purchase (items still exist)
            stock_result = self.stock_logic.reverse_purchase_stock_movements(company_id, purchase_id)
            if not stock_result['success']:
                return {
                    'success': False,
                    'message': f'Stock reversal failed: {stock_result["message"]}'
                }

            # Delete purchase header (cascade deletes purchase_items)
            success = self.db.delete_purchase(company_id, purchase_id)

            # Delete ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'purchase', purchase_id)
            except Exception as e:
                print(f"Warning: Ledger entry deletion failed: {e}")

            if success:
                return {
                    'success': True,
                    'message': 'Purchase deleted successfully'
                }
            else:
                return {
                    'success': False,
                    'message': 'Failed to delete purchase'
                }

        except Exception as e:
            return {
                'success': False,
                'message': f'Failed to delete purchase: {str(e)}'
            }
