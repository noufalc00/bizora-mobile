"""
Logic package for business logic layer.
"""
