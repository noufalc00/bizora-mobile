"""
Purchase Return Logic Module
Handles purchase return business logic and validation.
"""

from typing import Dict, Any, List, Optional
from .stock_logic import StockLogic


class PurchaseReturnLogic:
    """Business logic for purchase return operations."""

    def __init__(self, db):
        """Initialize purchase return logic with database instance."""
        self.db = db
        self.stock_logic = StockLogic(db)
        self.ledger_logic = None

    def _get_ledger_logic(self):
        """Lazy load ledger_logic."""
        if self.ledger_logic is None:
            from .ledger_logic import LedgerLogic
            self.ledger_logic = LedgerLogic(self.db)
        return self.ledger_logic

    def get_purchase_returns(self, company_id: int) -> Dict[str, Any]:
        """
        Get all purchase returns for a company.

        Returns:
            Dict with success status, message, and data
        """
        try:
            purchase_returns = self.db.get_purchase_returns_by_company(company_id)
            return {
                "success": True,
                "message": "Purchase returns retrieved successfully",
                "data": purchase_returns
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchase returns: {str(e)}",
                "data": []
            }

    def get_purchase_return_by_id(self, company_id: int, purchase_return_id: int) -> Dict[str, Any]:
        """
        Get a specific purchase return by ID.

        Returns:
            Dict with success status, message, and data
        """
        try:
            purchase_return = self.db.get_purchase_return_by_id(company_id, purchase_return_id)
            if purchase_return:
                return {
                    "success": True,
                    "message": "Purchase return retrieved successfully",
                    "data": purchase_return
                }
            else:
                return {
                    "success": False,
                    "message": "Purchase return not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchase return: {str(e)}",
                "data": None
            }

    def get_purchase_return_items(self, purchase_return_id: int) -> Dict[str, Any]:
        """
        Get all items for a specific purchase return.

        Returns:
            Dict with success status, message, and data
        """
        try:
            items = self.db.get_purchase_return_items(purchase_return_id)
            return {
                "success": True,
                "message": "Purchase return items retrieved successfully",
                "data": items
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve purchase return items: {str(e)}",
                "data": []
            }

    def validate_purchase_return_data(self, purchase_return_data: Dict[str, Any],
                                      current_purchase_return_id: Optional[int] = None) -> Dict[str, Any]:
        """Validate purchase return data. party_id is required only for Credit returns."""
        company_id = purchase_return_data.get('company_id')
        if not company_id:
            return {"success": False, "message": "Missing required field: company_id"}

        return_no = purchase_return_data.get('return_no', '').strip()
        if not return_no:
            return {"success": False, "message": "Missing required field: return_no"}

        if not purchase_return_data.get('return_date'):
            return {"success": False, "message": "Missing required field: return_date"}

        return_type = purchase_return_data.get('return_type', 'Cash')
        if return_type == 'Credit' and not purchase_return_data.get('party_id'):
            return {"success": False, "message": "Credit return requires a party (creditor)."}

        items = purchase_return_data.get('items', [])
        if not items:
            return {"success": False, "message": "Purchase return must have at least one item."}

        for idx, item in enumerate(items):
            if not item.get('product_id'):
                return {"success": False, "message": f"Item {idx + 1}: Missing product."}
            if float(item.get('quantity', 0)) <= 0:
                return {"success": False, "message": f"Item {idx + 1}: Quantity must be > 0."}

        # Uniqueness check only on new save
        if current_purchase_return_id is None:
            existing = self.db.get_purchase_return_by_return_no(company_id, return_no)
            if existing:
                return {"success": False, "message": f"Return No '{return_no}' already exists."}

        return {"success": True, "message": "Valid"}

    def save_purchase_return(self, purchase_return_data: Dict[str, Any]) -> Dict[str, Any]:
        """Save a new purchase return with items and stock movements."""
        try:
            validation = self.validate_purchase_return_data(purchase_return_data)
            if not validation['success']:
                return validation

            company_id = purchase_return_data['company_id']

            # Save header
            purchase_return_id = self.db.insert_purchase_return(company_id, purchase_return_data)
            if not purchase_return_id:
                return {"success": False, "message": "Failed to insert purchase return header."}

            # Save items
            items = purchase_return_data.get('items', [])
            for item in items:
                self.db.insert_purchase_return_item(purchase_return_id, item)

            # Apply stock movements (purchase return = stock OUT = negative qty)
            self.stock_logic.apply_purchase_return_stock_movements(
                company_id, purchase_return_id, items
            )

            # Post ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.post_purchase_return_voucher(
                    company_id, purchase_return_id, purchase_return_data, items
                )
            except Exception as e:
                print(f"Warning: Purchase return ledger posting failed: {e}")

            return {
                "success": True,
                "message": "Purchase return saved successfully",
                "purchase_return_id": purchase_return_id
            }

        except Exception as e:
            return {"success": False, "message": f"Failed to save purchase return: {str(e)}"}

    def update_purchase_return(self, purchase_return_id: int, purchase_return_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing purchase return - replace items and stock movements."""
        try:
            company_id = purchase_return_data['company_id']

            validation = self.validate_purchase_return_data(
                purchase_return_data, current_purchase_return_id=purchase_return_id
            )
            if not validation['success']:
                return validation

            # Get old items for stock reversal
            old_items_result = self.get_purchase_return_items(purchase_return_id)
            old_items = old_items_result.get('data', []) if old_items_result.get('success') else []

            # Adjust stock movements (delete old, insert new)
            new_items = purchase_return_data.get('items', [])
            self.stock_logic.adjust_purchase_return_stock_movements(
                company_id, purchase_return_id, old_items, new_items
            )

            # Update header
            self.db.update_purchase_return(purchase_return_id, purchase_return_data)

            # Replace items
            self.db.delete_purchase_return_items(purchase_return_id)
            for item in new_items:
                self.db.insert_purchase_return_item(purchase_return_id, item)

            # Update ledger entries: delete old, repost fresh
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'purchase_return', purchase_return_id)
                ledger_logic.post_purchase_return_voucher(
                    company_id, purchase_return_id, purchase_return_data, new_items
                )
            except Exception as e:
                print(f"Warning: Purchase return ledger update failed: {e}")

            return {"success": True, "message": "Purchase return updated successfully"}

        except Exception as e:
            return {"success": False, "message": f"Failed to update purchase return: {str(e)}"}

    def delete_purchase_return(self, company_id: int, purchase_return_id: int) -> Dict[str, Any]:
        """Delete a purchase return and reverse its stock movements."""
        try:
            existing = self.get_purchase_return_by_id(company_id, purchase_return_id)
            if not existing['success']:
                return existing

            # Reverse stock movements first
            self.stock_logic.reverse_purchase_return_stock_movements(company_id, purchase_return_id)

            # Delete items then header (cascade handles items but explicit is safer)
            self.db.delete_purchase_return_items(purchase_return_id)
            self.db.delete_purchase_return(purchase_return_id)

            # Delete ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'purchase_return', purchase_return_id)
            except Exception as e:
                print(f"Warning: Purchase return ledger deletion failed: {e}")

            return {"success": True, "message": "Purchase return deleted successfully"}

        except Exception as e:
            return {"success": False, "message": f"Failed to delete purchase return: {str(e)}"}

    def get_next_return_no(self, company_id: int) -> str:
        """
        Get next return number for a company.

        Returns:
            Next return number as string
        """
        try:
            last_return = self.db.get_last_purchase_return_no(company_id)
            if last_return:
                # Extract numeric part and increment
                try:
                    num = int(last_return)
                    return str(num + 1)
                except ValueError:
                    return "1"
            return "1"
        except Exception as e:
            return "1"
