"""
Ledger Logic Module — Commercial Double-Entry Accounting Engine.

Supports:
- System account creation per company (all required types)
- Party account auto-creation and linking
- Voucher posting: Sales, Purchase, Sales Return, Purchase Return
- Proper GST/CESS split entries (CGST/SGST for local, IGST for inter-state)
- Delete-and-repost on edit, delete on void
- Running balance rebuild after any change
- SQLite/MySQL compatible via db.py helpers
"""

from typing import Dict, List, Any, Optional, Tuple
from datetime import date, datetime


class LedgerLogic:
    """Core ledger logic for double-entry accounting operations."""

    def __init__(self, db):
        """
        Initialize ledger logic with database connection.

        Args:
            db: Database instance (db.Database)
        """
        self.db = db
        # Cache system accounts per company_id to avoid repeated DB queries
        self._system_accounts_cache: Dict[int, Dict[str, Any]] = {}

    # ============================================================
    # ACCOUNT METHODS
    # ============================================================

    def _load_system_accounts_cache(self, company_id: int) -> None:
        """Load all system accounts for company into cache in one query."""
        try:
            placeholder = self.db._get_placeholder()
            result = self.db.execute_query(
                f"SELECT id, account_name, account_code, account_type, group_name FROM ledger_accounts WHERE company_id = {placeholder} AND is_system = 1",
                (company_id,)
            )
            self._system_accounts_cache[company_id] = {
                row['account_name']: dict(row) for row in result
            }
        except Exception as e:
            print(f"Error loading system accounts cache: {e}")
            self._system_accounts_cache[company_id] = {}

    def get_account_by_name_cached(self, company_id: int, account_name: str) -> Optional[Dict[str, Any]]:
        """Get system account from cache (no DB query if already loaded)."""
        if company_id not in self._system_accounts_cache:
            self._load_system_accounts_cache(company_id)
        return self._system_accounts_cache.get(company_id, {}).get(account_name)

    def invalidate_accounts_cache(self, company_id: int) -> None:
        """Invalidate cache when accounts are created/modified."""
        self._system_accounts_cache.pop(company_id, None)

    # Required system accounts: (name, code, type, group, ob_type)
    _SYSTEM_ACCOUNTS = [
        ('Cash Account',            'CASH',       'cash_bank',    'Cash & Bank',       'Dr'),
        ('Bank Account',            'BANK',       'cash_bank',    'Cash & Bank',       'Dr'),
        ('Sundry Debtors',          'DEBTORS',    'party',        'Current Assets',    'Dr'),
        ('Sundry Creditors',        'CREDITORS',  'party',        'Current Liabilities','Cr'),
        ('Stock Account',           'STOCK',      'stock',        'Current Assets',    'Dr'),
        ('Sales Account',           'SALES',      'income',       'Income',            'Cr'),
        ('Purchase Account',        'PURCHASE',   'expense',      'Purchase',          'Dr'),
        ('Sales Return Account',    'SALES_RET',  'expense',      'Returns',           'Dr'),
        ('Purchase Return Account', 'PUR_RET',    'income',       'Returns',           'Cr'),
        ('Output CGST',             'CGST_OUT',   'tax_liability','Tax',               'Cr'),
        ('Output SGST',             'SGST_OUT',   'tax_liability','Tax',               'Cr'),
        ('Output IGST',             'IGST_OUT',   'tax_liability','Tax',               'Cr'),
        ('Output CESS',             'CESS_OUT',   'tax_liability','Tax',               'Cr'),
        ('Input CGST',              'CGST_IN',    'tax_liability','Tax',               'Dr'),
        ('Input SGST',              'SGST_IN',    'tax_liability','Tax',               'Dr'),
        ('Input IGST',              'IGST_IN',    'tax_liability','Tax',               'Dr'),
        ('Input CESS',              'CESS_IN',    'tax_liability','Tax',               'Dr'),
        ('GST Payable',             'GST_PAY',    'tax_liability','Tax',               'Cr'),
        ('GST Receivable',          'GST_REC',    'tax_liability','Tax',               'Dr'),
        ('Capital Account',         'CAPITAL',    'capital',      'Capital',           'Cr'),
        ('Suspense Account',        'SUSPENSE',   'expense',      'Suspense',          'Dr'),
    ]

    def ensure_system_accounts(self, company_id: int) -> bool:
        """Ensure all required system accounts exist for a company."""
        if company_id in self._system_accounts_cache and self._system_accounts_cache[company_id]:
            return True
        try:
            conn = self.db.connect()
            cursor = conn.cursor()
            placeholder = self.db._get_placeholder()
            ts = self.db._get_timestamp_default()
            for name, code, actype, group, ob_type in self._SYSTEM_ACCOUNTS:
                cursor.execute(
                    f"SELECT id FROM ledger_accounts WHERE company_id={placeholder} AND account_name={placeholder}",
                    (company_id, name)
                )
                if not cursor.fetchone():
                    cursor.execute(
                        f"""INSERT INTO ledger_accounts (company_id, account_name, account_code,
                            account_type, group_name, opening_balance, opening_balance_type,
                            is_system, is_active, created_at, updated_at)
                           VALUES ({placeholder},{placeholder},{placeholder},{placeholder},{placeholder},
                                   0.0,{placeholder},1,1,{ts},{ts})""",
                        (company_id, name, code, actype, group, ob_type)
                    )
            conn.commit()
            self.db.disconnect()
            self.invalidate_accounts_cache(company_id)
            self._load_system_accounts_cache(company_id)
            return True
        except Exception as e:
            print(f"Error ensuring system accounts: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return False

    # ============================================================
    # PARTY ACCOUNT METHODS
    # ============================================================

    def get_or_create_party_account(self, company_id: int, party_id: int,
                                    party_name: str, party_type: str,
                                    opening_balance: float = 0.0,
                                    opening_balance_type: str = 'Dr') -> Optional[Dict[str, Any]]:
        """Get or create a ledger account for a party and link it.

        party_type: 'Debitor', 'Creditor', or 'Both'
        opening_balance_type: 'Dr' for debitors, 'Cr' for creditors
        Returns the ledger account dict or None on failure.
        """
        try:
            placeholder = self.db._get_placeholder()
            # Check if party already has a linked ledger_account_id
            result = self.db.execute_query(
                f"SELECT ledger_account_id FROM parties WHERE id={placeholder} AND company_id={placeholder}",
                (party_id, company_id)
            )
            if result and result[0]['ledger_account_id']:
                acct = self.get_account(company_id, result[0]['ledger_account_id'])
                if acct:
                    return acct

            # Look up by name
            existing = self.get_account_by_name(company_id, party_name)
            if not existing:
                # Determine ob_type from party_type
                if party_type in ('Creditor',):
                    ob_type = 'Cr'
                else:
                    ob_type = 'Dr'
                if opening_balance_type:
                    ob_type = opening_balance_type
                acct_id = self.create_account(company_id, {
                    'account_name': party_name,
                    'account_code': None,
                    'account_type': 'party',
                    'group_name': 'Sundry Debtors' if ob_type == 'Dr' else 'Sundry Creditors',
                    'opening_balance': opening_balance,
                    'opening_balance_type': ob_type,
                })
                if not acct_id:
                    return None
                existing = self.get_account(company_id, acct_id)

            # Link the account to the party
            try:
                conn = self.db.connect()
                cursor = conn.cursor()
                cursor.execute(
                    f"UPDATE parties SET ledger_account_id={placeholder} WHERE id={placeholder} AND company_id={placeholder}",
                    (existing['id'], party_id, company_id)
                )
                conn.commit()
                self.db.disconnect()
            except Exception as e:
                print(f"Warning: could not link party ledger: {e}")
            return existing
        except Exception as e:
            print(f"Error get_or_create_party_account: {e}")
            return None

    def get_account_by_party_id(self, company_id: int, party_id: int) -> Optional[Dict[str, Any]]:
        """Get the linked ledger account for a party by party_id."""
        try:
            placeholder = self.db._get_placeholder()
            result = self.db.execute_query(
                f"SELECT ledger_account_id FROM parties WHERE id={placeholder} AND company_id={placeholder}",
                (party_id, company_id)
            )
            if result and result[0]['ledger_account_id']:
                return self.get_account(company_id, result[0]['ledger_account_id'])
            # Fallback: look up by party name
            party_result = self.db.execute_query(
                f"SELECT name, party_type, opening_balance FROM parties WHERE id={placeholder} AND company_id={placeholder}",
                (party_id, company_id)
            )
            if party_result:
                p = party_result[0]
                ptype = p.get('party_type', 'Debitor')
                ob = float(p.get('opening_balance', 0.0) or 0.0)
                ob_type = 'Cr' if ptype == 'Creditor' else 'Dr'
                return self.get_or_create_party_account(
                    company_id, party_id, p['name'], ptype, ob, ob_type
                )
            return None
        except Exception as e:
            print(f"Error get_account_by_party_id: {e}")
            return None

    def create_account(self, company_id: int, account_data: Dict[str, Any]) -> Optional[int]:
        """
        Create a new ledger account.

        Args:
            company_id: Company ID
            account_data: Dictionary with account details
                - account_name
                - account_code (optional)
                - account_type (party, cash_bank, income, expense, tax_liability, capital, stock)
                - group_name (optional)
                - opening_balance (optional, default 0)
                - opening_balance_type (optional, default 'Dr')

        Returns:
            Account ID if successful, None otherwise
        """
        try:
            conn = self.db.connect()
            cursor = conn.cursor()

            timestamp_default = self.db._get_timestamp_default()
            placeholder = self.db._get_placeholder()
            query = f"""
                INSERT INTO ledger_accounts (
                    company_id, account_name, account_code, account_type, group_name,
                    opening_balance, opening_balance_type, is_system, is_active,
                    created_at, updated_at
                ) VALUES ({placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder},
                    {placeholder}, {placeholder}, 0, 1, {timestamp_default}, {timestamp_default})
            """
            params = (
                company_id,
                account_data.get('account_name'),
                account_data.get('account_code'),
                account_data.get('account_type'),
                account_data.get('group_name'),
                account_data.get('opening_balance', 0.0),
                account_data.get('opening_balance_type', 'Dr')
            )
            cursor.execute(query, params)

            account_id = self.db._get_last_insert_id(cursor)
            conn.commit()
            self.db.disconnect()
            return account_id
        except Exception as e:
            print(f"Error creating account: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return None

    def update_account(self, company_id: int, account_id: int, account_data: Dict[str, Any]) -> bool:
        """
        Update an existing ledger account.

        Args:
            company_id: Company ID
            account_id: Account ID
            account_data: Dictionary with fields to update

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = self.db.connect()
            cursor = conn.cursor()

            # Build dynamic update query
            update_fields = []
            params = []
            timestamp_default = self.db._get_timestamp_default()
            placeholder = self.db._get_placeholder()

            if 'account_name' in account_data:
                update_fields.append(f"account_name = {placeholder}")
                params.append(account_data['account_name'])
            if 'account_code' in account_data:
                update_fields.append(f"account_code = {placeholder}")
                params.append(account_data['account_code'])
            if 'account_type' in account_data:
                update_fields.append(f"account_type = {placeholder}")
                params.append(account_data['account_type'])
            if 'group_name' in account_data:
                update_fields.append(f"group_name = {placeholder}")
                params.append(account_data['group_name'])
            if 'opening_balance' in account_data:
                update_fields.append(f"opening_balance = {placeholder}")
                params.append(account_data['opening_balance'])
            if 'opening_balance_type' in account_data:
                update_fields.append(f"opening_balance_type = {placeholder}")
                params.append(account_data['opening_balance_type'])
            if 'is_active' in account_data:
                update_fields.append(f"is_active = {placeholder}")
                params.append(account_data['is_active'])

            if not update_fields:
                self.db.disconnect()
                return True

            update_fields.append(f"updated_at = {timestamp_default}")
            params.extend([company_id, account_id])

            query = f"""
                UPDATE ledger_accounts
                SET {', '.join(update_fields)}
                WHERE company_id = {placeholder} AND id = {placeholder}
            """
            cursor.execute(query, params)

            conn.commit()
            self.db.disconnect()
            return True
        except Exception as e:
            print(f"Error updating account: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return False

    def get_account(self, company_id: int, account_id: int) -> Optional[Dict[str, Any]]:
        """
        Get account details by ID.

        Args:
            company_id: Company ID
            account_id: Account ID

        Returns:
            Account dictionary if found, None otherwise
        """
        try:
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT id, company_id, account_name, account_code, account_type,
                       group_name, opening_balance, opening_balance_type, is_system, is_active
                FROM ledger_accounts
                WHERE company_id = {placeholder} AND id = {placeholder}
            """
            result = self.db.execute_query(query, (company_id, account_id))
            return result[0] if result else None
        except Exception as e:
            print(f"Error getting account: {e}")
            return None

    def get_account_by_name(self, company_id: int, account_name: str) -> Optional[Dict[str, Any]]:
        """
        Get account details by name.

        Args:
            company_id: Company ID
            account_name: Account name

        Returns:
            Account dictionary if found, None otherwise
        """
        try:
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT id, company_id, account_name, account_code, account_type,
                       group_name, opening_balance, opening_balance_type, is_system, is_active
                FROM ledger_accounts
                WHERE company_id = {placeholder} AND account_name = {placeholder}
            """
            result = self.db.execute_query(query, (company_id, account_name))
            return result[0] if result else None
        except Exception as e:
            print(f"Error getting account by name: {e}")
            return None

    def search_accounts(self, company_id: int, search_term: str = None,
                      account_type: str = None, is_active: bool = True) -> List[Dict[str, Any]]:
        """
        Search accounts with optional filters.

        Args:
            company_id: Company ID
            search_term: Optional search term for account name/code
            account_type: Optional account type filter
            is_active: Filter by active status (default True)

        Returns:
            List of account dictionaries
        """
        try:
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT id, company_id, account_name, account_code, account_type,
                       group_name, opening_balance, opening_balance_type, is_system, is_active
                FROM ledger_accounts
                WHERE company_id = {placeholder}
            """
            params = [company_id]

            if search_term:
                query += f" AND (account_name LIKE {placeholder} OR account_code LIKE {placeholder})"
                params.extend([f"%{search_term}%", f"%{search_term}%"])

            if account_type:
                query += f" AND account_type = {placeholder}"
                params.append(account_type)

            if is_active is not None:
                query += f" AND is_active = {placeholder}"
                params.append(1 if is_active else 0)

            query += " ORDER BY account_name"

            return self.db.execute_query(query, params)
        except Exception as e:
            print(f"Error searching accounts: {e}")
            return []

    # ============================================================
    # LEDGER METHODS
    # ============================================================

    def post_entry(self, company_id: int, entry_data: Dict[str, Any]) -> Optional[int]:
        """
        Post a single ledger entry.

        Args:
            company_id: Company ID
            entry_data: Dictionary with entry details
                - voucher_type (sales, purchase, receipt, payment, journal)
                - voucher_id (ID of the voucher record)
                - voucher_no (voucher number)
                - voucher_date
                - account_id
                - contra_account_id (optional)
                - narration (optional)
                - debit
                - credit
                - reference_type (optional)
                - reference_id (optional)

        Returns:
            Entry ID if successful, None otherwise
        """
        try:
            conn = self.db.connect()
            cursor = conn.cursor()

            timestamp_default = self.db._get_timestamp_default()
            placeholder = self.db._get_placeholder()
            query = f"""
                INSERT INTO ledger_entries (
                    company_id, voucher_type, voucher_id, voucher_no, voucher_date,
                    account_id, contra_account_id, narration, debit, credit, running_balance,
                    reference_type, reference_id, created_at, updated_at
                ) VALUES ({placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder},
                    {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, 0.0,
                    {placeholder}, {placeholder}, {timestamp_default}, {timestamp_default})
            """
            params = (
                company_id,
                entry_data.get('voucher_type'),
                entry_data.get('voucher_id'),
                entry_data.get('voucher_no'),
                entry_data.get('voucher_date'),
                entry_data.get('account_id'),
                entry_data.get('contra_account_id'),
                entry_data.get('narration'),
                entry_data.get('debit', 0.0),
                entry_data.get('credit', 0.0),
                entry_data.get('reference_type'),
                entry_data.get('reference_id')
            )
            cursor.execute(query, params)

            entry_id = self.db._get_last_insert_id(cursor)

            # Update running balance
            self._update_running_balance(cursor, company_id, entry_data.get('account_id'),
                                        entry_data.get('voucher_date'))

            conn.commit()
            self.db.disconnect()
            return entry_id
        except Exception as e:
            print(f"Error posting entry: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return None

    def post_double_entry(self, company_id: int, voucher_type: str, voucher_id: int,
                        voucher_no: str, voucher_date: date, entries: List[Dict[str, Any]],
                        narration: str = None, reference_type: str = None,
                        reference_id: int = None) -> bool:
        """
        Post a double-entry voucher (multiple entries that balance).

        Args:
            company_id: Company ID
            voucher_type: Voucher type (sales, purchase, receipt, payment, journal)
            voucher_id: ID of the voucher record
            voucher_no: Voucher number
            voucher_date: Voucher date
            entries: List of entry dictionaries, each with:
                - account_id
                - debit
                - credit
            narration: Optional narration
            reference_type: Optional reference type
            reference_id: Optional reference ID

        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate that debits equal credits
            total_debit = sum(e.get('debit', 0.0) for e in entries)
            total_credit = sum(e.get('credit', 0.0) for e in entries)

            if abs(total_debit - total_credit) > 0.01:  # Allow small rounding differences
                print(f"Double-entry validation failed: debit={total_debit}, credit={total_credit}")
                return False

            conn = self.db.connect()
            cursor = conn.cursor()

            timestamp_default = self.db._get_timestamp_default()
            placeholder = self.db._get_placeholder()

            insert_query = f"""
                INSERT INTO ledger_entries (
                    company_id, voucher_type, voucher_id, voucher_no, voucher_date,
                    account_id, contra_account_id, narration, debit, credit, running_balance,
                    reference_type, reference_id, created_at, updated_at
                ) VALUES ({placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder},
                    {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, 0.0,
                    {placeholder}, {placeholder}, {timestamp_default}, {timestamp_default})
            """
            insert_data = [
                (
                    company_id, voucher_type, voucher_id, voucher_no, voucher_date,
                    entry.get('account_id'), entry.get('contra_account_id'), narration,
                    entry.get('debit', 0.0), entry.get('credit', 0.0),
                    reference_type, reference_id
                )
                for entry in entries
            ]
            cursor.executemany(insert_query, insert_data)

            # Rebuild running balances for all affected accounts
            affected_accounts = list({e.get('account_id') for e in entries if e.get('account_id')})
            for acct_id in affected_accounts:
                self._rebuild_account_running_balance(cursor, company_id, acct_id)

            conn.commit()
            self.db.disconnect()
            return True
        except Exception as e:
            print(f"Error posting double entry: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return False

    def update_voucher_entries(self, company_id: int, voucher_type: str, voucher_id: int,
                             new_entries: List[Dict[str, Any]]) -> bool:
        """
        Update voucher entries (delete old, post new).

        Args:
            company_id: Company ID
            voucher_type: Voucher type
            voucher_id: Voucher ID
            new_entries: New entries to post

        Returns:
            True if successful, False otherwise
        """
        try:
            # First, delete old entries for this voucher
            if not self.delete_voucher_entries(company_id, voucher_type, voucher_id):
                return False

            # Get voucher details for reposting
            voucher_details = self._get_voucher_details(company_id, voucher_type, voucher_id)
            if not voucher_details:
                return False

            # Post new entries
            return self.post_double_entry(
                company_id,
                voucher_type,
                voucher_id,
                voucher_details.get('voucher_no', ''),
                voucher_details.get('voucher_date'),
                new_entries,
                voucher_details.get('narration'),
                voucher_details.get('reference_type'),
                voucher_details.get('reference_id')
            )
        except Exception as e:
            print(f"Error updating voucher entries: {e}")
            return False

    def delete_voucher_entries(self, company_id: int, voucher_type: str, voucher_id: int) -> bool:
        """
        Delete all ledger entries for a voucher.

        Args:
            company_id: Company ID
            voucher_type: Voucher type
            voucher_id: Voucher ID

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = self.db.connect()
            cursor = conn.cursor()

            # Get affected accounts to rebuild running balances
            placeholder = self.db._get_placeholder()
            cursor.execute(
                f"SELECT DISTINCT account_id FROM ledger_entries WHERE company_id = {placeholder} AND voucher_type = {placeholder} AND voucher_id = {placeholder}",
                (company_id, voucher_type, voucher_id)
            )
            affected_accounts = [row[0] for row in cursor.fetchall()]

            # Get the voucher date for balance rebuilding
            cursor.execute(
                f"SELECT voucher_date FROM ledger_entries WHERE company_id = {placeholder} AND voucher_type = {placeholder} AND voucher_id = {placeholder} LIMIT 1",
                (company_id, voucher_type, voucher_id)
            )
            result = cursor.fetchone()
            voucher_date = result[0] if result else None

            # Delete entries
            cursor.execute(
                f"DELETE FROM ledger_entries WHERE company_id = {placeholder} AND voucher_type = {placeholder} AND voucher_id = {placeholder}",
                (company_id, voucher_type, voucher_id)
            )

            # Rebuild running balances for affected accounts
            if voucher_date:
                for account_id in affected_accounts:
                    self._update_running_balance(cursor, company_id, account_id, voucher_date)

            conn.commit()
            self.db.disconnect()
            return True
        except Exception as e:
            print(f"Error deleting voucher entries: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return False

    def get_account_balance(self, company_id: int, account_id: int, as_of_date: date = None) -> Dict[str, float]:
        """
        Get account balance as of a specific date.

        Args:
            company_id: Company ID
            account_id: Account ID
            as_of_date: Optional date (defaults to current date)

        Returns:
            Dictionary with debit, credit, and net balance
        """
        try:
            if as_of_date is None:
                as_of_date = date.today()

            # Get account details to determine Dr/Cr nature
            account = self.get_account(company_id, account_id)
            if not account:
                return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}

            # Sum debits and credits
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT COALESCE(SUM(debit), 0.0) as total_debit,
                       COALESCE(SUM(credit), 0.0) as total_credit
                FROM ledger_entries
                WHERE company_id = {placeholder} AND account_id = {placeholder} AND voucher_date <= {placeholder}
            """
            result = self.db.execute_query(query, (company_id, account_id, as_of_date))

            if result:
                total_debit = result[0]['total_debit']
                total_credit = result[0]['total_credit']

                # Add opening balance
                opening_balance = account.get('opening_balance', 0.0)
                opening_type = account.get('opening_balance_type', 'Dr')

                if opening_type == 'Dr':
                    total_debit += opening_balance
                else:
                    total_credit += opening_balance

                net_balance = total_debit - total_credit
                return {
                    'debit': total_debit,
                    'credit': total_credit,
                    'net': net_balance
                }

            return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}
        except Exception as e:
            print(f"Error getting account balance: {e}")
            return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}

    def get_account_balance_before_date(self, company_id: int, account_id: int, before_date: date) -> Dict[str, float]:
        """
        Get account balance before a specific date.

        Args:
            company_id: Company ID
            account_id: Account ID
            before_date: Date (exclusive)

        Returns:
            Dictionary with debit, credit, and net balance
        """
        try:
            # Get account details
            account = self.get_account(company_id, account_id)
            if not account:
                return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}

            # Sum debits and credits before date
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT COALESCE(SUM(debit), 0.0) as total_debit,
                       COALESCE(SUM(credit), 0.0) as total_credit
                FROM ledger_entries
                WHERE company_id = {placeholder} AND account_id = {placeholder} AND voucher_date < {placeholder}
            """
            result = self.db.execute_query(query, (company_id, account_id, before_date))

            if result:
                total_debit = result[0]['total_debit']
                total_credit = result[0]['total_credit']

                # Add opening balance
                opening_balance = account.get('opening_balance', 0.0)
                opening_type = account.get('opening_balance_type', 'Dr')

                if opening_type == 'Dr':
                    total_debit += opening_balance
                else:
                    total_credit += opening_balance

                net_balance = total_debit - total_credit
                return {
                    'debit': total_debit,
                    'credit': total_credit,
                    'net': net_balance
                }

            return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}
        except Exception as e:
            print(f"Error getting account balance before date: {e}")
            return {'debit': 0.0, 'credit': 0.0, 'net': 0.0}

    def get_running_ledger(self, company_id: int, account_id: int,
                         from_date: date = None, to_date: date = None,
                         limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Get running ledger for an account with pagination.

        Args:
            company_id: Company ID
            account_id: Account ID
            from_date: Optional start date
            to_date: Optional end date
            limit: Number of records to return
            offset: Number of records to skip

        Returns:
            List of ledger entries with running balance
        """
        try:
            placeholder = self.db._get_placeholder()
            query = f"""
                SELECT id, voucher_type, voucher_id, voucher_no, voucher_date,
                       account_id, contra_account_id, narration, debit, credit,
                       running_balance, created_at
                FROM ledger_entries
                WHERE company_id = {placeholder} AND account_id = {placeholder}
            """
            params = [company_id, account_id]

            if from_date:
                query += f" AND voucher_date >= {placeholder}"
                params.append(from_date)
            if to_date:
                query += f" AND voucher_date <= {placeholder}"
                params.append(to_date)

            query += f" ORDER BY voucher_date, id LIMIT {placeholder} OFFSET {placeholder}"
            params.extend([limit, offset])

            return self.db.execute_query(query, params)
        except Exception as e:
            print(f"Error getting running ledger: {e}")
            return []

    def get_trial_balance(self, company_id: int, as_of_date: date = None) -> List[Dict[str, Any]]:
        """
        Get trial balance for all accounts as of a date.

        Args:
            company_id: Company ID
            as_of_date: Optional date (defaults to current date)

        Returns:
            List of account balances
        """
        try:
            if as_of_date is None:
                as_of_date = date.today()

            accounts = self.search_accounts(company_id, is_active=True)
            trial_balance = []

            for account in accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                trial_balance.append({
                    'account_id': account['id'],
                    'account_name': account['account_name'],
                    'account_type': account['account_type'],
                    'debit': balance['debit'],
                    'credit': balance['credit'],
                    'net': balance['net']
                })

            return trial_balance
        except Exception as e:
            print(f"Error getting trial balance: {e}")
            return []

    def get_profit_loss_data(self, company_id: int, from_date: date = None,
                            to_date: date = None) -> Dict[str, Any]:
        """
        Get profit and loss data for a period.

        Args:
            company_id: Company ID
            from_date: Optional start date
            to_date: Optional end date

        Returns:
            Dictionary with income, expenses, and net profit/loss
        """
        try:
            if to_date is None:
                to_date = date.today()
            if from_date is None:
                from_date = to_date.replace(day=1)  # First day of current month

            # Get income accounts
            income_accounts = self.search_accounts(company_id, account_type='income')
            total_income = 0.0

            for account in income_accounts:
                balance = self.get_account_balance(company_id, account['id'], to_date)
                # Income accounts normally have credit balance
                total_income += balance['credit'] - balance['debit']

            # Get expense accounts
            expense_accounts = self.search_accounts(company_id, account_type='expense')
            total_expense = 0.0

            for account in expense_accounts:
                balance = self.get_account_balance(company_id, account['id'], to_date)
                # Expense accounts normally have debit balance
                total_expense += balance['debit'] - balance['credit']

            net_profit_loss = total_income - total_expense

            return {
                'total_income': total_income,
                'total_expense': total_expense,
                'net_profit_loss': net_profit_loss,
                'from_date': from_date,
                'to_date': to_date
            }
        except Exception as e:
            print(f"Error getting profit loss data: {e}")
            return {
                'total_income': 0.0,
                'total_expense': 0.0,
                'net_profit_loss': 0.0,
                'from_date': from_date,
                'to_date': to_date
            }

    def get_balance_sheet_data(self, company_id: int, as_of_date: date = None) -> Dict[str, Any]:
        """
        Get balance sheet data as of a date.

        Args:
            company_id: Company ID
            as_of_date: Optional date (defaults to current date)

        Returns:
            Dictionary with assets, liabilities, and equity
        """
        try:
            if as_of_date is None:
                as_of_date = date.today()

            # Get assets (cash_bank, capital with debit balance)
            assets = 0.0
            cash_bank_accounts = self.search_accounts(company_id, account_type='cash_bank')
            for account in cash_bank_accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                assets += balance['debit'] - balance['credit']

            # Get debtors (party accounts with debit balance)
            party_accounts = self.search_accounts(company_id, account_type='party')
            for account in party_accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                if balance['debit'] > balance['credit']:
                    assets += balance['debit'] - balance['credit']

            # Get liabilities (party accounts with credit balance)
            liabilities = 0.0
            for account in party_accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                if balance['credit'] > balance['debit']:
                    liabilities += balance['credit'] - balance['debit']

            # Get tax liabilities
            tax_accounts = self.search_accounts(company_id, account_type='tax_liability')
            for account in tax_accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                if balance['credit'] > balance['debit']:
                    liabilities += balance['credit'] - balance['debit']

            # Get equity (capital)
            equity = 0.0
            capital_accounts = self.search_accounts(company_id, account_type='capital')
            for account in capital_accounts:
                balance = self.get_account_balance(company_id, account['id'], as_of_date)
                equity += balance['credit'] - balance['debit']

            # Add profit/loss to equity
            pl_data = self.get_profit_loss_data(company_id, to_date=as_of_date)
            equity += pl_data['net_profit_loss']

            return {
                'assets': assets,
                'liabilities': liabilities,
                'equity': equity,
                'as_of_date': as_of_date
            }
        except Exception as e:
            print(f"Error getting balance sheet data: {e}")
            return {
                'assets': 0.0,
                'liabilities': 0.0,
                'equity': 0.0,
                'as_of_date': as_of_date
            }

    def get_outstanding_parties(self, company_id: int, party_type: str = None) -> List[Dict[str, Any]]:
        """
        Get outstanding balances for parties.

        Args:
            company_id: Company ID
            party_type: Optional filter (debitor, creditor)

        Returns:
            List of party outstanding balances
        """
        try:
            # This would need integration with parties table
            # For now, return empty list
            return []
        except Exception as e:
            print(f"Error getting outstanding parties: {e}")
            return []

    def rebuild_running_balances(self, company_id: int) -> bool:
        """
        Rebuild running balances for all accounts.

        Args:
            company_id: Company ID

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = self.db.connect()
            cursor = conn.cursor()

            # Get all accounts
            placeholder = self.db._get_placeholder()
            cursor.execute(f"SELECT id FROM ledger_accounts WHERE company_id = {placeholder}", (company_id,))
            account_ids = [row[0] for row in cursor.fetchall()]

            # Rebuild running balance for each account using full rebuild
            for account_id in account_ids:
                self._rebuild_account_running_balance(cursor, company_id, account_id)

            conn.commit()
            self.db.disconnect()
            return True
        except Exception as e:
            print(f"Error rebuilding running balances: {e}")
            if 'conn' in locals():
                conn.rollback()
            self.db.disconnect()
            return False

    # ============================================================
    # VOUCHER HELPERS
    # ============================================================

    def post_sales_voucher(self, company_id: int, sale_id: int, sale_data: Dict[str, Any],
                          sale_items: List[Dict[str, Any]]) -> bool:
        """Post sales voucher with proper double-entry.

        Credit Sale:  Dr Debitor  |  Cr Sales + Cr Output GST/CESS
        Cash Sale:    Dr Cash     |  Cr Sales + Cr Output GST/CESS
        """
        try:
            self.ensure_system_accounts(company_id)

            sales_acct = self.get_account_by_name_cached(company_id, 'Sales Account')
            if not sales_acct:
                return False

            grand_total = float(sale_data.get('grand_total', 0.0) or 0.0)
            cgst_total  = float(sale_data.get('cgst_total', 0.0) or 0.0)
            sgst_total  = float(sale_data.get('sgst_total', 0.0) or 0.0)
            igst_total  = float(sale_data.get('igst_total', 0.0) or 0.0)
            cess_total  = float(sale_data.get('cess_total', 0.0) or 0.0)
            tax_total   = float(sale_data.get('tax_total', 0.0) or 0.0)
            net_sales   = round(grand_total - tax_total, 2)

            entries = []

            # Cr Sales (net of tax)
            entries.append({'account_id': sales_acct['id'], 'debit': 0.0, 'credit': net_sales})

            # Cr Output GST/CESS (split by nature)
            nature = str(sale_data.get('nature', 'Local')).lower()
            if 'inter' in nature:
                if igst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output IGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': igst_total})
            else:
                if cgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output CGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': cgst_total})
                if sgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output SGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': sgst_total})
            if cess_total > 0:
                a = self.get_account_by_name_cached(company_id, 'Output CESS')
                if a:
                    entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': cess_total})

            # Dr side: Cash or Debitor party
            sale_type = str(sale_data.get('sales_type', 'Credit')).lower()
            if 'cash' in sale_type:
                cash_acct = self.get_account_by_name_cached(company_id, 'Cash Account')
                dr_acct = cash_acct
            else:
                party_id = sale_data.get('party_id')
                party_name = sale_data.get('customer_name') or sale_data.get('party_name', '')
                dr_acct = None
                if party_id:
                    dr_acct = self.get_account_by_party_id(company_id, party_id)
                if not dr_acct:
                    dr_acct = self.get_account_by_name_cached(company_id, 'Sundry Debtors')

            if dr_acct:
                entries.append({'account_id': dr_acct['id'], 'debit': grand_total, 'credit': 0.0})
            else:
                susp = self.get_account_by_name_cached(company_id, 'Suspense Account')
                if susp:
                    entries.append({'account_id': susp['id'], 'debit': grand_total, 'credit': 0.0})

            # Validate balance
            total_dr = sum(e['debit'] for e in entries)
            total_cr = sum(e['credit'] for e in entries)
            if abs(total_dr - total_cr) > 0.02:
                print(f"Sales voucher imbalance: Dr={total_dr} Cr={total_cr} — skipping post")
                return False

            return self.post_double_entry(
                company_id, 'sales', sale_id,
                sale_data.get('invoice_number', sale_data.get('invoice_no', '')),
                sale_data.get('invoice_date'),
                entries,
                sale_data.get('narration'), 'sale', sale_id
            )
        except Exception as e:
            print(f"Error posting sales voucher: {e}")
            return False

    def post_purchase_voucher(self, company_id: int, purchase_id: int, purchase_data: Dict[str, Any],
                             purchase_items: List[Dict[str, Any]]) -> bool:
        """Post purchase voucher with proper double-entry.

        Credit Purchase:  Dr Purchase + Dr Input GST/CESS  |  Cr Creditor
        Cash Purchase:    Dr Purchase + Dr Input GST/CESS  |  Cr Cash
        """
        try:
            self.ensure_system_accounts(company_id)

            purch_acct = self.get_account_by_name_cached(company_id, 'Purchase Account')
            if not purch_acct:
                return False

            grand_total = float(purchase_data.get('grand_total', 0.0) or 0.0)
            cgst_total  = float(purchase_data.get('cgst_total', 0.0) or 0.0)
            sgst_total  = float(purchase_data.get('sgst_total', 0.0) or 0.0)
            igst_total  = float(purchase_data.get('igst_total', 0.0) or 0.0)
            cess_total  = float(purchase_data.get('cess_total', 0.0) or 0.0)
            tax_total   = float(purchase_data.get('tax_total', 0.0) or 0.0)
            net_purch   = round(grand_total - tax_total, 2)

            entries = []

            # Dr Purchase (net of tax)
            entries.append({'account_id': purch_acct['id'], 'debit': net_purch, 'credit': 0.0})

            # Dr Input GST/CESS (split by nature)
            nature = str(purchase_data.get('nature', 'Local')).lower()
            if 'inter' in nature:
                if igst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input IGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': igst_total, 'credit': 0.0})
            else:
                if cgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input CGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': cgst_total, 'credit': 0.0})
                if sgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input SGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': sgst_total, 'credit': 0.0})
            if cess_total > 0:
                a = self.get_account_by_name_cached(company_id, 'Input CESS')
                if a:
                    entries.append({'account_id': a['id'], 'debit': cess_total, 'credit': 0.0})

            # Cr side: Cash or Creditor party
            purch_type = str(purchase_data.get('purchase_type', 'Credit')).lower()
            if 'cash' in purch_type:
                cash_acct = self.get_account_by_name_cached(company_id, 'Cash Account')
                cr_acct = cash_acct
            else:
                party_id = purchase_data.get('party_id')
                cr_acct = None
                if party_id:
                    cr_acct = self.get_account_by_party_id(company_id, party_id)
                if not cr_acct:
                    cr_acct = self.get_account_by_name_cached(company_id, 'Sundry Creditors')

            if cr_acct:
                entries.append({'account_id': cr_acct['id'], 'debit': 0.0, 'credit': grand_total})
            else:
                susp = self.get_account_by_name_cached(company_id, 'Suspense Account')
                if susp:
                    entries.append({'account_id': susp['id'], 'debit': 0.0, 'credit': grand_total})

            total_dr = sum(e['debit'] for e in entries)
            total_cr = sum(e['credit'] for e in entries)
            if abs(total_dr - total_cr) > 0.02:
                print(f"Purchase voucher imbalance: Dr={total_dr} Cr={total_cr} — skipping post")
                return False

            return self.post_double_entry(
                company_id, 'purchase', purchase_id,
                purchase_data.get('purchase_number', ''),
                purchase_data.get('purchase_date'),
                entries,
                purchase_data.get('narration'), 'purchase', purchase_id
            )
        except Exception as e:
            print(f"Error posting purchase voucher: {e}")
            return False

    def post_sales_return_voucher(self, company_id: int, sr_id: int,
                                  sr_data: Dict[str, Any], sr_items: List[Dict[str, Any]]) -> bool:
        """Post sales return voucher with proper double-entry.

        Cash Return:   Dr Sales Return + Dr Output GST reversal  |  Cr Cash
        Credit Return: Dr Sales Return + Dr Output GST reversal  |  Cr Debitor
        """
        try:
            self.ensure_system_accounts(company_id)

            sr_acct = self.get_account_by_name_cached(company_id, 'Sales Return Account')
            if not sr_acct:
                return False

            grand_total = float(sr_data.get('grand_total', 0.0) or 0.0)
            cgst_total  = float(sr_data.get('cgst_total', 0.0) or 0.0)
            sgst_total  = float(sr_data.get('sgst_total', 0.0) or 0.0)
            igst_total  = float(sr_data.get('igst_total', 0.0) or 0.0)
            cess_total  = float(sr_data.get('cess_total', 0.0) or 0.0)
            tax_total   = float(sr_data.get('tax_total', 0.0) or 0.0)
            net_return  = round(grand_total - tax_total, 2)

            entries = []

            # Dr Sales Return (net)
            entries.append({'account_id': sr_acct['id'], 'debit': net_return, 'credit': 0.0})

            # Dr Output GST reversal
            nature = str(sr_data.get('nature', 'Local')).lower()
            if 'inter' in nature:
                if igst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output IGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': igst_total, 'credit': 0.0})
            else:
                if cgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output CGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': cgst_total, 'credit': 0.0})
                if sgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Output SGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': sgst_total, 'credit': 0.0})
            if cess_total > 0:
                a = self.get_account_by_name_cached(company_id, 'Output CESS')
                if a:
                    entries.append({'account_id': a['id'], 'debit': cess_total, 'credit': 0.0})

            # Cr side: Cash or Debitor party
            return_type = str(sr_data.get('return_type', 'Credit')).lower()
            if 'cash' in return_type:
                cash_acct = self.get_account_by_name_cached(company_id, 'Cash Account')
                cr_acct = cash_acct
            else:
                party_id = sr_data.get('party_id')
                cr_acct = None
                if party_id:
                    cr_acct = self.get_account_by_party_id(company_id, party_id)
                if not cr_acct:
                    cr_acct = self.get_account_by_name_cached(company_id, 'Sundry Debtors')

            if cr_acct:
                entries.append({'account_id': cr_acct['id'], 'debit': 0.0, 'credit': grand_total})
            else:
                susp = self.get_account_by_name_cached(company_id, 'Suspense Account')
                if susp:
                    entries.append({'account_id': susp['id'], 'debit': 0.0, 'credit': grand_total})

            total_dr = sum(e['debit'] for e in entries)
            total_cr = sum(e['credit'] for e in entries)
            if abs(total_dr - total_cr) > 0.02:
                print(f"Sales return voucher imbalance: Dr={total_dr} Cr={total_cr} — skipping post")
                return False

            return self.post_double_entry(
                company_id, 'sales_return', sr_id,
                sr_data.get('return_no', ''),
                sr_data.get('return_date'),
                entries,
                sr_data.get('narration'), 'sales_return', sr_id
            )
        except Exception as e:
            print(f"Error posting sales return voucher: {e}")
            return False

    def post_purchase_return_voucher(self, company_id: int, pr_id: int,
                                     pr_data: Dict[str, Any], pr_items: List[Dict[str, Any]]) -> bool:
        """Post purchase return voucher with proper double-entry.

        Cash Return:   Dr Cash              |  Cr Purchase Return + Cr Input GST reversal
        Credit Return: Dr Creditor          |  Cr Purchase Return + Cr Input GST reversal
        """
        try:
            self.ensure_system_accounts(company_id)

            pr_acct = self.get_account_by_name_cached(company_id, 'Purchase Return Account')
            if not pr_acct:
                return False

            grand_total = float(pr_data.get('grand_total', 0.0) or 0.0)
            cgst_total  = float(pr_data.get('cgst_total', 0.0) or 0.0)
            sgst_total  = float(pr_data.get('sgst_total', 0.0) or 0.0)
            igst_total  = float(pr_data.get('igst_total', 0.0) or 0.0)
            cess_total  = float(pr_data.get('cess_total', 0.0) or 0.0)
            tax_total   = float(pr_data.get('tax_total', 0.0) or 0.0)
            net_return  = round(grand_total - tax_total, 2)

            entries = []

            # Cr Purchase Return (net)
            entries.append({'account_id': pr_acct['id'], 'debit': 0.0, 'credit': net_return})

            # Cr Input GST reversal
            nature = str(pr_data.get('nature', 'Local')).lower()
            if 'inter' in nature:
                if igst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input IGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': igst_total})
            else:
                if cgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input CGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': cgst_total})
                if sgst_total > 0:
                    a = self.get_account_by_name_cached(company_id, 'Input SGST')
                    if a:
                        entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': sgst_total})
            if cess_total > 0:
                a = self.get_account_by_name_cached(company_id, 'Input CESS')
                if a:
                    entries.append({'account_id': a['id'], 'debit': 0.0, 'credit': cess_total})

            # Dr side: Cash or Creditor party
            return_type = str(pr_data.get('return_type', 'Credit')).lower()
            if 'cash' in return_type:
                cash_acct = self.get_account_by_name_cached(company_id, 'Cash Account')
                dr_acct = cash_acct
            else:
                party_id = pr_data.get('party_id')
                dr_acct = None
                if party_id:
                    dr_acct = self.get_account_by_party_id(company_id, party_id)
                if not dr_acct:
                    dr_acct = self.get_account_by_name_cached(company_id, 'Sundry Creditors')

            if dr_acct:
                entries.append({'account_id': dr_acct['id'], 'debit': grand_total, 'credit': 0.0})
            else:
                susp = self.get_account_by_name_cached(company_id, 'Suspense Account')
                if susp:
                    entries.append({'account_id': susp['id'], 'debit': grand_total, 'credit': 0.0})

            total_dr = sum(e['debit'] for e in entries)
            total_cr = sum(e['credit'] for e in entries)
            if abs(total_dr - total_cr) > 0.02:
                print(f"Purchase return voucher imbalance: Dr={total_dr} Cr={total_cr} — skipping post")
                return False

            return self.post_double_entry(
                company_id, 'purchase_return', pr_id,
                pr_data.get('return_no', ''),
                pr_data.get('return_date'),
                entries,
                pr_data.get('narration'), 'purchase_return', pr_id
            )
        except Exception as e:
            print(f"Error posting purchase return voucher: {e}")
            return False

    # legacy alias kept for backward compat
    def create_purchase_return_ledger_entry(self, company_id, purchase_return_id, purchase_return_data):
        """Alias: delegates to post_purchase_return_voucher."""
        ok = self.post_purchase_return_voucher(company_id, purchase_return_id, purchase_return_data, [])
        return {'success': ok, 'message': 'OK' if ok else 'Failed'}

    def post_receipt_voucher(self, company_id: int, receipt_id: int, receipt_data: Dict[str, Any]) -> bool:
        """
        Post receipt voucher (money received from debtor).

        Args:
            company_id: Company ID
            receipt_id: Receipt ID
            receipt_data: Receipt data

        Returns:
            True if successful, False otherwise
        """
        # Placeholder for future implementation
        return True

    def post_payment_voucher(self, company_id: int, payment_id: int, payment_data: Dict[str, Any]) -> bool:
        """
        Post payment voucher (money paid to creditor).

        Args:
            company_id: Company ID
            payment_id: Payment ID
            payment_data: Payment data

        Returns:
            True if successful, False otherwise
        """
        # Placeholder for future implementation
        return True

    def post_journal_voucher(self, company_id: int, journal_id: int, journal_data: Dict[str, Any],
                            entries: List[Dict[str, Any]]) -> bool:
        """
        Post journal voucher (general journal entry).

        Args:
            company_id: Company ID
            journal_id: Journal ID
            journal_data: Journal header data
            entries: Journal entries

        Returns:
            True if successful, False otherwise
        """
        # Placeholder for future implementation
        return True

    # ============================================================
    # HELPER METHODS
    # ============================================================

    def _rebuild_account_running_balance(self, cursor, company_id: int, account_id: int):
        """Rebuild running_balance for every entry of account_id in date+id order.

        Starts from opening_balance (Dr positive / Cr negative), then applies
        each debit (+) and credit (-) in chronological order.
        """
        try:
            placeholder = self.db._get_placeholder()
            cursor.execute(
                f"SELECT opening_balance, opening_balance_type FROM ledger_accounts WHERE id = {placeholder}",
                (account_id,)
            )
            row = cursor.fetchone()
            if not row:
                return
            ob = float(row[0] or 0.0)
            ob_type = row[1] or 'Dr'
            running = ob if ob_type == 'Dr' else -ob

            cursor.execute(
                f"""SELECT id, debit, credit FROM ledger_entries
                   WHERE company_id = {placeholder} AND account_id = {placeholder}
                   ORDER BY voucher_date, id""",
                (company_id, account_id)
            )
            rows = cursor.fetchall()
            updates = []
            for r in rows:
                running += float(r[1] or 0.0) - float(r[2] or 0.0)
                updates.append((round(running, 2), r[0]))
            if updates:
                cursor.executemany(
                    f"UPDATE ledger_entries SET running_balance = {placeholder} WHERE id = {placeholder}",
                    updates
                )
        except Exception as e:
            print(f"Error rebuilding running balance for account {account_id}: {e}")

    def _update_running_balance(self, cursor, company_id: int, account_id: int, as_of_date):
        """Legacy shim — delegates to full rebuild."""
        self._rebuild_account_running_balance(cursor, company_id, account_id)

    def _get_voucher_details(self, company_id: int, voucher_type: str, voucher_id: int) -> Optional[Dict[str, Any]]:
        """
        Get voucher details for reposting.

        Args:
            company_id: Company ID
            voucher_type: Voucher type
            voucher_id: Voucher ID

        Returns:
            Voucher details dictionary
        """
        try:
            if voucher_type == 'sales':
                from .sales_logic import SalesLogic
                sales_logic = SalesLogic(self.db)
                result = sales_logic.get_sale_by_id(company_id, voucher_id)
                sale = result.get('data') if result and result.get('success') else None
                if sale:
                    return {
                        'voucher_no': sale.get('invoice_number', ''),
                        'voucher_date': sale.get('invoice_date'),
                        'narration': sale.get('narration'),
                        'reference_type': 'sale',
                        'reference_id': voucher_id
                    }
            elif voucher_type == 'purchase':
                from .purchase_logic import PurchaseLogic
                purchase_logic = PurchaseLogic(self.db)
                result = purchase_logic.get_purchase_by_id(company_id, voucher_id)
                purchase = result.get('data') if result and result.get('success') else None
                if purchase:
                    return {
                        'voucher_no': purchase.get('purchase_number', ''),
                        'voucher_date': purchase.get('purchase_date'),
                        'narration': purchase.get('narration'),
                        'reference_type': 'purchase',
                        'reference_id': voucher_id
                    }

            return None
        except Exception as e:
            print(f"Error getting voucher details: {e}")
            return None

    # ============================================================
    # SALES RETURN LEDGER HOOKS
    # ============================================================

    def create_sales_return_ledger_entry(self, company_id: int, sales_return_id: int,
                                          sales_return_data: Dict[str, Any]) -> bool:
        """Create ledger entries for a sales return."""
        return self.post_sales_return_voucher(company_id, sales_return_id, sales_return_data, [])

    def update_sales_return_ledger_entry(self, company_id: int, sales_return_id: int,
                                          sales_return_data: Dict[str, Any]) -> bool:
        """Update ledger entries for a sales return (delete old, repost fresh)."""
        self.delete_voucher_entries(company_id, 'sales_return', sales_return_id)
        return self.post_sales_return_voucher(company_id, sales_return_id, sales_return_data, [])

    def delete_sales_return_ledger_entry(self, company_id: int, sales_return_id: int) -> bool:
        """Delete ledger entries for a sales return."""
        return self.delete_voucher_entries(company_id, 'sales_return', sales_return_id)

    # ============================================================
    # LEDGER PAGE SUPPORT METHODS
    # ============================================================

    def ensure_party_ledger_accounts(self, company_id: int) -> bool:
        """
        Ensure all parties have corresponding ledger accounts.
        Creates missing ledger accounts for parties without ledger_account_id.
        Preserves opening_balance from party master.
        Uses backend-safe placeholders for MySQL compatibility.

        Args:
            company_id: Company ID

        Returns:
            True if successful, False otherwise
        """
        try:
            placeholder = self.db._get_placeholder()
            # Get all parties for this company
            parties = self.db.execute_query(
                f"""SELECT id, name, party_type, opening_balance
                    FROM parties
                    WHERE company_id = {placeholder}
                    ORDER BY name""",
                (company_id,)
            )

            if not parties:
                return True  # No parties to process

            created_count = 0
            for party in parties:
                party_id = party['id']
                party_name = party['name']
                party_type = party.get('party_type', 'Debitor')
                opening_balance = float(party.get('opening_balance', 0.0) or 0.0)

                # Check if party already has a linked ledger account
                result = self.db.execute_query(
                    f"SELECT ledger_account_id FROM parties WHERE id = {placeholder} AND company_id = {placeholder}",
                    (party_id, company_id)
                )

                if result and result[0].get('ledger_account_id'):
                    # Already has a ledger account - verify it exists
                    acct_id = result[0]['ledger_account_id']
                    acct_check = self.db.execute_query(
                        f"SELECT id FROM ledger_accounts WHERE id = {placeholder} AND company_id = {placeholder}",
                        (acct_id, company_id)
                    )
                    if acct_check:
                        continue  # Account exists, skip

                # Determine opening balance type based on party_type
                if party_type == 'Creditor':
                    ob_type = 'Cr'
                elif party_type == 'Debitor':
                    ob_type = 'Dr'
                else:  # 'Both'
                    ob_type = 'Dr'  # Default to Dr for 'Both' type

                # Check if an account with this name already exists
                existing = self.get_account_by_name(company_id, party_name)
                if existing:
                    # Link existing account to party
                    try:
                        conn = self.db.connect()
                        cursor = conn.cursor()
                        cursor.execute(
                            f"UPDATE parties SET ledger_account_id = {placeholder} WHERE id = {placeholder} AND company_id = {placeholder}",
                            (existing['id'], party_id, company_id)
                        )
                        conn.commit()
                        self.db.disconnect()
                    except Exception as e:
                        print(f"Warning: could not link party {party_name}: {e}")
                else:
                    # Create new ledger account for party
                    group_name = 'Sundry Debtors' if ob_type == 'Dr' else 'Sundry Creditors'
                    acct_id = self.create_account(company_id, {
                        'account_name': party_name,
                        'account_code': None,
                        'account_type': 'party',
                        'group_name': group_name,
                        'opening_balance': opening_balance,
                        'opening_balance_type': ob_type,
                    })

                    if acct_id:
                        # Link the new account to the party
                        try:
                            conn = self.db.connect()
                            cursor = conn.cursor()
                            cursor.execute(
                                f"UPDATE parties SET ledger_account_id = {placeholder} WHERE id = {placeholder} AND company_id = {placeholder}",
                                (acct_id, party_id, company_id)
                            )
                            conn.commit()
                            self.db.disconnect()
                            created_count += 1
                        except Exception as e:
                            print(f"Warning: could not link new party account {party_name}: {e}")

            if created_count > 0:
                print(f"Created {created_count} party ledger accounts")
                self.invalidate_accounts_cache(company_id)

            return True

        except Exception as e:
            print(f"Error ensuring party ledger accounts: {e}")
            return False

    def get_debtor_accounts(self, company_id: int) -> List[Dict[str, Any]]:
        """
        Get all debtor party accounts with their ledger account info.
        Includes parties where party_type IN ('Debitor', 'Both').

        Args:
            company_id: Company ID

        Returns:
            List of debtor account dictionaries
        """
        try:
            placeholder = self.db._get_placeholder()
            # First ensure all parties have ledger accounts
            self.ensure_party_ledger_accounts(company_id)

            # Get all party ledger accounts that are debtors
            result = self.db.execute_query(
                f"""SELECT
                        la.id,
                        la.account_name,
                        la.account_type,
                        la.group_name,
                        la.opening_balance,
                        la.opening_balance_type,
                        p.id as party_id,
                        p.party_type
                    FROM ledger_accounts la
                    INNER JOIN parties p ON p.ledger_account_id = la.id
                    WHERE la.company_id = {placeholder}
                      AND la.account_type = 'party'
                      AND p.party_type IN ('Debitor', 'Both')
                      AND la.is_active = 1
                    ORDER BY la.account_name""",
                (company_id,)
            )

            return [dict(row) for row in result] if result else []

        except Exception as e:
            print(f"Error getting debtor accounts: {e}")
            return []

    def get_creditor_accounts(self, company_id: int) -> List[Dict[str, Any]]:
        """
        Get all creditor party accounts with their ledger account info.
        Includes parties where party_type IN ('Creditor', 'Both').

        Args:
            company_id: Company ID

        Returns:
            List of creditor account dictionaries
        """
        try:
            placeholder = self.db._get_placeholder()
            # First ensure all parties have ledger accounts
            self.ensure_party_ledger_accounts(company_id)

            # Get all party ledger accounts that are creditors
            result = self.db.execute_query(
                f"""SELECT
                        la.id,
                        la.account_name,
                        la.account_type,
                        la.group_name,
                        la.opening_balance,
                        la.opening_balance_type,
                        p.id as party_id,
                        p.party_type
                    FROM ledger_accounts la
                    INNER JOIN parties p ON p.ledger_account_id = la.id
                    WHERE la.company_id = {placeholder}
                      AND la.account_type = 'party'
                      AND p.party_type IN ('Creditor', 'Both')
                      AND la.is_active = 1
                    ORDER BY la.account_name""",
                (company_id,)
            )

            return [dict(row) for row in result] if result else []

        except Exception as e:
            print(f"Error getting creditor accounts: {e}")
            return []

    def get_group_account_summary(self, company_id: int, group: str,
                                   from_date: date, to_date: date) -> Dict[str, Any]:
        """
        Get account summary for a specific ledger group.

        Args:
            company_id: Company ID
            group: Group identifier ('debtors', 'creditors', 'cash_bank', 'sales',
                                      'purchase', 'sales_return', 'purchase_return',
                                      'tax', 'stock', 'expense', 'income', 'all')
            from_date: Start date for period calculation
            to_date: End date for period calculation

        Returns:
            Dict with 'accounts' list and 'totals' dict
        """
        try:
            accounts = []

            if group == 'debtors':
                accounts = self.get_debtor_accounts(company_id)
            elif group == 'creditors':
                accounts = self.get_creditor_accounts(company_id)
            elif group == 'cash_bank':
                accounts = self.search_accounts(company_id, account_type='cash_bank', is_active=True)
            elif group == 'sales':
                all_income = self.search_accounts(company_id, account_type='income', is_active=True)
                accounts = [a for a in all_income if 'sales' in a.get('account_name', '').lower()]
            elif group == 'purchase':
                all_expense = self.search_accounts(company_id, account_type='expense', is_active=True)
                accounts = [a for a in all_expense if 'purchase' in a.get('account_name', '').lower()]
            elif group == 'sales_return':
                accounts = self.search_accounts(company_id, account_type='expense', is_active=True)
                accounts = [a for a in accounts if 'sales return' in a.get('account_name', '').lower()]
            elif group == 'purchase_return':
                accounts = self.search_accounts(company_id, account_type='income', is_active=True)
                accounts = [a for a in accounts if 'purchase return' in a.get('account_name', '').lower()]
            elif group == 'tax':
                accounts = self.search_accounts(company_id, account_type='tax_liability', is_active=True)
            elif group == 'stock':
                accounts = self.search_accounts(company_id, account_type='stock', is_active=True)
            elif group == 'expense':
                accounts = self.search_accounts(company_id, account_type='expense', is_active=True)
            elif group == 'income':
                accounts = self.search_accounts(company_id, account_type='income', is_active=True)
            elif group == 'all':
                accounts = self.search_accounts(company_id, is_active=True)

            # Calculate balances for each account
            account_data = []
            total_dr = 0.0
            total_cr = 0.0

            for acct in accounts:
                account_id = acct['id']

                # Get opening balance before from_date
                opening_data = self.get_account_balance_before_date(company_id, account_id, from_date)
                opening_net = opening_data['net']

                # Get closing balance as of to_date
                closing_data = self.get_account_balance(company_id, account_id, to_date)
                closing_net = closing_data['net']

                # Calculate period movement
                period_dr = closing_data['debit'] - opening_data['debit']
                period_cr = closing_data['credit'] - opening_data['credit']

                # Format opening and closing with Dr/Cr
                opening_fmt = self._fmt_balance(opening_net)
                closing_fmt = self._fmt_balance(closing_net)

                account_data.append({
                    'account_id': account_id,
                    'account_name': acct.get('account_name', ''),
                    'account_type': acct.get('account_type', ''),
                    'group_name': acct.get('group_name', ''),
                    'opening_balance': opening_net,
                    'opening_formatted': opening_fmt,
                    'period_debit': period_dr,
                    'period_credit': period_cr,
                    'closing_balance': closing_net,
                    'closing_formatted': closing_fmt,
                })

                total_dr += period_dr
                total_cr += period_cr

            return {
                'accounts': account_data,
                'totals': {
                    'debit': total_dr,
                    'credit': total_cr,
                    'count': len(account_data)
                }
            }

        except Exception as e:
            print(f"Error getting group account summary: {e}")
            return {'accounts': [], 'totals': {'debit': 0.0, 'credit': 0.0, 'count': 0}}

    def get_account_ledger(self, company_id: int, account_id: int,
                           from_date: date, to_date: date) -> Dict[str, Any]:
        """
        Get detailed ledger for a specific account.

        Args:
            company_id: Company ID
            account_id: Account ID
            from_date: Start date
            to_date: End date

        Returns:
            Dict with 'opening_balance', 'entries', 'totals', 'closing_balance'
        """
        try:
            # Get opening balance before from_date
            opening_data = self.get_account_balance_before_date(company_id, account_id, from_date)
            opening_net = opening_data['net']

            # Get ledger entries in date range with running balance
            entries = self.get_running_ledger(company_id, account_id, from_date, to_date, limit=5000)

            # Calculate totals for the period
            total_dr = sum(float(e.get('debit', 0.0) or 0.0) for e in entries)
            total_cr = sum(float(e.get('credit', 0.0) or 0.0) for e in entries)

            # Calculate closing balance
            closing_net = opening_net + total_dr - total_cr

            return {
                'opening_balance': opening_net,
                'opening_formatted': self._fmt_balance(opening_net),
                'entries': entries,
                'period_debit': total_dr,
                'period_credit': total_cr,
                'closing_balance': closing_net,
                'closing_formatted': self._fmt_balance(closing_net),
            }

        except Exception as e:
            print(f"Error getting account ledger: {e}")
            return {
                'opening_balance': 0.0,
                'opening_formatted': '0.00',
                'entries': [],
                'period_debit': 0.0,
                'period_credit': 0.0,
                'closing_balance': 0.0,
                'closing_formatted': '0.00',
            }

    @staticmethod
    def _fmt_balance(net: float) -> str:
        """Format a net balance with Dr/Cr suffix."""
        if net > 0.001:
            return f"{net:,.2f} Dr"
        elif net < -0.001:
            return f"{abs(net):,.2f} Cr"
        else:
            return "0.00"
