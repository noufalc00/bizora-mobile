"""
Product Logic Module
Handles product business logic and validation.
"""

import random
import time
from typing import Dict, Any, List, Optional
from .stock_logic import StockLogic


class ProductLogic:
    """Business logic for product operations."""

    def __init__(self, db):
        """Initialize product logic with database instance."""
        self.db = db
        self.stock_logic = StockLogic(db)

    def get_products(self, company_id: int) -> Dict[str, Any]:
        """
        Get all products for a company.
        
        Returns:
            Dict with success status, message, and data
        """
        try:
            products = self.db.get_products_by_company(company_id)
            return {
                "success": True,
                "message": "Products retrieved successfully",
                "data": products
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve products: {str(e)}",
                "data": []
            }

    def get_product_by_id(self, company_id: int, product_id: int) -> Dict[str, Any]:
        """
        Get a specific product by ID.

        Returns:
            Dict with success status, message, and data
        """
        try:
            product = self.db.get_product_by_id(company_id, product_id)
            if product:
                return {
                    "success": True,
                    "message": "Product retrieved successfully",
                    "data": product
                }
            else:
                return {
                    "success": False,
                    "message": "Product not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve product: {str(e)}",
                "data": None
            }

    def get_product_by_barcode(self, company_id: int, barcode: str) -> Dict[str, Any]:
        """
        Get a specific product by barcode (exact match).

        Returns:
            Dict with success status, message, and data
        """
        try:
            product = self.db.get_product_by_barcode(company_id, barcode)
            if product:
                return {
                    "success": True,
                    "message": "Product retrieved successfully",
                    "data": product
                }
            else:
                return {
                    "success": False,
                    "message": "Product not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve product: {str(e)}",
                "data": None
            }

    def validate_product_data(self, product_data: Dict[str, Any], 
                            auto_barcode: bool, 
                            current_product_id: Optional[int] = None,
                            company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Validate product data.
        
        Returns:
            Dict with success status and message
        """
        # Check required fields
        if not product_data.get('name', '').strip():
            return {
                "success": False,
                "message": "Product/Service Name is required"
            }

        # Validate barcode if manual entry
        if not auto_barcode:
            barcode = product_data.get('barcode', '').strip()
            if not barcode:
                return {
                    "success": False,
                    "message": "Please enter a barcode or enable Auto Barcode"
                }

            # Check barcode uniqueness if company_id is provided
            if company_id:
                exists = self.db.barcode_exists(company_id, barcode, current_product_id)
                if exists:
                    return {
                        "success": False,
                        "message": f"Barcode '{barcode}' already exists for another product in this company"
                    }

        # Validate numeric fields
        try:
            if product_data.get('purchase_rate'):
                float(product_data['purchase_rate'])
            if product_data.get('sale_price'):
                float(product_data['sale_price'])
            if product_data.get('wholesale_rate'):
                float(product_data['wholesale_rate'])
            if product_data.get('mrp'):
                float(product_data['mrp'])
            if product_data.get('cgst'):
                float(product_data['cgst'])
            if product_data.get('sgst'):
                float(product_data['sgst'])
            if product_data.get('igst'):
                float(product_data['igst'])
            if product_data.get('cess'):
                float(product_data['cess'])
            if product_data.get('reorder_level'):
                float(product_data['reorder_level'])
            if product_data.get('quantity'):
                float(product_data['quantity'])
        except (ValueError, TypeError):
            return {
                "success": False,
                "message": "Please enter valid numeric values for rates, prices, taxes, reorder level, and quantity"
            }

        return {
            "success": True,
            "message": "Product data is valid"
        }

    def normalize_product_data(self, product_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize product data (ensure proper types and defaults).
        
        Returns:
            Normalized product data dict
        """
        normalized = product_data.copy()

        # Ensure numeric fields are floats
        numeric_fields = ['purchase_rate', 'sale_price', 'wholesale_rate', 'mrp',
                         'cgst', 'sgst', 'igst', 'cess', 'reorder_level', 'quantity']
        
        for field in numeric_fields:
            value = normalized.get(field)
            if value is None or value == '':
                normalized[field] = 0.0
            else:
                try:
                    normalized[field] = float(value)
                except (ValueError, TypeError):
                    normalized[field] = 0.0

        # Ensure quantity is never negative
        normalized['quantity'] = max(0, normalized.get('quantity', 0.0))

        # Ensure text fields are stripped
        text_fields = ['name', 'barcode', 'hsn', 'color', 'size', 'category', 'description']
        for field in text_fields:
            if field in normalized and normalized[field]:
                normalized[field] = normalized[field].strip()

        return normalized

    def generate_next_barcode(self, company_id: int, 
                            exclude_current_id: Optional[int] = None) -> str:
        """
        Generate the next unique barcode for a company.
        
        Returns:
            Next available barcode as string
        """
        try:
            existing_barcodes = self.db.get_existing_barcodes(company_id, exclude_current_id)
            
            # Find the next available sequential number
            next_barcode = 1
            while next_barcode in existing_barcodes:
                next_barcode += 1
            
            return str(next_barcode)
        except Exception:
            # Fallback to timestamp-based unique number
            return str(int(time.time() * 1000) % 1000000)
    
    def generate_sequential_barcode(self, company_id: int) -> str:
        """
        Generate sequential barcode based on max numeric barcode for a company.
        
        Returns:
            Next sequential barcode as string
        """
        try:
            max_barcode = self.db.get_max_numeric_barcode(company_id)
            
            if max_barcode:
                next_barcode = str(max_barcode + 1)
            else:
                next_barcode = "1"
            
            return next_barcode
        except Exception:
            # Fallback to simple sequential number
            return "1"

    def save_product(self, company_id: int, product_data: Dict[str, Any],
                    product_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Save a product (insert or update).

        Returns:
            Dict with success status and message
        """
        try:
            # Normalize data
            normalized_data = self.normalize_product_data(product_data)
            opening_qty = float(normalized_data.get('quantity', 0.0))

            if product_id:
                # Update existing product
                self.db.update_product(company_id, product_id, normalized_data)

                # Replace opening stock movement safely (delete old, insert new if > 0)
                self.db.delete_stock_movements_by_reference('product', product_id)
                if opening_qty > 0:
                    self.stock_logic.create_opening_stock_movement(company_id, product_id, opening_qty)
                # Sync products.quantity cache from movements
                self.stock_logic.sync_product_quantity_from_movements(company_id, product_id)

                result = self.get_product_by_id(company_id, product_id)
                if result['success']:
                    return {
                        "success": True,
                        "message": "Product updated successfully",
                        "data": result['data']
                    }
                else:
                    return {
                        "success": True,
                        "message": "Product updated successfully",
                        "data": {"id": product_id}
                    }
            else:
                # Insert new product
                product_id = self.db.insert_product(company_id, normalized_data)

                # Create opening stock movement if quantity > 0
                if opening_qty > 0:
                    self.stock_logic.create_opening_stock_movement(company_id, product_id, opening_qty)
                    # Sync cache so products.quantity reflects movement balance
                    self.stock_logic.sync_product_quantity_from_movements(company_id, product_id)

                result = self.get_product_by_id(company_id, product_id)
                if result['success']:
                    return {
                        "success": True,
                        "message": "Product saved successfully",
                        "data": result['data']
                    }
                else:
                    return {
                        "success": True,
                        "message": "Product saved successfully",
                        "data": {"id": product_id}
                    }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to save product: {str(e)}"
            }

    def delete_product(self, company_id: int, product_id: int) -> Dict[str, Any]:
        """
        Delete a product.
        
        Returns:
            Dict with success status and message
        """
        try:
            self.db.delete_product(company_id, product_id)
            return {
                "success": True,
                "message": "Product deleted successfully"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to delete product: {str(e)}"
            }

    def filter_products(self, products: List[Dict[str, Any]],
                       search_term: str) -> List[Dict[str, Any]]:
        """
        Filter products based on search term.

        Returns:
            Filtered list of products
        """
        search_term = search_term.strip()

        if not search_term:
            return products

        filtered = []
        for product in products:
            name_match = search_term.lower() in (product.get('name') or "").lower()
            barcode_match = search_term.lower() in (product.get('barcode') or "").lower()

            if name_match or barcode_match:
                filtered.append(product)

        return filtered

    def search_products_limited(self, company_id: int, search_term: str, limit: int = 100) -> Dict[str, Any]:
        """
        Search products by name or barcode with a result limit (DB-backed).

        Safe for very large product catalogs.

        Returns:
            Dict with success status, message, and data
        """
        try:
            products = self.db.search_products_limited(company_id, search_term, limit)
            return {
                "success": True,
                "message": "Products searched successfully",
                "data": products
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to search products: {str(e)}",
                "data": []
            }

    def get_product_count(self, company_id: int) -> Dict[str, Any]:
        """
        Get total product count for a company (lightweight query).

        Returns:
            Dict with success status, message, and count
        """
        try:
            count = self.db.get_product_count(company_id)
            return {
                "success": True,
                "message": "Product count retrieved successfully",
                "data": count
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to get product count: {str(e)}",
                "data": 0
            }

    def get_product_by_exact_name(self, company_id: int, name: str) -> Dict[str, Any]:
        """
        Get product by exact name match (DB-backed).

        Safe for very large product catalogs.

        Returns:
            Dict with success status, message, and data
        """
        try:
            product = self.db.get_product_by_exact_name(company_id, name)
            if product:
                return {
                    "success": True,
                    "message": "Product retrieved successfully",
                    "data": product
                }
            else:
                return {
                    "success": False,
                    "message": "Product not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve product: {str(e)}",
                "data": None
            }
