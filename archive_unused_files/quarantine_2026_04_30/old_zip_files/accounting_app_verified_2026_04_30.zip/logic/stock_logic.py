"""
Stock Logic module for the Accounting Desktop Application.
Handles stock movement validation, creation, and balance calculations.
This is a foundation module - stock movements are tracked but products.quantity
remains the primary display field for now.
"""

from typing import Optional, List, Dict, Any


class StockLogic:
    """Business logic for stock movements."""
    
    def __init__(self, db):
        """Initialize stock logic with database instance."""
        self.db = db
    
    def validate_movement_data(self, movement_data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate stock movement data before creation.
        
        Args:
            movement_data: Dictionary containing movement information
            
        Returns:
            Dictionary with validation result and normalized data
        """
        errors = []
        
        # Validate required fields
        if 'company_id' not in movement_data or not movement_data['company_id']:
            errors.append("Company ID is required")
        
        if 'product_id' not in movement_data or not movement_data['product_id']:
            errors.append("Product ID is required")
        
        if 'movement_type' not in movement_data or not movement_data['movement_type']:
            errors.append("Movement type is required")
        else:
            valid_types = ['opening', 'purchase', 'sale', 'adjustment', 'return', 'transfer_in', 'transfer_out']
            if movement_data['movement_type'] not in valid_types:
                errors.append(f"Invalid movement type. Must be one of: {', '.join(valid_types)}")
        
        if 'quantity' not in movement_data:
            errors.append("Quantity is required")
        else:
            try:
                quantity = float(movement_data['quantity'])
                if quantity <= 0:
                    errors.append("Quantity must be greater than 0")
            except (ValueError, TypeError):
                errors.append("Quantity must be a valid number")
        
        if errors:
            return {
                'success': False,
                'errors': errors,
                'data': None
            }
        
        # Normalize data
        normalized_data = {
            'company_id': int(movement_data['company_id']),
            'product_id': int(movement_data['product_id']),
            'movement_type': movement_data['movement_type'].strip().lower(),
            'quantity': float(movement_data['quantity']),
            'reference_type': movement_data.get('reference_type'),
            'reference_id': movement_data.get('reference_id'),
            'notes': movement_data.get('notes')
        }
        
        return {
            'success': True,
            'errors': None,
            'data': normalized_data
        }
    
    def create_stock_movement(self, movement_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new stock movement entry.
        
        Args:
            movement_data: Dictionary containing movement information
            
        Returns:
            Dictionary with operation result
        """
        # Validate movement data
        validation = self.validate_movement_data(movement_data)
        
        if not validation['success']:
            return {
                'success': False,
                'errors': validation['errors'],
                'message': 'Validation failed'
            }
        
        data = validation['data']
        
        try:
            # Create stock movement
            success = self.db.create_stock_movement(
                company_id=data['company_id'],
                product_id=data['product_id'],
                movement_type=data['movement_type'],
                quantity=data['quantity'],
                reference_type=data['reference_type'],
                reference_id=data['reference_id'],
                notes=data['notes']
            )
            
            if success:
                return {
                    'success': True,
                    'message': 'Stock movement created successfully',
                    'data': data
                }
            else:
                return {
                    'success': False,
                    'message': 'Failed to create stock movement'
                }
                
        except Exception as e:
            return {
                'success': False,
                'message': f'Error creating stock movement: {str(e)}'
            }
    
    def get_stock_movements_by_product(self, company_id: int, product_id: int) -> List[Dict[str, Any]]:
        """Get all stock movements for a specific product.
        
        Args:
            company_id: Company ID
            product_id: Product ID
            
        Returns:
            List of stock movement records
        """
        try:
            return self.db.get_stock_movements_by_product(company_id, product_id)
        except Exception as e:
            print(f"Error getting stock movements: {e}")
            return []
    
    def get_stock_movements_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all stock movements for a specific company.
        
        Args:
            company_id: Company ID
            
        Returns:
            List of stock movement records
        """
        try:
            return self.db.get_stock_movements_by_company(company_id)
        except Exception as e:
            print(f"Error getting stock movements: {e}")
            return []
    
    def get_stock_balance_from_movements(self, company_id: int, product_id: int) -> float:
        """Calculate current stock balance from movements for a product.
        
        Args:
            company_id: Company ID
            product_id: Product ID
            
        Returns:
            Current stock balance
        """
        try:
            return self.db.get_stock_balance_from_movements(company_id, product_id)
        except Exception as e:
            print(f"Error calculating stock balance: {e}")
            return 0.0
    
    def create_opening_stock_movement(self, company_id: int, product_id: int, opening_quantity: float) -> bool:
        """Create an opening stock movement for a new product.
        
        This is a helper method to create an initial 'opening' movement
        when a product is created with opening quantity.
        
        Args:
            company_id: Company ID
            product_id: Product ID
            opening_quantity: Opening stock quantity
            
        Returns:
            True if successful, False otherwise
        """
        if opening_quantity <= 0:
            return True  # No opening stock, no movement needed
        
        movement_data = {
            'company_id': company_id,
            'product_id': product_id,
            'movement_type': 'opening',
            'quantity': opening_quantity,
            'reference_type': 'product_creation',
            'reference_id': product_id,
            'notes': 'Opening stock from product creation'
        }
        
        result = self.create_stock_movement(movement_data)
        return result['success']

    def validate_sale_stock(self, company_id: int, sale_items: List[Dict[str, Any]], 
                          current_sale_id: Optional[int] = None) -> Dict[str, Any]:
        """Validate that sale items won't cause negative stock.
        
        This method fetches the latest stock from DB (multi-window safe) and checks
        if the sale quantities would cause negative stock.
        
        Args:
            company_id: Company ID
            sale_items: List of sale items with product_id and quantity
            current_sale_id: Current sale ID (for edit mode, to exclude current bill from stock calculation)
            
        Returns:
            Dictionary with validation result
        """
        try:
            for item in sale_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                
                if not product_id or quantity <= 0:
                    continue
                
                # Get latest stock from DB (multi-window safe)
                current_stock = self.db.get_stock_balance_from_movements(company_id, product_id)
                
                # If editing, add back current bill's stock to get pre-bill stock
                if current_sale_id:
                    old_items = self.db.get_sale_items(current_sale_id) or []
                    for old_item in old_items:
                        if old_item.get('product_id') == product_id:
                            old_qty = float(old_item.get('quantity', 0))
                            current_stock += old_qty
                            break
                
                # Check if this would cause negative stock
                if quantity > current_stock:
                    return {
                        'success': False,
                        'message': f"Insufficient stock for product. Available: {current_stock:.3f}, Required: {quantity:.3f}",
                        'product_id': product_id,
                        'available_stock': current_stock,
                        'required_quantity': quantity
                    }
            
            return {
                'success': True,
                'message': 'Stock validation passed'
            }
            
        except Exception as e:
            return {
                'success': False,
                'message': f'Error validating stock: {str(e)}'
            }

    def get_current_stock(self, company_id: int, product_id: int) -> float:
        """Return current stock calculated from stock_movements table.

        Formula: opening + purchase - sale + adjustment_in - adjustment_out
        This is the authoritative stock source. Do NOT use products.quantity as truth.

        Args:
            company_id: Company ID
            product_id: Product ID

        Returns:
            Current stock balance as float
        """
        try:
            return self.db.get_stock_balance_from_movements(company_id, product_id)
        except Exception as e:
            print(f"Error getting current stock: {e}")
            return 0.0

    def delete_movements_for_reference(self, reference_type: str, reference_id: int) -> bool:
        """Delete all stock movements for a given reference (bill/product).

        Used before replacing movements when a sale/purchase is edited or deleted.

        Args:
            reference_type: 'sale', 'purchase', or 'product'
            reference_id: ID of the referenced bill or product

        Returns:
            True if successful
        """
        try:
            return self.db.delete_stock_movements_by_reference(reference_type, reference_id)
        except Exception as e:
            print(f"Error deleting movements for reference: {e}")
            return False

    def replace_movements_for_reference(self, company_id: int, reference_type: str,
                                        reference_id: int,
                                        movements: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Safely replace all stock movements for a reference.

        Steps:
        1. Delete old movements for the reference.
        2. Insert new movements.
        3. Sync products.quantity cache for all affected products.

        Args:
            company_id: Company ID
            reference_type: 'sale' or 'purchase'
            reference_id: Bill ID
            movements: List of dicts with keys: product_id, movement_type, quantity

        Returns:
            Dict with success/message
        """
        try:
            self.db.delete_stock_movements_by_reference(reference_type, reference_id)
            affected_product_ids = set()
            for m in movements:
                product_id = m.get('product_id')
                quantity = float(m.get('quantity', 0))
                movement_type = m.get('movement_type', reference_type)
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, movement_type,
                    quantity, reference_type, reference_id
                )
                affected_product_ids.add(product_id)
            for pid in affected_product_ids:
                self.sync_product_quantity_from_movements(company_id, pid)
            return {'success': True, 'message': 'Stock movements replaced successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error replacing movements: {str(e)}'}

    def sync_product_quantity_from_movements(self, company_id: int, product_id: int) -> bool:
        """Update products.quantity from movement balance (cache sync only).

        products.quantity is a display cache. The authoritative value is always
        computed via get_current_stock() from the movements table.

        Args:
            company_id: Company ID
            product_id: Product ID

        Returns:
            True if successful
        """
        try:
            balance = self.db.get_stock_balance_from_movements(company_id, product_id)
            return self.db.set_product_quantity_cache(company_id, product_id, balance)
        except Exception as e:
            print(f"Error syncing product quantity: {e}")
            return False

    def apply_sale_stock_movements(self, company_id: int, sale_id: int,
                                   sale_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create 'sale' stock movements for a new sale and sync cache.

        Args:
            company_id: Company ID
            sale_id: Sale ID
            sale_items: List of sale items with product_id and quantity

        Returns:
            Dictionary with operation result
        """
        try:
            affected = set()
            for item in sale_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'sale', quantity, 'sale', sale_id
                )
                affected.add(product_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Stock movements applied successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error applying stock movements: {str(e)}'}

    def reverse_sale_stock_movements(self, company_id: int, sale_id: int) -> Dict[str, Any]:
        """Delete stock movements for a sale when the sale is deleted.

        Clean approach: simply delete the movements for this reference.
        The balance formula (opening+purchase-sale) will automatically restore
        the correct stock without needing orphan 'return' movements.

        Args:
            company_id: Company ID
            sale_id: Sale ID

        Returns:
            Dictionary with operation result
        """
        try:
            items = self.db.get_sale_items(sale_id) or []
            affected = {item['product_id'] for item in items
                        if item.get('product_id') and float(item.get('quantity', 0)) > 0}
            self.db.delete_stock_movements_by_reference('sale', sale_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Stock movements reversed successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error reversing stock movements: {str(e)}'}

    def adjust_sale_stock_movements(self, company_id: int, sale_id: int,
                                    old_items: List[Dict[str, Any]],
                                    new_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Replace stock movements when editing a saved sale.

        Clean approach: delete old movements for this sale, insert new ones.
        No orphan 'return' movements are created.

        Args:
            company_id: Company ID
            sale_id: Sale ID
            old_items: Previous sale items (used to identify affected products)
            new_items: Updated sale items

        Returns:
            Dictionary with operation result
        """
        try:
            affected = set()
            for item in old_items:
                if item.get('product_id'):
                    affected.add(item['product_id'])
            self.db.delete_stock_movements_by_reference('sale', sale_id)
            for item in new_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'sale', quantity, 'sale', sale_id
                )
                affected.add(product_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Stock movements adjusted successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error adjusting stock movements: {str(e)}'}

    def apply_purchase_stock_movements(self, company_id: int, purchase_id: int,
                                       purchase_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create 'purchase' stock movements for a new purchase and sync cache.

        Args:
            company_id: Company ID
            purchase_id: Purchase ID
            purchase_items: List of purchase items with product_id and quantity

        Returns:
            Dictionary with operation result
        """
        try:
            affected = set()
            for item in purchase_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'purchase', quantity, 'purchase', purchase_id
                )
                affected.add(product_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase stock movements applied successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error applying purchase stock movements: {str(e)}'}

    def adjust_purchase_stock_movements(self, company_id: int, purchase_id: int,
                                        old_items: List[Dict[str, Any]],
                                        new_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Replace stock movements when editing a saved purchase.

        Args:
            company_id: Company ID
            purchase_id: Purchase ID
            old_items: Previous purchase items
            new_items: Updated purchase items

        Returns:
            Dictionary with operation result
        """
        try:
            affected = set()
            for item in old_items:
                if item.get('product_id'):
                    affected.add(item['product_id'])
            self.db.delete_stock_movements_by_reference('purchase', purchase_id)
            for item in new_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'purchase', quantity, 'purchase', purchase_id
                )
                affected.add(product_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase stock movements adjusted successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error adjusting purchase stock movements: {str(e)}'}

    def reverse_purchase_stock_movements(self, company_id: int, purchase_id: int) -> Dict[str, Any]:
        """Delete stock movements for a purchase when the purchase is deleted.

        Args:
            company_id: Company ID
            purchase_id: Purchase ID

        Returns:
            Dictionary with operation result
        """
        try:
            items = self.db.get_purchase_items(purchase_id) or []
            affected = {item['product_id'] for item in items
                        if item.get('product_id') and float(item.get('quantity', 0)) > 0}
            self.db.delete_stock_movements_by_reference('purchase', purchase_id)
            self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase stock movements reversed successfully'}
        except Exception as e:
            return {'success': False, 'message': f'Error reversing purchase stock movements: {str(e)}'}

    def apply_purchase_return_stock_movements(self, company_id: int, purchase_return_id: int,
                                              return_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create 'purchase_return' stock movements (stock OUT) and sync cache.

        Purchase return reduces stock - each movement has NEGATIVE quantity.
        """
        try:
            affected = set()
            for item in return_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'purchase_return', -quantity,
                    'purchase_return', purchase_return_id
                )
                affected.add(product_id)
            if affected:
                self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase return stock movements applied'}
        except Exception as e:
            return {'success': False, 'message': f'Error applying purchase return stock movements: {str(e)}'}

    def adjust_purchase_return_stock_movements(self, company_id: int, purchase_return_id: int,
                                               old_items: List[Dict[str, Any]],
                                               new_items: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Replace stock movements when editing a saved purchase return."""
        try:
            affected = set()
            for item in old_items:
                if item.get('product_id'):
                    affected.add(item['product_id'])
            self.db.delete_stock_movements_by_reference('purchase_return', purchase_return_id)
            for item in new_items:
                product_id = item.get('product_id')
                quantity = float(item.get('quantity', 0))
                if not product_id or quantity <= 0:
                    continue
                self.db.create_stock_movement(
                    company_id, product_id, 'purchase_return', -quantity,
                    'purchase_return', purchase_return_id
                )
                affected.add(product_id)
            if affected:
                self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase return stock movements adjusted'}
        except Exception as e:
            return {'success': False, 'message': f'Error adjusting purchase return stock movements: {str(e)}'}

    def reverse_purchase_return_stock_movements(self, company_id: int, purchase_return_id: int) -> Dict[str, Any]:
        """Delete stock movements when a purchase return is deleted."""
        try:
            items = self.db.get_purchase_return_items(purchase_return_id) or []
            affected = {item['product_id'] for item in items if item.get('product_id')}
            self.db.delete_stock_movements_by_reference('purchase_return', purchase_return_id)
            if affected:
                self.db.batch_sync_product_quantities(company_id, list(affected))
            return {'success': True, 'message': 'Purchase return stock movements reversed'}
        except Exception as e:
            return {'success': False, 'message': f'Error reversing purchase return stock movements: {str(e)}'}
