"""
Sales Logic Module
Handles sales business logic and validation.
"""

from typing import Dict, Any, List, Optional
from .stock_logic import StockLogic


class SalesLogic:
    """Business logic for sales operations."""

    def __init__(self, db):
        """Initialize sales logic with database instance."""
        self.db = db
        self.stock_logic = StockLogic(db)
        self.ledger_logic = None  # Lazy load ledger_logic when needed

    def _get_ledger_logic(self):
        """Lazy load ledger_logic."""
        if self.ledger_logic is None:
            from .ledger_logic import LedgerLogic
            self.ledger_logic = LedgerLogic(self.db)
        return self.ledger_logic

    def get_sales(self, company_id: int) -> Dict[str, Any]:
        """
        Get all sales for a company.

        Returns:
            Dict with success status, message, and data
        """
        try:
            sales = self.db.get_sales_by_company(company_id)
            return {
                "success": True,
                "message": "Sales retrieved successfully",
                "data": sales
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sales: {str(e)}",
                "data": []
            }

    def get_sale_by_id(self, company_id: int, sale_id: int) -> Dict[str, Any]:
        """
        Get a specific sale by ID.

        Returns:
            Dict with success status, message, and data
        """
        try:
            sale = self.db.get_sale_by_id(company_id, sale_id)
            if sale:
                return {
                    "success": True,
                    "message": "Sale retrieved successfully",
                    "data": sale
                }
            else:
                return {
                    "success": False,
                    "message": "Sale not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sale: {str(e)}",
                "data": None
            }

    def get_sale_items(self, sale_id: int) -> Dict[str, Any]:
        """
        Get all items for a specific sale.

        Returns:
            Dict with success status, message, and data
        """
        try:
            items = self.db.get_sale_items(sale_id)
            return {
                "success": True,
                "message": "Sale items retrieved successfully",
                "data": items
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sale items: {str(e)}",
                "data": []
            }

    def validate_sale_data(self, sale_data: Dict[str, Any], 
                          current_sale_id: Optional[int] = None,
                          company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Validate sale data.

        Returns:
            Dict with success status and message
        """
        # Check required fields
        if not sale_data.get('invoice_number', '').strip():
            return {
                "success": False,
                "message": "Invoice Number is required"
            }

        if not sale_data.get('invoice_date', '').strip():
            return {
                "success": False,
                "message": "Invoice Date is required"
            }

        if not sale_data.get('party_id'):
            return {
                "success": False,
                "message": "Customer/Party is required"
            }

        # Check for duplicate invoice number if company_id is provided
        if company_id:
            exists = self.db.invoice_number_exists(company_id, sale_data['invoice_number'].strip(), current_sale_id)
            if exists:
                return {
                    "success": False,
                    "message": "Invoice Number already exists"
                }

        return {
            "success": True,
            "message": "Sale data is valid"
        }

    def normalize_sale_data(self, sale_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize sale data by trimming and converting types.

        Returns:
            Normalized sale data
        """
        return {
            'invoice_number': str(sale_data.get('invoice_number', '')).strip(),
            'invoice_date': str(sale_data.get('invoice_date', '')).strip(),
            'party_id': int(sale_data.get('party_id', 0)),
            'sales_type': str(sale_data.get('sales_type', 'Sales')).strip(),
            'bill_series': str(sale_data.get('bill_series', '')).strip(),
            'nature': str(sale_data.get('nature', '')).strip(),
            'due_date': str(sale_data.get('due_date', '')).strip() if sale_data.get('due_date') else None,
            'address': str(sale_data.get('address', '')).strip(),
            'gstin': str(sale_data.get('gstin', '')).strip().upper(),
            'state': str(sale_data.get('state', '')).strip(),
            'sales_rate': str(sale_data.get('sales_rate', 'Exclusive')).strip(),
            'narration': str(sale_data.get('narration', '')).strip(),
            'sub_total': float(sale_data.get('sub_total', 0.0)),
            'discount_total': float(sale_data.get('discount_total', 0.0)),
            'tax_total': float(sale_data.get('tax_total', 0.0)),
            'round_off': float(sale_data.get('round_off', 0.0)),
            'grand_total': float(sale_data.get('grand_total', 0.0)),
            'amount_received': float(sale_data.get('amount_received', 0.0))
        }

    def save_sale(self, company_id: int, sale_data: Dict[str, Any],
                   sale_items: List[Dict[str, Any]],
                   current_sale_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Save a sale (create or update).

        Args:
            company_id: Company ID
            sale_data: Dictionary containing sale header information
            sale_items: List of dictionaries containing sale item information
            current_sale_id: Sale ID (None for create, ID for update)

        Returns:
            Dictionary with operation result
        """
        # Validate sale data
        validation = self.validate_sale_data(sale_data, current_sale_id, company_id)
        if not validation['success']:
            return {
                'success': False,
                'message': validation['message'],
                'errors': None,
                'data': None
            }

        # Normalize sale data
        normalized_data = self.normalize_sale_data(sale_data)

        try:
            if current_sale_id:
                # ---------- UPDATE EXISTING SALE ----------
                # Get old items for stock adjustment
                old_items = self.db.get_sale_items(current_sale_id) or []

                # Adjust stock movements using stock_logic (handles differences)
                stock_result = self.stock_logic.adjust_sale_stock_movements(
                    company_id, current_sale_id, old_items, sale_items
                )
                if not stock_result['success']:
                    return {
                        'success': False,
                        'message': f'Stock adjustment failed: {stock_result["message"]}',
                        'errors': None,
                        'data': None
                    }

                # Remove old sales_items
                self.db.delete_sale_items_by_sale(current_sale_id)

                # Update the sale header
                self.db.update_sale(company_id, current_sale_id, normalized_data)

                # Insert new items
                for item_data in sale_items:
                    self.db.insert_sale_item(current_sale_id, item_data)

                # Update ledger entries: delete old, then repost fresh
                try:
                    ledger_logic = self._get_ledger_logic()
                    ledger_logic.delete_voucher_entries(company_id, 'sales', current_sale_id)
                    ledger_logic.post_sales_voucher(company_id, current_sale_id, normalized_data, sale_items)
                except Exception as e:
                    print(f"Warning: Ledger update failed: {e}")

                return {
                    'success': True,
                    'message': 'Sale updated successfully',
                    'errors': None,
                    'data': {'sale_id': current_sale_id}
                }

            # ---------- CREATE NEW SALE ----------
            sale_id = self.db.insert_sale(company_id, normalized_data)
            if sale_id:
                # Insert new items
                for item_data in sale_items:
                    self.db.insert_sale_item(sale_id, item_data)

                # Apply stock movements using stock_logic
                stock_result = self.stock_logic.apply_sale_stock_movements(company_id, sale_id, sale_items)
                if not stock_result['success']:
                    # Stock movement failed but sale was saved - log warning
                    print(f'Warning: Stock movement failed after save: {stock_result["message"]}')

                # Post ledger entries
                try:
                    ledger_logic = self._get_ledger_logic()
                    ledger_logic.post_sales_voucher(company_id, sale_id, normalized_data, sale_items)
                except Exception as e:
                    print(f"Warning: Ledger posting failed: {e}")

                return {
                    'success': True,
                    'message': 'Sale saved successfully',
                    'errors': None,
                    'data': {'sale_id': sale_id}
                }
            return {
                'success': False,
                'message': 'Failed to save sale',
                'errors': None,
                'data': None
            }

        except Exception as e:
            return {
                'success': False,
                'message': f'Error saving sale: {str(e)}',
                'errors': None,
                'data': None
            }

    def delete_sale(self, company_id: int, sale_id: int) -> Dict[str, Any]:
        """
        Delete a sale.

        Args:
            company_id: Company ID
            sale_id: Sale ID

        Returns:
            Dictionary with operation result
        """
        try:
            # Reverse stock movements BEFORE deleting sale (items still exist in DB)
            # reverse_sale_stock_movements cleanly deletes movements and syncs cache.
            stock_result = self.stock_logic.reverse_sale_stock_movements(company_id, sale_id)
            if not stock_result['success']:
                return {
                    'success': False,
                    'message': f'Stock reversal failed: {stock_result["message"]}'
                }

            # Delete sale header (cascade will delete sale_items)
            ph = self.db._get_placeholder()
            query = f"DELETE FROM sales WHERE id = {ph} AND company_id = {ph}"
            success = self.db.execute_update(query, (sale_id, company_id))

            # Delete ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'sales', sale_id)
            except Exception as e:
                print(f"Warning: Ledger entry deletion failed: {e}")

            if success:
                return {
                    'success': True,
                    'message': 'Sale deleted successfully'
                }
            else:
                return {
                    'success': False,
                    'message': 'Failed to delete sale'
                }

        except Exception as e:
            return {
                'success': False,
                'message': f'Failed to delete sale: {str(e)}'
            }
