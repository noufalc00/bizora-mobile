"""
Dark theme module for the Accounting Desktop Application.
Provides the dark stylesheet as a Python function.
"""

import os
from pathlib import Path


def get_dark_stylesheet() -> str:
    """Load and return the dark theme stylesheet."""
    # Get the directory of this file
    current_dir = Path(__file__).parent
    qss_file = current_dir / "dark_theme.qss"
    
    try:
        with open(qss_file, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        # Fallback basic dark theme if file not found
        return """
        QApplication {
            background-color: #121212;
            color: #ffffff;
        }
        QMainWindow {
            background-color: #121212;
            color: #ffffff;
        }
        QWidget {
            background-color: #121212;
            color: #ffffff;
        }
        QPushButton {
            background-color: #2D2D2D;
            color: #ffffff;
            border: 1px solid #404040;
            padding: 8px 16px;
            border-radius: 4px;
        }
        QPushButton:hover {
            background-color: #3D3D3D;
        }
        QPushButton:pressed {
            background-color: #4D4D4D;
        }
        QLineEdit {
            background-color: #2D2D2D;
            color: #ffffff;
            border: 1px solid #404040;
            padding: 8px;
            border-radius: 4px;
        }
        QComboBox {
            background-color: #2D2D2D;
            color: #ffffff;
            border: 1px solid #404040;
            padding: 8px;
            border-radius: 4px;
        }
        QLabel {
            color: #ffffff;
        }
        """


def apply_dark_theme(app):
    """Apply dark theme to the QApplication."""
    stylesheet = get_dark_stylesheet()
    app.setStyleSheet(stylesheet)
