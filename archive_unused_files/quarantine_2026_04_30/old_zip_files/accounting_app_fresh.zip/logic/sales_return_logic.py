"""
Sales Return Logic Module
Handles sales return business logic and validation.
"""

from typing import Dict, Any, List, Optional
from .stock_logic import StockLogic


class SalesReturnLogic:
    """Business logic for sales return operations."""

    def __init__(self, db):
        """Initialize sales return logic with database instance."""
        self.db = db
        self.stock_logic = StockLogic(db)
        self.ledger_logic = None  # Lazy load ledger_logic when needed

    def _get_ledger_logic(self):
        """Lazy load ledger_logic."""
        if self.ledger_logic is None:
            from .ledger_logic import LedgerLogic
            self.ledger_logic = LedgerLogic(self.db)
        return self.ledger_logic

    def get_sales_returns(self, company_id: int) -> Dict[str, Any]:
        """
        Get all sales returns for a company.

        Returns:
            Dict with success status, message, and data
        """
        try:
            sales_returns = self.db.get_sales_returns_by_company(company_id)
            return {
                "success": True,
                "message": "Sales returns retrieved successfully",
                "data": sales_returns
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sales returns: {str(e)}",
                "data": []
            }

    def get_sales_return_by_id(self, company_id: int, sales_return_id: int) -> Dict[str, Any]:
        """
        Get a specific sales return by ID.

        Returns:
            Dict with success status, message, and data
        """
        try:
            sales_return = self.db.get_sales_return_by_id(company_id, sales_return_id)
            if sales_return:
                return {
                    "success": True,
                    "message": "Sales return retrieved successfully",
                    "data": sales_return
                }
            else:
                return {
                    "success": False,
                    "message": "Sales return not found",
                    "data": None
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sales return: {str(e)}",
                "data": None
            }

    def get_sales_return_items(self, sales_return_id: int) -> Dict[str, Any]:
        """
        Get all items for a specific sales return.

        Returns:
            Dict with success status, message, and data
        """
        try:
            items = self.db.get_sales_return_items(sales_return_id)
            return {
                "success": True,
                "message": "Sales return items retrieved successfully",
                "data": items
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to retrieve sales return items: {str(e)}",
                "data": []
            }

    def validate_sales_return_data(self, sales_return_data: Dict[str, Any],
                                   current_sales_return_id: Optional[int] = None,
                                   company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Validate sales return data.

        Returns:
            Dict with success status and message
        """
        # Check required fields (party_id is optional for Cash returns)
        required_fields = ['company_id', 'return_no', 'return_date']
        for field in required_fields:
            if field not in sales_return_data or not sales_return_data[field]:
                return {
                    "success": False,
                    "message": f"Missing required field: {field}"
                }
        # Credit return must have a party
        if sales_return_data.get('return_type') == 'Credit' and not sales_return_data.get('party_id'):
            return {
                "success": False,
                "message": "Credit return requires a customer (party_id)"
            }

        # Check if items exist
        if 'items' not in sales_return_data or not sales_return_data['items']:
            return {
                "success": False,
                "message": "Sales return must have at least one item"
            }

        # Validate items
        for idx, item in enumerate(sales_return_data['items']):
            if 'product_id' not in item or not item['product_id']:
                return {
                    "success": False,
                    "message": f"Item {idx + 1}: Missing product_id"
                }
            if 'quantity' not in item or item['quantity'] <= 0:
                return {
                    "success": False,
                    "message": f"Item {idx + 1}: Quantity must be greater than 0"
                }

        # Check return_no uniqueness if new
        if current_sales_return_id is None:
            existing = self.db.get_sales_return_by_return_no(
                sales_return_data['company_id'],
                sales_return_data['return_no']
            )
            if existing:
                return {
                    "success": False,
                    "message": f"Return number {sales_return_data['return_no']} already exists"
                }

        return {
            "success": True,
            "message": "Sales return data is valid"
        }

    def save_sales_return(self, sales_return_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Save a new sales return with items.

        Returns:
            Dict with success status, message, and sales_return_id
        """
        try:
            # Validate data
            validation = self.validate_sales_return_data(sales_return_data)
            if not validation['success']:
                return validation

            company_id = sales_return_data['company_id']

            # Save sales return header
            sales_return_id = self.db.insert_sales_return(company_id, sales_return_data)

            # Save items
            items = sales_return_data.get('items', [])
            for item in items:
                self.db.insert_sales_return_item(sales_return_id, item)

            # Create stock movements (stock INCREASES on sales return)
            for item in items:
                self.stock_logic.create_stock_movement({
                    'company_id': company_id,
                    'product_id': item['product_id'],
                    'movement_type': 'return',
                    'quantity': item['quantity'],
                    'reference_type': 'sales_return',
                    'reference_id': sales_return_id,
                    'notes': f"Sales Return {sales_return_data['return_no']}"
                })
                self.stock_logic.sync_product_quantity_from_movements(
                    company_id, item['product_id']
                )

            # Post ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.post_sales_return_voucher(
                    company_id, sales_return_id, sales_return_data, items
                )
            except Exception as e:
                print(f"Warning: Sales return ledger posting failed: {e}")

            return {
                "success": True,
                "message": "Sales return saved successfully",
                "sales_return_id": sales_return_id
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to save sales return: {str(e)}"
            }

    def update_sales_return(self, sales_return_id: int, sales_return_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update an existing sales return.

        Returns:
            Dict with success status and message
        """
        try:
            company_id = sales_return_data['company_id']

            # Get existing sales return
            existing = self.get_sales_return_by_id(company_id, sales_return_id)
            if not existing['success']:
                return existing

            # Collect product_ids before delete for cache sync later
            old_items_result = self.get_sales_return_items(sales_return_id)
            old_product_ids = [i['product_id'] for i in old_items_result.get('data', [])]

            # Reverse old stock movements (delete them)
            self.db.execute_update(
                "DELETE FROM stock_movements WHERE reference_type=? AND reference_id=?",
                ('sales_return', sales_return_id)
            )

            # Delete old items
            self.db.delete_sales_return_items(sales_return_id)

            # Update header
            self.db.update_sales_return(sales_return_id, sales_return_data)

            # Save new items
            items = sales_return_data.get('items', [])
            for item in items:
                self.db.insert_sales_return_item(sales_return_id, item)

            # Create new stock movements
            all_product_ids = set(old_product_ids)
            for item in items:
                self.stock_logic.create_stock_movement({
                    'company_id': company_id,
                    'product_id': item['product_id'],
                    'movement_type': 'return',
                    'quantity': item['quantity'],
                    'reference_type': 'sales_return',
                    'reference_id': sales_return_id,
                    'notes': f"Sales Return {sales_return_data['return_no']}"
                })
                all_product_ids.add(item['product_id'])

            for pid in all_product_ids:
                self.stock_logic.sync_product_quantity_from_movements(company_id, pid)

            # Update ledger entries: delete old, repost fresh
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'sales_return', sales_return_id)
                ledger_logic.post_sales_return_voucher(
                    company_id, sales_return_id, sales_return_data, items
                )
            except Exception as e:
                print(f"Warning: Sales return ledger update failed: {e}")

            return {
                "success": True,
                "message": "Sales return updated successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to update sales return: {str(e)}"
            }

    def delete_sales_return(self, company_id: int, sales_return_id: int) -> Dict[str, Any]:
        """
        Delete a sales return.

        Returns:
            Dict with success status and message
        """
        try:
            # Get existing sales return
            existing = self.get_sales_return_by_id(company_id, sales_return_id)
            if not existing['success']:
                return existing

            # Collect product_ids for cache sync after delete
            items_result = self.get_sales_return_items(sales_return_id)
            product_ids = [i['product_id'] for i in items_result.get('data', [])]

            # Reverse stock movements
            self.db.execute_update(
                "DELETE FROM stock_movements WHERE reference_type=? AND reference_id=?",
                ('sales_return', sales_return_id)
            )

            # Delete items (cascade handles, but explicit for safety)
            self.db.delete_sales_return_items(sales_return_id)

            # Delete header
            self.db.delete_sales_return(sales_return_id)

            # Sync product quantity cache
            for pid in product_ids:
                self.stock_logic.sync_product_quantity_from_movements(company_id, pid)

            # Delete ledger entries
            try:
                ledger_logic = self._get_ledger_logic()
                ledger_logic.delete_voucher_entries(company_id, 'sales_return', sales_return_id)
            except Exception as e:
                print(f"Warning: Sales return ledger deletion failed: {e}")

            return {
                "success": True,
                "message": "Sales return deleted successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "message": f"Failed to delete sales return: {str(e)}"
            }

    def get_next_return_no(self, company_id: int) -> str:
        """
        Get next return number for a company.

        Returns:
            Next return number as string
        """
        try:
            last_return = self.db.get_last_sales_return_no(company_id)
            if last_return:
                # Extract numeric part and increment
                try:
                    num = int(last_return)
                    return str(num + 1)
                except ValueError:
                    return "1"
            return "1"
        except Exception as e:
            return "1"
