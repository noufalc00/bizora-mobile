"""
Database module for the Accounting Desktop Application.
Handles SQLite and MySQL database initialization and basic operations.
"""

import os
import sqlite3
from datetime import datetime
from typing import Optional, List, Dict, Any

from config import DATABASE_NAME, DATABASE_BACKUP_DIR, DATABASE_TYPE, MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE

# Try to import MySQL connector, but don't fail if not present
MYSQL_AVAILABLE = False
try:
    import mysql.connector
    from mysql.connector import Error as MySQLError
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False


class Database:
    """Database manager for the accounting application supporting SQLite and MySQL."""
    
    def __init__(self, db_type: Optional[str] = None, db_path: Optional[str] = None):
        """Initialize database connection with backend type selection.
        
        Args:
            db_type: Database type ('sqlite' or 'mysql'). Defaults to config DATABASE_TYPE.
            db_path: Database path for SQLite. Ignored for MySQL. Defaults to config DATABASE_NAME.
        """
        if db_type is None:
            self.db_type = DATABASE_TYPE
        else:
            self.db_type = db_type
        
        if self.db_type == "mysql":
            if not MYSQL_AVAILABLE:
                raise ImportError("MySQL connector is not installed. Please install mysql-connector-python: pip install mysql-connector-python")
            self.db_path = None
            self.mysql_config = {
                'host': MYSQL_HOST,
                'port': MYSQL_PORT,
                'user': MYSQL_USER,
                'password': MYSQL_PASSWORD,
                'database': MYSQL_DATABASE
            }
        else:
            if db_path is None:
                self.db_path = DATABASE_NAME
            else:
                self.db_path = db_path
            self.mysql_config = None
        
        self.connection = None
    
    def connect(self):
        """Return existing connection or establish a new one (persistent connection)."""
        try:
            if self.db_type == "mysql":
                if self.connection is None:
                    return self._connect_mysql()
                return self.connection
            else:
                if self.connection is None:
                    return self._connect_sqlite()
                return self.connection
        except Exception as e:
            raise Exception(f"Database connection error: {e}")
    
    def _connect_sqlite(self) -> sqlite3.Connection:
        """Establish SQLite database connection (called once, then reused)."""
        try:
            # Add timeout of 30 seconds to handle concurrent access
            self.connection = sqlite3.connect(self.db_path, timeout=30.0)
            self.connection.row_factory = sqlite3.Row  # Enable dict-like access
            # Enable foreign keys (SQLite-specific)
            self.connection.execute("PRAGMA foreign_keys = ON")
            # Enable WAL mode for better concurrency (SQLite-specific)
            self.connection.execute("PRAGMA journal_mode = WAL")
            self.connection.execute("PRAGMA synchronous = NORMAL")
            return self.connection
        except sqlite3.Error as e:
            raise Exception(f"SQLite connection error: {e}")
    
    def _connect_mysql(self):
        """Establish MySQL database connection."""
        try:
            self.connection = mysql.connector.connect(**self.mysql_config)
            # Enable foreign keys
            cursor = self.connection.cursor()
            cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
            cursor.close()
            return self.connection
        except MySQLError as e:
            raise Exception(f"MySQL connection error: {e}")
    
    def disconnect(self):
        """No-op: connection is kept persistent for performance.
        Call force_disconnect() only when the app is shutting down.
        """
        pass

    def force_disconnect(self):
        """Actually close the database connection (use on app shutdown only)."""
        if self.connection:
            self.connection.close()
            self.connection = None
    
    def _get_auto_increment(self) -> str:
        """Get the AUTO_INCREMENT syntax for the current backend."""
        return "AUTOINCREMENT" if self.db_type == "sqlite" else "AUTO_INCREMENT"
    
    def _get_primary_key_autoincrement(self) -> str:
        """Get the PRIMARY KEY AUTO_INCREMENT syntax for the current backend."""
        if self.db_type == "sqlite":
            return "INTEGER PRIMARY KEY AUTOINCREMENT"
        else:
            return "INT AUTO_INCREMENT PRIMARY KEY"
    
    def _get_boolean_type(self) -> str:
        """Get the BOOLEAN type for the current backend."""
        return "BOOLEAN" if self.db_type == "sqlite" else "TINYINT(1)"
    
    def _get_timestamp_default(self) -> str:
        """Get the default timestamp syntax for the current backend."""
        return "CURRENT_TIMESTAMP" if self.db_type == "sqlite" else "CURRENT_TIMESTAMP"

    def _get_last_insert_id(self, cursor) -> Optional[int]:
        """Get the last inserted ID in a cross-database compatible way."""
        if self.db_type == "sqlite":
            return cursor.lastrowid
        else:
            # MySQL: use SELECT LAST_INSERT_ID()
            cursor.execute("SELECT LAST_INSERT_ID()")
            result = cursor.fetchone()
            return result[0] if result else None
    
    def _check_table_exists(self, cursor, table_name: str) -> bool:
        """Check if a table exists in the current backend."""
        if self.db_type == "sqlite":
            ph = self._get_placeholder()
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name={ph}", (table_name,))
            return cursor.fetchone() is not None
        else:
            cursor.execute("SHOW TABLES LIKE %s", (table_name,))
            return cursor.fetchone() is not None
    
    def _get_placeholder(self) -> str:
        """Get the parameter placeholder for the current backend."""
        return "?" if self.db_type == "sqlite" else "%s"
    
    def _get_cast_integer(self) -> str:
        """Get the CAST syntax for integer conversion."""
        return "AS INTEGER" if self.db_type == "sqlite" else "AS SIGNED"
    
    def _is_sqlite(self) -> bool:
        """Check if current backend is SQLite."""
        return self.db_type == "sqlite"
    
    def _is_mysql(self) -> bool:
        """Check if current backend is MySQL."""
        return self.db_type == "mysql"
    
    def _safe_identifier(self, identifier: str) -> str:
        """
        Validate and return a safe SQL identifier.
        Only allows letters, numbers, and underscore.
        Cannot start with a number.
        Raises ValueError if invalid.
        """
        if not identifier:
            raise ValueError("Identifier cannot be empty")
        
        # Check if identifier is valid
        if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', identifier):
            raise ValueError(f"Invalid SQL identifier: {identifier}")
        
        return identifier
    
    def _get_text_type(self, length: Optional[int] = None) -> str:
        """Get TEXT/VARCHAR type for the current backend.
        
        Args:
            length: Optional length for VARCHAR (ignored for SQLite TEXT).
        
        Returns:
            'TEXT' for SQLite, 'VARCHAR(N)' for MySQL if length provided, else 'TEXT'
        """
        if self._is_sqlite():
            return "TEXT"
        elif length:
            return f"VARCHAR({length})"
        else:
            return "TEXT"
    
    def _get_datetime_type(self) -> str:
        """Get DATETIME type for the current backend."""
        return "TIMESTAMP" if self._is_sqlite() else "DATETIME"
    
    def _get_if_not_exists_supported(self) -> bool:
        """Check if CREATE TABLE IF NOT EXISTS is supported (both backends support this)."""
        return True
    
    def _check_column_exists(self, cursor, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table for the current backend."""
        if self._is_sqlite():
            safe_table = self._safe_identifier(table_name)
            cursor.execute(f"PRAGMA table_info({safe_table})")
            columns = [row[1] for row in cursor.fetchall()]
            return column_name in columns
        else:
            # MySQL: use information_schema
            cursor.execute(
                "SELECT COUNT(*) FROM information_schema.columns "
                "WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s",
                (table_name, column_name)
            )
            result = cursor.fetchone()
            return result[0] > 0 if result else False
    
    def _check_index_exists(self, cursor, table_name: str, index_name: str) -> bool:
        """Check if an index exists for the current backend."""
        if self._is_sqlite():
            ph = self._get_placeholder()
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='index' AND name={ph}", (index_name,))
            return cursor.fetchone() is not None
        else:
            # MySQL: use information_schema
            cursor.execute(
                "SELECT COUNT(*) FROM information_schema.statistics "
                "WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s",
                (table_name, index_name)
            )
            result = cursor.fetchone()
            return result[0] > 0 if result else False
    
    def _create_index_if_missing(self, cursor, table_name: str, index_name: str, columns: str, unique: bool = False) -> None:
        """Create an index if it doesn't exist, using backend-safe method."""
        try:
            if not self._check_index_exists(cursor, table_name, index_name):
                unique_kw = "UNIQUE " if unique else ""
                if self._is_sqlite():
                    cursor.execute(f"CREATE {unique_kw}INDEX IF NOT EXISTS {index_name} ON {table_name} ({columns})")
                else:
                    cursor.execute(f"CREATE {unique_kw}INDEX {index_name} ON {table_name} ({columns})")
        except Exception as e:
            print(f"Note: Index creation for {index_name} skipped: {e}")
    
    def initialize_database(self) -> bool:
        """Initialize the database with all required tables."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            
            # Create all tables
            self._create_accounts_table(cursor)
            self._create_transactions_table(cursor)
            self._create_categories_table(cursor)
            self._create_companies_table(cursor)
            self._create_products_table(cursor)
            self._create_parties_table(cursor)
            self._create_bank_accounts_table(cursor)
            self._create_stock_movements_table(cursor)
            self._create_sales_table(cursor)
            self._create_sales_items_table(cursor)
            self._create_sales_returns_table(cursor)
            self._create_sales_return_items_table(cursor)
            self._create_purchases_table(cursor)
            self._create_purchase_items_table(cursor)
            self._create_purchase_returns_table(cursor)
            self._create_purchase_return_items_table(cursor)
            self._create_settings_table(cursor)
            self._create_ledger_accounts_table(cursor)
            self._create_ledger_entries_table(cursor)
            
            # Add missing columns for existing databases
            self._migrate_database(cursor)
            
            conn.commit()
            print("Database tables created successfully")
            return True
            
        except Exception as e:
            print(f"Database initialization error: {e}")
            return False
        finally:
            self.disconnect()
    
    def _create_accounts_table(self, cursor):
        """Create accounts table."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS accounts (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('checking', 'savings', 'credit', 'cash', 'investment')),
                balance REAL DEFAULT 0.0,
                currency TEXT DEFAULT 'USD',
                description TEXT,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                UNIQUE(company_id, name)
            )
        """)
    
    def _create_transactions_table(self, cursor):
        """Create transactions table."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS transactions (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                account_id INTEGER NOT NULL,
                category_id INTEGER,
                type TEXT NOT NULL CHECK (type IN ('income', 'expense', 'transfer')),
                amount REAL NOT NULL,
                description TEXT,
                date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE CASCADE,
                FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
            )
        """)
    
    def _create_categories_table(self, cursor):
        """Create categories table."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS categories (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
                color TEXT DEFAULT '#2196F3',
                description TEXT,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                UNIQUE(company_id, name)
            )
        """)
    
    def _create_products_table(self, cursor):
        """Create products table."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        name_type = self._get_text_type(255)
        barcode_type = self._get_text_type(100)
        hsn_type = self._get_text_type(50)
        unit_type = self._get_text_type(50)
        category_type = self._get_text_type(100)
        color_type = self._get_text_type(50)
        size_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS products (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                name {name_type} NOT NULL,
                barcode {barcode_type},
                hsn {hsn_type},
                unit {unit_type} DEFAULT 'pcs',
                category {category_type},
                color {color_type},
                size {size_type},
                purchase_rate REAL DEFAULT 0.0,
                sale_price REAL DEFAULT 0.0,
                wholesale_rate REAL DEFAULT 0.0,
                mrp REAL DEFAULT 0.0,
                cgst REAL DEFAULT 0.0,
                sgst REAL DEFAULT 0.0,
                igst REAL DEFAULT 0.0,
                cess REAL DEFAULT 0.0,
                reorder_level REAL DEFAULT 0.0,
                description TEXT,
                quantity REAL DEFAULT 0.0,
                auto_barcode INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
            )
        """)
        # Create indexes for fast lookup (barcode and name searches)
        self._create_index_if_missing(cursor, 'products', 'idx_products_company_name', 'company_id, name')
        self._create_index_if_missing(cursor, 'products', 'idx_products_company_barcode', 'company_id, barcode')
        self._create_index_if_missing(cursor, 'products', 'idx_products_company_category', 'company_id, category')
    
    def _create_settings_table(self, cursor):
        """Create settings table."""
        timestamp_default = self._get_timestamp_default()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
            )
        """)
    
    def _create_stock_movements_table(self, cursor):
        """Create stock_movements table for stock tracking foundation."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        movement_type_type = self._get_text_type(50)
        reference_type_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS stock_movements (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                movement_type {movement_type_type} NOT NULL CHECK (movement_type IN ('opening', 'purchase', 'sale', 'adjustment', 'return', 'transfer_in', 'transfer_out')),
                quantity REAL NOT NULL,
                reference_type {reference_type_type},
                reference_id INTEGER,
                notes TEXT,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            )
        """)
    
    def _create_bank_accounts_table(self, cursor):
        """Create bank_accounts table for bank account management."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        account_name_type = self._get_text_type(255)
        bank_name_type = self._get_text_type(255)
        account_number_type = self._get_text_type(50)
        ifsc_code_type = self._get_text_type(50)
        branch_name_type = self._get_text_type(255)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS bank_accounts (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                account_name {account_name_type} NOT NULL,
                bank_name {bank_name_type} NOT NULL,
                account_number {account_number_type} NOT NULL,
                ifsc_code {ifsc_code_type},
                branch_name {branch_name_type},
                opening_balance REAL DEFAULT 0.0,
                notes TEXT,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                UNIQUE(company_id, account_name)
            )
        """)
    
    def _create_sales_table(self, cursor):
        """Create sales table for sales header information."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        invoice_number_type = self._get_text_type(100)
        sales_type_type = self._get_text_type(50)
        bill_series_type = self._get_text_type(50)
        nature_type = self._get_text_type(50)
        gstin_type = self._get_text_type(15)
        state_type = self._get_text_type(100)
        sales_rate_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS sales (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                invoice_number {invoice_number_type} NOT NULL,
                invoice_date DATE NOT NULL,
                party_id INTEGER NOT NULL,
                sales_type {sales_type_type} DEFAULT 'Sales' CHECK (sales_type IN ('Sales', 'Credit Sales', 'Return')),
                bill_series {bill_series_type},
                nature {nature_type},
                due_date DATE,
                address TEXT,
                gstin {gstin_type},
                state {state_type},
                sales_rate {sales_rate_type} DEFAULT 'Exclusive',
                narration TEXT,
                sub_total REAL DEFAULT 0.0,
                discount_total REAL DEFAULT 0.0,
                tax_total REAL DEFAULT 0.0,
                round_off REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                amount_received REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (party_id) REFERENCES parties (id) ON DELETE CASCADE,
                UNIQUE(company_id, invoice_number)
            )
        """)

    def _migrate_sales_table(self, cursor):
        """Migrate sales table to add missing columns safely."""
        if self.db_type == "sqlite":
            try:
                cursor.execute("ALTER TABLE sales ADD COLUMN amount_received REAL DEFAULT 0.0")
            except Exception:
                pass  # Column may already exist
        else:
            # MySQL: use IF NOT EXISTS
            try:
                cursor.execute("ALTER TABLE sales ADD COLUMN IF NOT EXISTS amount_received REAL DEFAULT 0.0")
            except Exception:
                pass
    
    def _create_sales_items_table(self, cursor):
        """Create sales_items table for sales line items."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        hsn_type = self._get_text_type(50)
        unit_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS sales_items (
                id {pk_autoinc},
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                sl_no INTEGER NOT NULL,
                hsn {hsn_type},
                tax_percent REAL DEFAULT 0.0,
                unit {unit_type},
                rate REAL DEFAULT 0.0,
                quantity REAL DEFAULT 0.0,
                gross_value REAL DEFAULT 0.0,
                discount REAL DEFAULT 0.0,
                net_value REAL DEFAULT 0.0,
                tax_amount REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (sale_id) REFERENCES sales (id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            )
        """)
    
    def _create_purchases_table(self, cursor):
        """Create purchases table for purchase header information."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        purchase_number_type = self._get_text_type(100)
        purchase_type_type = self._get_text_type(50)
        bill_series_type = self._get_text_type(50)
        nature_type = self._get_text_type(50)
        gstin_type = self._get_text_type(15)
        state_type = self._get_text_type(100)
        purchase_rate_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS purchases (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                purchase_number {purchase_number_type} NOT NULL,
                purchase_date DATE NOT NULL,
                party_id INTEGER NOT NULL,
                purchase_type {purchase_type_type} DEFAULT 'Cash' CHECK (purchase_type IN ('Cash', 'Credit')),
                bill_series {bill_series_type},
                nature {nature_type},
                due_date DATE,
                address TEXT,
                gstin {gstin_type},
                state {state_type},
                purchase_rate {purchase_rate_type} DEFAULT 'Exclusive',
                narration TEXT,
                sub_total REAL DEFAULT 0.0,
                discount_total REAL DEFAULT 0.0,
                tax_total REAL DEFAULT 0.0,
                round_off REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                amount_paid REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (party_id) REFERENCES parties (id) ON DELETE CASCADE,
                UNIQUE(company_id, purchase_number)
            )
        """)

        # Create indexes for performance and MySQL compatibility
        try:
            self._create_index_if_missing(cursor, 'purchases', 'idx_purchases_company_id', 'company_id')
            self._create_index_if_missing(cursor, 'purchases', 'idx_purchases_purchase_no', 'purchase_number')
            self._create_index_if_missing(cursor, 'purchases', 'idx_purchases_party_id', 'party_id')
            self._create_index_if_missing(cursor, 'purchases', 'idx_purchases_date', 'purchase_date')
        except Exception as e:
            # Index creation may fail if already exists or not supported
            print(f"Note: Index creation failed (may already exist): {e}")

    def _create_ledger_accounts_table(self, cursor):
        """Create ledger accounts table for double-entry accounting."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        account_name_type = self._get_text_type(255)
        account_type_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS ledger_accounts (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                account_name {account_name_type} NOT NULL,
                account_code VARCHAR(50),
                account_type {account_type_type} NOT NULL CHECK (account_type IN ('party', 'cash_bank', 'income', 'expense', 'tax_liability', 'capital', 'stock')),
                group_name VARCHAR(100),
                opening_balance REAL DEFAULT 0.0,
                opening_balance_type VARCHAR(10) DEFAULT 'Dr' CHECK (opening_balance_type IN ('Dr', 'Cr')),
                is_system INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                UNIQUE(company_id, account_name)
            )
        """)

        # Create indexes for performance
        try:
            self._create_index_if_missing(cursor, 'ledger_accounts', 'idx_ledger_accounts_company_id', 'company_id')
            self._create_index_if_missing(cursor, 'ledger_accounts', 'idx_ledger_accounts_account_name', 'account_name')
            self._create_index_if_missing(cursor, 'ledger_accounts', 'idx_ledger_accounts_account_type', 'account_type')
        except Exception as e:
            print(f"Note: Ledger accounts index creation failed (may already exist): {e}")

    def _create_ledger_entries_table(self, cursor):
        """Create ledger_entries table for double-entry accounting transactions."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        voucher_type_type = self._get_text_type(50)
        voucher_no_type = self._get_text_type(100)
        reference_type_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS ledger_entries (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                voucher_type {voucher_type_type} NOT NULL,
                voucher_id INTEGER NOT NULL,
                voucher_no {voucher_no_type},
                voucher_date DATE NOT NULL,
                account_id INTEGER NOT NULL,
                contra_account_id INTEGER,
                narration TEXT,
                debit REAL DEFAULT 0.0,
                credit REAL DEFAULT 0.0,
                running_balance REAL DEFAULT 0.0,
                reference_type {reference_type_type},
                reference_id INTEGER,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (account_id) REFERENCES ledger_accounts (id) ON DELETE CASCADE
            )
        """)

        # Create indexes for performance
        try:
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_company_id', 'company_id')
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_voucher_date', 'voucher_date')
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_voucher_type', 'voucher_type')
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_voucher_id', 'voucher_id')
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_account_id', 'account_id')
            self._create_index_if_missing(cursor, 'ledger_entries', 'idx_ledger_entries_reference_id', 'reference_id')
        except Exception as e:
            print(f"Note: Ledger entries index creation failed (may already exist): {e}")
    
    def _create_purchase_items_table(self, cursor):
        """Create purchase_items table for purchase line items."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        hsn_type = self._get_text_type(50)
        unit_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS purchase_items (
                id {pk_autoinc},
                purchase_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                sl_no INTEGER NOT NULL,
                hsn {hsn_type},
                tax_percent REAL DEFAULT 0.0,
                unit {unit_type},
                rate REAL DEFAULT 0.0,
                quantity REAL DEFAULT 0.0,
                gross_value REAL DEFAULT 0.0,
                discount REAL DEFAULT 0.0,
                net_value REAL DEFAULT 0.0,
                tax_amount REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (purchase_id) REFERENCES purchases (id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            )
        """)
    
    def _create_sales_returns_table(self, cursor):
        """Create sales_returns table for sales return header information."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        return_no_type = self._get_text_type(100)
        original_bill_no_type = self._get_text_type(100)
        return_type_type = self._get_text_type(50)
        nature_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS sales_returns (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                return_no {return_no_type} NOT NULL,
                return_date DATE NOT NULL,
                original_bill_id INTEGER,
                original_bill_no {original_bill_no_type},
                party_id INTEGER,
                return_type {return_type_type} DEFAULT 'Cash' CHECK (return_type IN ('Cash', 'Credit')),
                nature {nature_type},
                narration TEXT,
                sub_total REAL DEFAULT 0.0,
                discount_total REAL DEFAULT 0.0,
                tax_total REAL DEFAULT 0.0,
                round_off REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                amount_refunded_or_adjusted REAL DEFAULT 0.0,
                balance_adjustment REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (party_id) REFERENCES parties (id) ON DELETE CASCADE,
                UNIQUE(company_id, return_no)
            )
        """)

    def _create_sales_return_items_table(self, cursor):
        """Create sales_return_items table for sales return line items."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        hsn_type = self._get_text_type(50)
        unit_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS sales_return_items (
                id {pk_autoinc},
                sales_return_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                sl_no INTEGER NOT NULL,
                hsn {hsn_type},
                cgst REAL DEFAULT 0.0,
                sgst REAL DEFAULT 0.0,
                igst REAL DEFAULT 0.0,
                cess REAL DEFAULT 0.0,
                tax_percent REAL DEFAULT 0.0,
                unit {unit_type},
                rate REAL DEFAULT 0.0,
                quantity REAL DEFAULT 0.0,
                gross_value REAL DEFAULT 0.0,
                discount REAL DEFAULT 0.0,
                net_value REAL DEFAULT 0.0,
                tax_amount REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (sales_return_id) REFERENCES sales_returns (id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            )
        """)
    
    def _create_purchase_returns_table(self, cursor):
        """Create purchase_returns table for purchase return header information."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        return_no_type = self._get_text_type(100)
        original_purchase_no_type = self._get_text_type(100)
        return_type_type = self._get_text_type(50)
        nature_type = self._get_text_type(50)
        supplier_invoice_no_type = self._get_text_type(100)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS purchase_returns (
                id {pk_autoinc},
                company_id INTEGER NOT NULL,
                return_no {return_no_type} NOT NULL,
                return_date DATE NOT NULL,
                original_purchase_id INTEGER,
                original_purchase_no {original_purchase_no_type},
                party_id INTEGER NOT NULL,
                return_type {return_type_type} DEFAULT 'Cash' CHECK (return_type IN ('Cash', 'Credit')),
                nature {nature_type},
                supplier_invoice_no {supplier_invoice_no_type},
                narration TEXT,
                sub_total REAL DEFAULT 0.0,
                discount_total REAL DEFAULT 0.0,
                tax_total REAL DEFAULT 0.0,
                round_off REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                amount_received_or_adjusted REAL DEFAULT 0.0,
                balance_adjustment REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                updated_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                FOREIGN KEY (party_id) REFERENCES parties (id) ON DELETE CASCADE,
                UNIQUE(company_id, return_no)
            )
        """)

    def _create_purchase_return_items_table(self, cursor):
        """Create purchase_return_items table for purchase return line items."""
        pk_autoinc = self._get_primary_key_autoincrement()
        timestamp_default = self._get_timestamp_default()
        # Use VARCHAR for indexed/searchable fields, TEXT for large fields
        hsn_type = self._get_text_type(50)
        unit_type = self._get_text_type(50)
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS purchase_return_items (
                id {pk_autoinc},
                purchase_return_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                sl_no INTEGER NOT NULL,
                hsn {hsn_type},
                cgst REAL DEFAULT 0.0,
                sgst REAL DEFAULT 0.0,
                igst REAL DEFAULT 0.0,
                cess REAL DEFAULT 0.0,
                tax_percent REAL DEFAULT 0.0,
                unit {unit_type},
                rate REAL DEFAULT 0.0,
                quantity REAL DEFAULT 0.0,
                gross_value REAL DEFAULT 0.0,
                discount REAL DEFAULT 0.0,
                net_value REAL DEFAULT 0.0,
                tax_amount REAL DEFAULT 0.0,
                grand_total REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT {timestamp_default},
                FOREIGN KEY (purchase_return_id) REFERENCES purchase_returns (id) ON DELETE CASCADE,
                FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
            )
        """)
        # Create indexes for purchase_return_items
        self._create_index_if_missing(cursor, 'purchase_return_items', 'idx_purchase_return_items_return_id', 'purchase_return_id')
        self._create_index_if_missing(cursor, 'purchase_return_items', 'idx_purchase_return_items_product_id', 'product_id')

    def _create_purchase_return_indexes(self, cursor):
        """Create indexes for purchase_returns table if they don't exist."""
        self._create_index_if_missing(cursor, 'purchase_returns', 'idx_purchase_returns_company_id', 'company_id')
        self._create_index_if_missing(cursor, 'purchase_returns', 'idx_purchase_returns_return_no', 'return_no')
        self._create_index_if_missing(cursor, 'purchase_returns', 'idx_purchase_returns_return_date', 'return_date')
        self._create_index_if_missing(cursor, 'purchase_returns', 'idx_purchase_returns_party_id', 'party_id')
        self._create_index_if_missing(cursor, 'purchase_returns', 'idx_purchase_returns_company_return', 'company_id, return_no')

    def _migrate_products_table(self, cursor):
        """Migrate products table to remove old global barcode uniqueness constraints (SQLite only)."""
        # Skip migration for MySQL (fresh install)
        if not self._is_sqlite():
            return
        
        try:
            # Check if products table exists
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products'")
            if not cursor.fetchone():
                return  # Table doesn't exist, no migration needed
            
            # Check if products table has old global barcode uniqueness constraint
            cursor.execute("PRAGMA table_info(products)")
            columns = [row[1] for row in cursor.fetchall()]
            
            # Check for old unique indexes on barcode only
            cursor.execute("PRAGMA index_list(products)")
            indexes = cursor.fetchall()
            
            has_old_barcode_constraint = False
            for index in indexes:
                if index[2]:  # unique flag
                    cursor.execute(f"PRAGMA index_info({index[1]})")
                    index_columns = [row[2] for row in cursor.fetchall()]
                    if len(index_columns) == 1 and index_columns[0] == 'barcode':
                        has_old_barcode_constraint = True
                        break
            
            # Also check if barcode column has UNIQUE constraint in table definition
            cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='products'")
            table_sql = cursor.fetchone()
            if table_sql and 'barcode TEXT UNIQUE' in table_sql[0]:
                has_old_barcode_constraint = True
            
            if has_old_barcode_constraint:
                print("Detected old global barcode uniqueness constraint, rebuilding products table...")
                
                # Rename current products table
                cursor.execute("ALTER TABLE products RENAME TO products_old")
                print("Renamed products table to products_old")
                
                # Create new products table with correct schema
                cursor.execute("""
                    CREATE TABLE products (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        company_id INTEGER NOT NULL,
                        name TEXT NOT NULL,
                        barcode TEXT,
                        hsn TEXT,
                        unit TEXT DEFAULT 'pcs',
                        category TEXT,
                        color TEXT,
                        size TEXT,
                        purchase_rate REAL DEFAULT 0.0,
                        sale_price REAL DEFAULT 0.0,
                        wholesale_rate REAL DEFAULT 0.0,
                        mrp REAL DEFAULT 0.0,
                        cgst REAL DEFAULT 0.0,
                        sgst REAL DEFAULT 0.0,
                        igst REAL DEFAULT 0.0,
                        cess REAL DEFAULT 0.0,
                        reorder_level REAL DEFAULT 0.0,
                        description TEXT,
                        quantity REAL DEFAULT 0.0,
                        auto_barcode INTEGER DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
                    )
                """)
                print("Created new products table with correct schema")
                
                # Copy data from old table to new table
                cursor.execute("""
                    INSERT INTO products (
                        id, company_id, name, barcode, hsn, unit, category, color, size,
                        purchase_rate, sale_price, wholesale_rate, mrp, cgst, sgst, igst,
                        cess, reorder_level, description, quantity, auto_barcode, created_at, updated_at
                    )
                    SELECT 
                        id, company_id, name, barcode, hsn, unit, category, color, size,
                        purchase_rate, sale_price, wholesale_rate, mrp, cgst, sgst, igst,
                        cess, reorder_level, description, quantity, auto_barcode, created_at, updated_at
                    FROM products_old
                """)
                print("Copied data from products_old to products")
                
                # Drop the old table
                cursor.execute("DROP TABLE products_old")
                print("Dropped products_old table")
                
                # Create company-specific unique index for barcode
                self._create_index_if_missing(cursor, 'products', 'idx_products_company_barcode', 'company_id, barcode', unique=True)
                print("Created company-specific unique index on products (company_id, barcode)")

                print("Products table migration completed successfully")

            # Ensure company-specific unique index exists on sales (company_id, invoice_number)
            self._create_index_if_missing(cursor, 'sales', 'idx_sales_company_invoice_number', 'company_id, invoice_number', unique=True)

        except Exception as e:
            print(f"Sales table migration error: {e}")
            raise

    def _migrate_stock_movements_table(self, cursor):
        """Migrate stock_movements table to add comprehensive stock tracking columns (SQLite only)."""
        if not self._is_sqlite():
            return
        
        try:
            cursor.execute("PRAGMA table_info(stock_movements)")
            columns = [row[1] for row in cursor.fetchall()]

            # Add comprehensive stock tracking columns for audit-ready stock report
            required_columns = [
                ('movement_date', 'TEXT'),
                ('voucher_type', 'TEXT'),
                ('voucher_no', 'TEXT'),
                ('narration', 'TEXT'),
                ('qty_in', 'REAL DEFAULT 0.0'),
                ('qty_out', 'REAL DEFAULT 0.0'),
                ('rate', 'REAL DEFAULT 0.0'),
                ('value_in', 'REAL DEFAULT 0.0'),
                ('value_out', 'REAL DEFAULT 0.0'),
                ('balance_qty', 'REAL DEFAULT 0.0'),
                ('balance_value', 'REAL DEFAULT 0.0')
            ]

            for field_name, field_type in required_columns:
                if field_name not in columns:
                    cursor.execute(f"ALTER TABLE stock_movements ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to stock_movements table")

            # Note: updated_at column not added via ALTER TABLE due to SQLite limitation
            # It will be added when the table is recreated in fresh install

            # Create indexes for performance with large datasets
            indexes = [
                ('idx_stock_movements_company_id', 'company_id'),
                ('idx_stock_movements_product_id', 'product_id'),
                ('idx_stock_movements_movement_date', 'movement_date'),
                ('idx_stock_movements_voucher_type', 'voucher_type'),
                ('idx_stock_movements_voucher_no', 'voucher_no'),
                ('idx_stock_movements_product_date', 'product_id, movement_date'),
                ('idx_stock_movements_company_date', 'company_id, movement_date')
            ]

            for index_name, index_cols in indexes:
                self._create_index_if_missing(cursor, 'stock_movements', index_name, index_cols)
                print(f"Created index {index_name}")

        except Exception as e:
            print(f"Stock movements table migration error: {e}")
            raise

    def _migrate_database(self, cursor):
        """Migrate existing database to add missing columns (SQLite only)."""
        # Skip migration for MySQL (fresh install)
        if not self._is_sqlite():
            return

        try:
            # Check if products table needs migration for barcode uniqueness
            self._migrate_products_table(cursor)

            # Migrate sales table to add missing columns (e.g. amount_received)
            self._migrate_sales_table(cursor)

            # Migrate stock_movements table to add comprehensive stock tracking columns
            self._migrate_stock_movements_table(cursor)

            # Check if logo_path column exists in companies table
            cursor.execute("PRAGMA table_info(companies)")
            columns = [row[1] for row in cursor.fetchall()]

            if 'logo_path' not in columns:
                cursor.execute("ALTER TABLE companies ADD COLUMN logo_path TEXT")
                print("Added logo_path column to companies table")

            if 'signature_path' not in columns:
                cursor.execute("ALTER TABLE companies ADD COLUMN signature_path TEXT")
                print("Added signature_path column to companies table")
                
            # Check if all required product fields exist
            cursor.execute("PRAGMA table_info(products)")
            product_columns = [row[1] for row in cursor.fetchall()]
            
            required_product_fields = [
                ('hsn', 'TEXT'),
                ('color', 'TEXT'),
                ('size', 'TEXT'),
                ('purchase_rate', 'REAL DEFAULT 0.0'),
                ('wholesale_rate', 'REAL DEFAULT 0.0'),
                ('mrp', 'REAL DEFAULT 0.0'),
                ('cgst', 'REAL DEFAULT 0.0'),
                ('sgst', 'REAL DEFAULT 0.0'),
                ('igst', 'REAL DEFAULT 0.0'),
                ('cess', 'REAL DEFAULT 0.0'),
                ('reorder_level', 'REAL DEFAULT 0.0'),
                ('quantity', 'REAL DEFAULT 0.0'),
                ('auto_barcode', 'INTEGER DEFAULT 1')
            ]
            
            for field_name, field_type in required_product_fields:
                if field_name not in product_columns:
                    cursor.execute(f"ALTER TABLE products ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to products table")

            # Check if state column exists in parties table
            cursor.execute("PRAGMA table_info(parties)")
            party_columns = [row[1] for row in cursor.fetchall()]

            if 'state' not in party_columns:
                cursor.execute("ALTER TABLE parties ADD COLUMN state TEXT")
                print("Added state column to parties table")
                
                # Add company-specific unique constraint for barcode
                self._create_index_if_missing(cursor, 'products', 'idx_products_company_barcode', 'company_id, barcode', unique=True)
                print("Added company-specific unique index on products (company_id, barcode)")
                
            # Check if accounts table needs company_id column
            cursor.execute("PRAGMA table_info(accounts)")
            account_columns = [row[1] for row in cursor.fetchall()]
            
            if 'company_id' not in account_columns:
                cursor.execute("ALTER TABLE accounts ADD COLUMN company_id INTEGER NOT NULL DEFAULT 1")
                # Add unique constraint for company_id, name
                self._create_index_if_missing(cursor, 'accounts', 'idx_accounts_company_name', 'company_id, name', unique=True)
                print("Added company_id column to accounts table")
                
            # Check if transactions table needs company_id column
            cursor.execute("PRAGMA table_info(transactions)")
            transaction_columns = [row[1] for row in cursor.fetchall()]
            
            if 'company_id' not in transaction_columns:
                cursor.execute("ALTER TABLE transactions ADD COLUMN company_id INTEGER NOT NULL DEFAULT 1")
                print("Added company_id column to transactions table")
                
            # Check if categories table needs company_id column
            cursor.execute("PRAGMA table_info(categories)")
            category_columns = [row[1] for row in cursor.fetchall()]
            
            if 'company_id' not in category_columns:
                cursor.execute("ALTER TABLE categories ADD COLUMN company_id INTEGER NOT NULL DEFAULT 1")
                # Add unique constraint for company_id, name
                self._create_index_if_missing(cursor, 'categories', 'idx_categories_company_name', 'company_id, name', unique=True)
                print("Added company_id column to categories table")

            # Migrate sales_returns.party_id to allow NULL (Cash returns need no party)
            self._migrate_sales_returns_party_nullable(cursor)

            # Create indexes for purchase_returns table
            self._create_purchase_return_indexes(cursor)

            # Migrate sales_items table to add split GST columns
            self._migrate_sales_items_split_gst(cursor)

            # Migrate purchase_items table to add split GST columns
            self._migrate_purchase_items_split_gst(cursor)

            # Migrate sales_return_items table to add split GST amount columns
            self._migrate_sales_return_items_split_gst_amounts(cursor)

            # Migrate purchase_return_items table to add split GST amount columns
            self._migrate_purchase_return_items_split_gst_amounts(cursor)

            # Migrate return items tables to add missing unit column
            self._migrate_return_items_add_unit(cursor)

            # Create performance indexes for faster bill navigation and loading
            self._create_performance_indexes(cursor)

            # Add ledger_account_id to parties table for party-ledger linkage
            self._migrate_parties_ledger_account_id(cursor)

            # Add compound ledger indexes for performance
            self._create_ledger_compound_indexes(cursor)

        except Exception as e:
            print(f"Database migration error: {e}")

    def _migrate_parties_ledger_account_id(self, cursor):
        """Add ledger_account_id column to parties table if missing (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(parties)")
            cols = [row[1] for row in cursor.fetchall()]
            if 'ledger_account_id' not in cols:
                cursor.execute("ALTER TABLE parties ADD COLUMN ledger_account_id INTEGER")
        except Exception as e:
            print(f"Note: parties ledger_account_id migration: {e}")

    def _create_ledger_compound_indexes(self, cursor):
        """Create compound indexes on ledger tables for performance."""
        self._create_index_if_missing(cursor, 'ledger_accounts', 'idx_la_company_name', 'company_id, account_name')
        self._create_index_if_missing(cursor, 'ledger_accounts', 'idx_la_company_type', 'company_id, account_type')
        self._create_index_if_missing(cursor, 'ledger_entries', 'idx_le_company_account_date', 'company_id, account_id, voucher_date')
        self._create_index_if_missing(cursor, 'ledger_entries', 'idx_le_company_vtype_vid', 'company_id, voucher_type, voucher_id')
        self._create_index_if_missing(cursor, 'ledger_entries', 'idx_le_company_vno', 'company_id, voucher_no')

    def _migrate_sales_items_split_gst(self, cursor):
        """Add split GST columns to sales_items table (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(sales_items)")
            columns = [row[1] for row in cursor.fetchall()]
            
            required_fields = [
                ('cgst', 'REAL DEFAULT 0.0'),
                ('sgst', 'REAL DEFAULT 0.0'),
                ('igst', 'REAL DEFAULT 0.0'),
                ('cess', 'REAL DEFAULT 0.0'),
                ('cgst_amount', 'REAL DEFAULT 0.0'),
                ('sgst_amount', 'REAL DEFAULT 0.0'),
                ('igst_amount', 'REAL DEFAULT 0.0'),
                ('cess_amount', 'REAL DEFAULT 0.0'),
            ]
            
            for field_name, field_type in required_fields:
                if field_name not in columns:
                    cursor.execute(f"ALTER TABLE sales_items ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to sales_items table")
                    
        except Exception as e:
            print(f"Sales items split GST migration error: {e}")

    def _migrate_purchase_items_split_gst(self, cursor):
        """Add split GST columns to purchase_items table (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(purchase_items)")
            columns = [row[1] for row in cursor.fetchall()]
            
            required_fields = [
                ('cgst', 'REAL DEFAULT 0.0'),
                ('sgst', 'REAL DEFAULT 0.0'),
                ('igst', 'REAL DEFAULT 0.0'),
                ('cess', 'REAL DEFAULT 0.0'),
                ('cgst_amount', 'REAL DEFAULT 0.0'),
                ('sgst_amount', 'REAL DEFAULT 0.0'),
                ('igst_amount', 'REAL DEFAULT 0.0'),
                ('cess_amount', 'REAL DEFAULT 0.0'),
            ]
            
            for field_name, field_type in required_fields:
                if field_name not in columns:
                    cursor.execute(f"ALTER TABLE purchase_items ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to purchase_items table")
                    
        except Exception as e:
            print(f"Purchase items split GST migration error: {e}")

    def _migrate_sales_return_items_split_gst_amounts(self, cursor):
        """Add split GST amount columns to sales_return_items table (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(sales_return_items)")
            columns = [row[1] for row in cursor.fetchall()]
            
            required_fields = [
                ('cgst_amount', 'REAL DEFAULT 0.0'),
                ('sgst_amount', 'REAL DEFAULT 0.0'),
                ('igst_amount', 'REAL DEFAULT 0.0'),
                ('cess_amount', 'REAL DEFAULT 0.0'),
            ]
            
            for field_name, field_type in required_fields:
                if field_name not in columns:
                    cursor.execute(f"ALTER TABLE sales_return_items ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to sales_return_items table")
                    
        except Exception as e:
            print(f"Sales return items split GST amount migration error: {e}")

    def _migrate_purchase_return_items_split_gst_amounts(self, cursor):
        """Add split GST amount columns to purchase_return_items table (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(purchase_return_items)")
            columns = [row[1] for row in cursor.fetchall()]
            
            required_fields = [
                ('cgst_amount', 'REAL DEFAULT 0.0'),
                ('sgst_amount', 'REAL DEFAULT 0.0'),
                ('igst_amount', 'REAL DEFAULT 0.0'),
                ('cess_amount', 'REAL DEFAULT 0.0'),
            ]
            
            for field_name, field_type in required_fields:
                if field_name not in columns:
                    cursor.execute(f"ALTER TABLE purchase_return_items ADD COLUMN {field_name} {field_type}")
                    print(f"Added {field_name} column to purchase_return_items table")
                    
        except Exception as e:
            print(f"Purchase return items split GST amount migration error: {e}")

    def _migrate_return_items_add_unit(self, cursor):
        """Add unit column to sales_return_items and purchase_return_items tables (SQLite only).

        This column was missing from the original schema, causing INSERT errors.
        """
        if not self._is_sqlite():
            return
        try:
            # Check and add unit column to sales_return_items
            cursor.execute("PRAGMA table_info(sales_return_items)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'unit' not in columns:
                cursor.execute("ALTER TABLE sales_return_items ADD COLUMN unit TEXT")
                print("Added unit column to sales_return_items table")

            # Check and add unit column to purchase_return_items
            cursor.execute("PRAGMA table_info(purchase_return_items)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'unit' not in columns:
                cursor.execute("ALTER TABLE purchase_return_items ADD COLUMN unit TEXT")
                print("Added unit column to purchase_return_items table")
        except Exception as e:
            print(f"Return items unit column migration error: {e}")

    def _migrate_sales_returns_party_nullable(self, cursor):
        """Recreate sales_returns table so party_id allows NULL (needed for Cash returns) (SQLite only)."""
        if not self._is_sqlite():
            return
        try:
            cursor.execute("PRAGMA table_info(sales_returns)")
            cols = cursor.fetchall()
            if not cols:
                return  # table doesn't exist yet, schema creation handles it
            # Check if party_id is currently NOT NULL
            party_col = next((c for c in cols if c[1] == 'party_id'), None)
            if party_col is None:
                return
            # col[3] is the 'notnull' flag in SQLite PRAGMA table_info
            if party_col[3] == 0:
                return  # already nullable, nothing to do
            print("Migrating sales_returns.party_id to allow NULL...")
            cursor.execute("ALTER TABLE sales_returns RENAME TO sales_returns_old")
            pk_autoinc = self._get_primary_key_autoincrement()
            timestamp_default = self._get_timestamp_default()
            cursor.execute(f"""
                CREATE TABLE sales_returns (
                    id {pk_autoinc},
                    company_id INTEGER NOT NULL,
                    return_no TEXT NOT NULL,
                    return_date DATE NOT NULL,
                    original_bill_id INTEGER,
                    original_bill_no TEXT,
                    party_id INTEGER,
                    return_type TEXT DEFAULT 'Cash' CHECK (return_type IN ('Cash', 'Credit')),
                    nature TEXT,
                    narration TEXT,
                    sub_total REAL DEFAULT 0.0,
                    discount_total REAL DEFAULT 0.0,
                    tax_total REAL DEFAULT 0.0,
                    round_off REAL DEFAULT 0.0,
                    grand_total REAL DEFAULT 0.0,
                    amount_refunded_or_adjusted REAL DEFAULT 0.0,
                    balance_adjustment REAL DEFAULT 0.0,
                    created_at TIMESTAMP DEFAULT {timestamp_default},
                    updated_at TIMESTAMP DEFAULT {timestamp_default},
                    FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE,
                    UNIQUE(company_id, return_no)
                )
            """)
            cursor.execute("""
                INSERT INTO sales_returns
                SELECT id, company_id, return_no, return_date, original_bill_id, original_bill_no,
                       party_id, return_type, nature, narration, sub_total, discount_total,
                       tax_total, round_off, grand_total, amount_refunded_or_adjusted,
                       balance_adjustment, created_at, updated_at
                FROM sales_returns_old
            """)
            cursor.execute("DROP TABLE sales_returns_old")
            self._create_index_if_missing(cursor, 'sales_returns', 'idx_sales_returns_company_return_no', 'company_id, return_no')
            self._create_index_if_missing(cursor, 'sales_returns', 'idx_sales_returns_company_return_date', 'company_id, return_date')
            # SQLite auto-updates FK references in child tables to point to the renamed table.
            # Recreate sales_return_items so its FK points back to new sales_returns.
            cursor.execute("ALTER TABLE sales_return_items RENAME TO sales_return_items_fk_old")
            pk_autoinc2 = self._get_primary_key_autoincrement()
            ts2 = self._get_timestamp_default()
            cursor.execute(f"""
                CREATE TABLE sales_return_items (
                    id {pk_autoinc2},
                    sales_return_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    sl_no INTEGER NOT NULL,
                    hsn TEXT,
                    cgst REAL DEFAULT 0.0,
                    sgst REAL DEFAULT 0.0,
                    igst REAL DEFAULT 0.0,
                    cess REAL DEFAULT 0.0,
                    tax_percent REAL DEFAULT 0.0,
                    rate REAL DEFAULT 0.0,
                    quantity REAL DEFAULT 0.0,
                    gross_value REAL DEFAULT 0.0,
                    discount REAL DEFAULT 0.0,
                    net_value REAL DEFAULT 0.0,
                    tax_amount REAL DEFAULT 0.0,
                    grand_total REAL DEFAULT 0.0,
                    created_at TIMESTAMP DEFAULT {ts2},
                    FOREIGN KEY (sales_return_id) REFERENCES sales_returns (id) ON DELETE CASCADE,
                    FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
                )
            """)
            cursor.execute("INSERT INTO sales_return_items SELECT * FROM sales_return_items_fk_old")
            cursor.execute("DROP TABLE sales_return_items_fk_old")
            self._create_index_if_missing(cursor, 'sales_return_items', 'idx_sales_return_items_product_id', 'product_id')
            print("sales_returns.party_id migration complete.")
        except Exception as e:
            print(f"sales_returns party_id migration error: {e}")

    def _create_performance_indexes(self, cursor):
        """Create performance-critical indexes for faster bill operations.

        These indexes significantly speed up:
        - Bill navigation (previous/next)
        - Bill loading (sale items lookup)
        - Bill deletion (cascade operations)
        - Stock report generation
        """
        indexes = [
            # Sales items - critical for loading bills quickly
            ("idx_sales_items_sale_id", "sales_items", "sale_id"),
            ("idx_sales_items_product_id", "sales_items", "product_id"),

            # Purchase items - critical for loading purchase bills
            ("idx_purchase_items_purchase_id", "purchase_items", "purchase_id"),
            ("idx_purchase_items_product_id", "purchase_items", "product_id"),

            # Sales navigation - for fast previous/next bill lookups
            ("idx_sales_company_id", "sales", "company_id"),
            ("idx_sales_company_id_id", "sales", "company_id, id"),

            # Purchase navigation
            ("idx_purchases_company_id", "purchases", "company_id"),
            ("idx_purchases_company_id_id", "purchases", "company_id, id"),

            # Stock movements - for faster stock balance calculations
            ("idx_stock_movements_company_product", "stock_movements", "company_id, product_id"),
            ("idx_stock_movements_reference", "stock_movements", "reference_type, reference_id"),

            # Sales returns
            ("idx_sales_return_items_return_id", "sales_return_items", "sales_return_id"),

            # Purchase returns
            ("idx_purchase_return_items_return_id", "purchase_return_items", "purchase_return_id"),
        ]

        created_count = 0
        for index_name, table, columns in indexes:
            try:
                self._create_index_if_missing(cursor, table, index_name, columns)
                created_count += 1
            except Exception as e:
                print(f"Note: Index {index_name} creation skipped: {e}")

        if created_count > 0:
            print(f"Created {created_count} performance indexes")

    def execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Execute a SELECT query and return results."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            cursor.execute(query, params)
            
            # Handle different cursor result formats
            if self.db_type == "sqlite":
                results = [dict(row) for row in cursor.fetchall()]
            else:
                # MySQL: convert to dict using cursor.description
                columns = [column[0] for column in cursor.description]
                results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            return results
        except Exception as e:
            print(f"Query execution error: {e}")
            return []
        finally:
            self.disconnect()
    
    def execute_update(self, query: str, params: tuple = ()) -> bool:
        """Execute an INSERT, UPDATE, or DELETE query."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            return True
        except Exception as e:
            print(f"Update execution error: {e}")
            raise  # Re-raise to allow caller to handle the error
        finally:
            self.disconnect()
    
    def backup_database(self, backup_path: Optional[str] = None) -> bool:
        """Create a backup of the database (SQLite only)."""
        # Backup is only supported for SQLite
        if self.db_type != "sqlite":
            print("Backup is only supported for SQLite backend")
            return False
        
        if backup_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_dir = DATABASE_BACKUP_DIR
            os.makedirs(backup_dir, exist_ok=True)
            backup_path = os.path.join(backup_dir, f"backup_{timestamp}.db")
        
        try:
            source = sqlite3.connect(self.db_path)
            backup = sqlite3.connect(backup_path)
            source.backup(backup)
            source.close()
            backup.close()
            print(f"Database backed up to: {backup_path}")
            return True
        except Exception as e:
            print(f"Backup error: {e}")
            return False
    
    def company_name_exists(self, business_name: str) -> bool:
        """Check if a company name already exists (case-insensitive, ignoring leading/trailing spaces)."""
        normalized_name = business_name.strip().lower()
        ph = self._get_placeholder()
        query = f"SELECT COUNT(*) as count FROM companies WHERE LOWER(TRIM(business_name)) = {ph}"
        result = self.execute_query(query, (normalized_name,))
        return result[0]['count'] > 0 if result else False
    
    def create_company(self, company_data: Dict[str, Any]) -> bool:
        """Create a new company record and set it as active."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            
            # Deactivate all existing companies first
            cursor.execute("UPDATE companies SET is_active = 0")
            
            # Insert new company as active
            placeholder = self._get_placeholder()
            query = f"""
                INSERT INTO companies (
                    business_name, phone_number, gstin, email, business_type, 
                    business_category, address, state, pincode, logo_path, signature_path, is_active
                ) VALUES ({placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, {placeholder}, 1)
            """
            params = (
                company_data.get('business_name'),
                company_data.get('phone_number'),
                company_data.get('gstin'),
                company_data.get('email'),
                company_data.get('business_type'),
                company_data.get('business_category'),
                company_data.get('address'),
                company_data.get('state'),
                company_data.get('pincode'),
                company_data.get('logo_path'),
                company_data.get('signature_path')
            )
            cursor.execute(query, params)
            
            conn.commit()
            self.disconnect()
            return True
        except Exception as e:
            print(f"Error creating company: {e}")
            return False
    
    def get_all_companies(self) -> List[Dict[str, Any]]:
        """Get all companies."""
        query = "SELECT * FROM companies ORDER BY business_name"
        return self.execute_query(query)
    
    def get_active_company(self) -> Optional[Dict[str, Any]]:
        """Get the currently active company."""
        query = "SELECT * FROM companies WHERE is_active = 1 LIMIT 1"
        result = self.execute_query(query)
        return result[0] if result else None
    
    def set_active_company(self, company_id: int) -> bool:
        """Set a company as active (deactivate all others first)."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            
            # Deactivate all companies
            cursor.execute("UPDATE companies SET is_active = 0")
            
            # Activate the specified company
            placeholder = self._get_placeholder()
            cursor.execute(f"UPDATE companies SET is_active = 1 WHERE id = {placeholder}", (company_id,))
            
            conn.commit()
            self.disconnect()
            return True
        except Exception as e:
            print(f"Error setting active company: {e}")
            return False
    
    def update_company(self, company_id: int, company_data: Dict[str, Any]) -> bool:
        """Update an existing company record."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            
            # Update company
            placeholder = self._get_placeholder()
            timestamp_default = self._get_timestamp_default()
            query = f"""
                UPDATE companies SET 
                    business_name = {placeholder}, phone_number = {placeholder}, gstin = {placeholder}, email = {placeholder}, 
                    business_type = {placeholder}, business_category = {placeholder}, address = {placeholder}, 
                    state = {placeholder}, pincode = {placeholder}, logo_path = {placeholder}, signature_path = {placeholder},
                    updated_at = {timestamp_default}
                WHERE id = {placeholder}
            """
            params = (
                company_data.get('business_name'),
                company_data.get('phone_number'),
                company_data.get('gstin'),
                company_data.get('email'),
                company_data.get('business_type'),
                company_data.get('business_category'),
                company_data.get('address'),
                company_data.get('state'),
                company_data.get('pincode'),
                company_data.get('logo_path'),
                company_data.get('signature_path'),
                company_id
            )
            cursor.execute(query, params)
            
            conn.commit()
            self.disconnect()
            return True
        except Exception as e:
            print(f"Error updating company: {e}")
            return False
    
    def company_name_exists_excluding_id(self, business_name: str, exclude_id: int) -> bool:
        """Check if a company name already exists, excluding a specific company ID."""
        normalized_name = business_name.strip().lower()
        ph = self._get_placeholder()
        query = f"SELECT COUNT(*) as count FROM companies WHERE LOWER(TRIM(business_name)) = {ph} AND id != {ph}"
        result = self.execute_query(query, (normalized_name, exclude_id))
        return result[0]['count'] > 0 if result else False
    
    def delete_company(self, company_id: int) -> bool:
        """Delete a company permanently from database."""
        try:
            conn = self.connect()
            cursor = conn.cursor()
            
            # Delete related data in correct order to avoid foreign key constraints
            placeholder = self._get_placeholder()
            # Delete transactions first
            cursor.execute(f"DELETE FROM transactions WHERE company_id = {placeholder}", (company_id,))
            # Delete categories
            cursor.execute(f"DELETE FROM categories WHERE company_id = {placeholder}", (company_id,))
            # Delete accounts
            cursor.execute(f"DELETE FROM accounts WHERE company_id = {placeholder}", (company_id,))
            # Delete products
            cursor.execute(f"DELETE FROM products WHERE company_id = {placeholder}", (company_id,))
            # Delete parties
            cursor.execute(f"DELETE FROM parties WHERE company_id = {placeholder}", (company_id,))
            # Finally delete the company
            cursor.execute(f"DELETE FROM companies WHERE id = {placeholder}", (company_id,))
            
            conn.commit()
            self.disconnect()
            return True
        except Exception as e:
            print(f"Error deleting company: {e}")
            return False
    
    def get_accounts(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all accounts for a specific company."""
        query = """
            SELECT id, name, type, balance, currency, description, created_at, updated_at
            FROM accounts 
            WHERE company_id = {ph}
            ORDER BY name
        """
        ph = self._get_placeholder()
        query = f"""
            SELECT a.id, a.name, a.type, a.balance, a.currency, a.description
            FROM accounts 
            WHERE company_id = {ph}
            ORDER BY name
        """
        return self.execute_query(query, (company_id,))
    
    def create_account(self, company_id: int, name: str, account_type: str, 
                    balance: float = 0.0, currency: str = 'USD', 
                    description: str = None) -> bool:
        """Create a new account for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO accounts (company_id, name, type, balance, currency, description)
            VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        return self.execute_update(query, (company_id, name, account_type, balance, currency, description))
    
    def update_account(self, account_id: int, name: str, account_type: str,
                    balance: float, currency: str, description: str) -> bool:
        """Update an existing account."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE accounts 
            SET name = {ph},
                type = {ph},
                balance = {ph},
                currency = {ph},
                description = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph}
        """
        return self.execute_update(query, (name, account_type, balance, currency, description, account_id))
    
    def delete_account(self, account_id: int) -> bool:
        """Delete an account."""
        ph = self._get_placeholder()
        query = f"DELETE FROM accounts WHERE id = {ph}"
        return self.execute_update(query, (account_id,))
    
    def get_setting(self, key: str) -> Optional[str]:
        """Get a setting value."""
        ph = self._get_placeholder()
        query = f"SELECT value FROM settings WHERE key = {ph}"
        result = self.execute_query(query, (key,))
        return result[0]['value'] if result else None
    
    def get_transactions_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all transactions for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT t.id, t.date, t.account_id, a.name as account_name, t.amount, t.type,
                   t.description, t.category_id, c.name as category_name, t.created_at
            FROM transactions t
            LEFT JOIN accounts a ON t.account_id = a.id
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE t.company_id = {ph}
            ORDER BY t.date DESC, t.created_at DESC
        """
        return self.execute_query(query, (company_id,))
    
    def create_transaction(self, company_id: int, account_id: int, amount: float,
                         transaction_type: str, description: str = None, 
                         date: str = None, category_id: int = None) -> bool:
        """Create a new transaction for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO transactions (company_id, account_id, amount, type, description, date, category_id)
            VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        return self.execute_update(query, (company_id, account_id, amount, transaction_type, description, date, category_id))
    
    def get_categories(self, company_id: int, category_type: str = None) -> List[Dict[str, Any]]:
        """Get all categories for a specific company."""
        ph = self._get_placeholder()
        if category_type:
            query = f"""
                SELECT id, name, type, color, description, created_at
                FROM categories 
                WHERE company_id = {ph} AND type = {ph}
                ORDER BY name
            """
            return self.execute_query(query, (company_id, category_type))
        else:
            query = f"""
                SELECT id, name, type, color, description, created_at
                FROM categories 
                WHERE company_id = {ph}
                ORDER BY name
            """
            return self.execute_query(query, (company_id,))
    
    def create_category(self, company_id: int, name: str, category_type: str,
                       color: str = '#2196F3', description: str = None) -> bool:
        """Create a new category for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO categories (company_id, name, type, color, description)
            VALUES ({ph}, {ph}, {ph}, {ph}, {ph})
        """
        return self.execute_update(query, (company_id, name, category_type, color, description))
    
    def set_setting(self, key: str, value: str) -> bool:
        """Set a setting value using backend-safe INSERT OR REPLACE."""
        ph = self._get_placeholder()
        if self._is_sqlite():
            query = f"INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES ({ph}, {ph}, CURRENT_TIMESTAMP)"
        else:
            query = f"""
                INSERT INTO settings (key, value, updated_at)
                VALUES ({ph}, {ph}, CURRENT_TIMESTAMP)
                ON DUPLICATE KEY UPDATE value = {ph}, updated_at = CURRENT_TIMESTAMP
            """
        if self._is_mysql():
            return self.execute_update(query, (key, value, value))
        return self.execute_update(query, (key, value))
    
    # Product-specific methods
    
    def get_products_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all products for a specific company, ordered by barcode.

        Returns calculated stock balance from movements instead of products.quantity.
        """
        ph = self._get_placeholder()
        query = f"""
            SELECT p.id, p.name, p.barcode, p.hsn, p.color, p.size, p.unit, p.category,
                   p.purchase_rate, p.sale_price, p.wholesale_rate, p.mrp,
                   p.cgst, p.sgst, p.igst, p.cess, p.reorder_level,
                   COALESCE(
                       (SELECT SUM(CASE
                           WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                           WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                           ELSE 0
                       END)
                       FROM stock_movements sm
                       WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                       0.0
                   ) as quantity
            FROM products p
            WHERE p.company_id = {ph}
            ORDER BY
                CASE
                    WHEN p.barcode IS NULL OR p.barcode = '' THEN 1
                    ELSE 0
                END,
                CAST(p.barcode AS INTEGER)
        """
        return self.execute_query(query, (company_id,))

    def search_products_limited(self, company_id: int, search_term: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Search products by name or barcode with a result limit.

        Safe for very large product catalogs. Uses SQL LIKE for prefix and
        contains matching, with an early LIMIT to avoid loading everything.
        """
        if not search_term:
            return []
        search_pattern = f"%{search_term}%"
        ph = self._get_placeholder()
        query = f"""
            SELECT p.id, p.name, p.barcode, p.hsn, p.color, p.size, p.unit, p.category,
                   p.purchase_rate, p.sale_price, p.wholesale_rate, p.mrp,
                   p.cgst, p.sgst, p.igst, p.cess, p.reorder_level,
                   COALESCE(
                       (SELECT SUM(CASE
                           WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                           WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                           ELSE 0
                       END)
                       FROM stock_movements sm
                       WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                       0.0
                   ) as quantity
            FROM products p
            WHERE p.company_id = {ph} AND (p.name LIKE {ph} OR p.barcode LIKE {ph})
            ORDER BY p.name
            LIMIT {ph}
        """
        return self.execute_query(query, (company_id, search_pattern, search_pattern, limit))

    def get_product_count(self, company_id: int) -> int:
        """Get total product count for a company (lightweight query)."""
        ph = self._get_placeholder()
        query = f"SELECT COUNT(*) as count FROM products WHERE company_id = {ph}"
        result = self.execute_query(query, (company_id,))
        return result[0]['count'] if result else 0

    def get_product_by_exact_name(self, company_id: int, name: str) -> Optional[Dict[str, Any]]:
        """Get product by exact name match (case-insensitive)."""
        ph = self._get_placeholder()
        query = f"""
            SELECT p.id, p.name, p.barcode, p.hsn, p.color, p.size, p.unit, p.category,
                   p.purchase_rate, p.sale_price, p.wholesale_rate, p.mrp,
                   p.cgst, p.sgst, p.igst, p.cess, p.reorder_level,
                   COALESCE(
                       (SELECT SUM(CASE
                           WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                           WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                           ELSE 0
                       END)
                       FROM stock_movements sm
                       WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                       0.0
                   ) as quantity
            FROM products p
            WHERE p.company_id = {ph} AND LOWER(p.name) = LOWER({ph})
        """
        result = self.execute_query(query, (company_id, name))
        return result[0] if result else None

    def get_product_by_id(self, company_id: int, product_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific product by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, name, barcode, hsn, color, size, unit, category,
                   purchase_rate, sale_price, wholesale_rate, mrp,
                   cgst, sgst, igst, cess, reorder_level,
                   description, quantity, auto_barcode
            FROM products
            WHERE company_id = {ph} AND id = {ph}
        """
        result = self.execute_query(query, (company_id, product_id))
        return result[0] if result else None

    def get_product_by_barcode(self, company_id: int, barcode: str) -> Optional[Dict[str, Any]]:
        """Get a specific product by barcode for a company (exact match)."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, name, barcode, hsn, color, size, unit, category,
                   purchase_rate, sale_price, wholesale_rate, mrp,
                   cgst, sgst, igst, cess, reorder_level,
                   description, quantity, auto_barcode
            FROM products
            WHERE company_id = {ph} AND barcode = {ph}
        """
        result = self.execute_query(query, (company_id, barcode))
        return result[0] if result else None
    
    def insert_product(self, company_id: int, product_data: Dict[str, Any]) -> int:
        """Insert a new product for a company and return the product ID."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO products (
                company_id, name, barcode, hsn, color, size, unit, category,
                purchase_rate, sale_price, wholesale_rate, mrp,
                cgst, sgst, igst, cess, reorder_level,
                description, quantity, auto_barcode
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            product_data.get('name'),
            product_data.get('barcode'),
            product_data.get('hsn'),
            product_data.get('color'),
            product_data.get('size'),
            product_data.get('unit', 'pcs'),
            product_data.get('category'),
            product_data.get('purchase_rate', 0.0),
            product_data.get('sale_price', 0.0),
            product_data.get('wholesale_rate', 0.0),
            product_data.get('mrp', 0.0),
            product_data.get('cgst', 0.0),
            product_data.get('sgst', 0.0),
            product_data.get('igst', 0.0),
            product_data.get('cess', 0.0),
            product_data.get('reorder_level', 0.0),
            product_data.get('description'),
            product_data.get('quantity', 0.0),
            1 if product_data.get('auto_barcode', True) else 0
        )
        try:
            conn = self.connect()
            cursor = conn.cursor()
            cursor.execute(query, params)
            conn.commit()
            product_id = self._get_last_insert_id(cursor)
            return product_id
        except Exception as e:
            print(f"Insert product error: {e}")
            raise
        finally:
            self.disconnect()
    
    def update_product(self, company_id: int, product_id: int, product_data: Dict[str, Any]) -> bool:
        """Update an existing product for a company."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE products
            SET name = {ph},
                barcode = {ph},
                hsn = {ph},
                color = {ph},
                size = {ph},
                unit = {ph},
                category = {ph},
                purchase_rate = {ph},
                sale_price = {ph},
                wholesale_rate = {ph},
                mrp = {ph},
                cgst = {ph},
                sgst = {ph},
                igst = {ph},
                cess = {ph},
                reorder_level = {ph},
                description = {ph},
                quantity = {ph},
                auto_barcode = {ph}
            WHERE id = {ph} AND company_id = {ph}
        """
        params = (
            product_data.get('name'),
            product_data.get('barcode'),
            product_data.get('hsn'),
            product_data.get('color'),
            product_data.get('size'),
            product_data.get('unit', 'pcs'),
            product_data.get('category'),
            product_data.get('purchase_rate', 0.0),
            product_data.get('sale_price', 0.0),
            product_data.get('wholesale_rate', 0.0),
            product_data.get('mrp', 0.0),
            product_data.get('cgst', 0.0),
            product_data.get('sgst', 0.0),
            product_data.get('igst', 0.0),
            product_data.get('cess', 0.0),
            product_data.get('reorder_level', 0.0),
            product_data.get('description'),
            product_data.get('quantity', 0.0),
            1 if product_data.get('auto_barcode', True) else 0,
            product_id,
            company_id
        )
        return self.execute_update(query, params)
    
    def delete_product(self, company_id: int, product_id: int) -> bool:
        """Delete a product for a company."""
        ph = self._get_placeholder()
        query = f"DELETE FROM products WHERE id = {ph} AND company_id = {ph}"
        return self.execute_update(query, (product_id, company_id))
    
    def barcode_exists(self, company_id: int, barcode: str, exclude_product_id: Optional[int] = None) -> bool:
        """Check if a barcode exists for a company (excluding a specific product if editing)."""
        ph = self._get_placeholder()
        if exclude_product_id:
            query = f"SELECT id FROM products WHERE barcode = {ph} AND company_id = {ph} AND id != {ph}"
            result = self.execute_query(query, (barcode, company_id, exclude_product_id))
        else:
            query = f"SELECT id FROM products WHERE barcode = {ph} AND company_id = {ph}"
            result = self.execute_query(query, (barcode, company_id))
        return len(result) > 0
    
    def get_existing_barcodes(self, company_id: int, exclude_product_id: Optional[int] = None) -> List[int]:
        """Get all existing numeric barcodes for a company."""
        ph = self._get_placeholder()
        if exclude_product_id:
            query = f"""
                SELECT barcode FROM products 
                WHERE company_id = {ph} AND id != {ph} AND barcode IS NOT NULL AND barcode != ''
            """
            result = self.execute_query(query, (company_id, exclude_product_id))
        else:
            query = f"""
                SELECT barcode FROM products 
                WHERE company_id = {ph} AND barcode IS NOT NULL AND barcode != ''
            """
            result = self.execute_query(query, (company_id,))
        
        existing_barcodes = []
        for row in result:
            if row['barcode']:
                try:
                    existing_barcodes.append(int(row['barcode']))
                except (ValueError, TypeError):
                    pass
        
        return existing_barcodes
    
    def get_max_numeric_barcode(self, company_id: int) -> Optional[int]:
        """Get the maximum numeric barcode for a company."""
        cast_integer = self._get_cast_integer()
        ph = self._get_placeholder()
        query = f"""
            SELECT MAX(CAST(barcode {cast_integer})) as max_barcode
            FROM products 
            WHERE company_id = {ph} AND barcode IS NOT NULL AND barcode != ''
        """
        result = self.execute_query(query, (company_id,))
        if result and result[0]['max_barcode']:
            return int(result[0]['max_barcode'])
        return None

    # Party-specific methods
    
    def get_parties_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all parties for a specific company, ordered by name."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, name, party_type, opening_balance, mobile_number,
                   email, gstin, credit_limit, contact_person, address, notes, state
            FROM parties
            WHERE company_id = {ph}
            ORDER BY name
        """
        return self.execute_query(query, (company_id,))
    
    def get_party_by_id(self, company_id: int, party_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific party by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, name, party_type, opening_balance, mobile_number,
                   email, gstin, credit_limit, contact_person, address, notes, state
            FROM parties
            WHERE company_id = {ph} AND id = {ph}
        """
        result = self.execute_query(query, (company_id, party_id))
        return result[0] if result else None

    def get_party_balance(self, company_id: int, party_id: int) -> float:
        """Return current balance for a party = opening_balance + sum of outstanding credit sales."""
        try:
            # Get party opening_balance
            party = self.get_party_by_id(company_id, party_id)
            opening_balance = float(party.get('opening_balance', 0.0)) if party else 0.0

            # Sum outstanding amounts from all credit sales for this party
            ph = self._get_placeholder()
            query = f"""
                SELECT COALESCE(SUM(grand_total - amount_received), 0.0) as outstanding
                FROM sales
                WHERE company_id = {ph} AND party_id = {ph} AND sales_type = 'Credit Sales'
            """
            result = self.execute_query(query, (company_id, party_id))
            outstanding = float(result[0].get('outstanding', 0.0)) if result else 0.0
            return opening_balance + outstanding
        except Exception:
            return 0.0
    
    def insert_party(self, company_id: int, party_data: Dict[str, Any]) -> Optional[int]:
        """Insert a new party for a company. Returns the new party ID or None on failure."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO parties (
                company_id, name, party_type, opening_balance, mobile_number,
                email, gstin, credit_limit, contact_person, address, notes
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            party_data.get('name'),
            party_data.get('party_type'),
            party_data.get('opening_balance', 0.0),
            party_data.get('mobile_number'),
            party_data.get('email'),
            party_data.get('gstin'),
            party_data.get('credit_limit', 0.0),
            party_data.get('contact_person'),
            party_data.get('address'),
            party_data.get('notes')
        )
        self.execute_update(query, params)
        # Look up by UNIQUE(company_id, name) to get the new ID
        ph = self._get_placeholder()
        result = self.execute_query(
            f"SELECT id FROM parties WHERE company_id = {ph} AND name = {ph} ORDER BY id DESC LIMIT 1",
            (company_id, party_data.get('name'))
        )
        return result[0]['id'] if result else None
    
    def update_party(self, company_id: int, party_id: int, party_data: Dict[str, Any]) -> bool:
        """Update an existing party for a company."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE parties
            SET name = {ph},
                party_type = {ph},
                opening_balance = {ph},
                mobile_number = {ph},
                email = {ph},
                gstin = {ph},
                credit_limit = {ph},
                contact_person = {ph},
                address = {ph},
                notes = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        params = (
            party_data.get('name'),
            party_data.get('party_type'),
            party_data.get('opening_balance', 0.0),
            party_data.get('mobile_number'),
            party_data.get('email'),
            party_data.get('gstin'),
            party_data.get('credit_limit', 0.0),
            party_data.get('contact_person'),
            party_data.get('address'),
            party_data.get('notes'),
            party_id,
            company_id
        )
        return self.execute_update(query, params)
    
    def delete_party(self, company_id: int, party_id: int) -> bool:
        """Delete a party for a company."""
        ph = self._get_placeholder()
        query = f"DELETE FROM parties WHERE id = {ph} AND company_id = {ph}"
        return self.execute_update(query, (party_id, company_id))
    
    def party_name_exists(self, company_id: int, party_name: str, exclude_party_id: Optional[int] = None) -> bool:
        """Check if a party name exists for a company (excluding a specific party if editing)."""
        ph = self._get_placeholder()
        if exclude_party_id:
            query = f"SELECT id FROM parties WHERE name = {ph} AND company_id = {ph} AND id != {ph}"
            result = self.execute_query(query, (party_name, company_id, exclude_party_id))
        else:
            query = f"SELECT id FROM parties WHERE name = {ph} AND company_id = {ph}"
            result = self.execute_query(query, (party_name, company_id))
        return len(result) > 0

    # Purchase-specific methods

    def get_next_purchase_number(self, company_id: int, series: str = "") -> str:
        """Get the next auto-incrementing purchase number for a company."""
        ph = self._get_placeholder()
        if series:
            query = f"""
                SELECT MAX(CAST(SUBSTR(purchase_number, LENGTH({ph}) + 1) AS INTEGER)) as max_num
                FROM purchases
                WHERE company_id = {ph} AND purchase_number LIKE {ph}
            """
            pattern = f"{series}%"
            result = self.execute_query(query, (series, company_id, pattern))
        else:
            query = f"""
                SELECT MAX(CAST(purchase_number AS INTEGER)) as max_num
                FROM purchases
                WHERE company_id = {ph}
            """
            result = self.execute_query(query, (company_id,))
        
        if result and result[0]['max_num']:
            next_num = result[0]['max_num'] + 1
        else:
            next_num = 1
        
        return f"{series}{next_num}" if series else str(next_num)

    def get_purchases_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all purchases for a specific company, ordered by date desc."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, purchase_number, purchase_date, party_id, purchase_type,
                   bill_series, nature, due_date, address, gstin, state,
                   narration, sub_total, discount_total, tax_total, round_off,
                   grand_total, amount_paid, created_at
            FROM purchases
            WHERE company_id = {ph}
            ORDER BY purchase_date DESC, id DESC
        """
        return self.execute_query(query, (company_id,))

    def get_purchase_ids_by_company(self, company_id: int) -> List[int]:
        """Get only purchase IDs for a specific company - optimized for navigation.

        This is much faster than get_purchases_by_company() for prev/next navigation
        because it doesn't return full rows.
        """
        ph = self._get_placeholder()
        query = f"""
            SELECT id FROM purchases
            WHERE company_id = {ph}
            ORDER BY id ASC
        """
        results = self.execute_query(query, (company_id,))
        return [r['id'] for r in results if r.get('id') is not None]

    def get_purchase_by_id(self, company_id: int, purchase_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific purchase by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, purchase_number, purchase_date, party_id, purchase_type,
                   bill_series, nature, due_date, address, gstin, state,
                   narration, sub_total, discount_total, tax_total, round_off,
                   grand_total, amount_paid, created_at
            FROM purchases
            WHERE company_id = {ph} AND id = {ph}
        """
        result = self.execute_query(query, (company_id, purchase_id))
        return result[0] if result else None

    def get_purchase_items(self, purchase_id: int) -> List[Dict[str, Any]]:
        """Get all items for a specific purchase, ordered by sl_no."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, product_id, sl_no, hsn, tax_percent, unit, rate, quantity,
                   gross_value, discount, net_value, tax_amount, grand_total,
                   cgst, sgst, igst, cess, cgst_amount, sgst_amount, igst_amount, cess_amount
            FROM purchase_items
            WHERE purchase_id = {ph}
            ORDER BY sl_no
        """
        return self.execute_query(query, (purchase_id,))

    def purchase_number_exists(self, company_id: int, purchase_number: str, exclude_purchase_id: Optional[int] = None) -> bool:
        """Check if a purchase number exists for a company (excluding a specific purchase if editing)."""
        ph = self._get_placeholder()
        if exclude_purchase_id:
            query = f"SELECT id FROM purchases WHERE purchase_number = {ph} AND company_id = {ph} AND id != {ph}"
            result = self.execute_query(query, (purchase_number, company_id, exclude_purchase_id))
        else:
            query = f"SELECT id FROM purchases WHERE purchase_number = {ph} AND company_id = {ph}"
            result = self.execute_query(query, (purchase_number, company_id))
        return len(result) > 0

    def save_purchase(self, company_id: int, purchase_data: Dict[str, Any], purchase_items: List[Dict[str, Any]]) -> Optional[int]:
        """Save a new purchase with its items. Returns purchase_id on success, None on failure."""
        conn = self.connect()
        cursor = conn.cursor()
        try:
            # Insert purchase header
            timestamp_default = self._get_timestamp_default()
            ph = self._get_placeholder()
            query = f"""
                INSERT INTO purchases (
                    company_id, purchase_number, purchase_date, party_id, purchase_type,
                    bill_series, nature, due_date, address, gstin, state,
                    narration, sub_total, discount_total, tax_total, round_off,
                    grand_total, amount_paid, created_at, updated_at
                ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {timestamp_default}, {timestamp_default})
            """
            params = (
                company_id,
                purchase_data.get('purchase_number'),
                purchase_data.get('purchase_date'),
                purchase_data.get('party_id'),
                purchase_data.get('purchase_type', 'Cash'),
                purchase_data.get('bill_series'),
                purchase_data.get('nature'),
                purchase_data.get('due_date'),
                purchase_data.get('address'),
                purchase_data.get('gstin'),
                purchase_data.get('state'),
                purchase_data.get('narration'),
                purchase_data.get('sub_total', 0.0),
                purchase_data.get('discount_total', 0.0),
                purchase_data.get('tax_total', 0.0),
                purchase_data.get('round_off', 0.0),
                purchase_data.get('grand_total', 0.0),
                purchase_data.get('amount_paid', 0.0)
            )
            cursor.execute(query, params)
            purchase_id = self._get_last_insert_id(cursor)

            # Insert purchase items with split GST columns
            for item in purchase_items:
                ph = self._get_placeholder()
                query = f"""
                    INSERT INTO purchase_items (
                        purchase_id, product_id, sl_no, hsn, tax_percent, unit, rate, quantity,
                        gross_value, discount, net_value, tax_amount, grand_total, created_at,
                        cgst, sgst, igst, cess, cgst_amount, sgst_amount, igst_amount, cess_amount
                    ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {timestamp_default}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
                """
                params = (
                    purchase_id,
                    item.get('product_id'),
                    item.get('sl_no'),
                    item.get('hsn'),
                    item.get('tax_percent', 0.0),
                    item.get('unit'),
                    item.get('rate', 0.0),
                    item.get('quantity', 0.0),
                    item.get('gross_value', 0.0),
                    item.get('discount', 0.0),
                    item.get('net_value', 0.0),
                    item.get('tax_amount', 0.0),
                    item.get('grand_total', 0.0),
                    item.get('cgst', 0.0),
                    item.get('sgst', 0.0),
                    item.get('igst', 0.0),
                    item.get('cess', 0.0),
                    item.get('cgst_amount', 0.0),
                    item.get('sgst_amount', 0.0),
                    item.get('igst_amount', 0.0),
                    item.get('cess_amount', 0.0)
                )
                cursor.execute(query, params)

            # Create stock movements for purchase (stock increases)
            for item in purchase_items:
                ph = self._get_placeholder()
                query = f"""
                    INSERT INTO stock_movements (
                        company_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_at
                    ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {timestamp_default})
                """
                params = (
                    company_id,
                    item.get('product_id'),
                    'purchase',
                    item.get('quantity', 0.0),
                    'purchase',
                    purchase_id,
                    f"Purchase {purchase_data.get('purchase_number')}"
                )
                cursor.execute(query, params)

            # Update product quantities (for backward compatibility with stock_display)
            for item in purchase_items:
                ph = self._get_placeholder()
                query = f"""
                    UPDATE products
                    SET quantity = COALESCE(quantity, 0) + {ph},
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = {ph} AND company_id = {ph}
                """
                cursor.execute(query, (item.get('quantity', 0.0), item.get('product_id'), company_id))

            conn.commit()
            return purchase_id
        except Exception as e:
            conn.rollback()
            print(f"Error saving purchase: {e}")
            return None
        finally:
            self.disconnect()

    def update_purchase(self, company_id: int, purchase_id: int, purchase_data: Dict[str, Any]) -> bool:
        """Update the header fields of an existing purchase.

        Items and stock movements are managed separately by purchase_logic
        using delete_purchase_items_by_purchase / insert_purchase_item /
        adjust_purchase_stock_movements.
        """
        ph = self._get_placeholder()
        query = f"""
            UPDATE purchases
            SET purchase_number = {ph},
                purchase_date = {ph},
                party_id = {ph},
                purchase_type = {ph},
                bill_series = {ph},
                nature = {ph},
                due_date = {ph},
                address = {ph},
                gstin = {ph},
                state = {ph},
                narration = {ph},
                sub_total = {ph},
                discount_total = {ph},
                tax_total = {ph},
                round_off = {ph},
                grand_total = {ph},
                amount_paid = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        params = (
            purchase_data.get('purchase_number'),
            purchase_data.get('purchase_date'),
            purchase_data.get('party_id'),
            purchase_data.get('purchase_type', 'Cash'),
            purchase_data.get('bill_series'),
            purchase_data.get('nature'),
            purchase_data.get('due_date'),
            purchase_data.get('address'),
            purchase_data.get('gstin'),
            purchase_data.get('state'),
            purchase_data.get('narration'),
            purchase_data.get('sub_total', 0.0),
            purchase_data.get('discount_total', 0.0),
            purchase_data.get('tax_total', 0.0),
            purchase_data.get('round_off', 0.0),
            purchase_data.get('grand_total', 0.0),
            purchase_data.get('amount_paid', 0.0),
            purchase_id,
            company_id
        )
        return self.execute_update(query, params)

    def delete_purchase(self, company_id: int, purchase_id: int) -> bool:
        """Delete a purchase and its items. Returns True on success.

        Stock movements are cleaned up by purchase_logic before this is called
        (via reverse_purchase_stock_movements). This method only deletes the
        purchase header and items (cascade).
        """
        ph = self._get_placeholder()
        query = f"DELETE FROM purchases WHERE id = {ph} AND company_id = {ph}"
        return self.execute_update(query, (purchase_id, company_id))

    def get_purchase_nav_ids(self, company_id: int) -> List[int]:
        """Get all purchase IDs for navigation, ordered by date desc."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id FROM purchases
            WHERE company_id = {ph}
            ORDER BY purchase_date DESC, id DESC
        """
        result = self.execute_query(query, (company_id,))
        return [row['id'] for row in result]

    # Stock movement methods for stock tracking foundation

    def delete_stock_movements_by_reference(self, reference_type: str, reference_id: int) -> bool:
        """Delete all stock movements for a given reference (purchase, sale, purchase_return, etc.)."""
        ph = self._get_placeholder()
        query = f"DELETE FROM stock_movements WHERE reference_type = {ph} AND reference_id = {ph}"
        return self.execute_update(query, (reference_type, reference_id))

    def set_product_quantity_cache(self, company_id: int, product_id: int, quantity: float) -> bool:
        """Update products.quantity cache directly (authoritative value is stock_movements)."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE products SET quantity = {ph}, updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        return self.execute_update(query, (quantity, product_id, company_id))

    def batch_sync_product_quantities(self, company_id: int, product_ids: List[int]) -> None:
        """Recalculate and cache products.quantity for each product from stock_movements."""
        if not product_ids:
            return
        for product_id in product_ids:
            balance = self.get_stock_balance_from_movements(company_id, product_id)
            self.set_product_quantity_cache(company_id, product_id, balance)

    def adjust_product_quantity(self, company_id: int, product_id: int, delta: float) -> bool:
        """Increment (delta > 0) or decrement (delta < 0) the on-hand stock
        stored on the products table for a given product.

        Used to keep `products.quantity` in sync with sale/purchase events so
        the stock_display in Sales Entry shows the live on-hand value.
        """
        ph = self._get_placeholder()
        query = f"""
            UPDATE products
            SET quantity = COALESCE(quantity, 0) + {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        return self.execute_update(query, (delta, product_id, company_id))

    def create_stock_movement(self, company_id: int, product_id: int, movement_type: str,
                            quantity: float, reference_type: Optional[str] = None,
                            reference_id: Optional[int] = None, notes: Optional[str] = None) -> bool:
        """Create a new stock movement entry."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO stock_movements (
                company_id, product_id, movement_type, quantity, reference_type, reference_id, notes
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (company_id, product_id, movement_type, quantity, reference_type, reference_id, notes)
        return self.execute_update(query, params)

    def create_stock_movement_with_cursor(self, cursor, company_id: int, product_id: int, movement_type: str,
                                        quantity: float, reference_type: Optional[str] = None,
                                        reference_id: Optional[int] = None, notes: Optional[str] = None):
        """Create a new stock movement entry using an existing cursor (to avoid nested connections)."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO stock_movements (
                company_id, product_id, movement_type, quantity, reference_type, reference_id, notes
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (company_id, product_id, movement_type, quantity, reference_type, reference_id, notes)
        cursor.execute(query, params)
    
    def get_stock_movements_by_product(self, company_id: int, product_id: int) -> List[Dict[str, Any]]:
        """Get all stock movements for a specific product."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, company_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_at
            FROM stock_movements
            WHERE company_id = {ph} AND product_id = {ph}
            ORDER BY created_at DESC
        """
        return self.execute_query(query, (company_id, product_id))
    
    def get_stock_movements_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all stock movements for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, company_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_at
            FROM stock_movements
            WHERE company_id = {ph}
            ORDER BY created_at DESC
        """
        return self.execute_query(query, (company_id,))
    
    def get_stock_balance_from_movements(self, company_id: int, product_id: int) -> float:
        """Get the current stock balance for a product from stock movements."""
        ph = self._get_placeholder()
        query = f"""
            SELECT SUM(CASE
                WHEN movement_type IN ('opening', 'purchase', 'transfer_in', 'return',
                                       'purchase_return', 'sale_return') THEN quantity
                WHEN movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -quantity
                ELSE 0
            END) as balance
            FROM stock_movements
            WHERE company_id = {ph} AND product_id = {ph}
        """
        result = self.execute_query(query, (company_id, product_id))
        return float(result[0]['balance']) if result and result[0]['balance'] else 0.0

    def get_stock_balances_for_products(self, company_id: int, product_ids: List[int]) -> Dict[int, float]:
        """Get stock balances for multiple products in a single query.

        Much faster than calling get_stock_balance_from_movements() for each product
        when updating stock after a sale/purchase with multiple items.

        Args:
            company_id: Company ID
            product_ids: List of product IDs to get balances for

        Returns:
            Dictionary mapping product_id to stock balance
        """
        if not product_ids:
            return {}

        # Build placeholders for IN clause
        ph = self._get_placeholder()
        placeholders = ",".join([ph] * len(product_ids))
        query = f"""
            SELECT
                product_id,
                SUM(CASE
                    WHEN movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN quantity
                    WHEN movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -quantity
                    ELSE 0
                END) as balance
            FROM stock_movements
            WHERE company_id = {ph} AND product_id IN ({placeholders})
            GROUP BY product_id
        """
        params = [company_id] + list(product_ids)
        results = self.execute_query(query, tuple(params))
        return {r['product_id']: float(r['balance']) if r['balance'] else 0.0 for r in results}

    # Stock Report Methods

    def get_stock_summary_count(self, company_id: int, filters: Dict[str, Any] = None) -> int:
        """Get total count of products for stock summary pagination."""
        filters = filters or {}
        search_text = filters.get('search_text')
        category = filters.get('category')

        ph = self._get_placeholder()
        query = f"""
            SELECT COUNT(*) as count
            FROM products p
            WHERE p.company_id = {ph}
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        if category:
            query += f" AND p.category = {ph}"
            params.append(category)

        result = self.execute_query(query, params)
        return result[0]['count'] if result else 0

    def get_stock_summary(self, company_id: int, filters: Dict[str, Any] = None,
                         limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get product-wise stock summary with pagination."""
        filters = filters or {}
        search_text = filters.get('search_text')
        category = filters.get('category')
        date_from = filters.get('date_from')
        date_to = filters.get('date_to')

        # Calculate stock from movements with date filtering
        date_filter = ""
        if date_from:
            date_filter += f" AND COALESCE(sm.movement_date, sm.created_at) >= '{date_from}'"
        if date_to:
            date_filter += f" AND COALESCE(sm.movement_date, sm.created_at) <= '{date_to}'"

        ph = self._get_placeholder()
        query = f"""
            SELECT
                p.id,
                p.name,
                p.barcode,
                p.category,
                p.unit,
                p.purchase_rate,
                p.sale_price,
                p.wholesale_rate,
                p.reorder_level,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type = 'opening' THEN sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id {date_filter}),
                    0.0
                ) as opening_qty,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('purchase', 'transfer_in', 'return') THEN sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id {date_filter}),
                    0.0
                ) as inward_qty,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id {date_filter}),
                    0.0
                ) as outward_qty,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id {date_filter}),
                    0.0
                ) as closing_qty,
                COALESCE(
                    (SELECT sm.created_at
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id
                    ORDER BY sm.created_at DESC
                    LIMIT 1),
                    NULL
                ) as last_movement_date
            FROM products p
            WHERE p.company_id = {ph}
        """

        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        if category:
            query += f" AND p.category = {ph}"
            params.append(category)

        query += f" ORDER BY p.name LIMIT {ph} OFFSET {ph}"
        params.extend([limit, offset])

        return self.execute_query(query, params)

    def get_stock_ledger_count(self, company_id: int, product_id: int,
                               date_from: str = None, date_to: str = None) -> int:
        """Get total count of stock movements for ledger pagination."""
        ph = self._get_placeholder()
        query = f"""
            SELECT COUNT(*) as count
            FROM stock_movements
            WHERE company_id = {ph} AND product_id = {ph}
        """
        params = [company_id, product_id]

        if date_from:
            query += f" AND COALESCE(movement_date, created_at) >= {ph}"
            params.append(date_from)
        if date_to:
            query += f" AND COALESCE(movement_date, created_at) <= {ph}"
            params.append(date_to)

        result = self.execute_query(query, params)
        return result[0]['count'] if result else 0

    def get_stock_ledger(self, company_id: int, product_id: int,
                        date_from: str = None, date_to: str = None,
                        limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get movement-wise stock ledger for a specific product."""
        ph = self._get_placeholder()
        query = f"""
            SELECT
                id,
                COALESCE(movement_date, created_at) as movement_date,
                movement_type,
                voucher_type,
                voucher_no,
                notes as narration,
                COALESCE(qty_in, 0) as qty_in,
                COALESCE(qty_out, 0) as qty_out,
                COALESCE(rate, 0) as rate,
                COALESCE(value_in, 0) as value_in,
                COALESCE(value_out, 0) as value_out,
                COALESCE(balance_qty, 0) as balance_qty,
                COALESCE(balance_value, 0) as balance_value
            FROM stock_movements
            WHERE company_id = {ph} AND product_id = {ph}
        """
        params = [company_id, product_id]

        if date_from:
            query += f" AND COALESCE(movement_date, created_at) >= {ph}"
            params.append(date_from)
        if date_to:
            query += f" AND COALESCE(movement_date, created_at) <= {ph}"
            params.append(date_to)

        query += f" ORDER BY COALESCE(movement_date, created_at) ASC LIMIT {ph} OFFSET {ph}"
        params.extend([limit, offset])

        return self.execute_query(query, params)

    def get_negative_stock_count(self, company_id: int, filters: Dict[str, Any] = None) -> int:
        """Get count of products with negative stock."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT COUNT(*) as count
            FROM products p
            WHERE p.company_id = {ph}
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) < 0
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        result = self.execute_query(query, params)
        return result[0]['count'] if result else 0

    def get_negative_stock(self, company_id: int, filters: Dict[str, Any] = None,
                           limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get products with negative stock."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT
                p.id,
                p.name,
                p.barcode,
                p.category,
                p.unit,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                    0.0
                ) as closing_qty,
                p.purchase_rate,
                p.sale_price
            FROM products p
            WHERE p.company_id = {ph}
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) < 0
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        query += f" ORDER BY p.name LIMIT {ph} OFFSET {ph}"
        params.extend([limit, offset])

        return self.execute_query(query, params)

    def get_low_stock_count(self, company_id: int, filters: Dict[str, Any] = None) -> int:
        """Get count of products below reorder level."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT COUNT(*) as count
            FROM products p
            WHERE p.company_id = {ph}
              AND p.reorder_level > 0
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) <= p.reorder_level
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        result = self.execute_query(query, params)
        return result[0]['count'] if result else 0

    def get_low_stock(self, company_id: int, filters: Dict[str, Any] = None,
                      limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get products below reorder level."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT
                p.id,
                p.name,
                p.barcode,
                p.category,
                p.unit,
                p.reorder_level,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                    0.0
                ) as closing_qty,
                p.purchase_rate,
                p.sale_price
            FROM products p
            WHERE p.company_id = {ph}
              AND p.reorder_level > 0
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) <= p.reorder_level
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        query += f" ORDER BY p.name LIMIT {ph} OFFSET {ph}"
        params.extend([limit, offset])

        return self.execute_query(query, params)

    def get_zero_stock_count(self, company_id: int, filters: Dict[str, Any] = None) -> int:
        """Get count of products with zero stock."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT COUNT(*) as count
            FROM products p
            WHERE p.company_id = {ph}
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) = 0
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        result = self.execute_query(query, params)
        return result[0]['count'] if result else 0

    def get_zero_stock(self, company_id: int, filters: Dict[str, Any] = None,
                      limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get products with zero stock."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT
                p.id,
                p.name,
                p.barcode,
                p.category,
                p.unit,
                COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                    0.0
                ) as closing_qty,
                p.purchase_rate,
                p.sale_price
            FROM products p
            WHERE p.company_id = {ph}
              AND COALESCE(
                  (SELECT SUM(CASE
                      WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                      WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                      ELSE 0
                  END)
                  FROM stock_movements sm
                  WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                  0.0
              ) = 0
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        query += f" ORDER BY p.name LIMIT {ph} OFFSET {ph}"
        params.extend([limit, offset])

        return self.execute_query(query, params)

    def get_fast_moving_products(self, company_id: int, date_from: str, date_to: str,
                                 limit: int = 50) -> List[Dict[str, Any]]:
        """Get fast-moving products based on sales volume (future-ready)."""
        # Placeholder for future implementation
        return []

    def get_slow_moving_products(self, company_id: int, date_from: str, date_to: str,
                                 limit: int = 50) -> List[Dict[str, Any]]:
        """Get slow-moving products based on sales volume (future-ready)."""
        # Placeholder for future implementation
        return []

    def get_stock_value(self, company_id: int, filters: Dict[str, Any] = None) -> float:
        """Get total stock valuation."""
        filters = filters or {}
        search_text = filters.get('search_text')

        ph = self._get_placeholder()
        query = f"""
            SELECT
                SUM(
                    COALESCE(
                        (SELECT SUM(CASE
                            WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                            WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                            ELSE 0
                        END)
                        FROM stock_movements sm
                        WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                        0.0
                    ) * COALESCE(p.purchase_rate, 0)
                ) as total_value
            FROM products p
            WHERE p.company_id = {ph}
        """
        params = [company_id]

        if search_text:
            query += f" AND (p.name LIKE {ph} OR p.barcode LIKE {ph})"
            search_pattern = f"%{search_text}%"
            params.extend([search_pattern, search_pattern])

        result = self.execute_query(query, params)
        return float(result[0]['total_value']) if result and result[0]['total_value'] else 0.0

    def get_stock_summary_stats(self, company_id: int, filters: Dict[str, Any] = None) -> Dict[str, Any]:
        """Get summary statistics for stock report dashboard."""
        filters = filters or {}

        # Get total products count
        total_products = self.get_product_count(company_id)

        # Get total stock qty
        ph = self._get_placeholder()
        query = f"""
            SELECT
                SUM(COALESCE(
                    (SELECT SUM(CASE
                        WHEN sm.movement_type IN ('opening', 'purchase', 'transfer_in', 'return') THEN sm.quantity
                        WHEN sm.movement_type IN ('sale', 'adjustment', 'transfer_out') THEN -sm.quantity
                        ELSE 0
                    END)
                    FROM stock_movements sm
                    WHERE sm.company_id = p.company_id AND sm.product_id = p.id),
                    0.0
                )) as total_qty
            FROM products p
            WHERE p.company_id = {ph}
        """
        result = self.execute_query(query, (company_id,))
        total_qty = float(result[0]['total_qty']) if result and result[0]['total_qty'] else 0.0

        # Get total stock value
        total_value = self.get_stock_value(company_id, filters)

        # Get negative stock count
        negative_count = self.get_negative_stock_count(company_id, filters)

        # Get zero stock count
        zero_count = self.get_zero_stock_count(company_id, filters)

        return {
            'total_products': total_products,
            'total_qty': total_qty,
            'total_value': total_value,
            'negative_count': negative_count,
            'zero_count': zero_count
        }

    def rebuild_stock_balances(self, company_id: int) -> bool:
        """Rebuild stock balances from movements (audit/support method)."""
        try:
            conn = self._connect()
            cursor = conn.cursor()
            ph = self._get_placeholder()

            # Get all products for the company
            cursor.execute(f"SELECT id FROM products WHERE company_id = {ph}", (company_id,))
            product_ids = [row[0] for row in cursor.fetchall()]

            # Recalculate balance for each product
            for product_id in product_ids:
                balance = self.get_stock_balance_from_movements(company_id, product_id)

                # Update all movements with running balance
                query = f"""
                    SELECT id, movement_type, quantity, COALESCE(movement_date, created_at) as movement_date
                    FROM stock_movements
                    WHERE company_id = {ph} AND product_id = {ph}
                    ORDER BY COALESCE(movement_date, created_at) ASC
                """
                cursor.execute(query, (company_id, product_id))
                movements = cursor.fetchall()

                running_balance = 0.0
                for movement in movements:
                    movement_id = movement[0]
                    movement_type = movement[1]
                    quantity = movement[2]

                    if movement_type in ('opening', 'purchase', 'transfer_in', 'return'):
                        running_balance += quantity
                    else:
                        running_balance -= quantity

                    # Update balance_qty
                    cursor.execute(
                        f"UPDATE stock_movements SET balance_qty = {ph} WHERE id = {ph}",
                        (running_balance, movement_id)
                    )

            conn.commit()
            return True
        except Exception as e:
            if conn:
                conn.rollback()
            print(f"Error rebuilding stock balances: {e}")
            return False
        finally:
            self.disconnect()

    # Sales methods for Sales Entry module

    def insert_sale(self, company_id: int, sale_data: Dict[str, Any]) -> int:
        """Insert a new sale for a company and return the sale ID."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO sales (
                company_id, invoice_number, invoice_date, party_id, sales_type,
                bill_series, nature, due_date, address, gstin, state,
                sales_rate, narration, sub_total, discount_total, tax_total,
                round_off, grand_total, amount_received
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            sale_data.get('invoice_number'),
            sale_data.get('invoice_date'),
            sale_data.get('party_id'),
            sale_data.get('sales_type', 'Sales'),
            sale_data.get('bill_series'),
            sale_data.get('nature'),
            sale_data.get('due_date'),
            sale_data.get('address'),
            sale_data.get('gstin'),
            sale_data.get('state'),
            sale_data.get('sales_rate', 'Exclusive'),
            sale_data.get('narration'),
            sale_data.get('sub_total', 0.0),
            sale_data.get('discount_total', 0.0),
            sale_data.get('tax_total', 0.0),
            sale_data.get('round_off', 0.0),
            sale_data.get('grand_total', 0.0),
            sale_data.get('amount_received', 0.0)
        )
        self.execute_update(query, params)

        # NOTE: execute_update closes the connection in `finally`, so SQLite's
        # last_insert_rowid() on a fresh connection returns 0. Look up the id
        # via the UNIQUE(company_id, invoice_number) index instead — this works
        # correctly for both SQLite and MySQL.
        ph = self._get_placeholder()
        lookup_query = f"SELECT id FROM sales WHERE company_id = {ph} AND invoice_number = {ph}"
        result = self.execute_query(
            lookup_query,
            (company_id, sale_data.get('invoice_number'))
        )
        return result[0]['id'] if result else None

    def update_sale(self, company_id: int, sale_id: int, sale_data: Dict[str, Any]) -> bool:
        """Update the header fields of an existing sale."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE sales
            SET invoice_number = {ph},
                invoice_date = {ph},
                party_id = {ph},
                sales_type = {ph},
                bill_series = {ph},
                nature = {ph},
                due_date = {ph},
                address = {ph},
                gstin = {ph},
                state = {ph},
                sales_rate = {ph},
                narration = {ph},
                sub_total = {ph},
                discount_total = {ph},
                tax_total = {ph},
                round_off = {ph},
                grand_total = {ph},
                amount_received = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        params = (
            sale_data.get('invoice_number'),
            sale_data.get('invoice_date'),
            sale_data.get('party_id'),
            sale_data.get('sales_type', 'Sales'),
            sale_data.get('bill_series'),
            sale_data.get('nature'),
            sale_data.get('due_date'),
            sale_data.get('address'),
            sale_data.get('gstin'),
            sale_data.get('state'),
            sale_data.get('sales_rate', 'Exclusive'),
            sale_data.get('narration'),
            sale_data.get('sub_total', 0.0),
            sale_data.get('discount_total', 0.0),
            sale_data.get('tax_total', 0.0),
            sale_data.get('round_off', 0.0),
            sale_data.get('grand_total', 0.0),
            sale_data.get('amount_received', 0.0),
            sale_id,
            company_id,
        )
        return self.execute_update(query, params)

    def delete_sale_items_by_sale(self, sale_id: int) -> bool:
        """Delete all line items for a given sale id."""
        ph = self._get_placeholder()
        query = f"DELETE FROM sales_items WHERE sale_id = {ph}"
        return self.execute_update(query, (sale_id,))

    def delete_stock_movements_by_reference(self, reference_type: str, reference_id: int) -> bool:
        """Delete stock movements tied to a reference (e.g. a sale)."""
        ph = self._get_placeholder()
        query = f"DELETE FROM stock_movements WHERE reference_type = {ph} AND reference_id = {ph}"
        return self.execute_update(query, (reference_type, reference_id))

    def set_product_quantity_cache(self, company_id: int, product_id: int, quantity: float) -> bool:
        """Set products.quantity as a display cache from movement balance.

        This is NOT the authoritative stock source — use get_stock_balance_from_movements()
        for authoritative values. This only syncs the cache column.
        """
        ph = self._get_placeholder()
        query = f"""
            UPDATE products
            SET quantity = {ph}, updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        return self.execute_update(query, (quantity, product_id, company_id))

    def batch_sync_product_quantities(self, company_id: int, product_ids: List[int]) -> bool:
        """Sync products.quantity cache for multiple products in 2 queries.

        1 query to get all balances, then 1 UPDATE per product via executemany.
        Much faster than N calls to sync_product_quantity_from_movements().

        Args:
            company_id: Company ID
            product_ids: List of product IDs to sync

        Returns:
            True if successful
        """
        if not product_ids:
            return True
        try:
            # Single query to get all balances
            balances = self.get_stock_balances_for_products(company_id, product_ids)
            if not balances:
                return True
            # Batch update using executemany
            conn = self.connect()
            cursor = conn.cursor()
            update_data = [
                (balances.get(pid, 0.0), pid, company_id)
                for pid in product_ids
                if pid in balances
            ]
            ph = self._get_placeholder()
            cursor.executemany(
                f"UPDATE products SET quantity = {ph}, updated_at = CURRENT_TIMESTAMP WHERE id = {ph} AND company_id = {ph}",
                update_data
            )
            conn.commit()
            return True
        except Exception as e:
            print(f"Error in batch_sync_product_quantities: {e}")
            return False

    def delete_purchase_items_by_purchase(self, purchase_id: int) -> bool:
        """Delete all line items for a given purchase id."""
        ph = self._get_placeholder()
        query = f"DELETE FROM purchase_items WHERE purchase_id = {ph}"
        return self.execute_update(query, (purchase_id,))

    def insert_purchase_item(self, purchase_id: int, item_data: Dict[str, Any]) -> bool:
        """Insert a purchase item for a purchase."""
        timestamp_default = self._get_timestamp_default()
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO purchase_items (
                purchase_id, product_id, sl_no, hsn, tax_percent, unit, rate, quantity,
                gross_value, discount, net_value, tax_amount, grand_total, created_at,
                cgst, sgst, igst, cess, cgst_amount, sgst_amount, igst_amount, cess_amount
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {timestamp_default}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            purchase_id,
            item_data.get('product_id'),
            item_data.get('sl_no'),
            item_data.get('hsn'),
            item_data.get('tax_percent', 0.0),
            item_data.get('unit'),
            item_data.get('rate', 0.0),
            item_data.get('quantity', 0.0),
            item_data.get('gross_value', 0.0),
            item_data.get('discount', 0.0),
            item_data.get('net_value', 0.0),
            item_data.get('tax_amount', 0.0),
            item_data.get('grand_total', 0.0),
            item_data.get('cgst', 0.0),
            item_data.get('sgst', 0.0),
            item_data.get('igst', 0.0),
            item_data.get('cess', 0.0),
            item_data.get('cgst_amount', 0.0),
            item_data.get('sgst_amount', 0.0),
            item_data.get('igst_amount', 0.0),
            item_data.get('cess_amount', 0.0)
        )
        return self.execute_update(query, params)

    def insert_sale_item(self, sale_id: int, item_data: Dict[str, Any]) -> bool:
        """Insert a sale item for a sale."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO sales_items (
                sale_id, product_id, sl_no, hsn, tax_percent, unit, rate,
                quantity, gross_value, discount, net_value, tax_amount, grand_total,
                cgst, sgst, igst, cess, cgst_amount, sgst_amount, igst_amount, cess_amount
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            sale_id,
            item_data.get('product_id'),
            item_data.get('sl_no'),
            item_data.get('hsn'),
            item_data.get('tax_percent', 0.0),
            item_data.get('unit'),
            item_data.get('rate', 0.0),
            item_data.get('quantity', 0.0),
            item_data.get('gross_value', 0.0),
            item_data.get('discount', 0.0),
            item_data.get('net_value', 0.0),
            item_data.get('tax_amount', 0.0),
            item_data.get('grand_total', 0.0),
            item_data.get('cgst', 0.0),
            item_data.get('sgst', 0.0),
            item_data.get('igst', 0.0),
            item_data.get('cess', 0.0),
            item_data.get('cgst_amount', 0.0),
            item_data.get('sgst_amount', 0.0),
            item_data.get('igst_amount', 0.0),
            item_data.get('cess_amount', 0.0)
        )
        return self.execute_update(query, params)

    def get_sales_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all sales for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT s.id, s.invoice_number, s.invoice_date, s.party_id, p.name as party_name,
                   s.sales_type, s.bill_series, s.nature, s.due_date, s.sales_rate,
                   s.sub_total, s.discount_total, s.tax_total, s.round_off, s.grand_total,
                   s.amount_received, s.created_at
            FROM sales s
            LEFT JOIN parties p ON s.party_id = p.id
            WHERE s.company_id = {ph}
            ORDER BY s.invoice_date DESC, s.id DESC
        """
        return self.execute_query(query, (company_id,))

    def get_sales_by_party(self, company_id: int, party_id: int) -> List[Dict[str, Any]]:
        """Get all sales for a specific party."""
        ph = self._get_placeholder()
        query = f"""
            SELECT s.id, s.invoice_number, s.invoice_date, s.party_id, p.name as party_name,
                   s.sales_type, s.bill_series, s.nature, s.due_date, s.sales_rate,
                   s.sub_total, s.discount_total, s.tax_total, s.round_off, s.grand_total,
                   s.amount_received, s.created_at
            FROM sales s
            LEFT JOIN parties p ON s.party_id = p.id
            WHERE s.company_id = {ph} AND s.party_id = {ph}
            ORDER BY s.invoice_date DESC, s.id DESC
        """
        return self.execute_query(query, (company_id, party_id))

    def get_vouchers_before_date(
        self,
        company_id: int,
        party_id: int,
        voucher_type: str,
        voucher_id: Optional[int] = None,
        voucher_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Get all vouchers for a party before a specific voucher date/id.

        This is used for balance calculation to exclude current and future vouchers.

        Args:
            company_id: Company ID
            party_id: Party ID
            voucher_type: Type of current voucher ('sales', 'purchase', 'sales_return', 'purchase_return')
            voucher_id: ID of current voucher (to exclude)
            voucher_date: Date of current voucher (for date-based exclusion)

        Returns:
            List of vouchers with voucher_type, voucher_date, voucher_id, grand_total, amount_received/amount_paid
        """
        vouchers = []

        ph = self._get_placeholder()
        # Get sales before current voucher
        if voucher_type in ['sales', 'sales_return']:
            sales_query = f"""
                SELECT 'sales' as voucher_type, s.id as voucher_id, s.invoice_date as voucher_date,
                       s.grand_total, s.amount_received as amount_received_or_paid
                FROM sales s
                WHERE s.company_id = {ph} AND s.party_id = {ph}
            """
            params = [company_id, party_id]

            # Add date filter if provided
            if voucher_date:
                sales_query += f" AND s.invoice_date < {ph}"
                params.append(voucher_date)
            elif voucher_id:
                # If no date but has ID, use ID ordering
                sales_query += f" AND s.id < {ph}"
                params.append(voucher_id)

            sales_query += " ORDER BY s.invoice_date ASC, s.id ASC"
            sales = self.execute_query(sales_query, tuple(params))
            vouchers.extend(sales)

        # Get purchases before current voucher
        if voucher_type in ['purchase', 'purchase_return']:
            purchase_query = f"""
                SELECT 'purchase' as voucher_type, p.id as voucher_id, p.bill_date as voucher_date,
                       p.grand_total, p.amount_paid as amount_received_or_paid
                FROM purchases p
                WHERE p.company_id = {ph} AND p.party_id = {ph}
            """
            params = [company_id, party_id]

            # Add date filter if provided
            if voucher_date:
                purchase_query += f" AND p.bill_date < {ph}"
                params.append(voucher_date)
            elif voucher_id:
                # If no date but has ID, use ID ordering
                purchase_query += f" AND p.id < {ph}"
                params.append(voucher_id)

            purchase_query += " ORDER BY p.bill_date ASC, p.id ASC"
            purchases = self.execute_query(purchase_query, tuple(params))
            vouchers.extend(purchases)

        # Get sales returns before current voucher
        if voucher_type == 'sales_return':
            sales_return_query = f"""
                SELECT 'sales_return' as voucher_type, sr.id as voucher_id, sr.return_date as voucher_date,
                       sr.grand_total, sr.amount_received as amount_received_or_paid
                FROM sales_returns sr
                WHERE sr.company_id = {ph} AND sr.party_id = {ph}
            """
            params = [company_id, party_id]

            # Add date filter if provided
            if voucher_date:
                sales_return_query += f" AND sr.return_date < {ph}"
                params.append(voucher_date)
            elif voucher_id:
                # If no date but has ID, use ID ordering
                sales_return_query += f" AND sr.id < {ph}"
                params.append(voucher_id)

            sales_return_query += " ORDER BY sr.return_date ASC, sr.id ASC"
            sales_returns = self.execute_query(sales_return_query, tuple(params))
            vouchers.extend(sales_returns)

        # Get purchase returns before current voucher
        if voucher_type == 'purchase_return':
            purchase_return_query = f"""
                SELECT 'purchase_return' as voucher_type, pr.id as voucher_id, pr.return_date as voucher_date,
                       pr.grand_total, pr.amount_paid as amount_received_or_paid
                FROM purchase_returns pr
                WHERE pr.company_id = {ph} AND pr.party_id = {ph}
            """
            params = [company_id, party_id]

            # Add date filter if provided
            if voucher_date:
                purchase_return_query += f" AND pr.return_date < {ph}"
                params.append(voucher_date)
            elif voucher_id:
                # If no date but has ID, use ID ordering
                purchase_return_query += f" AND pr.id < {ph}"
                params.append(voucher_id)

            purchase_return_query += " ORDER BY pr.return_date ASC, pr.id ASC"
            purchase_returns = self.execute_query(purchase_return_query, tuple(params))
            vouchers.extend(purchase_returns)

        return vouchers

    def get_sale_ids_by_company(self, company_id: int) -> List[int]:
        """Get only sale IDs for a specific company - optimized for navigation.

        This is much faster than get_sales_by_company() for prev/next navigation
        because it doesn't JOIN with parties or return full rows.
        """
        ph = self._get_placeholder()
        query = f"""
            SELECT id FROM sales
            WHERE company_id = {ph}
            ORDER BY id ASC
        """
        results = self.execute_query(query, (company_id,))
        return [r['id'] for r in results if r.get('id') is not None]

    def get_sale_by_id(self, company_id: int, sale_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific sale by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT s.id, s.invoice_number, s.invoice_date, s.party_id, p.name as party_name,
                   p.mobile_number, p.address, p.gstin, s.sales_type, s.bill_series, s.nature,
                   s.due_date, s.address, s.gstin, s.state, s.sales_rate, s.narration,
                   s.sub_total, s.discount_total, s.tax_total, s.round_off, s.grand_total,
                   s.amount_received
            FROM sales s
            LEFT JOIN parties p ON s.party_id = p.id
            WHERE s.company_id = {ph} AND s.id = {ph}
        """
        result = self.execute_query(query, (company_id, sale_id))
        return result[0] if result else None

    def get_sale_items(self, sale_id: int) -> List[Dict[str, Any]]:
        """Get all items for a specific sale."""
        ph = self._get_placeholder()
        query = f"""
            SELECT si.id, si.sale_id, si.product_id, pr.name as product_name, pr.barcode,
                   si.sl_no, si.hsn, si.tax_percent, si.unit, si.rate,
                   si.quantity, si.gross_value, si.discount, si.net_value, si.tax_amount, si.grand_total,
                   si.cgst, si.sgst, si.igst, si.cess, si.cgst_amount, si.sgst_amount, si.igst_amount, si.cess_amount
            FROM sales_items si
            LEFT JOIN products pr ON si.product_id = pr.id
            WHERE si.sale_id = {ph}
            ORDER BY si.sl_no
        """
        return self.execute_query(query, (sale_id,))

    def invoice_number_exists(self, company_id: int, invoice_number: str, exclude_sale_id: Optional[int] = None) -> bool:
        """Check if an invoice number exists for a company (excluding a specific sale if editing)."""
        ph = self._get_placeholder()
        if exclude_sale_id:
            query = f"SELECT id FROM sales WHERE invoice_number = {ph} AND company_id = {ph} AND id != {ph}"
            result = self.execute_query(query, (invoice_number, company_id, exclude_sale_id))
        else:
            query = f"SELECT id FROM sales WHERE invoice_number = {ph} AND company_id = {ph}"
            result = self.execute_query(query, (invoice_number, company_id))
        return len(result) > 0

    # Sales Return methods
    def insert_sales_return(self, company_id: int, sales_return_data: Dict[str, Any]) -> int:
        """Insert a new sales return for a company and return the sales_return ID."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO sales_returns (
                company_id, return_no, return_date, original_bill_id, original_bill_no, party_id,
                return_type, nature, narration, sub_total, discount_total, tax_total,
                round_off, grand_total, amount_refunded_or_adjusted, balance_adjustment
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            sales_return_data.get('return_no'),
            sales_return_data.get('return_date'),
            sales_return_data.get('original_bill_id'),
            sales_return_data.get('original_bill_no'),
            sales_return_data.get('party_id'),
            sales_return_data.get('return_type', 'Cash'),
            sales_return_data.get('nature'),
            sales_return_data.get('narration'),
            sales_return_data.get('sub_total', 0.0),
            sales_return_data.get('discount_total', 0.0),
            sales_return_data.get('tax_total', 0.0),
            sales_return_data.get('round_off', 0.0),
            sales_return_data.get('grand_total', 0.0),
            sales_return_data.get('amount_refunded_or_adjusted', 0.0),
            sales_return_data.get('balance_adjustment', 0.0)
        )
        self.execute_update(query, params)
        ph = self._get_placeholder()
        result = self.execute_query(
            f"SELECT id FROM sales_returns WHERE company_id = {ph} AND return_no = {ph}",
            (company_id, sales_return_data.get('return_no'))
        )
        return result[0]['id'] if result else None

    def insert_sales_return_item(self, sales_return_id: int, item_data: Dict[str, Any]) -> bool:
        """Insert a sales return item for a sales return."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO sales_return_items (
                sales_return_id, product_id, sl_no, hsn, cgst, sgst, igst, cess,
                tax_percent, unit, rate, quantity, gross_value, discount, net_value, tax_amount, grand_total,
                cgst_amount, sgst_amount, igst_amount, cess_amount
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            sales_return_id,
            item_data.get('product_id'),
            item_data.get('sl_no'),
            item_data.get('hsn'),
            item_data.get('cgst', 0.0),
            item_data.get('sgst', 0.0),
            item_data.get('igst', 0.0),
            item_data.get('cess', 0.0),
            item_data.get('tax_percent', 0.0),
            item_data.get('unit', ''),  # Added missing unit column
            item_data.get('rate', 0.0),
            item_data.get('quantity', 0.0),
            item_data.get('gross_value', 0.0),
            item_data.get('discount', 0.0),
            item_data.get('net_value', 0.0),
            item_data.get('tax_amount', 0.0),
            item_data.get('grand_total', 0.0),
            item_data.get('cgst_amount', 0.0),
            item_data.get('sgst_amount', 0.0),
            item_data.get('igst_amount', 0.0),
            item_data.get('cess_amount', 0.0)
        )
        return self.execute_update(query, params)

    def get_sales_returns_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all sales returns for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT sr.id, sr.return_no, sr.return_date, sr.party_id, p.name as party_name,
                   sr.return_type, sr.nature, sr.original_bill_no, sr.narration,
                   sr.sub_total, sr.discount_total, sr.tax_total, sr.round_off, sr.grand_total,
                   sr.amount_refunded_or_adjusted, sr.balance_adjustment, sr.created_at
            FROM sales_returns sr
            LEFT JOIN parties p ON sr.party_id = p.id
            WHERE sr.company_id = {ph}
            ORDER BY sr.return_date DESC, sr.id DESC
        """
        return self.execute_query(query, (company_id,))

    def get_sales_return_by_id(self, company_id: int, sales_return_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific sales return by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT sr.id, sr.return_no, sr.return_date, sr.party_id, p.name as party_name,
                   p.mobile_number, p.address, p.gstin, p.state,
                   sr.return_type, sr.nature, sr.original_bill_id, sr.original_bill_no, sr.narration,
                   sr.sub_total, sr.discount_total, sr.tax_total, sr.round_off, sr.grand_total,
                   sr.amount_refunded_or_adjusted, sr.balance_adjustment
            FROM sales_returns sr
            LEFT JOIN parties p ON sr.party_id = p.id
            WHERE sr.company_id = {ph} AND sr.id = {ph}
        """
        result = self.execute_query(query, (company_id, sales_return_id))
        return result[0] if result else None

    def get_sales_return_by_return_no(self, company_id: int, return_no: str) -> Optional[Dict[str, Any]]:
        """Get a specific sales return by return number for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT sr.id, sr.return_no, sr.return_date, sr.party_id
            FROM sales_returns sr
            WHERE sr.company_id = {ph} AND sr.return_no = {ph}
        """
        result = self.execute_query(query, (company_id, return_no))
        return result[0] if result else None

    def get_sales_return_items(self, sales_return_id: int) -> List[Dict[str, Any]]:
        """Get all items for a specific sales return."""
        ph = self._get_placeholder()
        query = f"""
            SELECT sri.id, sri.sales_return_id, sri.product_id, pr.name as product_name, pr.barcode,
                   sri.sl_no, sri.hsn, sri.cgst, sri.sgst, sri.igst, sri.cess, sri.tax_percent,
                   sri.unit, sri.rate, sri.quantity, sri.gross_value, sri.discount, sri.net_value,
                   sri.tax_amount, sri.grand_total, sri.cgst_amount, sri.sgst_amount, sri.igst_amount, sri.cess_amount
            FROM sales_return_items sri
            LEFT JOIN products pr ON sri.product_id = pr.id
            WHERE sri.sales_return_id = {ph}
            ORDER BY sri.sl_no
        """
        return self.execute_query(query, (sales_return_id,))

    def update_sales_return(self, sales_return_id: int, sales_return_data: Dict[str, Any]) -> bool:
        """Update an existing sales return."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE sales_returns SET
                return_no = {ph},
                return_date = {ph},
                original_bill_id = {ph},
                original_bill_no = {ph},
                party_id = {ph},
                return_type = {ph},
                nature = {ph},
                narration = {ph},
                sub_total = {ph},
                discount_total = {ph},
                tax_total = {ph},
                round_off = {ph},
                grand_total = {ph},
                amount_refunded_or_adjusted = {ph},
                balance_adjustment = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph}
        """
        params = (
            sales_return_data.get('return_no'),
            sales_return_data.get('return_date'),
            sales_return_data.get('original_bill_id'),
            sales_return_data.get('original_bill_no'),
            sales_return_data.get('party_id'),
            sales_return_data.get('return_type'),
            sales_return_data.get('nature'),
            sales_return_data.get('narration'),
            sales_return_data.get('sub_total', 0.0),
            sales_return_data.get('discount_total', 0.0),
            sales_return_data.get('tax_total', 0.0),
            sales_return_data.get('round_off', 0.0),
            sales_return_data.get('grand_total', 0.0),
            sales_return_data.get('amount_refunded_or_adjusted', 0.0),
            sales_return_data.get('balance_adjustment', 0.0),
            sales_return_id
        )
        return self.execute_update(query, params)

    def delete_sales_return(self, sales_return_id: int) -> bool:
        """Delete a sales return."""
        ph = self._get_placeholder()
        query = f"DELETE FROM sales_returns WHERE id = {ph}"
        return self.execute_update(query, (sales_return_id,))

    def delete_sales_return_items(self, sales_return_id: int) -> bool:
        """Delete all line items for a given sales return id."""
        ph = self._get_placeholder()
        query = f"DELETE FROM sales_return_items WHERE sales_return_id = {ph}"
        return self.execute_update(query, (sales_return_id,))

    def get_last_sales_return_no(self, company_id: int) -> Optional[str]:
        """Get the last sales return number for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT return_no FROM sales_returns
            WHERE company_id = {ph}
            ORDER BY id DESC
            LIMIT 1
        """
        result = self.execute_query(query, (company_id,))
        return result[0]['return_no'] if result else None

    # Purchase Return methods
    def insert_purchase_return(self, company_id: int, purchase_return_data: Dict[str, Any]) -> int:
        """Insert a new purchase return for a company and return the purchase_return ID."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO purchase_returns (
                company_id, return_no, return_date, original_purchase_id, original_purchase_no, party_id,
                return_type, nature, supplier_invoice_no, narration, sub_total, discount_total, tax_total,
                round_off, grand_total, amount_received_or_adjusted, balance_adjustment
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            purchase_return_data.get('return_no'),
            purchase_return_data.get('return_date'),
            purchase_return_data.get('original_purchase_id'),
            purchase_return_data.get('original_purchase_no'),
            purchase_return_data.get('party_id'),
            purchase_return_data.get('return_type', 'Cash'),
            purchase_return_data.get('nature'),
            purchase_return_data.get('supplier_invoice_no'),
            purchase_return_data.get('narration'),
            purchase_return_data.get('sub_total', 0.0),
            purchase_return_data.get('discount_total', 0.0),
            purchase_return_data.get('tax_total', 0.0),
            purchase_return_data.get('round_off', 0.0),
            purchase_return_data.get('grand_total', 0.0),
            purchase_return_data.get('amount_received_or_adjusted', 0.0),
            purchase_return_data.get('balance_adjustment', 0.0)
        )
        self.execute_update(query, params)
        ph = self._get_placeholder()
        result = self.execute_query(
            f"SELECT id FROM purchase_returns WHERE company_id = {ph} AND return_no = {ph}",
            (company_id, purchase_return_data.get('return_no'))
        )
        return result[0]['id'] if result else None

    def insert_purchase_return_item(self, purchase_return_id: int, item_data: Dict[str, Any]) -> bool:
        """Insert a purchase return item for a purchase return."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO purchase_return_items (
                purchase_return_id, product_id, sl_no, hsn, cgst, sgst, igst, cess,
                tax_percent, unit, rate, quantity, gross_value, discount, net_value, tax_amount, grand_total,
                cgst_amount, sgst_amount, igst_amount, cess_amount
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            purchase_return_id,
            item_data.get('product_id'),
            item_data.get('sl_no'),
            item_data.get('hsn'),
            item_data.get('cgst', 0.0),
            item_data.get('sgst', 0.0),
            item_data.get('igst', 0.0),
            item_data.get('cess', 0.0),
            item_data.get('tax_percent', 0.0),
            item_data.get('unit', ''),  # Added missing unit column
            item_data.get('rate', 0.0),
            item_data.get('quantity', 0.0),
            item_data.get('gross_value', 0.0),
            item_data.get('discount', 0.0),
            item_data.get('net_value', 0.0),
            item_data.get('tax_amount', 0.0),
            item_data.get('grand_total', 0.0),
            item_data.get('cgst_amount', 0.0),
            item_data.get('sgst_amount', 0.0),
            item_data.get('igst_amount', 0.0),
            item_data.get('cess_amount', 0.0)
        )
        return self.execute_update(query, params)

    def get_purchase_returns_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all purchase returns for a specific company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT pr.id, pr.return_no, pr.return_date, pr.party_id, p.name as party_name,
                   pr.return_type, pr.nature, pr.original_purchase_no, pr.supplier_invoice_no, pr.narration,
                   pr.sub_total, pr.discount_total, pr.tax_total, pr.round_off, pr.grand_total,
                   pr.amount_received_or_adjusted, pr.balance_adjustment, pr.created_at
            FROM purchase_returns pr
            LEFT JOIN parties p ON pr.party_id = p.id
            WHERE pr.company_id = {ph}
            ORDER BY pr.return_date DESC, pr.id DESC
        """
        return self.execute_query(query, (company_id,))

    def get_purchase_return_by_id(self, company_id: int, purchase_return_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific purchase return by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT pr.id, pr.return_no, pr.return_date, pr.party_id, p.name as party_name,
                   p.mobile_number, p.address, p.gstin, p.state,
                   pr.return_type, pr.nature, pr.original_purchase_id, pr.original_purchase_no,
                   pr.supplier_invoice_no, pr.narration,
                   pr.sub_total, pr.discount_total, pr.tax_total, pr.round_off, pr.grand_total,
                   pr.amount_received_or_adjusted, pr.balance_adjustment
            FROM purchase_returns pr
            LEFT JOIN parties p ON pr.party_id = p.id
            WHERE pr.company_id = {ph} AND pr.id = {ph}
        """
        result = self.execute_query(query, (company_id, purchase_return_id))
        return result[0] if result else None

    def get_purchase_return_by_return_no(self, company_id: int, return_no: str) -> Optional[Dict[str, Any]]:
        """Get a specific purchase return by return number for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT pr.id, pr.return_no, pr.return_date, pr.party_id
            FROM purchase_returns pr
            WHERE pr.company_id = {ph} AND pr.return_no = {ph}
        """
        result = self.execute_query(query, (company_id, return_no))
        return result[0] if result else None

    def get_purchase_return_items(self, purchase_return_id: int) -> List[Dict[str, Any]]:
        """Get all items for a specific purchase return."""
        ph = self._get_placeholder()
        query = f"""
            SELECT pri.id, pri.purchase_return_id, pri.product_id, pr.name as product_name, pr.barcode,
                   pri.sl_no, pri.hsn, pri.cgst, pri.sgst, pri.igst, pri.cess, pri.tax_percent,
                   pri.unit, pri.rate, pri.quantity, pri.gross_value, pri.discount, pri.net_value,
                   pri.tax_amount, pri.grand_total, pri.cgst_amount, pri.sgst_amount, pri.igst_amount, pri.cess_amount
            FROM purchase_return_items pri
            LEFT JOIN products pr ON pri.product_id = pr.id
            WHERE pri.purchase_return_id = {ph}
            ORDER BY pri.sl_no
        """
        return self.execute_query(query, (purchase_return_id,))

    def update_purchase_return(self, purchase_return_id: int, purchase_return_data: Dict[str, Any]) -> bool:
        """Update an existing purchase return."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE purchase_returns SET
                return_no = {ph},
                return_date = {ph},
                original_purchase_id = {ph},
                original_purchase_no = {ph},
                party_id = {ph},
                return_type = {ph},
                nature = {ph},
                supplier_invoice_no = {ph},
                narration = {ph},
                sub_total = {ph},
                discount_total = {ph},
                tax_total = {ph},
                round_off = {ph},
                grand_total = {ph},
                amount_received_or_adjusted = {ph},
                balance_adjustment = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph}
        """
        params = (
            purchase_return_data.get('return_no'),
            purchase_return_data.get('return_date'),
            purchase_return_data.get('original_purchase_id'),
            purchase_return_data.get('original_purchase_no'),
            purchase_return_data.get('party_id'),
            purchase_return_data.get('return_type'),
            purchase_return_data.get('nature'),
            purchase_return_data.get('supplier_invoice_no'),
            purchase_return_data.get('narration'),
            purchase_return_data.get('sub_total', 0.0),
            purchase_return_data.get('discount_total', 0.0),
            purchase_return_data.get('tax_total', 0.0),
            purchase_return_data.get('round_off', 0.0),
            purchase_return_data.get('grand_total', 0.0),
            purchase_return_data.get('amount_received_or_adjusted', 0.0),
            purchase_return_data.get('balance_adjustment', 0.0),
            purchase_return_id
        )
        return self.execute_update(query, params)

    def delete_purchase_return(self, purchase_return_id: int) -> bool:
        """Delete a purchase return."""
        ph = self._get_placeholder()
        query = f"DELETE FROM purchase_returns WHERE id = {ph}"
        return self.execute_update(query, (purchase_return_id,))

    def delete_purchase_return_items(self, purchase_return_id: int) -> bool:
        """Delete all line items for a given purchase return id."""
        ph = self._get_placeholder()
        query = f"DELETE FROM purchase_return_items WHERE purchase_return_id = {ph}"
        return self.execute_update(query, (purchase_return_id,))

    def get_last_purchase_return_no(self, company_id: int) -> Optional[str]:
        """Get the last purchase return number for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT return_no FROM purchase_returns
            WHERE company_id = {ph}
            ORDER BY id DESC
            LIMIT 1
        """
        result = self.execute_query(query, (company_id,))
        return result[0]['return_no'] if result else None

    # Bank account methods
    
    def get_bank_accounts_by_company(self, company_id: int) -> List[Dict[str, Any]]:
        """Get all bank accounts for a specific company, ordered by account name."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, company_id, account_name, bank_name, account_number, ifsc_code,
                   branch_name, opening_balance, notes, created_at, updated_at
            FROM bank_accounts
            WHERE company_id = {ph}
            ORDER BY account_name
        """
        return self.execute_query(query, (company_id,))
    
    def get_bank_account_by_id(self, company_id: int, bank_account_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific bank account by ID for a company."""
        ph = self._get_placeholder()
        query = f"""
            SELECT id, company_id, account_name, bank_name, account_number, ifsc_code,
                   branch_name, opening_balance, notes, created_at, updated_at
            FROM bank_accounts
            WHERE company_id = {ph} AND id = {ph}
        """
        result = self.execute_query(query, (company_id, bank_account_id))
        return result[0] if result else None
    
    def create_bank_account(self, company_id: int, bank_account_data: Dict[str, Any]) -> bool:
        """Insert a new bank account for a company."""
        ph = self._get_placeholder()
        query = f"""
            INSERT INTO bank_accounts (
                company_id, account_name, bank_name, account_number, ifsc_code,
                branch_name, opening_balance, notes
            ) VALUES ({ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph}, {ph})
        """
        params = (
            company_id,
            bank_account_data.get('account_name'),
            bank_account_data.get('bank_name'),
            bank_account_data.get('account_number'),
            bank_account_data.get('ifsc_code'),
            bank_account_data.get('branch_name'),
            bank_account_data.get('opening_balance', 0.0),
            bank_account_data.get('notes')
        )
        return self.execute_update(query, params)
    
    def update_bank_account(self, company_id: int, bank_account_id: int, bank_account_data: Dict[str, Any]) -> bool:
        """Update an existing bank account for a company."""
        ph = self._get_placeholder()
        query = f"""
            UPDATE bank_accounts
            SET account_name = {ph},
                bank_name = {ph},
                account_number = {ph},
                ifsc_code = {ph},
                branch_name = {ph},
                opening_balance = {ph},
                notes = {ph},
                updated_at = CURRENT_TIMESTAMP
            WHERE id = {ph} AND company_id = {ph}
        """
        params = (
            bank_account_data.get('account_name'),
            bank_account_data.get('bank_name'),
            bank_account_data.get('account_number'),
            bank_account_data.get('ifsc_code'),
            bank_account_data.get('branch_name'),
            bank_account_data.get('opening_balance', 0.0),
            bank_account_data.get('notes'),
            bank_account_id,
            company_id
        )
        return self.execute_update(query, params)
    
    def delete_bank_account(self, company_id: int, bank_account_id: int) -> bool:
        """Delete a bank account for a company."""
        ph = self._get_placeholder()
        query = f"DELETE FROM bank_accounts WHERE id = {ph} AND company_id = {ph}"
        return self.execute_update(query, (bank_account_id, company_id))
    
    def bank_account_name_exists(self, company_id: int, account_name: str, exclude_bank_account_id: Optional[int] = None) -> bool:
        """Check if a bank account name exists for a company (excluding a specific account if editing)."""
        ph = self._get_placeholder()
        if exclude_bank_account_id:
            query = f"SELECT id FROM bank_accounts WHERE account_name = {ph} AND company_id = {ph} AND id != {ph}"
            result = self.execute_query(query, (account_name, company_id, exclude_bank_account_id))
        else:
            query = f"SELECT id FROM bank_accounts WHERE account_name = {ph} AND company_id = {ph}"
            result = self.execute_query(query, (account_name, company_id))
        return len(result) > 0
